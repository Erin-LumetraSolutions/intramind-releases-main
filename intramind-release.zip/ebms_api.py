"""EBMS write client for v3 Phase 4 (ClickUp 86e3q4zc9, PO 86e3q4ze6).

Spec section 11: IntraMind NEVER writes to EBMS with SQL. Every write goes through the Koble
EBMS API Gateway (OData v4, HTTP Basic auth), so EBMS's own validation, security and scripts
run. Research and live read-only verification: docs/design/ebms-api-gateway-research.md
(sections C2, D, F, K) and the CSDL in docs/design/ebms-api-metadata.xml.

Three implementations of one small interface:
  FakeEbmsWriteClient   in-memory, deterministic PO numbers. Used by the tests and, with
                        EBMS_LIVE_API_FAKE=1, for local demos. Never touches the network.
  ODataEbmsWriteClient  the real gateway. The PO create / read / delete calls use exactly the
                        shapes proven live on the owner's test gateway on 2026-10-14 (research
                        K.2 rows 1, 1b and 3). Still unproven there: that DELETE is refused for a
                        processed document (so the server always GETs STATUS first and refuses
                        Undo unless it is 'U'), and behaviour for a security-restricted EBMS user.
  get_write_client()    picks Fake / OData / None (writes not configured).
Sales orders (ARINV, 86e3q4ze8) use the shapes proven live in K.2 rows 4-6. New customers /
vendors / parts created inside a draft go through create_record / delete_record (INVENTRY
proven, K.2 rows 7-8; ARCUST / APVENDOR pending research K.5).

Safety rules built into every outgoing body (research C1/C2, Recommended approach 2 and 4):
  - PROCESS, Payments, ACTION, STATUS and SHIP_VIS are stripped from every body, at every
    nesting level. A stray PROCESS:"Process" would post the document to the GL; a Payment would
    record a cheque. Tests assert this.
  - TO_B_SENT is forced to false: a draft must never email a vendor.
  - EXTERNALID = "INTRAMIND-" + the draft's EBMS idempotency key (max 50 chars). Before every
    create, GET by EXTERNALID and return the existing document if found; after a POST timeout,
    GET again instead of retrying blindly.
  - After create, the document must read back STATUS 'U' (unprocessed); otherwise the client
    raises EbmsUnexpectedState: it logs loudly and the draft is marked failed.
  - Only the header/line fields proven live are sent (K.2 row 1): ID, MEMO, EXTERNALID,
    TO_B_SENT, Details[INVEN, O_QUAN_VIS, UNIT_VIS]. EBMS fills ORDER_DATE (today), PO_NO /
    INVOICE ("PO#<PO_NO>"), terms, address and warehouse from the vendor itself.

AUTH: EVERY CALL RUNS AS THE SIGNED-IN USER (owner decision, Marc, 2026-10-14)
  Data entry is a Premium feature and there is NO shared service account. Each method takes an
  EbmsAuth (the IntraMind user's own EBMS username + password, which server.py keeps in memory
  for that session only) and sends it as HTTP Basic on that one request. The shared httpx.Client
  carries no credentials. EBMS is the authority on what the user may do: a 401 raises
  EbmsAuthFailed (password changed in EBMS), a 403 or a security refusal raises EbmsForbidden.
  Configuration: EBMS_LIVE_API_URL (the OData root, https) and EBMS_LIVE_API_DATASET (the one
  schema that URL's EBMS company belongs to). Passwords are never logged, never put in an
  exception message or repr, and never written to the audit log.

  Resolved 2026-10-14 (research gap J6 / question 6): EBMS's APIREQUEST log does not store the
  password (confirmed by Marc), so per-user Basic auth doesn't leave credentials on the EBMS
  server or in the mirror.
"""

from __future__ import annotations

import logging
import os
import json
import random
import threading
import time

import http.cookiejar

import httpx  # installed with the anthropic SDK (not pinned in requirements_live.txt)

log = logging.getLogger("ebms_live.ebms_api")

EXTERNALID_PREFIX = "INTRAMIND-"
EXTERNALID_MAX = 50
# Never sent, at any level of a body (research C1/C2/D).
FORBIDDEN_BODY_KEYS = frozenset({"PROCESS", "Payments", "ACTION", "STATUS", "SHIP_VIS",
                                 "M_SHIP_VIS", "TOTAL_PAID"})
DEFAULT_TIMEOUT_SECONDS = 55.0  # under EBMS's own 60 s limit (research A)
MAX_RETRIES = 2                 # GET/DELETE only, on 5xx / timeouts / connection errors
BACKOFF_CAP_SECONDS = 8.0
BACKOFF_JITTER_SECONDS = 0.25


def _backoff(i: int) -> float:
    """Sleep before retry attempt i (1-based), without jitter."""
    return min(BACKOFF_CAP_SECONDS, 0.5 * (2 ** (i - 1)))


def max_retried_call_seconds(timeout: float = DEFAULT_TIMEOUT_SECONDS) -> float:
    """Worst case for one retried GET/DELETE: every attempt times out, plus every backoff."""
    return ((1 + MAX_RETRIES) * timeout
            + sum(_backoff(i) + BACKOFF_JITTER_SECONDS for i in range(1, MAX_RETRIES + 1)))


def max_create_seconds(timeout: float = DEFAULT_TIMEOUT_SECONDS) -> float:
    """Worst case for create_purchase_order: EXTERNALID lookup, one POST, lookup again.
    drafts_store.STALE_SAVING_SECONDS must stay well above this (86e3q4zc9 review #4)."""
    return 2 * max_retried_call_seconds(timeout) + timeout


# ---------------------------------------------------------------------------
# Errors. str(e) is for logs; .user_message is safe to show (never raw HTTP/EBMS text).
# ---------------------------------------------------------------------------

class EbmsApiError(Exception):
    user_message = "EBMS didn't accept the request. Nothing was changed."

    def __init__(self, message: str, *, status: int | None = None, request_id=None,
                 response_id=None, user_message: str | None = None, doc_number: str | None = None):
        super().__init__(message)
        self.status = status
        self.doc_number = doc_number
        self.request_id = request_id
        self.response_id = response_id
        if user_message:
            self.user_message = user_message


class EbmsRejected(EbmsApiError):
    """EBMS answered and refused (4xx). Nothing was created or deleted."""
    user_message = "EBMS rejected the document. Nothing was saved."


class EbmsUnavailable(EbmsApiError):
    """Timeout, connection failure or 5xx. The outcome of a write may be unknown; a retry with
    the same idempotency key looks the document up before creating anything."""
    user_message = "Couldn't reach EBMS. Nothing was saved yet; try again in a moment."


class EbmsNotFound(EbmsApiError):
    user_message = "That document is no longer in EBMS."


class EbmsUnexpectedState(EbmsApiError):
    """The document exists but not in the state we required (e.g. not STATUS 'U')."""
    user_message = "EBMS saved the document in an unexpected state. Check it in EBMS."


def _no_cookie_jar() -> http.cookiejar.CookieJar:
    """A cookie jar that never stores anything (empty allowed_domains blocks every domain)."""
    return http.cookiejar.CookieJar(policy=http.cookiejar.DefaultCookiePolicy(allowed_domains=[]))


class EbmsAuth:
    """One user's EBMS login for one call. repr/str never show the password."""

    __slots__ = ("username", "_password")

    def __init__(self, username: str, password: str):
        self.username = (username or "").strip()
        self._password = password or ""

    def __repr__(self):
        return f"EbmsAuth({self.username!r})"

    __str__ = __repr__

    def httpx_auth(self):
        return httpx.BasicAuth(self.username, self._password)


class EbmsAuthFailed(EbmsApiError):
    """HTTP 401: EBMS didn't accept this user's password (changed in EBMS since sign-in)."""
    user_message = "Your EBMS password seems to have changed. Sign out and back in, then try again."


class EbmsForbidden(EbmsApiError):
    """HTTP 403, or a 400 whose EBMS message is a security refusal, for this user."""


_SECURITY_WORDS = ("security", "permission", "not allowed", "access denied", "not authorized",
                   "unauthorized", "no access", "rights")


def _brief(resp) -> str:
    """EBMS's own BriefDescription, flattened to one short line (shown to the user only for
    security refusals, per owner decision; never echoes headers or credentials)."""
    try:
        for m in (resp.json().get("Messages") or []):
            text = str(m.get("BriefDescription") or m.get("TextBriefDescription") or "").strip()
            if text:
                text = " ".join(text.split())
                return text[:200]
    except Exception:
        pass
    return ""


def _is_security_refusal(resp) -> bool:
    try:
        for m in (resp.json().get("Messages") or []):
            blob = " ".join(str(m.get(k) or "") for k in ("Id", "BriefDescription", "Detail")).lower()
            if any(w in blob for w in _SECURITY_WORDS):
                return True
    except Exception:
        pass
    return False


def forbidden_message(username: str, brief: str) -> str:
    msg = f"EBMS didn't allow this for your user ({username})"
    return f"{msg}: {brief}" if brief else f"{msg}."


def external_id(idempotency_key: str) -> str:
    return (EXTERNALID_PREFIX + str(idempotency_key))[:EXTERNALID_MAX]


def sanitize_body(value, *, allow_in_details: frozenset = frozenset(), _in_details: bool = False):
    """Return a copy of a request body with every forbidden key removed at every level.
    allow_in_details lets a document type keep a key that is otherwise forbidden, ONLY inside
    the lines of its top-level "Details" list (bills: SHIP_VIS, the invoiced quantity)."""
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            if k in FORBIDDEN_BODY_KEYS and not (_in_details and k in allow_in_details):
                continue
            out[k] = sanitize_body(v, allow_in_details=allow_in_details, _in_details=False) \
                if k != "Details" else [sanitize_body(x, allow_in_details=allow_in_details, _in_details=True)
                                        for x in (v if isinstance(v, list) else [])]
        return out
    if isinstance(value, list):
        return [sanitize_body(v, allow_in_details=allow_in_details) for v in value]
    return value


def build_po_body(header: dict, lines: list[dict], idempotency_key: str) -> dict:
    """APINV POST body for an unprocessed PO (research K.3 step 1).
    header: {vendor, memo?} (other keys are ignored)
    lines:  [{item, qty, cost}]"""
    body = {
        "ID": str(header["vendor"]).strip(),
        "EXTERNALID": external_id(idempotency_key),
        "TO_B_SENT": False,
        "Details": [],
    }
    memo = (header.get("memo") or "").strip()
    if memo:
        body["MEMO"] = memo
    # ORDER_DATE is left to EBMS (DateDefaultedToday). The suggested expected date is shown on
    # the card only: ORDER_ETA / ETA_DATE were not part of the proven body (research K.2), so
    # they are not sent until tested.
    for ln in lines:
        det = {"INVEN": str(ln["item"]).strip(), "O_QUAN_VIS": _num(ln["qty"])}
        if ln.get("cost") is not None:
            det["UNIT_VIS"] = round(float(ln["cost"]), 4)
        body["Details"].append(det)
    body = sanitize_body(body)
    body["TO_B_SENT"] = False
    return body


def _num(x):
    f = float(x)
    return int(f) if f.is_integer() else f


# ---------------------------------------------------------------------------
# Vendor bills (86e3q4zeb). NOT LIVE-PROVEN: the body below follows Koble's own "Creating a new
# Purchase Document" sample (research I) minus Payments/PROCESS, and the APINV/APINVDET
# properties in docs/design/ebms-api-metadata.xml. The exact live tests to run before any
# customer uses it are in docs/design/ebms-api-gateway-research.md section K.4.
# ---------------------------------------------------------------------------

BILL_INVOICE_MAX = 15        # APINV.INVOICE MaxLength (research K.1)
BILL_MEMO_MAX = 1000
BILL_DESCR_MAX = 60          # APINVDET.DESCR: kept short (a non-inventory line's description)
BILL_ACCOUNT_MAX = 20
# Allowed keys, per level. Anything else is dropped before sending (allow-list, research rec. 4).
BILL_HEADER_KEYS = frozenset({"ID", "INVOICE", "INV_DATE", "MEMO", "EXTERNALID", "TO_B_SENT",
                              "FREIGHT", "Details"})
BILL_LINE_KEYS = frozenset({"INVEN", "DESCR", "O_QUAN_VIS", "SHIP_VIS", "UNIT_VIS", "ACCOUNT"})
# SHIP_VIS is forbidden everywhere else (a PO has received nothing). On a bill it is the
# invoiced/received quantity: EBMS bills the received quantity when the document is processed,
# so without it the unprocessed bill's amounts would not match the vendor's document.
BILL_DETAIL_ALLOWED = frozenset({"SHIP_VIS"})


def _money(x) -> float:
    return round(float(x), 2)


def build_bill_body(header: dict, lines: list[dict], idempotency_key: str) -> dict:
    """APINV POST body for an UNPROCESSED vendor bill (research C3), live-proven 2026-10-14
    (research K.4 results): INVOICE is kept, PO_NO is auto-assigned, STATUS 'U'. Tax and the
    document total are NOT sent: EBMS recalculates tax itself (sent 24.92, EBMS 25.57) and
    TOP_TOTAL follows its computed TOTAL, so sending them only creates a false mismatch. The
    caller compares EBMS's TOTAL with the PDF total after saving instead.
    header: {vendor, invoice, inv_date (YYYY-MM-DD), memo?, freight?, tax?, total?}
    lines:  [{item?, description?, qty, cost, account?}]  item = INVENTRY ID for a part line;
            no item = a non-inventory line, which needs account (GL).
    Each line sends O_QUAN_VIS (ordered) and SHIP_VIS (invoiced) as the same billed quantity
    and UNIT_VIS as the billed unit cost, so the amounts EBMS shows match the PDF."""
    invoice = str(header.get("invoice") or "").strip()
    if not invoice:
        raise ValueError("A bill needs the vendor's invoice number.")
    if len(invoice) > BILL_INVOICE_MAX:
        raise ValueError(f"Invoice number is longer than EBMS allows ({BILL_INVOICE_MAX} characters).")
    body = {
        "ID": str(header["vendor"]).strip(),
        "INVOICE": invoice,
        "EXTERNALID": external_id(idempotency_key),
        "TO_B_SENT": False,
        "Details": [],
    }
    if header.get("inv_date"):
        body["INV_DATE"] = str(header["inv_date"])[:10]
    memo = (header.get("memo") or "").strip()
    if memo:
        body["MEMO"] = memo[:BILL_MEMO_MAX]
    if header.get("freight") is not None:
        body["FREIGHT"] = _money(header["freight"])
    for ln in lines:
        qty = _num(ln["qty"])
        det = {"O_QUAN_VIS": qty, "SHIP_VIS": qty, "UNIT_VIS": round(float(ln["cost"]), 4)}
        item = str(ln.get("item") or "").strip()
        if item:
            det["INVEN"] = item
        else:
            account = str(ln.get("account") or "").strip()
            if not account:
                raise ValueError("A non-inventory bill line needs a GL account.")
            det["ACCOUNT"] = account[:BILL_ACCOUNT_MAX]
            descr = " ".join(str(ln.get("description") or "").split())[:BILL_DESCR_MAX]
            if descr:
                det["DESCR"] = descr
        body["Details"].append({k: v for k, v in det.items() if k in BILL_LINE_KEYS})
    body = {k: v for k, v in body.items() if k in BILL_HEADER_KEYS}
    body = sanitize_body(body, allow_in_details=BILL_DETAIL_ALLOWED)
    body["TO_B_SENT"] = False
    return body


# ---------------------------------------------------------------------------
# Receiving an open PO as the vendor's bill (86e3q4zeb "match to PO"). NOT LIVE-PROVEN: the
# shapes follow the proven PO edit (research K.2 row 2: PATCH APINV('<AUTOID>') with
# Details@delta, "@id" to edit a line) and the gateway's documented "@removed" / no-"@id" add.
# Live-proven in research K.6 (2026-10-14); on unless EBMS_LIVE_BILL_PO_MATCH=0, and each user
# can turn it off in Settings. PROCESS / Payments / STATUS are never sent.
# ---------------------------------------------------------------------------

PO_RECEIVE_HEADER_KEYS = frozenset({"INVOICE", "INV_DATE", "FREIGHT", "Details@delta"})
PO_RECEIVE_LINE_KEYS = frozenset({"@id", "@removed", "INVEN", "DESCR", "O_QUAN_VIS", "SHIP_VIS",
                                  "UNIT_VIS", "ACCOUNT"})


def _check_receive_body(body: dict) -> dict:
    """Allow-list both levels; nothing forbidden at the header (SHIP_VIS lives only in lines)."""
    out = {k: v for k, v in body.items() if k in PO_RECEIVE_HEADER_KEYS}
    out["Details@delta"] = [{k: v for k, v in ln.items() if k in PO_RECEIVE_LINE_KEYS}
                            for ln in out.get("Details@delta") or []]
    assert not (set(out) & FORBIDDEN_BODY_KEYS)
    return out


def _bill_line_detail(ln: dict) -> dict:
    """A bill line added to the PO: the same shape as a bill create line (build_bill_body)."""
    qty = _num(ln["qty"])
    det = {"O_QUAN_VIS": qty, "SHIP_VIS": qty, "UNIT_VIS": round(float(ln["cost"]), 4)}
    item = str(ln.get("item") or "").strip()
    if item:
        det["INVEN"] = item
    else:
        account = str(ln.get("account") or "").strip()
        if not account:
            raise ValueError("A non-inventory bill line needs a GL account.")
        det["ACCOUNT"] = account[:BILL_ACCOUNT_MAX]
        descr = " ".join(str(ln.get("description") or "").split())[:BILL_DESCR_MAX]
        if descr:
            det["DESCR"] = descr
    return det


def build_po_receive_body(header: dict, matched: list[dict], added: list[dict]) -> dict:
    """PATCH APINV('<PO AUTOID>') body that turns the PO into the vendor's bill.
    header:  {invoice, inv_date?, freight?}
    matched: [{line_id, qty, cost}]  PO lines the bill covers: SHIP_VIS = billed qty, UNIT_VIS = billed cost
    added:   bill lines not on the PO, as build_bill_body lines (added without "@id")
    PO lines not listed are left untouched."""
    invoice = str(header.get("invoice") or "").strip()
    if not invoice:
        raise ValueError("A bill needs the vendor's invoice number.")
    if len(invoice) > BILL_INVOICE_MAX:
        raise ValueError(f"Invoice number is longer than EBMS allows ({BILL_INVOICE_MAX} characters).")
    body = {"INVOICE": invoice, "Details@delta": []}
    if header.get("inv_date"):
        body["INV_DATE"] = str(header["inv_date"])[:10]
    if header.get("freight") is not None:
        body["FREIGHT"] = _money(header["freight"])
    for m in matched:
        if not m.get("line_id"):
            raise ValueError("a matched PO line needs its AUTOID")
        body["Details@delta"].append({"@id": str(m["line_id"]), "SHIP_VIS": _num(m["qty"]),
                                      "UNIT_VIS": round(float(m["cost"]), 4)})
    for ln in added:
        body["Details@delta"].append(_bill_line_detail(ln))
    return _check_receive_body(body)


def build_po_restore_body(snapshot: dict, added_line_ids: list[str]) -> dict:
    """PATCH body that puts a received PO back the way the snapshot (taken before the receive)
    had it: INVOICE ("PO#<PO_NO>"), INV_DATE, FREIGHT, each touched line's SHIP_VIS / UNIT_VIS,
    and the lines the bill added removed ("@removed")."""
    body = {"INVOICE": str(snapshot.get("invoice") or "").strip(), "Details@delta": []}
    if not body["INVOICE"]:
        raise ValueError("snapshot has no INVOICE")
    if snapshot.get("inv_date"):
        body["INV_DATE"] = str(snapshot["inv_date"])[:10]
    if snapshot.get("freight") is not None:
        body["FREIGHT"] = _money(snapshot["freight"])
    for ln in snapshot.get("lines") or []:
        if ln.get("touched"):
            body["Details@delta"].append({"@id": str(ln["line_id"]), "SHIP_VIS": _num(ln.get("ship") or 0),
                                          "UNIT_VIS": round(float(ln.get("unit") or 0), 4)})
    for lid in added_line_ids:
        body["Details@delta"].append({"@id": str(lid), "@removed": {"reason": "deleted"}})
    return _check_receive_body(body)


ATTACH_NAME_MAX = 100


def safe_attachment_name(name: str, content_type: str) -> str:
    """A file name EBMS's document storage can take: letters, digits, space, - _ . only, the
    right extension for the sniffed type, never a path."""
    ext = {"application/pdf": ".pdf", "image/png": ".png", "image/jpeg": ".jpg",
           "image/webp": ".webp"}.get(content_type, ".bin")
    base = str(name or "").replace("\\", "/").rsplit("/", 1)[-1]
    if "." in base:
        base = base.rsplit(".", 1)[0]
    base = "".join(c for c in base if c.isalnum() or c in " -_").strip(" .") or "bill"
    return base[:ATTACH_NAME_MAX - len(ext)] + ext


def build_attachment_body(filename: str, content_type: str, data: bytes) -> dict:
    """DirectoryFolder(...)/Model.Entities.Upload body (research G, Koble "Uploading files")."""
    import base64
    return {"FileName": safe_attachment_name(filename, content_type),
            "File": {"Value": base64.b64encode(bytes(data)).decode("ascii")}}


def attachment_folder(doc_id: str) -> str:
    """'APINV[<AUTOID>]': the entity name and AUTOID, as Koble's upload sample addresses ARCUST."""
    aid = str(doc_id or "").strip()
    if not aid or not aid.isalnum():
        raise ValueError("bad AUTOID for an attachment folder")
    return f"APINV[{aid}]"


# ---------------------------------------------------------------------------
# Sales orders (86e3q4ze8). Proven live 2026-10-14 (research K.2 rows 4-6): POST /ARINV with
# ID + Details[INVEN, M_QUAN_VIS, M_SHIP_VIS 0] and no PROCESS / Payments -> 200, INVOICE
# auto-numbered, STATUS 'U'. EBMS prices the lines from the customer's price level and taxes
# them; TOTAL is 0 on an order (it follows the shipped qty), TOTAL_SO is the order total.
# ---------------------------------------------------------------------------

SO_PO_MAX = 20               # ARINV.PO_NO length
SO_DESCR_MAX = 50            # ARINV.DESCR length
SO_MEMO_MAX = 1000
SO_HEADER_KEYS = frozenset({"ID", "PO_NO", "DESCR", "MEMO", "EXTERNALID", "TO_B_SENT", "Details"})
SO_LINE_KEYS = frozenset({"INVEN", "M_QUAN_VIS", "M_SHIP_VIS", "UNIT"})
# M_SHIP_VIS is forbidden everywhere else (shipped = pulled from stock). A sales order line
# carries it ONLY as 0, set by this builder after sanitising (K.2 row 4 sent exactly that).
SO_DETAIL_ALLOWED = frozenset({"M_SHIP_VIS"})


def build_so_body(header: dict, lines: list[dict], idempotency_key: str) -> dict:
    """ARINV POST body for an UNPROCESSED sales order.
    header: {customer, po_no?, descr?, memo?}
    lines:  [{item, qty, price?}]  price only when the user overrode EBMS's price (UNIT);
            otherwise EBMS applies the customer's price level."""
    body = {"ID": str(header["customer"]).strip(), "EXTERNALID": external_id(idempotency_key),
            "TO_B_SENT": False, "Details": []}
    po = str(header.get("po_no") or "").strip()
    if po:
        if len(po) > SO_PO_MAX:
            raise ValueError(f"Customer PO # is longer than EBMS allows ({SO_PO_MAX} characters).")
        body["PO_NO"] = po
    descr = " ".join(str(header.get("descr") or "").split())[:SO_DESCR_MAX]
    if descr:
        body["DESCR"] = descr
    memo = (header.get("memo") or "").strip()
    if memo:
        body["MEMO"] = memo[:SO_MEMO_MAX]
    for ln in lines:
        det = {"INVEN": str(ln["item"]).strip(), "M_QUAN_VIS": _num(ln["qty"])}
        if ln.get("price") is not None:
            det["UNIT"] = round(float(ln["price"]), 4)
        body["Details"].append({k: v for k, v in det.items() if k in SO_LINE_KEYS})
    body = {k: v for k, v in body.items() if k in SO_HEADER_KEYS}
    body = sanitize_body(body, allow_in_details=SO_DETAIL_ALLOWED)
    for det in body["Details"]:
        det["M_SHIP_VIS"] = 0     # an order ships nothing: never pull stock from IntraMind
    body["TO_B_SENT"] = False
    return body


# ---------------------------------------------------------------------------
# New master records inside a draft (86e3q4ze8): customer (ARCUST), vendor (APVENDOR), part
# (INVENTRY). INVENTRY create + delete is proven live (K.2 rows 7-8, PRI_VENDOR must be sent
# explicitly). ARCUST and APVENDOR bodies are NOT live-proven: research K.5 holds the exact
# test bodies for the owner to approve. Keys are allow-listed against the gateway metadata
# (tests/test_ebms_api.py parses docs/design/ebms-api-metadata.xml). APVENDOR exposes no
# phone, email or terms property there, so those are never sent for a vendor.
# ---------------------------------------------------------------------------

RECORD_ENTITIES = {"customer": "ARCUST", "vendor": "APVENDOR", "part": "INVENTRY"}
RECORD_KEYS = {
    # TREE_ID required (K.5); PHONE/EMAIL dropped: refused on companies without contact fields
    "ARCUST": frozenset({"ID", "TREE_ID", "L_NAME", "ADDRESS1", "ADDRESS2", "CITY", "STATE", "ZIP",
                         "IDCHARGE", "IN_LEVEL", "EXTERNALID"}),
    "APVENDOR": frozenset({"ID", "TREE_ID", "L_NAME", "ADDRESS1", "ADDRESS2", "CITY", "STATE", "ZIP",
                           "EXTERNALID"}),
    "INVENTRY": frozenset({"ID", "TREE_ID", "DESCR_1", "COST", "BASE", "PRI_VENDOR", "DEF_UNIT",
                           "C_TYPE", "EXTERNALID", "INVENDORs"}),
}
PART_VENDOR_KEYS = frozenset({"VENDOR_ID", "COST"})
_RECORD_MAP = {
    # Live test 2026-10-14 (research K.5 results): customers and vendors need a folder
    # (TREE_ID: EBMS takes their defaults from it, else "Could not find customer defaults"),
    # and PHONE/EMAIL are refused (403) on a company without writable contact fields, so they
    # are not sent.
    "customer": (("id", "ID"), ("folder", "TREE_ID"), ("name", "L_NAME"), ("address1", "ADDRESS1"),
                 ("address2", "ADDRESS2"), ("city", "CITY"), ("state", "STATE"), ("zip", "ZIP"),
                 ("terms", "IDCHARGE"), ("price_level", "IN_LEVEL")),
    "vendor": (("id", "ID"), ("folder", "TREE_ID"), ("name", "L_NAME"), ("address1", "ADDRESS1"),
               ("address2", "ADDRESS2"), ("city", "CITY"), ("state", "STATE"), ("zip", "ZIP")),
    "part": (("id", "ID"), ("folder", "TREE_ID"), ("description", "DESCR_1"), ("vendor", "PRI_VENDOR"),
             ("unit", "DEF_UNIT")),
}


def record_external_id(idempotency_key: str, tag: str) -> str:
    """EXTERNALID for a record a draft creates: the save's key plus a per-record tag, <= 50."""
    tag = "".join(c for c in str(tag) if c.isalnum())[:8] or "R"
    return (EXTERNALID_PREFIX + str(idempotency_key))[:EXTERNALID_MAX - len(tag) - 1] + "-" + tag


def build_record_body(kind: str, rec: dict, ext: str) -> dict:
    """POST body for a new customer / vendor / part from the draft's validated "new" block."""
    entity = RECORD_ENTITIES[kind]
    body = {"EXTERNALID": ext}
    for src, dst in _RECORD_MAP[kind]:
        v = " ".join(str(rec.get(src) or "").split())
        if v:
            body[dst] = v
    if not body.get("ID"):
        raise ValueError("A new record needs an ID.")
    if not body.get("TREE_ID"):
        raise ValueError(f"A new {kind} needs a folder.")
    body["TREE_ID"] = str(rec.get("folder"))   # folder IDs are space-padded ("    5"): keep as read
    if kind == "part":
        for src, dst in (("cost", "COST"), ("price", "BASE")):
            if rec.get(src) not in (None, ""):
                body[dst] = round(float(rec[src]), 2)
        # Count type is sent only when the user picked one; otherwise EBMS copies the folder's
        # (live test 2026-10-15, research K.7: C_TYPE from the folder, and an override sticks).
        ct = str(rec.get("count_type") or "").strip()
        if ct.isdigit():
            body["C_TYPE"] = int(ct)
        if body.get("PRI_VENDOR"):
            row = {"VENDOR_ID": body["PRI_VENDOR"]}
            if body.get("COST") is not None:
                row["COST"] = body["COST"]
            body["INVENDORs"] = [{k: v for k, v in row.items() if k in PART_VENDOR_KEYS}]
    body = {k: v for k, v in body.items() if k in RECORD_KEYS[entity]}
    return sanitize_body(body)


# ---------------------------------------------------------------------------
# Part updates (part import, 86e3q4zek; live-proven research K.8)
# ---------------------------------------------------------------------------
# A price level's PRICE is calculated from its formula and refused directly (403 "the record is
# not new"); INVPRICE can't be PATCHed on its own (422 "without accessing it through a parent").
# A fixed level price is the formula "Is $x" (MARKUP_ID 4IS), sent through the part:
#   PATCH INVENTRY('<AUTOID>') {"INVPRICEs@delta": [{"@id": "<INVPRICE AUTOID>", "MARKUP_ID": "4IS",
#                                                    "MARKUP": "Is $90.00"}]}
# Restoring the old formula (MARKUP_ID + MARKUP) is the Undo (K.8 row 6).

FIXED_PRICE_FORMULA = "4IS"


def level_markup(price: float) -> str:
    return f"Is ${float(price):.2f}"


def part_snapshot(row: dict) -> dict:
    """GET INVENTRY ... $expand=INVPRICEs -> {doc_id, id, base, cost, levels: {LEVEL: {doc_id,
    markup_id, markup, price}}} (LEVEL upper case)."""
    levels = {}
    for lv in row.get("INVPRICEs") or []:
        name = str(lv.get("LEVEL") or "").strip()
        if name:
            levels[name.upper()] = {"doc_id": lv.get("AUTOID"), "level": name,
                                    "markup_id": str(lv.get("MARKUP_ID") or "").strip(),
                                    "markup": str(lv.get("MARKUP") or "").strip(),
                                    "price": None if lv.get("PRICE") is None else round(float(lv["PRICE"]), 2)}
    return {"doc_id": row.get("AUTOID"), "id": str(row.get("ID") or "").strip(),
            "base": None if row.get("BASE") is None else round(float(row["BASE"]), 2),
            "cost": None if row.get("COST") is None else round(float(row["COST"]), 2), "levels": levels}


def build_part_update(snap: dict, sets: dict) -> tuple[dict, dict, dict]:
    """(PATCH body, before, after) for one part. sets: {"base"?, "cost"?, "level:<LEVEL>"?: price}.
    before/after hold exactly what is needed to undo / to recognise our own write later.
    ValueError when a level row isn't on the part."""
    body, before, after, deltas = {}, {}, {}, []
    for key, value in sets.items():
        v = round(float(value), 2)
        if key in ("base", "cost"):
            body[key.upper()] = v
            before[key] = snap.get(key)
            after[key] = v
            continue
        level = key.split(":", 1)[1]
        row = (snap.get("levels") or {}).get(level.upper())
        if not row or not row.get("doc_id"):
            raise ValueError(f"no {level} price row")
        deltas.append({"@id": str(row["doc_id"]), "MARKUP_ID": FIXED_PRICE_FORMULA, "MARKUP": level_markup(v)})
        before[key] = {"doc_id": row["doc_id"], "markup_id": row["markup_id"], "markup": row["markup"],
                       "price": row["price"]}
        after[key] = {"doc_id": row["doc_id"], "markup_id": FIXED_PRICE_FORMULA, "markup": level_markup(v), "price": v}
    if deltas:
        body["INVPRICEs@delta"] = deltas
    return body, before, after


def build_part_restore(snap: dict, before: dict, after: dict) -> tuple[dict, list[str]]:
    """(PATCH body putting `before` back, keys skipped because EBMS no longer has our `after`
    value: someone changed it since, and that newer value is kept)."""
    body, deltas, skipped = {}, [], []
    for key, old in before.items():
        if key in ("base", "cost"):
            if snap.get(key) is None or after.get(key) is None or abs(float(snap[key]) - float(after[key])) > 0.005:
                skipped.append(key)
                continue
            if old is not None:
                body[key.upper()] = old
            continue
        level = key.split(":", 1)[1]
        row = (snap.get("levels") or {}).get(level.upper())
        mine = after.get(key) or {}
        if not row or (row.get("markup_id") or "").upper() != (mine.get("markup_id") or "").upper() \
                or (row.get("markup") or "") != (mine.get("markup") or ""):
            skipped.append(key)
            continue
        deltas.append({"@id": str(row["doc_id"]), "MARKUP_ID": old.get("markup_id") or "",
                       "MARKUP": old.get("markup") or ""})
    if deltas:
        body["INVPRICEs@delta"] = deltas
    return body, skipped


# ---------------------------------------------------------------------------
# Interface
# ---------------------------------------------------------------------------

class EbmsWriteClient:
    """What the server needs from EBMS. Every method raises EbmsApiError subclasses."""

    name = "abstract"

    def create_purchase_order(self, header: dict, lines: list[dict], idempotency_key: str, *,
                              auth: EbmsAuth) -> dict:
        """Create an UNPROCESSED PO, as auth.username. Returns {doc_number, doc_id, request_id, response_id,
        existing: bool}. Same idempotency_key -> the same document, never a second one."""
        raise NotImplementedError

    def get_purchase_order(self, doc_number: str, *, doc_id: str | None = None, auth: EbmsAuth) -> dict:
        """Returns {doc_number, doc_id, status, processed: bool, paid: float}. Raises
        EbmsNotFound. (APINV has no IsLocked property in the gateway metadata; a document open in
        EBMS shows up as a refused DELETE instead.)"""
        raise NotImplementedError

    def find_purchase_order(self, idempotency_key: str, *, auth: EbmsAuth) -> dict | None:
        """The document created with this idempotency key (EXTERNALID), as get_purchase_order
        returns it, or None. Never creates anything."""
        raise NotImplementedError

    def delete_purchase_order(self, doc_number: str, *, doc_id: str | None = None, auth: EbmsAuth) -> dict:
        """Delete an unprocessed PO. Returns {request_id, response_id}. Callers must have
        checked get_purchase_order(...)["processed"] is False first."""
        raise NotImplementedError

    # ---- vendor bills (86e3q4zeb; request shapes NOT live-proven, research K.4)

    def create_bill(self, header: dict, lines: list[dict], idempotency_key: str, *, auth: EbmsAuth) -> dict:
        """Create an UNPROCESSED vendor bill (an APINV, STATUS 'U'), as auth.username. Returns
        {doc_number (the vendor's invoice #), po_number, doc_id, request_id, response_id,
        existing}. Same idempotency_key -> the same document."""
        raise NotImplementedError

    def find_bill(self, idempotency_key: str, *, auth: EbmsAuth) -> dict | None:
        raise NotImplementedError

    def get_bill(self, doc_id: str, *, auth: EbmsAuth) -> dict:
        """{doc_number, doc_id, status, processed, paid} by AUTOID. Raises EbmsNotFound."""
        raise NotImplementedError

    def delete_bill(self, doc_id: str, *, auth: EbmsAuth) -> dict:
        raise NotImplementedError

    def attach_document(self, doc_id: str, filename: str, content_type: str, data: bytes, *,
                        auth: EbmsAuth) -> dict:
        """Upload a file into the document's EBMS document storage folder. A separate call after
        create: a failure leaves the bill saved. Returns {request_id, file_name}."""
        raise NotImplementedError

    def get_po_detail(self, doc_id: str, *, auth: EbmsAuth) -> dict:
        """An APINV by AUTOID with its lines: {doc_id, po_number, invoice, inv_date, freight,
        total, tax, status, processed, paid, lines: [{line_id, item, ordered, ship, unit}]}.
        Raises EbmsNotFound. (Match to PO, research K.6.)"""
        raise NotImplementedError

    def patch_po(self, doc_id: str, body: dict, *, auth: EbmsAuth) -> dict:
        """PATCH APINV('<AUTOID>') with a build_po_receive_body / build_po_restore_body body.
        Never retried (the caller re-reads the PO). Returns {request_id}."""
        raise NotImplementedError

    # ---- sales orders (86e3q4ze8; proven live, research K.2 rows 4-6)

    def create_sales_order(self, header: dict, lines: list[dict], idempotency_key: str, *, auth: EbmsAuth) -> dict:
        """Create an UNPROCESSED sales order (ARINV, STATUS 'U'). Returns {doc_number (INVOICE),
        doc_id, total_so, request_id, response_id, existing}."""
        raise NotImplementedError

    def find_sales_order(self, idempotency_key: str, *, auth: EbmsAuth) -> dict | None:
        raise NotImplementedError

    def get_sales_order(self, doc_id: str, *, auth: EbmsAuth) -> dict:
        """{doc_number, doc_id, status, processed, paid, total_so} by AUTOID. Raises EbmsNotFound."""
        raise NotImplementedError

    def delete_sales_order(self, doc_id: str, *, auth: EbmsAuth) -> dict:
        raise NotImplementedError

    # ---- new master records (customer / vendor / part) created inside a draft

    def create_record(self, kind: str, body: dict, *, auth: EbmsAuth) -> dict:
        """POST a new ARCUST / APVENDOR / INVENTRY (body from build_record_body). Looks it up
        by EXTERNALID first. Returns {id, doc_id (AUTOID), request_id, existing}."""
        raise NotImplementedError

    def delete_record(self, kind: str, doc_id: str, *, auth: EbmsAuth) -> dict:
        raise NotImplementedError

    # ---- part import (86e3q4zek)

    def get_part(self, part_id: str, *, auth: EbmsAuth) -> dict:
        """The part as EBMS has it now: part_snapshot(...). Raises EbmsNotFound."""
        raise NotImplementedError

    def update_part(self, doc_id: str, body: dict, *, auth: EbmsAuth) -> dict:
        """PATCH INVENTRY('<AUTOID>') with a build_part_update / build_part_restore body.
        Returns {request_id}."""
        raise NotImplementedError


# ---------------------------------------------------------------------------
# Fake
# ---------------------------------------------------------------------------

class FakeEbmsWriteClient(EbmsWriteClient):
    """In-memory EBMS. Deterministic PO numbers from `start` (default 10001). Thread-safe.
    Test hooks: fail_next (an exception instance raised by the next create/delete),
    create_delay (seconds, to widen race windows), mark_processed(doc_number)."""

    name = "fake"

    def __init__(self, start: int = 10001):
        self._lock = threading.Lock()
        self._next = start
        self.docs: dict[str, dict] = {}          # doc_number -> doc
        self._by_external: dict[str, str] = {}   # EXTERNALID -> doc_number
        self.bodies: list[dict] = []             # every POST body "sent"
        self.create_calls = 0
        self.post_count = 0
        self.delete_calls = 0
        self.fail_next: Exception | None = None
        self.fail_get_next: Exception | None = None
        self.delete_succeeds_then_raises: Exception | None = None
        self.get_calls = 0
        self.calls_as: list[tuple[str, str]] = []   # (method, EBMS username the call ran as)
        self.reject_users: dict[str, int] = {}      # USERNAME -> 401 | 403 (test hook)
        self.create_delay = 0.0
        self.fail_attach_next: Exception | None = None
        self.attachments: list[dict] = []           # every Upload body "sent" (bills)
        self.sales: dict[str, dict] = {}            # AUTOID -> sales order (ARINV)
        self._next_invoice = 10447
        self.records: dict[str, dict] = {"ARCUST": {}, "APVENDOR": {}, "INVENTRY": {}}   # AUTOID -> body
        self.fail_record_next: Exception | None = None
        self.fail_delete_record_next: Exception | None = None
        self.so_total = 271.19                      # TOTAL_SO the fake "prices" every order at
        self.bill_tax_rate = 0.13                   # EBMS recalculates bill tax itself (K.4)
        self.patches: list[dict] = []               # every PATCH APINV body "sent" (match to PO)
        self.parts: dict[str, dict] = {}            # part import: ID upper -> INVENTRY row with INVPRICEs
        self.part_patches: list[tuple[str, dict]] = []
        self.fail_part_next: Exception | None = None
        self.fail_patch_next: Exception | None = None
        self._line_seq = 0

    def _as(self, method: str, auth) -> None:
        if not isinstance(auth, EbmsAuth) or not auth.username:
            raise EbmsAuthFailed("fake: no user credentials")
        self.calls_as.append((method, auth.username))
        if auth.username.upper() in self.reject_users:
            raise EbmsAuthFailed("fake: 401") if self.reject_users[auth.username.upper()] == 401 else \
                EbmsForbidden("fake: 403", user_message=forbidden_message(auth.username, "No access to purchase orders"))

    def create_purchase_order(self, header, lines, idempotency_key, *, auth):
        body = build_po_body(header, lines, idempotency_key)
        with self._lock:
            self._as("create", auth)
            self.create_calls += 1
            ext = body["EXTERNALID"]
            if ext in self._by_external:
                return self._existing(self.docs[self._by_external[ext]])
            if self.fail_next is not None:
                err, self.fail_next = self.fail_next, None
                raise err
        if self.create_delay:
            time.sleep(self.create_delay)
        with self._lock:
            # Re-check: a concurrent call may have created it during the delay. The server's
            # claim makes this unreachable, but the fake keeps EBMS-like at-most-once anyway.
            if ext in self._by_external:
                return self._existing(self.docs[self._by_external[ext]])
            number = str(self._next)
            self._next += 1
            doc = dict(body, PO_NO=number, INVOICE=f"PO#{number}", STATUS="U", PROCESS="Default",
                       AUTOID=f"FAKEAUTOID{number}", TOTAL_PAID=0.0, ORDER_DATE=None)
            doc["Details"] = self._lines_with_ids(doc["AUTOID"], body.get("Details") or [])
            self.docs[number] = doc
            self._by_external[ext] = number
            self.bodies.append(body)
            self.post_count += 1
        return {"doc_number": number, "doc_id": doc["AUTOID"], "request_id": f"fake-post-{number}",
                "response_id": doc["AUTOID"], "existing": False}

    @staticmethod
    def _info(doc):
        return {"doc_number": doc["PO_NO"], "doc_id": doc["AUTOID"], "status": doc["STATUS"],
                "processed": doc["STATUS"] != "U", "paid": float(doc.get("TOTAL_PAID") or 0)}

    @staticmethod
    def _existing(doc):
        if doc["STATUS"] != "U":
            raise EbmsUnexpectedState(f"fake: existing PO {doc['PO_NO']} has STATUS {doc['STATUS']!r}",
                                      doc_number=doc["PO_NO"])
        return {"doc_number": doc["PO_NO"], "doc_id": doc["AUTOID"], "request_id": f"fake-get-{doc['EXTERNALID']}",
                "response_id": doc["AUTOID"], "existing": True}

    def get_purchase_order(self, doc_number, *, doc_id=None, auth):
        with self._lock:
            self._as("get", auth)
            self.get_calls += 1
            if self.fail_get_next is not None:
                err, self.fail_get_next = self.fail_get_next, None
                raise err
            doc = self.docs.get(str(doc_number))
            if doc is None:
                raise EbmsNotFound(f"fake: PO {doc_number} not found")
            return self._info(doc)

    def find_purchase_order(self, idempotency_key, *, auth):
        with self._lock:
            self._as("find", auth)
            num = self._by_external.get(external_id(idempotency_key))
            return self._info(self.docs[num]) if num else None

    def create_out_of_band(self, header, lines, idempotency_key):
        """Test hook: a document EBMS made from an earlier, timed-out call."""
        f, self.fail_next = self.fail_next, None
        try:
            return self.create_purchase_order(header, lines, idempotency_key, auth=EbmsAuth("OUT-OF-BAND", "x"))
        finally:
            self.fail_next = f

    def delete_purchase_order(self, doc_number, *, doc_id=None, auth):
        with self._lock:
            self._as("delete", auth)
            self.delete_calls += 1
            if self.fail_next is not None:
                err, self.fail_next = self.fail_next, None
                raise err
            doc = self.docs.get(str(doc_number))
            if doc is None:
                raise EbmsNotFound(f"fake: PO {doc_number} not found")
            if doc["STATUS"] != "U":
                raise EbmsRejected("fake: processed document cannot be deleted", status=400)
            del self.docs[str(doc_number)]
            self._by_external = {k: v for k, v in self._by_external.items() if v != str(doc_number)}
            if self.delete_succeeds_then_raises is not None:
                err, self.delete_succeeds_then_raises = self.delete_succeeds_then_raises, None
                raise err
        return {"request_id": f"fake-delete-{doc_number}", "response_id": None}

    def mark_processed(self, doc_number):
        with self._lock:
            doc = self.docs.get(str(doc_number)) or self._by_autoid(doc_number)
            doc["STATUS"] = "O"

    # ---- bills (same in-memory store; docs keyed by the PO_NO EBMS assigns)

    def _by_autoid(self, doc_id):
        for doc in self.docs.values():
            if doc["AUTOID"] == doc_id:
                return doc
        return None

    def _bill_info(self, doc):
        return {"doc_number": doc["INVOICE"], "po_number": doc["PO_NO"], "doc_id": doc["AUTOID"],
                "status": doc["STATUS"], "processed": doc["STATUS"] != "U",
                "paid": float(doc.get("TOTAL_PAID") or 0), "total": self._totals(doc)[1]}

    def _lines_with_ids(self, doc_id, lines):
        out = []
        for ln in lines:
            self._line_seq += 1
            row = dict(ln, AUTOID=f"{doc_id}L{self._line_seq}")
            row.setdefault("SHIP_VIS", 0)
            out.append(row)
        return out

    def _totals(self, doc):
        """(tax, total) like EBMS: billed (SHIP_VIS) x UNIT_VIS + FREIGHT, tax recalculated at
        bill_tax_rate (EBMS calculates tax itself, research K.4)."""
        sub = sum(float(ln.get("SHIP_VIS") or 0) * float(ln.get("UNIT_VIS") or 0) for ln in doc.get("Details") or [])
        base = round(sub + float(doc.get("FREIGHT") or 0), 2)
        tax = round(base * self.bill_tax_rate, 2)
        return tax, round(base + tax, 2)

    def get_po_detail(self, doc_id, *, auth):
        with self._lock:
            self._as("get_po_detail", auth)
            self.get_calls += 1
            if self.fail_get_next is not None:
                err, self.fail_get_next = self.fail_get_next, None
                raise err
            doc = self._by_autoid(doc_id)
            if doc is None:
                raise EbmsNotFound(f"fake: APINV {doc_id} not found")
            tax, total = self._totals(doc)
            return {"doc_id": doc["AUTOID"], "po_number": doc["PO_NO"], "invoice": doc["INVOICE"],
                    "inv_date": doc.get("INV_DATE"), "freight": float(doc.get("FREIGHT") or 0),
                    "total": total, "tax": tax, "status": doc["STATUS"], "processed": doc["STATUS"] != "U",
                    "paid": float(doc.get("TOTAL_PAID") or 0), "externalid": doc.get("EXTERNALID"),
                    "lines": [{"line_id": ln["AUTOID"], "item": ln.get("INVEN") or "",
                               "ordered": float(ln.get("O_QUAN_VIS") or 0), "ship": float(ln.get("SHIP_VIS") or 0),
                               "unit": float(ln.get("UNIT_VIS") or 0)} for ln in doc.get("Details") or []]}

    def patch_po(self, doc_id, body, *, auth):
        with self._lock:
            self._as("patch_po", auth)
            if self.fail_patch_next is not None:
                err, self.fail_patch_next = self.fail_patch_next, None
                raise err
            doc = self._by_autoid(doc_id)
            if doc is None:
                raise EbmsNotFound(f"fake: APINV {doc_id} not found")
            if doc["STATUS"] != "U":
                raise EbmsRejected("fake: processed document cannot be edited", status=400)
            self.patches.append({"doc_id": doc_id, "body": body})
            for k in ("INVOICE", "INV_DATE", "FREIGHT"):
                if k in body:
                    doc[k] = body[k]
            lines = doc.setdefault("Details", [])
            for d in body.get("Details@delta") or []:
                if "@id" in d:
                    row = next((ln for ln in lines if ln["AUTOID"] == d["@id"]), None)
                    if row is None:
                        raise EbmsRejected(f"fake: line {d['@id']} not found", status=400)
                    if d.get("@removed"):
                        lines.remove(row)
                    else:
                        row.update({k: v for k, v in d.items() if not k.startswith("@")})
                else:
                    lines.extend(self._lines_with_ids(doc_id, [d]))
        return {"request_id": f"fake-patch-{doc_id}"}

    def create_bill(self, header, lines, idempotency_key, *, auth):
        body = build_bill_body(header, lines, idempotency_key)
        with self._lock:
            self._as("create_bill", auth)
            self.create_calls += 1
            ext = body["EXTERNALID"]
            if ext in self._by_external:
                doc = self.docs[self._by_external[ext]]
                if doc["STATUS"] != "U":
                    raise EbmsUnexpectedState(f"fake: existing bill has STATUS {doc['STATUS']!r}",
                                              doc_number=doc["INVOICE"])
                return dict(self._bill_info(doc), request_id=f"fake-get-{ext}", response_id=doc["AUTOID"],
                            existing=True)
            if self.fail_next is not None:
                err, self.fail_next = self.fail_next, None
                raise err
            number = str(self._next)
            self._next += 1
            doc = dict(body, PO_NO=number, STATUS="U", PROCESS="Default", AUTOID=f"FAKEAUTOID{number}",
                       TOTAL_PAID=0.0)
            doc["Details"] = self._lines_with_ids(doc["AUTOID"], body.get("Details") or [])
            self.docs[number] = doc
            self._by_external[ext] = number
            self.bodies.append(body)
            self.post_count += 1
        return dict(self._bill_info(doc), request_id=f"fake-post-{number}", response_id=doc["AUTOID"],
                    existing=False)

    def find_bill(self, idempotency_key, *, auth):
        with self._lock:
            self._as("find_bill", auth)
            num = self._by_external.get(external_id(idempotency_key))
            return self._bill_info(self.docs[num]) if num else None

    def get_bill(self, doc_id, *, auth):
        with self._lock:
            self._as("get_bill", auth)
            self.get_calls += 1
            if self.fail_get_next is not None:
                err, self.fail_get_next = self.fail_get_next, None
                raise err
            doc = self._by_autoid(doc_id)
            if doc is None:
                raise EbmsNotFound(f"fake: APINV {doc_id} not found")
            return self._bill_info(doc)

    def delete_bill(self, doc_id, *, auth):
        with self._lock:
            self._as("delete_bill", auth)
            self.delete_calls += 1
            doc = self._by_autoid(doc_id)
            if doc is None:
                raise EbmsNotFound(f"fake: APINV {doc_id} not found")
            if doc["STATUS"] != "U":
                raise EbmsRejected("fake: processed document cannot be deleted", status=400)
            del self.docs[doc["PO_NO"]]
            self._by_external = {k: v for k, v in self._by_external.items() if v != doc["PO_NO"]}
        return {"request_id": f"fake-delete-{doc_id}", "response_id": doc_id}

    def attach_document(self, doc_id, filename, content_type, data, *, auth):
        body = build_attachment_body(filename, content_type, data)
        folder = attachment_folder(doc_id)
        with self._lock:
            self._as("attach", auth)
            if self.fail_attach_next is not None:
                err, self.fail_attach_next = self.fail_attach_next, None
                raise err
            if self._by_autoid(doc_id) is None:
                raise EbmsNotFound(f"fake: APINV {doc_id} not found")
            self.attachments.append({"folder": folder, "body": body})
        return {"request_id": f"fake-upload-{doc_id}", "file_name": body["FileName"]}

    # ---- sales orders

    @staticmethod
    def _so_info(doc):
        return {"doc_number": doc["INVOICE"], "doc_id": doc["AUTOID"], "status": doc["STATUS"],
                "processed": doc["STATUS"] != "U", "paid": float(doc.get("TOTAL_PAID") or 0),
                "total_so": doc.get("TOTAL_SO")}

    def _so_by_ext(self, ext):
        for doc in self.sales.values():
            if doc["EXTERNALID"] == ext:
                return doc
        return None

    def create_sales_order(self, header, lines, idempotency_key, *, auth):
        body = build_so_body(header, lines, idempotency_key)
        with self._lock:
            self._as("create_so", auth)
            self.create_calls += 1
            doc = self._so_by_ext(body["EXTERNALID"])
            if doc is not None:
                if doc["STATUS"] != "U":
                    raise EbmsUnexpectedState("fake: existing order is not unprocessed", doc_number=doc["INVOICE"])
                return dict(self._so_info(doc), request_id=None, response_id=doc["AUTOID"], existing=True)
            if self.fail_next is not None:
                err, self.fail_next = self.fail_next, None
                raise err
            number = str(self._next_invoice)
            self._next_invoice += 1
            doc = dict(body, INVOICE=number, STATUS="U", PROCESS="Default", AUTOID=f"FAKESO{number}",
                       TOTAL=0.0, TOTAL_SO=self.so_total, TOTAL_PAID=0.0)
            self.sales[doc["AUTOID"]] = doc
            self.bodies.append(body)
            self.post_count += 1
        return dict(self._so_info(doc), request_id=f"fake-post-{number}", response_id=doc["AUTOID"], existing=False)

    def find_sales_order(self, idempotency_key, *, auth):
        with self._lock:
            self._as("find_so", auth)
            doc = self._so_by_ext(external_id(idempotency_key))
            return self._so_info(doc) if doc else None

    def get_sales_order(self, doc_id, *, auth):
        with self._lock:
            self._as("get_so", auth)
            self.get_calls += 1
            doc = self.sales.get(doc_id)
            if doc is None:
                raise EbmsNotFound(f"fake: ARINV {doc_id} not found")
            return self._so_info(doc)

    def delete_sales_order(self, doc_id, *, auth):
        with self._lock:
            self._as("delete_so", auth)
            self.delete_calls += 1
            doc = self.sales.get(doc_id)
            if doc is None:
                raise EbmsNotFound(f"fake: ARINV {doc_id} not found")
            if doc["STATUS"] != "U":
                raise EbmsRejected("fake: processed document cannot be deleted", status=400)
            del self.sales[doc_id]
        return {"request_id": f"fake-delete-{doc_id}", "response_id": doc_id}

    def mark_so_processed(self, doc_id):
        with self._lock:
            self.sales[doc_id]["STATUS"] = "O"

    # ---- master records

    def create_record(self, kind, body, *, auth):
        entity = RECORD_ENTITIES[kind]
        with self._lock:
            self._as(f"create_{kind}", auth)
            store = self.records[entity]
            for aid, row in store.items():
                if row.get("EXTERNALID") == body.get("EXTERNALID"):
                    return {"id": row["ID"], "doc_id": aid, "request_id": None, "existing": True}
            if self.fail_record_next is not None:
                err, self.fail_record_next = self.fail_record_next, None
                raise err
            if any(r["ID"].upper() == str(body["ID"]).upper() for r in store.values()):
                raise EbmsRejected(f"fake: {entity} {body['ID']} exists", status=400,
                                   user_message="EBMS rejected the document because of the ID field. Nothing was saved.")
            aid = f"FAKE{entity[:3]}{len(store) + 1:04d}{body['ID'][:4]}"
            store[aid] = dict(body)
            self.bodies.append(body)
        return {"id": body["ID"], "doc_id": aid, "request_id": f"fake-post-{aid}", "existing": False}

    def delete_record(self, kind, doc_id, *, auth):
        entity = RECORD_ENTITIES[kind]
        with self._lock:
            self._as(f"delete_{kind}", auth)
            if self.fail_delete_record_next is not None:
                err, self.fail_delete_record_next = self.fail_delete_record_next, None
                raise err
            if self.records[entity].pop(doc_id, None) is None:
                raise EbmsNotFound(f"fake: {entity} {doc_id} not found")
        return {"request_id": f"fake-delete-{doc_id}", "response_id": doc_id}

    # ---- part import

    def seed_part(self, part_id: str, *, base: float, cost: float, levels: dict | None = None) -> dict:
        """Test hook: a part EBMS 'has'. levels: {LEVEL: (MARKUP_ID, MARKUP)}; "6EQUAL" follows BASE."""
        aid = f"FAKEPART{len(self.parts) + 1:04d}"
        rows = [{"AUTOID": f"{aid}L{i}", "LEVEL": lv, "MARKUP_ID": mid, "MARKUP": mk, "PRICE": 0.0}
                for i, (lv, (mid, mk)) in enumerate((levels or {}).items())]
        row = {"AUTOID": aid, "ID": part_id, "BASE": base, "COST": cost, "INVPRICEs": rows}
        self._reprice(row)
        self.parts[part_id.upper()] = row
        return row

    @staticmethod
    def _reprice(row: dict) -> None:
        for lv in row["INVPRICEs"]:
            if lv["MARKUP_ID"] == FIXED_PRICE_FORMULA:
                lv["PRICE"] = float(str(lv["MARKUP"]).replace("Is $", "").replace(",", ""))
            elif lv["MARKUP_ID"] == "6EQUAL":
                lv["PRICE"] = row["BASE"]

    def get_part(self, part_id, *, auth):
        with self._lock:
            self._as("get_part", auth)
            row = self.parts.get(str(part_id).strip().upper())
            if row is None:
                raise EbmsNotFound(f"fake: INVENTRY {part_id} not found")
            return part_snapshot(json.loads(json.dumps(row)))

    def update_part(self, doc_id, body, *, auth):
        with self._lock:
            self._as("update_part", auth)
            if self.fail_part_next is not None:
                err, self.fail_part_next = self.fail_part_next, None
                raise err
            row = next((r for r in self.parts.values() if r["AUTOID"] == doc_id), None)
            if row is None:
                raise EbmsNotFound(f"fake: INVENTRY {doc_id} not found")
            if "PRICE" in json.dumps(body.get("INVPRICEs@delta") or []):
                raise EbmsForbidden("fake: Cannot set 'PRICE' property", status=403)
            self.part_patches.append((doc_id, json.loads(json.dumps(body))))
            for k in ("BASE", "COST"):
                if k in body:
                    row[k] = float(body[k])
            for d in body.get("INVPRICEs@delta") or []:
                lv = next((x for x in row["INVPRICEs"] if x["AUTOID"] == d["@id"]), None)
                if lv is None:
                    raise EbmsRejected("fake: no such INVPRICE", status=422)
                lv.update(MARKUP_ID=d["MARKUP_ID"], MARKUP=d["MARKUP"])
            self._reprice(row)
        return {"request_id": f"fake-patch-{doc_id}"}


# ---------------------------------------------------------------------------
# OData (real gateway): PO calls proven live 2026-10-14 (research K.2)
# ---------------------------------------------------------------------------

def _odata_quote(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _ebms_messages(resp) -> str:
    """Brief EBMS error text for LOGS only (research F/K.1 shape: {"Messages":[{...}]})."""
    try:
        data = resp.json()
        msgs = data.get("Messages") or []
        parts = []
        for m in msgs[:3]:
            prop = m.get("InitiatingProperty")
            text = m.get("BriefDescription") or m.get("Detail") or m.get("Id") or ""
            parts.append(f"{text}" + (f" ({prop})" if prop else ""))
        if parts:
            return "; ".join(parts)[:500]
        if isinstance(data.get("error"), dict):
            return str(data["error"].get("message"))[:500]
    except Exception:
        pass
    try:
        return resp.text[:300]
    except Exception:
        return ""


def _user_message_for(resp) -> str | None:
    """A human message for an EBMS refusal, naming the field when EBMS says which one. EBMS's
    own wording is NOT echoed (it can carry internal detail); only the property name is."""
    try:
        msgs = resp.json().get("Messages") or []
    except Exception:
        return None
    for m in msgs:
        prop = str(m.get("InitiatingProperty") or "").strip()
        if prop and prop.replace("_", "").isalnum() and len(prop) <= 40:
            return f"EBMS rejected the document because of the {prop} field. Nothing was saved."
    return None


class ODataEbmsWriteClient(EbmsWriteClient):
    """Koble EBMS API Gateway client. base_url is the OData root, e.g.
    https://<serial>.koblesystems.dev/MyEbms/<DATA_ID>/odata  (research K).

    Proven live 2026-10-14 (research K.2): POST /APINV -> 200 with the full entity (PO_NO
    auto-assigned, INVOICE "PO#<PO_NO>", STATUS "U", PROCESS "Default"); GET /APINV?$filter=
    EXTERNALID eq '...'; GET /APINV('<AUTOID>'); DELETE /APINV('<AUTOID>') -> 204.
    Not proven: DELETE refusal for a processed document (the server never relies on it)."""

    name = "odata"

    def __init__(self, base_url: str, *, timeout: float = DEFAULT_TIMEOUT_SECONDS, http=None,
                 sleep=time.sleep):
        # No credentials here: each call passes the signed-in user's EbmsAuth.
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._http = http       # injectable httpx.Client-like object (tests)
        self._http_lock = threading.Lock()
        self._sleep = sleep

    def __repr__(self):
        return f"ODataEbmsWriteClient({self.base_url!r})"

    def _client(self):
        # One httpx.Client per ODataEbmsWriteClient (thread-safe, connection pooling);
        # get_write_client() keeps one ODataEbmsWriteClient per process and config (review #10).
        if self._http is None:
            with self._http_lock:
                if self._http is None:
                    # NO COOKIES (security review #1): one client serves every user, so a cookie the
                    # gateway set on user A's response would ride on user B's next request and could
                    # run B's call as A. The jar's policy refuses to store any cookie, and _request
                    # also clears the jar and strips any Cookie header per request.
                    self._http = httpx.Client(timeout=self.timeout, headers={"Accept": "application/json"},
                                              cookies=_no_cookie_jar())
        return self._http

    def close(self):
        if self._http is not None:
            try:
                self._http.close()
            except Exception:
                pass

    def _request(self, method: str, path: str, *, auth: EbmsAuth, params=None, json_body=None, retry: bool):
        """One HTTP call as auth.username. retry=True (GET/DELETE) retries 5xx / timeouts /
        connection errors with jittered backoff; POST is never retried here (the caller re-GETs
        by EXTERNALID)."""
        if not isinstance(auth, EbmsAuth) or not auth.username:
            raise EbmsAuthFailed(f"{method} {path}: no user credentials")
        url = f"{self.base_url}/{path.lstrip('/')}"
        attempts = 1 + (MAX_RETRIES if retry else 0)
        last: Exception | None = None
        for i in range(attempts):
            if i:
                self._sleep(_backoff(i) + random.uniform(0, BACKOFF_JITTER_SECONDS))
            try:
                client = self._client()
                client.cookies.clear()
                req = client.build_request(method, url, params=params, json=json_body)
                req.headers.pop("cookie", None)
                resp = client.send(req, auth=auth.httpx_auth())
            except (httpx.TimeoutException, httpx.TransportError) as e:
                last = EbmsUnavailable(f"{method} {path}: {type(e).__name__}")
                continue
            rid = resp.headers.get("request-id") or resp.headers.get("x-request-id") or resp.headers.get("cf-ray")
            if resp.status_code >= 500:
                last = EbmsUnavailable(f"{method} {path}: HTTP {resp.status_code}: {_ebms_messages(resp)}",
                                       status=resp.status_code, request_id=rid)
                continue
            if resp.status_code == 404:
                raise EbmsNotFound(f"{method} {path}: 404", status=404, request_id=rid)
            if resp.status_code == 401:
                raise EbmsAuthFailed(f"{method} {path} as {auth.username}: HTTP 401: {_ebms_messages(resp)}",
                                     status=401, request_id=rid)
            if resp.status_code == 403 or (resp.status_code >= 400 and _is_security_refusal(resp)):
                raise EbmsForbidden(f"{method} {path} as {auth.username}: HTTP {resp.status_code}: {_ebms_messages(resp)}",
                                    status=resp.status_code, request_id=rid,
                                    user_message=forbidden_message(auth.username, _brief(resp)))
            if resp.status_code >= 400:
                raise EbmsRejected(f"{method} {path}: HTTP {resp.status_code}: {_ebms_messages(resp)}",
                                   status=resp.status_code, request_id=rid,
                                   user_message=_user_message_for(resp))
            resp.request_id = rid
            return resp
        raise last  # type: ignore[misc]

    # Every field must exist on APINV in docs/design/ebms-api-metadata.xml: the gateway answers
    # 400 "Could not find a property" for an unknown $select field (research K.1).
    # tests/test_ebms_api.py parses the metadata to pin this (86e3q4zc9 review #1).
    SELECT_FIELDS = ("AUTOID", "INVOICE", "PO_NO", "STATUS", "TOTAL_PAID", "TOTAL")
    # Match to PO (research K.6): the PO header and its lines, every field checked against the
    # metadata (APINVDET's AUTOID comes from its base type).
    PO_DETAIL_FIELDS = ("AUTOID", "INVOICE", "PO_NO", "STATUS", "TOTAL_PAID", "TOTAL", "TAX", "FREIGHT",
                        "INV_DATE", "EXTERNALID")
    PO_LINE_FIELDS = ("AUTOID", "INVEN", "O_QUAN_VIS", "SHIP_VIS", "UNIT_VIS")
    _SELECT = ",".join(SELECT_FIELDS)

    # Sales orders and new records: every field checked against the metadata the same way.
    SO_SELECT_FIELDS = ("AUTOID", "INVOICE", "PO_NO", "STATUS", "TOTAL_PAID", "TOTAL_SO")
    RECORD_SELECT_FIELDS = ("AUTOID", "ID")

    def _find_by_external(self, ext: str, auth: EbmsAuth, entity: str = "APINV",
                          select: str | None = None) -> dict | None:
        resp = self._request("GET", entity, auth=auth, retry=True, params={
            "$filter": f"EXTERNALID eq {_odata_quote(ext)}", "$select": select or self._SELECT, "$top": "2"})
        rows = (resp.json() or {}).get("value") or []
        if len(rows) > 1:
            raise EbmsUnexpectedState(f"EXTERNALID {ext} matches {len(rows)} {entity} rows")
        return rows[0] if rows else None

    # ---- sales orders (K.2 rows 4-6: POST 200 with the full entity, DELETE by AUTOID 204)

    def _so_info(self, row: dict) -> dict:
        status = str(row.get("STATUS") or "").strip().upper()
        tso = row.get("TOTAL_SO")
        return {"doc_number": str(row.get("INVOICE") or "").strip() or None, "doc_id": row.get("AUTOID"),
                "status": status, "processed": status != "U", "paid": float(row.get("TOTAL_PAID") or 0),
                "total_so": float(tso) if isinstance(tso, (int, float)) else None}

    def _so_require_unprocessed(self, row: dict, what: str) -> None:
        if str(row.get("STATUS") or "").strip().upper() != "U":
            log.error(f"EBMS {what} sales order {row.get('INVOICE')} has STATUS {row.get('STATUS')!r}, not 'U'. "
                      f"Check it in EBMS and disable writes for this dataset.")
            raise EbmsUnexpectedState(f"{what} sales order has STATUS {row.get('STATUS')!r}",
                                      doc_number=str(row.get("INVOICE") or "").strip() or None)

    def create_sales_order(self, header, lines, idempotency_key, *, auth):
        body = build_so_body(header, lines, idempotency_key)
        ext = body["EXTERNALID"]
        sel = ",".join(self.SO_SELECT_FIELDS)
        existing = self._find_by_external(ext, auth, "ARINV", sel)
        if existing is not None:
            self._so_require_unprocessed(existing, "existing")
            return dict(self._so_info(existing), request_id=None, response_id=existing.get("AUTOID"), existing=True)
        try:
            resp = self._request("POST", "ARINV", auth=auth, json_body=body, retry=False)
        except EbmsUnavailable:
            created = self._find_by_external(ext, auth, "ARINV", sel)
            if created is None:
                raise
            rid = None
        else:
            rid = getattr(resp, "request_id", None)
            try:
                created = resp.json()
            except Exception:
                created = None
            if not isinstance(created, dict) or not created.get("AUTOID") or not created.get("INVOICE"):
                created = self._find_by_external(ext, auth, "ARINV", sel)
                if created is None:
                    raise EbmsUnexpectedState(f"POST ARINV succeeded but EXTERNALID {ext} not found")
        self._so_require_unprocessed(created, "created")
        return dict(self._so_info(created), request_id=rid, response_id=created.get("AUTOID"), existing=False)

    def find_sales_order(self, idempotency_key, *, auth):
        row = self._find_by_external(external_id(idempotency_key), auth, "ARINV", ",".join(self.SO_SELECT_FIELDS))
        return None if row is None else self._so_info(row)

    def get_sales_order(self, doc_id, *, auth):
        if not doc_id:
            raise EbmsNotFound("sales order has no AUTOID")
        resp = self._request("GET", f"ARINV({_odata_quote(doc_id)})", auth=auth, retry=True,
                             params={"$select": ",".join(self.SO_SELECT_FIELDS)})
        return self._so_info(resp.json())

    def delete_sales_order(self, doc_id, *, auth):
        if not doc_id:
            raise EbmsNotFound("sales order has no AUTOID")
        resp = self._request("DELETE", f"ARINV({_odata_quote(doc_id)})", auth=auth, retry=True)
        return {"request_id": getattr(resp, "request_id", None), "response_id": doc_id}

    # ---- new master records (INVENTRY proven K.2 rows 7-8; ARCUST / APVENDOR: research K.5)

    def create_record(self, kind, body, *, auth):
        entity = RECORD_ENTITIES[kind]
        ext = body.get("EXTERNALID")
        if not ext:
            raise ValueError("a new record needs an EXTERNALID")
        sel = ",".join(self.RECORD_SELECT_FIELDS)
        existing = self._find_by_external(ext, auth, entity, sel)
        if existing is not None:
            return {"id": str(existing.get("ID") or "").strip(), "doc_id": existing.get("AUTOID"),
                    "request_id": None, "existing": True}
        try:
            resp = self._request("POST", entity, auth=auth, json_body=body, retry=False)
        except EbmsUnavailable:
            created = self._find_by_external(ext, auth, entity, sel)
            if created is None:
                raise
            rid = None
        else:
            rid = getattr(resp, "request_id", None)
            try:
                created = resp.json()
            except Exception:
                created = None
            if not isinstance(created, dict) or not created.get("AUTOID"):
                created = self._find_by_external(ext, auth, entity, sel)
                if created is None:
                    raise EbmsUnexpectedState(f"POST {entity} succeeded but EXTERNALID {ext} not found")
        # Live test 2026-10-14 (K.5): a part POSTed with COST and PRI_VENDOR came back COST 0
        # (setting the primary vendor resets it); a follow-up PATCH of COST sticks.
        # Count type is read back the same way: a part saved without the type the user picked
        # gets it PATCHed, so the card's promise holds.
        fix = {}
        if (kind == "part" and body.get("COST") is not None and created.get("AUTOID")
                and round(float(created.get("COST") or 0), 2) != round(float(body["COST"]), 2)):
            fix["COST"] = body["COST"]
        if (kind == "part" and body.get("C_TYPE") is not None and created.get("AUTOID")
                and "C_TYPE" in created and created.get("C_TYPE") != body["C_TYPE"]):
            fix["C_TYPE"] = body["C_TYPE"]
        if fix:
            self._request("PATCH", f"{entity}({_odata_quote(created['AUTOID'])})", auth=auth,
                          json_body=fix, retry=False)
        return {"id": str(created.get("ID") or body.get("ID") or "").strip(), "doc_id": created.get("AUTOID"),
                "request_id": rid, "existing": False}

    def delete_record(self, kind, doc_id, *, auth):
        entity = RECORD_ENTITIES[kind]
        if not doc_id:
            raise EbmsNotFound(f"{entity} record has no AUTOID")
        resp = self._request("DELETE", f"{entity}({_odata_quote(doc_id)})", auth=auth, retry=True)
        return {"request_id": getattr(resp, "request_id", None), "response_id": doc_id}

    # ---- part import (research K.8)

    PART_FIELDS = ("AUTOID", "ID", "BASE", "COST")
    PART_LEVEL_FIELDS = ("AUTOID", "LEVEL", "MARKUP", "MARKUP_ID", "PRICE")

    def get_part(self, part_id, *, auth):
        resp = self._request("GET", f"INVENTRY(ID={_odata_quote(str(part_id).strip())})", auth=auth, retry=True,
                             params={"$select": ",".join(self.PART_FIELDS),
                                     "$expand": f"INVPRICEs($select={','.join(self.PART_LEVEL_FIELDS)})"})
        return part_snapshot(resp.json() or {})

    def update_part(self, doc_id, body, *, auth):
        if not doc_id:
            raise EbmsNotFound("INVENTRY record has no AUTOID")
        # Setting values is idempotent, so a PATCH that timed out can be sent again.
        resp = self._request("PATCH", f"INVENTRY({_odata_quote(doc_id)})", auth=auth, json_body=body, retry=True)
        return {"request_id": getattr(resp, "request_id", None)}

    @staticmethod
    def _doc_number(row: dict) -> str:
        po = str(row.get("PO_NO") or "").strip()
        return po or str(row.get("INVOICE") or "").strip()

    def create_purchase_order(self, header, lines, idempotency_key, *, auth):
        body = build_po_body(header, lines, idempotency_key)
        ext = body["EXTERNALID"]
        existing = self._find_by_external(ext, auth)
        if existing is not None:
            # Same STATUS rule as a fresh create (review #3): a document that exists but is no
            # longer unprocessed is not "our saved draft" and must not be offered for Undo.
            self._require_unprocessed(existing, "existing")
            return {"doc_number": self._doc_number(existing), "doc_id": existing.get("AUTOID"),
                    "request_id": None, "response_id": existing.get("AUTOID"), "existing": True}
        try:
            resp = self._request("POST", "APINV", auth=auth, json_body=body, retry=False)
        except EbmsUnavailable:
            # Outcome unknown: look it up, never POST again blindly (research recommendation 5).
            created = self._find_by_external(ext, auth)
            if created is None:
                raise
            rid = None
        else:
            rid = getattr(resp, "request_id", None)
            try:
                created = resp.json()  # HTTP 200 with the full entity (K.2 row 1)
            except Exception:
                created = None
            if not isinstance(created, dict) or not created.get("AUTOID") or not self._doc_number(created):
                created = self._find_by_external(ext, auth)
                if created is None:
                    raise EbmsUnexpectedState(f"POST APINV succeeded but EXTERNALID {ext} not found")
        self._require_unprocessed(created, "created")
        return {"doc_number": self._doc_number(created), "doc_id": created.get("AUTOID"),
                "request_id": rid, "response_id": created.get("AUTOID"), "existing": False}

    def _require_unprocessed(self, row: dict, what: str) -> None:
        if str(row.get("STATUS") or "").strip().upper() != "U":
            # An alert, not an automatic switch-off: whoever reads this disables writes for the
            # dataset (EBMS_LIVE_WRITES_DATASETS) after checking the document in EBMS.
            log.error(f"EBMS {what} PO {self._doc_number(row)} has STATUS {row.get('STATUS')!r}, "
                      f"not 'U'. Check it in EBMS and disable writes for this dataset.")
            raise EbmsUnexpectedState(f"{what} PO has STATUS {row.get('STATUS')!r}",
                                      doc_number=self._doc_number(row) or None)

    def find_purchase_order(self, idempotency_key, *, auth):
        row = self._find_by_external(external_id(idempotency_key), auth)
        return None if row is None else self._info(row)

    def _info(self, row: dict, doc_number=None) -> dict:
        status = str(row.get("STATUS") or "").strip().upper()
        return {"doc_number": self._doc_number(row) or (str(doc_number) if doc_number else None),
                "doc_id": row.get("AUTOID"), "status": status, "processed": status != "U",
                "paid": float(row.get("TOTAL_PAID") or 0)}

    def _get_row(self, doc_number, doc_id, auth):
        if doc_id:
            resp = self._request("GET", f"APINV({_odata_quote(doc_id)})", auth=auth, retry=True,
                                 params={"$select": self._SELECT})
            return resp.json()
        resp = self._request("GET", "APINV", auth=auth, retry=True, params={
            "$filter": f"PO_NO eq {_odata_quote(doc_number)} and STATUS eq Model.Entities.InvoiceStatus'U'",
            "$select": self._SELECT, "$top": "2"})
        rows = (resp.json() or {}).get("value") or []
        if not rows:
            raise EbmsNotFound(f"PO {doc_number} not found")
        if len(rows) > 1:
            raise EbmsUnexpectedState(f"PO_NO {doc_number} matches {len(rows)} rows")
        return rows[0]

    def get_purchase_order(self, doc_number, *, doc_id=None, auth):
        return self._info(self._get_row(doc_number, doc_id, auth), doc_number)

    # ---- vendor bills (86e3q4zeb). NOT LIVE-PROVEN: research K.4 lists the tests to run.

    def _bill_info(self, row: dict) -> dict:
        info = self._info(row)
        info["po_number"] = str(row.get("PO_NO") or "").strip() or None
        info["doc_number"] = str(row.get("INVOICE") or "").strip() or info["doc_number"]
        tot = row.get("TOTAL")
        info["total"] = float(tot) if isinstance(tot, (int, float)) else None
        return info

    def get_po_detail(self, doc_id, *, auth):
        if not doc_id:
            raise EbmsNotFound("PO has no AUTOID")
        resp = self._request("GET", f"APINV({_odata_quote(doc_id)})", auth=auth, retry=True, params={
            "$select": ",".join(self.PO_DETAIL_FIELDS),
            "$expand": f"Details($select={','.join(self.PO_LINE_FIELDS)})"})
        row = resp.json() or {}
        status = str(row.get("STATUS") or "").strip().upper()

        def num(v):
            return float(v) if isinstance(v, (int, float)) else 0.0
        return {"doc_id": row.get("AUTOID"), "po_number": str(row.get("PO_NO") or "").strip() or None,
                "invoice": str(row.get("INVOICE") or "").strip(), "inv_date": (str(row.get("INV_DATE") or "")[:10] or None),
                "freight": num(row.get("FREIGHT")), "total": num(row.get("TOTAL")), "tax": num(row.get("TAX")),
                "status": status, "processed": status != "U", "paid": num(row.get("TOTAL_PAID")),
                "externalid": row.get("EXTERNALID"),
                "lines": [{"line_id": ln.get("AUTOID"), "item": str(ln.get("INVEN") or "").strip(),
                           "ordered": num(ln.get("O_QUAN_VIS")), "ship": num(ln.get("SHIP_VIS")),
                           "unit": num(ln.get("UNIT_VIS"))} for ln in row.get("Details") or []]}

    def patch_po(self, doc_id, body, *, auth):
        if not doc_id:
            raise EbmsNotFound("PO has no AUTOID")
        resp = self._request("PATCH", f"APINV({_odata_quote(doc_id)})", auth=auth,
                             json_body=_check_receive_body(body), retry=False)
        return {"request_id": getattr(resp, "request_id", None)}

    def create_bill(self, header, lines, idempotency_key, *, auth):
        body = build_bill_body(header, lines, idempotency_key)
        ext = body["EXTERNALID"]
        existing = self._find_by_external(ext, auth)
        if existing is not None:
            self._require_unprocessed(existing, "existing")
            return dict(self._bill_info(existing), request_id=None, response_id=existing.get("AUTOID"),
                        existing=True)
        try:
            resp = self._request("POST", "APINV", auth=auth, json_body=body, retry=False)
        except EbmsUnavailable:
            created = self._find_by_external(ext, auth)
            if created is None:
                raise
            rid = None
        else:
            rid = getattr(resp, "request_id", None)
            try:
                created = resp.json()
            except Exception:
                created = None
            if not isinstance(created, dict) or not created.get("AUTOID"):
                created = self._find_by_external(ext, auth)
                if created is None:
                    raise EbmsUnexpectedState(f"POST APINV (bill) succeeded but EXTERNALID {ext} not found")
        self._require_unprocessed(created, "created")
        return dict(self._bill_info(created), request_id=rid, response_id=created.get("AUTOID"), existing=False)

    def find_bill(self, idempotency_key, *, auth):
        row = self._find_by_external(external_id(idempotency_key), auth)
        return None if row is None else self._bill_info(row)

    def get_bill(self, doc_id, *, auth):
        if not doc_id:
            raise EbmsNotFound("bill has no AUTOID")
        return self._bill_info(self._get_row(None, doc_id, auth))

    def delete_bill(self, doc_id, *, auth):
        if not doc_id:
            raise EbmsNotFound("bill has no AUTOID")
        resp = self._request("DELETE", f"APINV({_odata_quote(doc_id)})", auth=auth, retry=True)
        return {"request_id": getattr(resp, "request_id", None), "response_id": doc_id}

    def attach_document(self, doc_id, filename, content_type, data, *, auth):
        # POST DirectoryFolder('APINV[<AUTOID>]')/Model.Entities.Upload (research G). Never
        # retried: a timed-out upload may have landed, and a second one would duplicate the file.
        body = build_attachment_body(filename, content_type, data)
        path = f"DirectoryFolder({_odata_quote(attachment_folder(doc_id))})/Model.Entities.Upload"
        resp = self._request("POST", path, auth=auth, json_body=body, retry=False)
        return {"request_id": getattr(resp, "request_id", None), "file_name": body["FileName"]}

    def delete_purchase_order(self, doc_number, *, doc_id=None, auth):
        # DELETE /APINV('<AUTOID>') -> 204 proven on an unprocessed PO (research K.2 row 3).
        if not doc_id:
            doc_id = self._get_row(doc_number, None, auth).get("AUTOID")
        resp = self._request("DELETE", f"APINV({_odata_quote(doc_id)})", auth=auth, retry=True)
        return {"request_id": getattr(resp, "request_id", None), "response_id": doc_id}


# ---------------------------------------------------------------------------
# Selection
# ---------------------------------------------------------------------------

_fake_singleton: FakeEbmsWriteClient | None = None
_odata_singleton: tuple[tuple, "ODataEbmsWriteClient"] | None = None
_singleton_lock = threading.Lock()

# Why a dataset has no write client (get_write_client_status reasons; server.py maps them to
# human /writes/config text).
REASON_NOT_CONFIGURED = "not_configured"
REASON_INSECURE_URL = "insecure_url"
REASON_NO_DATASET_PIN = "no_dataset_pin"
REASON_OTHER_DATASET = "other_dataset"


def fake_enabled() -> bool:
    return os.getenv("EBMS_LIVE_API_FAKE", "").strip() == "1"


def get_write_client_status(schema: str | None) -> tuple[EbmsWriteClient | None, str | None]:
    """(client, None) or (None, reason).
    Fake when EBMS_LIVE_API_FAKE=1. The real OData client needs EBMS_LIVE_API_URL (https) AND
    EBMS_LIVE_API_DATASET: the gateway URL names ONE EBMS company, so it is only ever used for
    that one schema (research H; review #2). There are no service-account credentials: each call
    carries the signed-in user's own EbmsAuth."""
    global _fake_singleton, _odata_singleton
    if fake_enabled():
        with _singleton_lock:
            if _fake_singleton is None:
                _fake_singleton = FakeEbmsWriteClient()
            return _fake_singleton, None
    url = (os.getenv("EBMS_LIVE_API_URL") or "").strip()
    if not url:
        return None, REASON_NOT_CONFIGURED
    if not url.lower().startswith("https://"):
        log.error("EBMS_LIVE_API_URL must be https; writes are disabled.")
        return None, REASON_INSECURE_URL
    pinned = (os.getenv("EBMS_LIVE_API_DATASET") or "").strip()
    if not pinned:
        log.error("EBMS_LIVE_API_DATASET is not set: the EBMS API URL is configured but not tied "
                  "to a dataset, so writes are disabled.")
        return None, REASON_NO_DATASET_PIN
    if schema is None or schema.strip() != pinned:
        return None, REASON_OTHER_DATASET
    key = (url, pinned)
    with _singleton_lock:
        if _odata_singleton is None or _odata_singleton[0] != key:
            if _odata_singleton is not None:
                _odata_singleton[1].close()
            _odata_singleton = (key, ODataEbmsWriteClient(url))
        return _odata_singleton[1], None


def get_write_client(schema: str | None = None) -> EbmsWriteClient | None:
    return get_write_client_status(schema)[0]


def reset_fake_client() -> None:
    """Tests: drop the cached clients."""
    global _fake_singleton, _odata_singleton
    with _singleton_lock:
        _fake_singleton = None
        if _odata_singleton is not None:
            _odata_singleton[1].close()
        _odata_singleton = None
