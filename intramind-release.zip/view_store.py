"""Dashboard view preference: storage for Assist role-based KPI views.

Stores, per IntraMind user and per dataset (schema), which dashboard view
they use (owner / purchaser / sales) and, for the Sales view, which EBMS
salesperson they are (ARSALESP.ID, chosen by the user in Settings).

Nothing in EBMS links an EBMS login to ARSALESP.ID, and ARINV.USER_NAME
(who keyed an invoice) is not SALESMAN (who gets credit for it), so the
mapping is asserted by the user here, never derived. ARCUST.SALESMAN is
the customer's assigned rep ("my customers"); ARINV.SALESMAN is the rep
credited on that invoice. The Sales view uses both, for those purposes.

This module is deliberately pure like pins_store.py: no FastAPI, no
psycopg, no server import. Storage is IntraMind's own SQLite file, never
EBMS's Postgres. Username normalisation matches pins_store / server login:
.strip().upper(). Schema is only whitespace-trimmed (case-sensitive).
"""

from __future__ import annotations

import os
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_VERSION = 1
VIEWS = frozenset({"owner", "purchaser", "sales"})
DEFAULT_VIEW = "owner"
SALESMAN_MAX = 20  # ARSALESP.ID / ARCUST.SALESMAN / ARINV.SALESMAN are char(20)
BUSY_TIMEOUT_SECONDS = 5.0

_DB_PATHS = [
    Path(r"C:\ProgramData\IntraMind\views.sqlite3"),
    Path(__file__).parent / "views.sqlite3",
]

_init_lock = threading.Lock()


def db_path(override: str | os.PathLike | None = None) -> Path:
    """Explicit argument > EBMS_LIVE_VIEWS_DB > ProgramData (if it exists) > next to this file."""
    if override:
        return Path(override)
    env = os.getenv("EBMS_LIVE_VIEWS_DB")
    if env:
        return Path(env)
    for p in _DB_PATHS if os.name == "nt" else _DB_PATHS[1:]:
        try:
            if p.parent.exists():
                return p
        except OSError:
            pass
    return _DB_PATHS[-1]


def _ensure_schema(conn: sqlite3.Connection) -> None:
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version >= SCHEMA_VERSION:
        return
    conn.execute("BEGIN IMMEDIATE")
    try:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS user_views (
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   view TEXT NOT NULL DEFAULT 'owner',
                   salesman_id TEXT NOT NULL DEFAULT '',
                   updated_at TEXT NOT NULL,
                   PRIMARY KEY (username, schema)
               )"""
        )
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise


def _connect(path: str | os.PathLike | None = None) -> sqlite3.Connection:
    p = db_path(path)
    conn = sqlite3.connect(str(p), timeout=BUSY_TIMEOUT_SECONDS, isolation_level=None)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute(f"PRAGMA busy_timeout = {int(BUSY_TIMEOUT_SECONDS * 1000)}")
        if conn.execute("PRAGMA user_version").fetchone()[0] < SCHEMA_VERSION:
            with _init_lock:
                conn.execute("PRAGMA journal_mode = WAL")
                _ensure_schema(conn)
    except BaseException:
        conn.close()
        raise
    return conn


def _norm_user(username: str) -> str:
    return (username or "").strip().upper()


def _norm_schema(schema: str) -> str:
    return (schema or "").strip()


def _owner(username: str, schema: str) -> tuple[str, str]:
    u, s = _norm_user(username), _norm_schema(schema)
    if not u or not s:
        raise ValueError("A view preference needs a signed-in user and a dataset.")
    return u, s


def normalize_view(view) -> str:
    """Anything unrecognised is the Owner view (the historical default)."""
    v = view.strip().lower() if isinstance(view, str) else ""
    return v if v in VIEWS else DEFAULT_VIEW


def normalize_salesman(salesman) -> str:
    """Trim and bound to the EBMS char(20) width; non-strings become ''."""
    if not isinstance(salesman, str):
        return ""
    return salesman.strip()[:SALESMAN_MAX]


def get_view(username: str, schema: str, *, path=None) -> dict:
    """This user's stored preference, or the Owner default when none is saved."""
    u, s = _owner(username, schema)
    conn = _connect(path)
    try:
        row = conn.execute(
            "SELECT view, salesman_id FROM user_views WHERE username = ? AND schema = ?",
            (u, s),
        ).fetchone()
    finally:
        conn.close()
    if row is None:
        return {"view": DEFAULT_VIEW, "salesman_id": ""}
    return {"view": normalize_view(row["view"]), "salesman_id": normalize_salesman(row["salesman_id"])}


def set_view(username: str, schema: str, view, salesman_id="", *, path=None) -> dict:
    """Save and return the preference. Raises ValueError on an unknown view name
    (unlike normalize_view's silent fallback, a save is an explicit choice)."""
    u, s = _owner(username, schema)
    v = view.strip().lower() if isinstance(view, str) else ""
    if v not in VIEWS:
        raise ValueError("View must be one of: " + ", ".join(sorted(VIEWS)) + ".")
    salesman = normalize_salesman(salesman_id)
    updated = datetime.now(timezone.utc).isoformat(timespec="microseconds")
    conn = _connect(path)
    try:
        conn.execute(
            """INSERT INTO user_views (username, schema, view, salesman_id, updated_at)
               VALUES (?, ?, ?, ?, ?)
               ON CONFLICT(username, schema) DO UPDATE SET
                   view = excluded.view, salesman_id = excluded.salesman_id,
                   updated_at = excluded.updated_at""",
            (u, s, v, salesman, updated),
        )
    finally:
        conn.close()
    return {"view": v, "salesman_id": salesman}
