"""Picker search for draft cards: customers, vendors and parts (GET /lookup/{kind}).

ClickUp 86e3q4zeb / 86e3q4ze8. Contract: docs/design/v3-drafts-contract.md ("Lookup search").

Pure, like drafts_po.py: no FastAPI, no psycopg, does not import server.py. Every query is one
parameterised SELECT through the `query(sql, params)` server.py supplies (enforce_permissions,
read-only transaction, statement timeout). The user's text only ever reaches SQL as a bound
parameter (LIKE patterns escaped by drafts_po._like rules). Every query has a LIMIT.

RULES DOCUMENTED HERE
  q: trimmed, 1..Q_MAX characters (ValueError otherwise). At most RESULT_MAX results.
  Customers (ARCUST) / vendors (APVENDOR): ID prefix, L_NAME / F_NAME contains, CITY contains.
    Rank: exact ID (0), ID prefix (1), name starts with q (2), anything else (3); then name, ID.
    '($)' folder placeholder rows are excluded. Inactive rows are kept, flagged and sorted last.
    label = name (F_NAME L_NAME, else L_NAME, else ID); sub = "ID · City, Prov"; customers add
    " · $X past due" when the shared AR past-due predicate sums to more than 0 for them.
  Parts (INVENTRY): ID prefix or contains, DESCR_1 contains, or a vendor part number
    (INVENDOR.PART_NO) containing q. Candidates come from two bounded sub-selects (INVENTRY and
    INVENDOR, CANDIDATE_LIMIT each) so the ranking query only touches those rows. '($)' items are
    excluded. Order: inactive last; exact ID first; then the boost (vendor=: the vendor has an
    INVENDOR row for the part; customer=: the part is on an ARINVDET line of one of the
    customer's ARINV documents dated in the last 2 years); then ID prefix (1), vendor part #
    equal to q (2), description starts with q (3), anything else (4); then ID.
    On hand is warehouse-aware like the reorder rule: SUM(INVENWH.COUNT) on INVENWH installs,
    else INVENTRY.COUNT. label = "ID — description"; sub = "On hand N · Cost $x · Price $y"
    (Price = INVENTRY.BASE) plus " · Vendor # ABC" when the match came from a vendor part #.
"""

from __future__ import annotations

from drafts_po import fmt_money, fmt_qty, vendor_display

KINDS = ("customer", "vendor", "part")
Q_MAX = 60
FILTER_MAX = 40
RESULT_MAX = 8
BROWSE_MAX = 50                      # the dropdown list: customers / vendors with nothing typed
BROWSE_KINDS = ("customer", "vendor")
CANDIDATE_LIMIT = 200
CUSTOMER_HISTORY_DAYS = 730
SEP = " · "


def normalize_query(q, *, allow_empty: bool = False) -> str:
    """The trimmed search text. ValueError (safe to show) when empty (unless allow_empty, for
    the customer / vendor dropdown) or too long."""
    t = " ".join(str(q or "").split())
    if not t and not allow_empty:
        raise ValueError("Type something to search for.")
    if len(t) > Q_MAX:
        raise ValueError(f"Search text must be {Q_MAX} characters or fewer.")
    return t


def normalize_filter(v) -> str:
    t = str(v or "").strip()
    return t[:FILTER_MAX]


def _esc(term: str) -> str:
    return term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")


def _contains(term: str) -> str:
    return f"%{_esc(term)}%"


def _prefix(term: str) -> str:
    return f"{_esc(term)}%"


def _place(city, state) -> str:
    c, p = (city or "").strip(), (state or "").strip()
    return ", ".join(x for x in (c, p) if x)


class LookupSearch:
    def __init__(self, schema: str, query, *, has_invenwh: bool = False, ar_past_due_sql: str | None = None,
                 customer_history: bool = True):
        self.s = schema
        self.query = query
        self.has_invenwh = has_invenwh
        self.ar_past_due_sql = ar_past_due_sql
        # False when the user can't read AR (the "bought before" boost needs ARINV / ARINVDET)
        self.customer_history = customer_history

    def _t(self, table: str) -> str:
        return f'"{self.s}"."{table}"'

    # ---- customers and vendors

    def _party_rows(self, table: str, q: str) -> list[dict]:
        t = self._t(table)
        if not q:
            # The dropdown: the first BROWSE_MAX active ones by name
            return self.query(
                f'SELECT trim({t}."ID") AS id, trim(COALESCE({t}."L_NAME", \'\')) AS l_name,'
                f' trim(COALESCE({t}."F_NAME", \'\')) AS f_name, trim(COALESCE({t}."CITY", \'\')) AS city,'
                f' trim(COALESCE({t}."STATE", \'\')) AS state, FALSE AS inactive FROM {t}'
                f' WHERE {t}."__deleted" IS NOT TRUE AND {t}."INACTIVE" IS NOT TRUE AND {t}."ID" NOT LIKE \'($)%%\''
                f' ORDER BY trim({t}."L_NAME"), trim({t}."ID") LIMIT {BROWSE_MAX}')
        pre, con = _prefix(q), _contains(q)
        return self.query(
            f'SELECT trim({t}."ID") AS id, trim(COALESCE({t}."L_NAME", \'\')) AS l_name,'
            f' trim(COALESCE({t}."F_NAME", \'\')) AS f_name, trim(COALESCE({t}."CITY", \'\')) AS city,'
            f' trim(COALESCE({t}."STATE", \'\')) AS state, ({t}."INACTIVE" IS TRUE) AS inactive,'
            f' CASE WHEN upper(trim({t}."ID")) = upper(%s) THEN 0'
            f' WHEN {t}."ID" ILIKE %s THEN 1'
            f' WHEN {t}."L_NAME" ILIKE %s OR {t}."F_NAME" ILIKE %s THEN 2 ELSE 3 END AS rank'
            f' FROM {t}'
            f' WHERE {t}."__deleted" IS NOT TRUE AND {t}."ID" NOT LIKE \'($)%%\''
            f' AND ({t}."ID" ILIKE %s OR {t}."L_NAME" ILIKE %s OR {t}."F_NAME" ILIKE %s OR {t}."CITY" ILIKE %s)'
            f' ORDER BY ({t}."INACTIVE" IS TRUE), 7, trim({t}."L_NAME"), trim({t}."ID") LIMIT {RESULT_MAX}',
            (q, pre, pre, pre, pre, con, con, con))

    def _past_due(self, ids: list[str]) -> dict[str, float]:
        if not ids or not self.ar_past_due_sql:
            return {}
        t = self._t("ARINV")
        rows = self.query(
            f'SELECT upper(trim({t}."ID")) AS id, COALESCE(SUM({t}."BALANCE"), 0) AS balance FROM {t}'
            f' WHERE upper(trim({t}."ID")) = ANY(%s) AND {self.ar_past_due_sql} GROUP BY 1 LIMIT {max(RESULT_MAX, len(ids))}',
            ([i.upper() for i in ids],))
        return {r["id"]: float(r.get("balance") or 0) for r in rows}

    def parties(self, kind: str, q: str) -> list[dict]:
        rows = self._party_rows("ARCUST" if kind == "customer" else "APVENDOR", q)
        due = self._past_due([r["id"] for r in rows]) if kind == "customer" else {}
        out = []
        for r in rows:
            place = _place(r.get("city"), r.get("state"))
            sub = r["id"] + (SEP + place if place else "")
            bal = due.get(r["id"].upper(), 0.0)
            if bal > 0:
                sub += f"{SEP}{fmt_money(bal)} past due"
            out.append({"id": r["id"], "label": vendor_display(r), "sub": sub, "inactive": bool(r.get("inactive"))})
        return out

    # ---- parts

    def parts(self, q: str, *, vendor: str = "", customer: str = "") -> list[dict]:
        i, v, w = self._t("INVENTRY"), self._t("INVENDOR"), self._t("INVENWH")
        h, d = self._t("ARINV"), self._t("ARINVDET")
        pre, con = _prefix(q), _contains(q)
        on_hand = (f'COALESCE((SELECT SUM({w}."COUNT") FROM {w} WHERE {w}."ID" = {i}."ID" AND {w}."__deleted" IS NOT TRUE), 0)'
                   if self.has_invenwh else f'{i}."COUNT"')
        params: list = []
        boost = "0"
        if vendor:
            boost = (f'CASE WHEN EXISTS (SELECT 1 FROM {v} WHERE {v}."ID" = {i}."ID"'
                     f' AND upper(trim({v}."VENDOR_ID")) = upper(%s) AND {v}."__deleted" IS NOT TRUE) THEN 1 ELSE 0 END')
            params.append(vendor)
        elif customer and self.customer_history:
            boost = (f'CASE WHEN EXISTS (SELECT 1 FROM {d} JOIN {h} ON {h}."INVOICE" = {d}."INVOICE"'
                     f' WHERE {d}."INVEN" = {i}."ID" AND upper(trim({h}."ID")) = upper(%s)'
                     f' AND {h}."INV_DATE" >= CURRENT_DATE - {CUSTOMER_HISTORY_DAYS}'
                     f' AND {h}."__deleted" IS NOT TRUE AND {d}."__deleted" IS NOT TRUE) THEN 1 ELSE 0 END')
            params.append(customer)
        vpart = (f'(SELECT trim({v}."PART_NO") FROM {v} WHERE {v}."ID" = {i}."ID" AND {v}."PART_NO" ILIKE %s'
                 f' AND {v}."__deleted" IS NOT TRUE'
                 f' ORDER BY (upper(trim({v}."PART_NO")) = upper(%s)) DESC LIMIT 1)')
        sql = (
            f'WITH cand AS ('
            f'(SELECT {i}."ID" AS id FROM {i} WHERE ({i}."ID" ILIKE %s OR {i}."DESCR_1" ILIKE %s)'
            f' AND {i}."__deleted" IS NOT TRUE AND {i}."ID" NOT LIKE \'($)%%\' LIMIT {CANDIDATE_LIMIT})'
            f' UNION (SELECT {v}."ID" AS id FROM {v} WHERE {v}."PART_NO" ILIKE %s AND {v}."__deleted" IS NOT TRUE'
            f' LIMIT {CANDIDATE_LIMIT})),'
            f' scored AS (SELECT trim({i}."ID") AS id, trim(COALESCE({i}."DESCR_1", \'\')) AS description,'
            f' ({i}."INACTIVE" IS TRUE) AS inactive, {i}."COST" AS cost, {i}."BASE" AS price,'
            f' {on_hand} AS on_hand,'
            f' CASE WHEN {i}."ID" ILIKE %s OR {i}."DESCR_1" ILIKE %s THEN NULL ELSE {vpart} END AS vendor_part,'
            f' {boost} AS boost,'
            f' CASE WHEN upper(trim({i}."ID")) = upper(%s) THEN 0 WHEN {i}."ID" ILIKE %s THEN 1'
            f' WHEN EXISTS (SELECT 1 FROM {v} WHERE {v}."ID" = {i}."ID" AND upper(trim({v}."PART_NO")) = upper(%s)'
            f' AND {v}."__deleted" IS NOT TRUE) THEN 2'
            f' WHEN {i}."DESCR_1" ILIKE %s THEN 3 ELSE 4 END AS rank'
            f' FROM {i} JOIN cand ON cand.id = {i}."ID"'
            f' WHERE {i}."__deleted" IS NOT TRUE AND {i}."ID" NOT LIKE \'($)%%\')'
            f' SELECT * FROM scored ORDER BY inactive, (rank = 0) DESC, boost DESC, rank, id LIMIT {RESULT_MAX}')
        all_params = [con, con, con,          # cand (INVENTRY ID / description, INVENDOR part #)
                      con, con,               # vendor_part: only when ID / description didn't match
                      con, q,                 # vpart
                      *params,                # boost
                      q, pre, q, pre]         # rank
        rows = self.query(sql, tuple(all_params))
        out = []
        for r in rows:
            bits = []
            if r.get("on_hand") is not None:
                bits.append(f"On hand {fmt_qty(r['on_hand'])}")
            if r.get("cost") is not None:
                bits.append(f"Cost {fmt_money(r['cost'], unit=True)}")
            if r.get("price") is not None:
                bits.append(f"Price {fmt_money(r['price'], unit=True)}")
            if r.get("vendor_part"):
                bits.append(f"Vendor # {r['vendor_part']}")
            label = r["id"] + (f" — {r['description']}" if r.get("description") else "")
            out.append({"id": r["id"], "label": label, "sub": SEP.join(bits), "inactive": bool(r.get("inactive"))})
        return out

    def search(self, kind: str, q: str, *, vendor: str = "", customer: str = "") -> list[dict]:
        if kind not in KINDS:
            raise ValueError("Unknown lookup.")
        q = normalize_query(q, allow_empty=kind in BROWSE_KINDS)
        if kind == "part":
            return self.parts(q, vendor=normalize_filter(vendor), customer=normalize_filter(customer))
        return self.parties(kind, q)
