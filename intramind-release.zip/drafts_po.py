"""Purchase-order drafts: input validation, read-only EBMS lookups, and the draft card.

v3 Phase 4 (ClickUp 86e3q4zc9), purchase orders (86e3q4ze6). Contract:
docs/design/v3-drafts-contract.md. Spec 8.9 (card), 11.3 (validation and enrichment), 11.6
(PO checks: primary vendor for each item, cost matches current cost).

Pure: no FastAPI, no psycopg import, does not import server.py. Every lookup goes through a
`query(sql, params) -> list[dict]` function that server.py supplies; server.py's version runs
enforce_permissions() on the SQL and executes on get_conn() (read-only transaction,
statement_timeout). Nothing here writes anywhere.

Customer strings (vendor names, descriptions, hints) are returned RAW in the card. ui.html
escapes everything it renders (spec section 3).

RULES DOCUMENTED HERE
  Current cost (11.6 "cost matches current cost"): the most recent INVENDOR row for this item
    AND this vendor with COST > 0 (the vendor's own purchase record, server.py SYSTEM_PROMPT
    "INVENDOR"), else INVENTRY.COST when > 0 (the item's "current unit cost"; the prompt warns
    it is often blank, never 0-as-real), else unknown (warn, the user enters it).
  Expected date: order date + APVENDOR.LEAD_DAYS, tagged Suggested. INVENDOR.LEAD_DAYS is
    per item and "blank on most rows" (SYSTEM_PROMPT), so the vendor default is used.
  Reorder quantity (source=reorder): parts at or below their reorder point for that primary
    vendor, using the same "low" rule as /attention (warehouse-aware: on INVENWH installs the
    SUM of INVENWH.COUNT vs MAX(MIN_INVEN), else INVENTRY.COUNT vs MIN_INVEN; active,
    track-count C_TYPEs only, no '($)' folder items). qty = MAX_INVEN - on_hand when MAX_INVEN
    is set (> 0) and above on_hand (order up to max), else MIN_INVEN - on_hand, rounded up,
    at least 1.
  Physical type: INVENTRY.C_TYPE in TRACK_COUNT_C_TYPES (EBMS's own "Product Order Sheet"
    definition, same constant as server.py) else a warn: it isn't a stocked part.
  Open PO: an APINV with STATUS 'U' (unprocessed = purchase order) that has an APINVDET line
    for the same item (joined on DOC_AID = AUTOID, never INVOICE). Warn, not block.
  Vendor by name: drafts_masters.match_vendor, shared with bills. Exact ID (inactive too); else
    the active name search, the same search on the normalised name, then only when no active
    vendor matches the INACTIVE ones (APVENDOR.INACTIVE IS TRUE; the stored name normalised in
    SQL, the exact normalised name first). Several hits narrow to the one whose normalised name
    equals the typed one. One hit is filled in and tagged matched; an inactive one blocks with
    "<name> (<id>) is inactive in EBMS. Make it active ..." and no new vendor is offered over it
    (vwzfx). "Create new" over an inactive vendor of the same normalised name blocks too
    (drafts_masters.new_vendor_name_block).
"""

from __future__ import annotations

import drafts_masters as dm
import ebms_links

import math
import re
from datetime import date, datetime, timedelta

# Same values as server.TRACK_COUNT_C_TYPES (tests/test_drafts_po.py asserts they match).
TRACK_COUNT_C_TYPES = (2, 3, 4, 7, 9, 11)

SOURCES = ("menu", "reorder", "text", "document")
MAX_LINES = 500
MAX_QTY = 10_000_000
MAX_COST = 1_000_000_000
ID_MAX = 40
HINT_MAX = 100
MEMO_MAX = 1000
SEARCH_LIMIT = 6
OPEN_PO_ROWS = 5000            # open_pos: (document, item) rows; a warning list, up to 5 documents shown
REORDER_SKIPPED_SHOWN = 10     # skipped reorder part IDs named on the card, then "and N more"
OPEN_PO_IDS_SHOWN = 10         # part IDs named in one open-PO warning, then "and N more"
MAX_NEW_RECORDS = 5            # new vendor + new parts a single draft may create
COST_TOLERANCE = 0.005

TYPE_TILE = "PO"
TYPE_LABEL = "Purchase order"
SAVE_LABEL = "Save PO, unprocessed"
UNDO_TITLE = "Deletes the PO. Only possible while it is unprocessed."
LINE_COLUMNS = [
    {"key": "item", "label": "Item"},
    {"key": "qty", "label": "Qty", "num": True},
    {"key": "cost", "label": "Cost", "num": True},
    {"key": "amount", "label": "Amount", "num": True},
]
NEW_VALUE = "__new__"          # PATCH value: the line's part picker chose "Create new part"
TAG_FOUND = {"kind": "found", "text": "Found in EBMS"}
TAG_PDF = {"kind": "pdf", "text": "From PDF"}
TAG_OPTIONAL = {"kind": "optional", "text": "Optional"}


# ---------------------------------------------------------------------------
# Formatting (CAD, "$" with thousands separators, cents always on documents)
# ---------------------------------------------------------------------------

def fmt_money(amount, *, unit: bool = False) -> str:
    """$1,234.50. unit=True keeps up to 4 decimals when a unit cost needs them ($0.1235)."""
    a = float(amount)
    sign = "-" if a < 0 else ""
    a = abs(a)
    if unit and round(a, 2) != round(a, 4):
        text = f"{a:,.4f}".rstrip("0")
    else:
        text = f"{a:,.2f}"
    return f"{sign}${text}"


def fmt_qty(q) -> str:
    f = float(q)
    if f.is_integer():
        return f"{int(f):,}" if abs(f) >= 10000 else str(int(f))
    return f"{f:.4f}".rstrip("0").rstrip(".")


def fmt_qty_or_blank(q) -> str:
    """A line's quantity for the card; "" when the document showed none (qty is None)."""
    return "" if q is None else fmt_qty(q)


NO_QTY_TEXT = "Line {n}: the document shows no quantity. Enter it."
NO_TEXT_TEXT = "Line {n} has no part number or description. Pick a part."


def qty_checks(i: int, qty: float | None, amount: float | None) -> list[tuple[str, str]]:
    """The block checks every document line shares (bill, PO, SO), in order: no quantity at
    all, a quantity over MAX_QTY, a line amount over MAX_COST. Each card keeps its own
    "must be more than 0" wording and only applies it to a quantity that exists."""
    out: list[tuple[str, str]] = []
    if qty is None:
        out.append(("block", NO_QTY_TEXT.format(n=i)))
    elif qty > MAX_QTY:
        out.append(("block", f"Line {i} quantity is too large"))
    if amount is not None and abs(amount) > MAX_COST:
        out.append(("block", f"Line {i} amount is too large"))
    return out


def _is_number(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


# A document PO's freight and charge rows are not part lines (D7): they are named, never saved.
CHARGES_MAX = 20            # charge rows kept on the payload; charges_count keeps the true number
CHARGES_NAMED = 5           # charges named in the sentence


def is_charge_row(row: dict) -> bool:
    """A row read from a document PO that is a charge, not a part line: no supplier part
    number, and either an amount with no quantity and no unit price (handling, a fee) or a
    negative amount or unit price (a discount or credit). A row with a part number is always
    a part line."""
    if (row.get("vendor_part_number") or "").strip():
        return False
    amount, qty, price = row.get("amount"), row.get("quantity"), row.get("unit_price")
    if _is_number(amount) and not _is_number(qty) and not _is_number(price):
        return True
    return (_is_number(amount) and amount < 0) or (_is_number(price) and price < 0)


def _charge_line(c: dict) -> str:
    return f"{c.get('description') or '(no description)'} {fmt_money(c['amount'])}"


def charges_text(not_on_order: dict | None) -> str | None:
    """The one sentence for what a document PO shows but the purchase order does not carry."""
    if not not_on_order:
        return None
    freight = not_on_order.get("freight")
    charges = not_on_order.get("charges") or []
    count = max(int(not_on_order.get("charges_count") or 0), len(charges))
    named = ", ".join(_charge_line(c) for c in charges[:CHARGES_NAMED])
    if count > CHARGES_NAMED:
        named += f" and {count - CHARGES_NAMED} more"
    if freight is not None and count:
        return (f"The document shows freight of {fmt_money(freight)} and other charges: {named}. "
                "These are not on the purchase order. Enter them when you enter the bill.")
    if freight is not None:
        return (f"The document shows freight of {fmt_money(freight)}. It is not on the purchase order. "
                "Enter it when you enter the bill.")
    if not count:
        return None
    if count == 1:
        return (f"The document shows other charges: {named}. It is not on the purchase order. "
                "Enter it when you enter the bill.")
    return (f"The document shows other charges: {named}. These are not on the purchase order. "
            "Enter them when you enter the bill.")


# Lines past a draft's cap (D5): kept as plain rows, listed on the card, and they block the save.
SURPLUS_MAX_ROWS = 1000     # lines plus surplus kept in all (the reader's bound; above every draft cap)


def surplus_row(n: int, part: str, description: str, qty, price, amount=None) -> dict:
    """One document line that did not fit on the draft: its number on the document and what
    the document printed, as plain values (never matched, never saved)."""
    row = {"n": n, "part": (part or "")[:HINT_MAX], "description": (description or "")[:200],
           "qty": float(qty) if _is_number(qty) else None,
           "price": float(price) if _is_number(price) else None}
    if _is_number(amount):
        row["amount"] = float(amount)
    return row


def surplus_text(row: dict) -> str:
    """`Line 101: W-77 Hydraulic filter, qty 3, $4.10`; blanks are left out."""
    head = " ".join(x for x in (row.get("part"), row.get("description")) if x)
    first = f"Line {row.get('n')}:" + (f" {head}" if head else "")
    tail = []
    if _is_number(row.get("qty")):
        tail.append(f"qty {fmt_qty(row['qty'])}")
    price = row.get("price") if _is_number(row.get("price")) else row.get("amount")
    if _is_number(price):
        tail.append(fmt_money(price, unit=True))
    if not tail:
        return first
    return first + (", " if head else " ") + ", ".join(tail)


def surplus_check(what: str, cap: int, count: int, surplus: list[dict]) -> dict | None:
    """The block for a document with more lines than the draft's cap. `what` is "bill",
    "purchase order" or "sales order"; `count` is the document's non-blank line count.
    None when nothing was cut. No override: split the document or enter the rest elsewhere."""
    surplus = [r for r in (surplus or []) if isinstance(r, dict)]
    if not surplus and count <= cap:
        return None
    count = max(int(count or 0), cap + len(surplus))
    text = (f"The document has {count} lines; only the first {cap} fit on this {what}. "
            + (f"The other {count - cap} lines are listed below. " if count - cap != 1
               else "The other line is listed below. ") +
            "Split the document, or enter them on another one.")
    if count > SURPLUS_MAX_ROWS:
        text += f" Only lines {cap + 1} to {SURPLUS_MAX_ROWS} are listed."
    return {"level": "block", "text": text, "lines": [surplus_text(r) for r in surplus]}


def surplus_rows(rows: list, cap: int, get) -> list[dict]:
    """The non-blank document rows after the first `cap`, numbered from cap + 1, up to
    SURPLUS_MAX_ROWS in all. `get(row) -> (part, description, qty, price, amount)`."""
    out = []
    for n, ln in enumerate(rows[cap:SURPLUS_MAX_ROWS], cap + 1):
        out.append(surplus_row(n, *get(ln)))
    return out


def fmt_date(d: date) -> str:
    return f"{d:%b} {d.day}, {d.year}"


def _plural(n: int, one: str, many: str | None = None) -> str:
    return f"{n} {one if n == 1 else (many or one + 's')}"


def is_cleared(value) -> bool:
    """A blank string (after trimming) is the user emptying a field; a missing key or None is
    "unchanged". Read by the PO, sales order and bill line patchers (vpa6d)."""
    return isinstance(value, str) and not value.strip()


def _num(value, name: str, *, minimum=None, maximum=None, allow_zero=True) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number.")
    try:
        f = float(str(value).replace(",", "").replace("$", "").strip()) if isinstance(value, str) else float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be a number.")
    if not math.isfinite(f):
        raise ValueError(f"{name} must be a number.")
    if not allow_zero and f <= 0:
        raise ValueError(f"{name} must be more than 0.")
    if minimum is not None and f < minimum:
        raise ValueError(f"{name} can't be negative.")
    if maximum is not None and f > maximum:
        raise ValueError(f"{name} is too large.")
    return f


def _short(value, name: str, max_len: int) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ValueError(f"{name} must be text.")
    value = value.strip()
    if len(value) > max_len:
        raise ValueError(f"{name} must be {max_len} characters or fewer.")
    return value


# ---------------------------------------------------------------------------
# Input normalisation (POST /drafts, PATCH, from-text). ValueError text is safe to show.
# ---------------------------------------------------------------------------

def normalize_lines(lines, *, allow_blank_qty: bool = False) -> list[dict]:
    """Typed input keeps the old rule: a quantity is required and above 0. allow_blank_qty
    (a PATCH of a card) lets a line that carries its card position send "" or None for its
    quantity: a document line the document gave no quantity for shows an empty cell and the
    page sends it back as it is; _carry_line_values then decides whether that is allowed."""
    if lines is None:
        return []
    if not isinstance(lines, list):
        raise ValueError("Lines must be a list.")
    if len(lines) > MAX_LINES:
        raise ValueError(f"A purchase order can have up to {MAX_LINES} lines.")
    out = []
    for i, ln in enumerate(lines, 1):
        if not isinstance(ln, dict):
            raise ValueError(f"Line {i} is not valid.")
        want_new = ln.get("item") == NEW_VALUE
        item = "" if want_new else _short(ln.get("item"), f"Line {i} item", ID_MAX)
        hint = _short(ln.get("item_hint"), f"Line {i} item", HINT_MAX)
        if not item and not hint and not want_new:
            raise ValueError(f"Line {i} needs an item.")
        if (allow_blank_qty and ln.get("line") is not None
                and (ln.get("qty") is None or (isinstance(ln.get("qty"), str) and not ln["qty"].strip()))):
            # blank, or no "qty" key at all, on a line with a card position: _carry_line_values
            # restores the stored quantity (never an invented 1)
            qty = None
        else:
            qty = _num(ln.get("qty", 1), f"Line {i} quantity", maximum=MAX_QTY, allow_zero=False)
        row = {"item": item, "qty": qty}
        if want_new:
            # "Create new part" from the line's picker: resolve_new_parts makes the block
            # (server.py checks the user may add parts)
            row["want_new"] = True
        if hint and not item:
            row["item_hint"] = hint
        if ln.get("cost") is not None and not is_cleared(ln["cost"]):
            row["cost"] = _num(ln.get("cost"), f"Line {i} cost", minimum=0, maximum=MAX_COST)
        matched = _short(ln.get("matched_from"), "matched_from", HINT_MAX)
        if matched and item:
            row["matched_from"] = matched
        out.append(row)
    return out


def normalize_po_input(body: dict) -> dict:
    """POST /drafts body -> the stored payload. Raises ValueError (safe to show)."""
    if not isinstance(body, dict):
        raise ValueError("Draft input must be an object.")
    source = body.get("source") or "menu"
    if source not in SOURCES:
        raise ValueError("Unknown draft source.")
    payload = {
        "type": "po",
        "source": source,
        "vendor": _short(body.get("vendor"), "Vendor", ID_MAX),
        "memo": _short(body.get("memo"), "Memo", MEMO_MAX),
        "lines": normalize_lines(body.get("lines")),
    }
    hint = _short(body.get("vendor_hint"), "Vendor", HINT_MAX)
    if hint and not payload["vendor"]:
        payload["vendor_hint"] = hint
    rv = _short(body.get("reorder_vendor"), "Reorder vendor", ID_MAX)
    if source == "reorder":
        rv = rv or payload["vendor"]
        if not rv:
            raise ValueError("Pick the vendor to reorder from.")
        payload["reorder_vendor"] = rv
        payload["vendor"] = payload["vendor"] or rv
    return payload


def _bare_po_no(text) -> str:
    """"PO#4637", "PO 4637", "#4637", "PO-1001" -> "4637" / "1001" (EBMS keeps PO_NO bare)."""
    t = str(text or "").strip()
    return re.sub(r"^(?:P\.?O\.?)?\s*(?:NO\.?|NUMBER)?\s*[#:\-]*\s*", "", t, flags=re.I).strip() or t


def payload_from_extraction(ext: dict, document: dict | None = None) -> dict:
    """A purchase order read from a document (bill_document kind purchase_order): this
    company's own PO to a supplier, or the supplier's order confirmation. Lines carry the
    supplier's part number (matched through INVENDOR once the vendor is known) and the
    printed description as a fallback search."""
    lines = []
    charges, charges_count, same_as_freight = [], 0, 0
    part_rows = []          # (printed row number, row): the number is the document's, charge rows included
    freight = ext.get("freight")
    freight = float(freight) if _is_number(freight) and freight else None
    for docno, ln in enumerate(ext.get("lines") or [], 1):
        if is_charge_row(ln):
            if (freight is not None and _is_number(ln.get("amount")) and float(ln["amount"]) == freight
                    and (ln.get("description") or "").strip().lower().startswith("freight")):
                same_as_freight += 1      # the header freight already names it: say it once
                continue
            # freight, handling, a discount or credit: named on the card, never a part line (D7)
            charges_count += 1
            if len(charges) < CHARGES_MAX:
                amount = ln.get("amount") if _is_number(ln.get("amount")) else ln.get("unit_price")
                charges.append({"description": (ln.get("description") or "").strip()[:60],
                                "amount": float(amount)})
            continue
        if ((ln.get("vendor_part_number") or "").strip() or (ln.get("description") or "").strip()
                or any(_is_number(ln.get(k)) for k in ("quantity", "unit_price", "amount"))):
            # a row with a quantity, price or amount is goods even with no text: the card blocks it
            part_rows.append((docno, ln))
    for _, ln in part_rows[:MAX_LINES]:
        part = (ln.get("vendor_part_number") or "").strip()[:HINT_MAX]
        desc = (ln.get("description") or "").strip()[:200]
        # The printed quantity and price are kept as they are (0, negative, huge); the card
        # blocks them. A quantity the document did not show stays None and blocks too.
        qty = ln.get("quantity")
        row = {"item": "", "item_hint": (part or desc)[:HINT_MAX],
               "qty": float(qty) if _is_number(qty) else None}
        price = ln.get("unit_price")
        if _is_number(price):
            row["cost"] = float(price)
        if part:
            row["vendor_part"] = part
        if desc:
            row["description"] = desc
        folder = (ln.get("suggested_folder") or "")[:60]
        if folder:
            row["pdf_folder"] = folder
        lines.append(row)
    po_no = _bare_po_no(ext.get("po_number"))[:ID_MAX]
    supplier_order = (ext.get("invoice_number") or "").strip()[:ID_MAX]
    memo = "; ".join(x for x in (f"PO {po_no} (from PDF)" if po_no else "",
                                 f"Supplier order {supplier_order}" if supplier_order else "") if x)
    payload = {"type": "po", "source": "document", "vendor": "", "memo": memo[:MEMO_MAX], "lines": lines,
               "pdf": {"vendor_name": (ext.get("vendor_name") or "").strip()[:HINT_MAX],
                       "po_number": po_no, "supplier_order": supplier_order},
               "edited": [], "new_vendor": None}
    # Rows past the cap are kept as plain rows, listed on the card and block the save (D5)
    payload["surplus_lines"] = [
        surplus_row(docno, (r.get("vendor_part_number") or "").strip(), (r.get("description") or "").strip(),
                    r.get("quantity"), r.get("unit_price"), r.get("amount"))
        for docno, r in part_rows[MAX_LINES:SURPLUS_MAX_ROWS]]
    # the reader's count minus the charge rows it holds (rows past its bound are all counted as lines)
    payload["doc_line_count"] = max(int(ext.get("lines_count") or 0) - charges_count - same_as_freight,
                                    len(part_rows))
    if freight is not None or charges_count:
        payload["not_on_order"] = {"freight": freight, "charges": charges, "charges_count": charges_count}
    hint = (ext.get("vendor_name") or "").strip()[:HINT_MAX]
    if hint:
        payload["vendor_hint"] = hint
    if po_no:
        payload["doc_po"] = po_no
    if document:
        payload["document"] = {"name": document.get("name"), "pages": document.get("pages")}
    return payload


def apply_patch(payload: dict, fields, lines, options: dict | None = None) -> dict:
    """PATCH /drafts/{id}: fields {vendor?, memo?, "new_vendor.<name>"?, "new_part.<line #>.<name>"?};
    lines replaces every line when given (a new part's block stays with its line). A field the
    user changed is remembered in payload["edited"] so it loses its "From PDF" tag."""
    new = dict(payload)
    edited = set(new.get("edited") or [])
    old_vendor = dm.effective_vendor(payload)
    groups = {}
    if fields is not None:
        if not isinstance(fields, dict):
            raise ValueError("Fields must be an object.")
        fields, groups = dm.split_new_fields(fields)
        unknown = set(fields) - {"vendor", "memo"}
        if unknown:
            raise ValueError("Only the vendor, memo, a new vendor and new parts can be changed here.")
        if "vendor" in fields:
            edited.add("vendor")
            new.pop("vendor_hint", None)
            new.pop("vendor_matched_from", None)
            new.pop("vendor_suggested", None)
            if fields["vendor"] == NEW_VALUE:
                # "Create new" from the vendor picker (server.py checks the user may add vendors);
                # resolve_new_vendor builds the block, seeded from the name the document printed
                name = (payload.get("vendor_hint") or payload.get("vendor_matched_from")
                        or (payload.get("pdf") or {}).get("vendor_name") or "").strip()[:HINT_MAX]
                new.update(vendor="", new_vendor=None, want_new_vendor=True)
                if name:
                    new["vendor_hint"] = name
            else:
                v = _short(fields["vendor"], "Vendor", ID_MAX)
                nv = new.get("new_vendor") or {}
                if not (nv and v.upper() == (nv.get("id") or "").upper()):
                    new["vendor"] = v
                    new["new_vendor"] = None
                    new.pop("want_new_vendor", None)
        if "memo" in fields:
            memo = _short(fields["memo"], "Memo", MEMO_MAX)
            if memo != new.get("memo"):
                edited.add("memo")
            new["memo"] = memo
    if lines is not None:
        new["lines"] = normalize_lines(lines, allow_blank_qty=True)
        _carry_line_values(payload.get("lines") or [], lines, new["lines"])
    new["edited"] = sorted(edited)
    for prefix, values in groups.items():
        if prefix == "new_vendor":
            if new.get("new_vendor"):
                new["new_vendor"] = dm.apply_fields("vendor", new["new_vendor"], values, options)
            continue
        parts = prefix.split(".")
        if len(parts) == 2 and parts[0] == "new_part" and parts[1].isdigit():
            i = int(parts[1]) - 1
            cur = new.get("lines") or []
            if 0 <= i < len(cur) and cur[i].get("new_part"):
                ln = dict(cur[i])
                ln["new_part"] = dm.apply_fields("part", ln["new_part"], values, options)
                new["lines"] = cur[:i] + [ln] + cur[i + 1:]
            continue
        raise ValueError("That field can't be changed here.")
    cur_vendor = dm.effective_vendor(new)
    if dm.norm_id(old_vendor) != dm.norm_id(cur_vendor):
        # a new part still on the old vendor moves with the PO (vpa6c)
        new["lines"] = dm.follow_vendor(new.get("lines") or [], old_vendor, cur_vendor)
    return new


STOPWORDS = frozenset({"and", "the", "for", "with", "from", "each", "per", "pcs", "pkg", "box", "qty", "item", "part"})


def description_words(text: str | None) -> set[str]:
    """The meaningful words of a description: lower-case, split on anything that is not a letter
    or digit, without words under 3 characters, pure numbers and STOPWORDS."""
    words = re.split(r"[^a-z0-9]+", (text or "").lower())
    return {w for w in words if len(w) >= 3 and not w.isdigit() and w not in STOPWORDS}


def their_part_check(i: int, printed: str, item_id: str, doc_desc: str | None, ebms_row: dict) -> tuple[str, str]:
    """A line matched on the other company's own part number (it equals one of our IDs): compare
    the document's description with EBMS's (DESCR_1 plus DESCR_2). No shared meaningful word
    blocks; anything else warns. Returns (level, text)."""
    ebms_desc = " ".join(x for x in ((ebms_row.get("description") or "").strip(),
                                     (ebms_row.get("description_2") or "").strip()) if x)
    doc = (doc_desc or "").strip()
    dw, ew = description_words(doc), description_words(ebms_desc)
    if dw and ew and not (dw & ew):
        return "block", (f"Line {i}: the document calls this \u201c{doc}\u201d but EBMS part {item_id} is "
                         f"\u201c{ebms_desc}\u201d. Choose the part.")
    return "warn", (f"Line {i}: the document's number {printed} is EBMS part {item_id}. The document calls it "
                    f"\u201c{doc or '(no description)'}\u201d, EBMS calls it \u201c{ebms_desc or '(no description)'}\u201d. "
                    "Check it's the right part.")


def _carry_line_values(old: list[dict], sent: list, normalized: list[dict]) -> None:
    """Edits send each line's card position ("line", 1-based like sales orders and bills);
    keep what the card doesn't send back: the stored cost (a document's printed price) unless
    a new one was typed, and a document line's supplier part # / description while it is
    still the same hint. A page cached before 2026-10-15 counted PO lines from 0; a "line": 0
    can only come from such a page, so then every position is read the old way, never shifted
    onto the next line."""
    refs = [raw.get("line") for raw in sent if isinstance(raw, dict)]
    shift = 0 if any(r == 0 and not isinstance(r, bool) for r in refs) else 1
    for n, (raw, ln) in enumerate(zip(sent, normalized), 1):
        idx = raw.get("line") if isinstance(raw, dict) else None
        base = None
        if isinstance(idx, int) and not isinstance(idx, bool) and 0 <= idx - shift < len(old):
            base = old[idx - shift]
        if (ln.get("qty") is None and base is not None and isinstance(raw, dict) and "qty" not in raw):
            ln["qty"] = base.get("qty")        # an omitted quantity is the stored one
        if ln.get("qty") is None and (base is None or base.get("qty") is not None):
            # a blank quantity is kept only for a line the document gave none for
            raise ValueError(f"Line {n} quantity must be more than 0.")
        if base is None:
            continue
        if ("cost" not in ln and base.get("cost") is not None
                and not (isinstance(raw, dict) and is_cleared(raw.get("cost")))):
            ln["cost"] = base["cost"]       # unchanged; a blanked cost goes back to EBMS's (vpa6d)
        np = base.get("new_part")
        if ln.get("want_new"):
            # Seed the new part from what the line had (its text, the document's description)
            seed = base.get("item_hint") or base.get("item") or (np or {}).get("id") or ""
            if seed:
                ln["item_hint"] = seed
            for k in ("vendor_part", "description"):
                if base.get(k):
                    ln[k] = base[k]
            continue
        if np and (ln.get("item") or ln.get("item_hint") or "").upper() == (np.get("id") or "").upper():
            # The card shows a new part's ID in the item column; it stays a new part
            ln.pop("item_hint", None)
            ln.update(item="", new_part=np)
            for k in ("vendor_part", "description"):
                if base.get(k):
                    ln[k] = base[k]
            continue
        if base.get("their_part") and base.get("item"):
            bi = base["item"].strip().upper()
            if (ln.get("item_hint") or "").strip().upper() == bi:
                # the page re-sent the shown ID of a line matched on the supplier's number: unchanged
                ln.pop("item_hint", None)
                ln.update(item=base["item"], their_part=True)
                if base.get("matched_from"):
                    ln["matched_from"] = base["matched_from"]
                for k in ("vendor_part", "description"):
                    if base.get(k):
                        ln[k] = base[k]
                continue
            if (ln.get("item") or "").strip().upper() == bi:
                # the user picked the part from the line's search: the flag clears
                ln.pop("matched_from", None)
                for k in ("vendor_part", "description"):
                    if base.get(k):
                        ln[k] = base[k]
                continue
        same = (ln.get("item_hint") and ln["item_hint"] == base.get("item_hint")) or \
               (ln.get("item") and ln["item"] == base.get("item"))
        if same:
            for k in ("vendor_part", "description"):
                if base.get(k):
                    ln[k] = base[k]
            if base.get("matched_from") and ln.get("item"):
                ln["matched_from"] = base["matched_from"]


# ---------------------------------------------------------------------------
# Read-only lookups (SQL on the EBMS mirror)
# ---------------------------------------------------------------------------

def _like(term: str) -> str:
    """ILIKE pattern for a user term with %, _ and backslash escaped (Postgres default escape)."""
    t = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{t}%"


class PoLookups(dm.MasterLookupsMixin):
    """Every method is one parameterised SELECT through `query`. IDs are fixed-width char
    fields in EBMS, so every comparison is upper(trim(...)) on both sides (an equality, not
    ILIKE, so an ID containing % or _ can't act as a wildcard), and every table gets
    "__deleted" IS NOT TRUE."""

    def __init__(self, schema: str, query, reorder_low_sql=None):
        self.s = schema
        self.query = query
        # server.py supplies the /attention reorder "low" CTE body (with quantity columns).
        self.reorder_low_sql = reorder_low_sql

    def _t(self, table: str) -> str:
        return f'"{self.s}"."{table}"'

    def vendor(self, vendor_id: str) -> dict | None:
        rows = self.query(
            f'SELECT trim({self._t("APVENDOR")}."ID") AS id,'
            f' trim(COALESCE({self._t("APVENDOR")}."L_NAME", \'\')) AS l_name,'
            f' trim(COALESCE({self._t("APVENDOR")}."F_NAME", \'\')) AS f_name,'
            f' {self._t("APVENDOR")}."INACTIVE" AS inactive,'
            f' {self._t("APVENDOR")}."LEAD_DAYS" AS lead_days'
            f' FROM {self._t("APVENDOR")}'
            f' WHERE upper(trim({self._t("APVENDOR")}."ID")) = upper(trim(%s))'
            f' AND {self._t("APVENDOR")}."__deleted" IS NOT TRUE LIMIT 1',
            (vendor_id,),
        )
        return rows[0] if rows else None

    def _vendor_cols(self) -> str:
        t = self._t("APVENDOR")
        return (f'trim({t}."ID") AS id, trim(COALESCE({t}."L_NAME", \'\')) AS l_name,'
                f' trim(COALESCE({t}."F_NAME", \'\')) AS f_name, {t}."INACTIVE" AS inactive,'
                f' {t}."LEAD_DAYS" AS lead_days')

    def vendor_search(self, hint: str, *, inactive_only: bool = False, active_normalised: bool = False) -> list[dict]:
        """Active vendors whose name or ID matches. inactive_only=True gives the inactive ones
        instead (drafts_masters.inactive_name_search: the normalised stored name too, the exact
        name first), so an inactive vendor is found and named rather than duplicated (vwzfx)."""
        if inactive_only or active_normalised:
            return self.query(*dm.inactive_name_search(self._t("APVENDOR"), self._vendor_cols(), hint,
                                                       inactive=inactive_only))
        p = _like(hint)
        return self.query(
            f'SELECT trim({self._t("APVENDOR")}."ID") AS id,'
            f' trim(COALESCE({self._t("APVENDOR")}."L_NAME", \'\')) AS l_name,'
            f' trim(COALESCE({self._t("APVENDOR")}."F_NAME", \'\')) AS f_name,'
            f' {self._t("APVENDOR")}."INACTIVE" AS inactive,'
            f' {self._t("APVENDOR")}."LEAD_DAYS" AS lead_days'
            f' FROM {self._t("APVENDOR")}'
            f' WHERE ({self._t("APVENDOR")}."L_NAME" ILIKE %s OR {self._t("APVENDOR")}."F_NAME" ILIKE %s'
            f' OR trim({self._t("APVENDOR")}."ID") ILIKE %s)'
            f' AND {self._t("APVENDOR")}."INACTIVE" IS NOT TRUE'
            f' AND {self._t("APVENDOR")}."__deleted" IS NOT TRUE'
            f' ORDER BY trim({self._t("APVENDOR")}."L_NAME"), trim({self._t("APVENDOR")}."ID") LIMIT {SEARCH_LIMIT}',
            (p, p, p),
        )

    _ITEM_COLS = (
        'trim({t}."ID") AS id, trim(COALESCE({t}."DESCR_1", \'\')) AS description,'
        ' {t}."INACTIVE" AS inactive, {t}."C_TYPE" AS c_type,'
        ' trim(COALESCE({t}."PRI_VENDOR", \'\')) AS pri_vendor, {t}."COST" AS cost,'
        ' trim(COALESCE({t}."DESCR_2", \'\')) AS description_2'
    )

    def items(self, ids: list[str]) -> dict[str, dict]:
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        if not keys:
            return {}
        t = self._t("INVENTRY")
        rows = self.query(
            f'SELECT {self._ITEM_COLS.format(t=t)} FROM {t}'
            f' WHERE upper(trim({t}."ID")) = ANY(%s) AND {t}."__deleted" IS NOT TRUE',
            (keys,),
        )
        return {r["id"].strip().upper(): r for r in rows}

    def item_search(self, hint: str) -> list[dict]:
        t = self._t("INVENTRY")
        p = _like(hint)
        return self.query(
            f'SELECT {self._ITEM_COLS.format(t=t)} FROM {t}'
            f' WHERE ({t}."DESCR_1" ILIKE %s OR trim({t}."ID") ILIKE %s)'
            f' AND {t}."INACTIVE" IS NOT TRUE AND {t}."__deleted" IS NOT TRUE'
            f" AND {t}.\"ID\" NOT LIKE '($)%%'"
            f' ORDER BY trim({t}."ID") LIMIT {SEARCH_LIMIT}',
            (p, p),
        )

    def vendor_costs(self, ids: list[str], vendor_id: str) -> dict[str, float]:
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        if not keys or not vendor_id:
            return {}
        t = self._t("INVENDOR")
        rows = self.query(
            f'SELECT DISTINCT ON (upper(trim({t}."ID"))) upper(trim({t}."ID")) AS item, {t}."COST" AS cost'
            f' FROM {t}'
            f' WHERE upper(trim({t}."ID")) = ANY(%s) AND upper(trim({t}."VENDOR_ID")) = upper(trim(%s))'
            f' AND {t}."COST" > 0 AND {t}."__deleted" IS NOT TRUE'
            f' ORDER BY upper(trim({t}."ID")), {t}."DATE" DESC NULLS LAST',
            (keys, vendor_id),
        )
        return {r["item"]: float(r["cost"]) for r in rows if r.get("cost") is not None}

    PART_BATCH = 100        # supplier part numbers per query (see vendor_part_items)

    def vendor_part_items(self, vendor_id: str, part_nos: list[str]) -> dict[str, list[str]]:
        """{PART_NO (upper): [item ids]} from INVENDOR rows of THIS vendor. A part number's
        item list must be COMPLETE: one item found where EBMS has two would be a false unique
        match, so the query carries no LIMIT (a LIMIT could cut the last part number's items
        mid-list once a long document is looked up). The part numbers go in batches of
        PART_BATCH, which keeps each query small; the rows are bounded by the document's part
        numbers times the items each one maps to."""
        keys = sorted({p.strip().upper() for p in part_nos if p and p.strip()})
        if not keys or not vendor_id:
            return {}
        t = self._t("INVENDOR")
        out: dict[str, list[str]] = {}
        for i in range(0, len(keys), self.PART_BATCH):
            rows = self.query(
                f'SELECT DISTINCT upper(trim({t}."PART_NO")) AS part_no, trim({t}."ID") AS item FROM {t}'
                f' WHERE upper(trim({t}."VENDOR_ID")) = upper(trim(%s)) AND upper(trim({t}."PART_NO")) = ANY(%s)'
                f' AND {t}."__deleted" IS NOT TRUE ORDER BY 1, 2',
                (vendor_id, keys[i:i + self.PART_BATCH]),
            )
            for r in rows:
                out.setdefault(r["part_no"], [])
                if r["item"] not in out[r["part_no"]]:
                    out[r["part_no"]].append(r["item"])
        return out

    def pos_by_number(self, po_no: str) -> list[dict]:
        """EBMS documents already carrying this PO number (PO_NO, or INVOICE "PO#<n>")."""
        t = self._t("APINV")
        return self.query(
            f'SELECT trim(COALESCE({t}."PO_NO", \'\')) AS po_no, trim({t}."INVOICE") AS invoice,'
            f' trim({t}."ID") AS vendor_id, {t}."STATUS" AS status, trim({t}."AUTOID") AS doc_id FROM {t}'
            f' WHERE (upper(trim({t}."PO_NO")) = upper(trim(%s)) OR upper(trim({t}."INVOICE")) = upper(%s))'
            f' AND {t}."__deleted" IS NOT TRUE LIMIT 5',
            (po_no, "PO#" + str(po_no).strip()),
        )

    def open_pos(self, ids: list[str]) -> list[dict]:
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        if not keys:
            return []
        h, d = self._t("APINV"), self._t("APINVDET")
        return self.query(
            f'SELECT DISTINCT upper(trim({d}."INVEN")) AS item,'
            f' COALESCE(NULLIF(trim({h}."PO_NO"), \'\'), trim({h}."INVOICE")) AS doc,'
            f' trim({h}."ID") AS vendor_id, trim({h}."INVOICE") AS invoice, trim({h}."AUTOID") AS doc_id'
            f' FROM {h} JOIN {d} ON {h}."AUTOID" = {d}."DOC_AID"'
            f" WHERE {h}.\"STATUS\" = 'U' AND {h}.\"__deleted\" IS NOT TRUE AND {d}.\"__deleted\" IS NOT TRUE"
            f' AND upper(trim({d}."INVEN")) = ANY(%s)'
            f' ORDER BY 2, 1 LIMIT {OPEN_PO_ROWS}',
            (keys,),
        )

    def _open_po_parts_sql(self) -> str:
        """`(SELECT part IDs ...)` of this vendor's open unprocessed PO lines, one placeholder
        (the vendor ID). Same definition as BillLookups.open_po_lines: STATUS U, nothing paid,
        INVOICE "PO#<n>"; part IDs upper(trim(...)) like every item lookup."""
        h, d = self._t("APINV"), self._t("APINVDET")
        return (f"(SELECT upper(trim({d}.\"INVEN\")) FROM {h}"
                f" JOIN {d} ON {h}.\"AUTOID\" = {d}.\"DOC_AID\""
                f" WHERE {h}.\"STATUS\" = 'U' AND upper(trim({h}.\"ID\")) = upper(trim(%s))"
                f" AND {h}.\"__deleted\" IS NOT TRUE AND {d}.\"__deleted\" IS NOT TRUE"
                f" AND COALESCE({h}.\"TOTAL_PAID\", 0) = 0"
                f" AND trim({h}.\"INVOICE\") LIKE 'PO#%%' AND {d}.\"INVEN\" IS NOT NULL)")

    @staticmethod
    def _clean_ids(ids) -> list[str]:
        return sorted({str(i).strip().upper() for i in ids or () if str(i).strip()})

    def reorder_lines(self, vendor_id: str, skip_open_po: bool = False, exclude_items=()) -> list[dict]:
        """Rows {item_id, on_hand, min_inven, max_inven, total} for this primary vendor, the
        first MAX_LINES by part ID; `total` (the same on every row) is how many parts are below
        their reorder point in all, so a caller can tell when parts were left out. With
        skip_open_po, parts already on one of this vendor's open unprocessed POs are left out of
        the rows and the total, and so are `exclude_items` (parts on this app's own just-saved
        reorder POs, which the lagging mirror does not show yet): that is what makes the parts
        past the cap reachable by a second request."""
        if self.reorder_low_sql is None:
            return []
        # The shared CTE carries a literal '($)%' pattern; with a bound parameter psycopg
        # treats a bare % as a placeholder, so double it.
        low = self.reorder_low_sql().replace("%", "%%")
        skip, params = "", [vendor_id]
        if skip_open_po:
            ex = self._clean_ids(exclude_items)
            skip = f" AND upper(trim(low.item_id)) NOT IN {self._open_po_parts_sql()}"
            if ex:
                skip += " AND upper(trim(low.item_id)) <> ALL(%s)"
            params += [vendor_id] + ([ex] if ex else [])
        return self.query(
            f"WITH low AS ({low}\n) SELECT trim(low.item_id) AS item_id, low.on_hand, low.min_inven, low.max_inven,"
            f" count(*) OVER () AS total"
            f" FROM low WHERE upper(low.vendor_id) = upper(trim(%s)){skip} ORDER BY trim(low.item_id) LIMIT {MAX_LINES}",
            tuple(params),
        )

    def reorder_skipped(self, vendor_id: str, exclude_items=()) -> list[dict]:
        """The low parts reorder_lines(skip_open_po=True, ...) leaves out: rows {item_id, total},
        the first REORDER_SKIPPED_SHOWN by part ID, `total` being how many there are."""
        if self.reorder_low_sql is None:
            return []
        low = self.reorder_low_sql().replace("%", "%%")
        ex = self._clean_ids(exclude_items)
        either = f"(upper(trim(low.item_id)) IN {self._open_po_parts_sql()}" + (
            " OR upper(trim(low.item_id)) = ANY(%s))" if ex else ")")
        return self.query(
            f"WITH low AS ({low}\n) SELECT trim(low.item_id) AS item_id, count(*) OVER () AS total"
            f" FROM low WHERE upper(low.vendor_id) = upper(trim(%s)) AND {either}"
            f" ORDER BY trim(low.item_id) LIMIT {REORDER_SKIPPED_SHOWN}",
            tuple([vendor_id, vendor_id] + ([ex] if ex else [])),
        )


def resolve_new_vendor(payload: dict, lookups, can_create: dict | None) -> dict:
    """The new-vendor block for a PO (same rule as a bill): when the picker chose "Create new",
    or a document/text vendor name matches no vendor in EBMS, and the user may add vendors. The
    block is seeded from the name (ID suggested from it, the usual folder). Runs on every build,
    edits included, and is idempotent."""
    out = dict(payload)
    want = out.pop("want_new_vendor", None)
    if out.get("new_vendor") and (can_create or {}).get("vendor"):
        before = out["new_vendor"].get("id")
        out["new_vendor"] = dm.refresh_auto_id(out["new_vendor"], lambda i: lookups.record_exists("vendor", i), 10)
        if dm.norm_id(before) != dm.norm_id(out["new_vendor"].get("id")):
            out["lines"] = dm.follow_vendor(out.get("lines") or [], before, out["new_vendor"].get("id"))
    if not (can_create or {}).get("vendor") or out.get("vendor") or out.get("new_vendor"):
        return out
    hint = (out.get("vendor_hint") or "").strip()
    if not hint and not want:
        return out
    if want or (out.get("source") in ("document", "text") and not dm.match_vendor(hint, lookups)[0]):
        out["new_vendor"] = dm.new_record(
            "vendor", name=hint[:50], id=dm.suggest_id(hint, lambda i: lookups.record_exists("vendor", i), 10),
            folder=lookups.common_folder("vendor") or "")
    return out


def resolve_new_parts(payload: dict, lookups, can_create: dict | None) -> dict:
    """New-part blocks for a PO's lines (86e3q4ze8), only when the user may add parts. A line whose
    picker chose "Create new part" always gets one. A line read from a DOCUMENT gets one by itself
    when it has a supplier part # and nothing in EBMS matches it or its description (several
    matches stay a "pick one"; a line with no part # is often a charge like freight, so the user
    decides). At most MAX_NEW_RECORDS records per draft, a new vendor counting as one; lines past
    that stay unmatched. The block is seeded from the line: ID from the supplier part # or text,
    description, folder of the most similar part, cost, and this PO's vendor as primary."""
    if not (can_create or {}).get("part"):
        out = dict(payload)
        out["lines"] = [{k: v for k, v in ln.items() if k != "want_new"} for ln in payload.get("lines") or []]
        return out
    out = dict(payload)
    lines = []
    used = ((1 if payload.get("new_vendor") and can_create.get("vendor") else 0)
            + sum(1 for ln in payload.get("lines") or [] if ln.get("new_part") or ln.get("want_new")))
    taken_ids = {dm.norm_id((ln.get("new_part") or {}).get("id")) for ln in payload.get("lines") or []} - {""}
    for ln in payload.get("lines") or []:
        ln = dict(ln)
        want = ln.pop("want_new", False)
        if (not want and payload.get("source") == "document" and used < MAX_NEW_RECORDS
                and not ln.get("item") and not ln.get("new_part") and (ln.get("vendor_part") or "").strip()):
            texts = [t for t in ((ln.get("item_hint") or "").strip(), (ln.get("description") or "").strip()) if t]
            if texts and not any(lookups.item_search(t) for t in texts):
                want = True
                used += 1
        if want and not ln.get("new_part"):
            seed = ln.get("vendor_part") or ln.get("item_hint") or ln.get("description") or ""
            desc = ln.get("description") or ln.get("item_hint") or ""
            new_id = dm.suggest_id(
                seed, lambda i: lookups.record_exists("part", i) or dm.norm_id(i) in taken_ids, 24)
            taken_ids.add(dm.norm_id(new_id))
            ln["new_part"] = dm.new_record(
                "part", id=new_id,
                description=desc[:80], folder=lookups.suggested_part_folder(desc, ln.get("pdf_folder")) or "",
                cost=ln.get("cost") if ln.get("cost") is not None else "",
                vendor=dm.effective_vendor(payload)[:10])
            ln["item"] = ""
            ln.pop("item_hint", None)
        lines.append(ln)
    out["lines"] = dm.fill_part_vendor(lines, dm.effective_vendor(payload))
    return out


def reorder_qty(on_hand, min_inven, max_inven) -> float:
    """MAX_INVEN - on_hand when MAX_INVEN is set (> 0) and above on_hand, else MIN_INVEN -
    on_hand; rounded up to a whole unit; never less than 1."""
    oh = float(on_hand or 0)
    mn = float(min_inven or 0)
    mx = float(max_inven or 0)
    need = mx - oh if (mx > 0 and mx > oh) else mn - oh
    return float(max(1, math.ceil(need - 1e-9)))


def vendor_display(v: dict) -> str:
    l_name = (v.get("l_name") or "").strip()
    f_name = (v.get("f_name") or "").strip()
    name = f"{f_name} {l_name}".strip() if f_name else l_name
    return name or (v.get("id") or "").strip()


def vendor_name_id(v: dict) -> str:
    """"Name (ID)", or just the ID for a vendor with no name."""
    name, vid = vendor_display(v), (v.get("id") or "").strip()
    return vid if name == vid else f"{name} ({vid})"


# ---------------------------------------------------------------------------
# Resolution (hints -> real IDs) and the card
# ---------------------------------------------------------------------------

def resolve_reorder(payload: dict, lookups: PoLookups, recent_items=None) -> dict:
    """source=reorder at creation: fill lines from the reorder rule (stored, so later edits stick).
    A PO holds MAX_LINES lines. When more parts are below their reorder point, the first
    MAX_LINES by part ID are used that are not already on an open unprocessed PO to this vendor
    and not on this app's own recently saved reorder POs for it (`recent_items(vendor)` -> part
    IDs; the mirror lags EBMS, so a PO saved a minute ago is not on it yet), so the rest are
    reachable by asking again once this PO is saved. `reorder_more` (parts left off for lack of
    room), `reorder_total`, `reorder_skipped` and `reorder_skipped_ids` (up to 10, parts left off
    because they are already on order or were just saved) feed the card's warning."""
    out = dict(payload)
    vendor = payload["reorder_vendor"]
    rows = lookups.reorder_lines(vendor)
    total = int(rows[0].get("total") or len(rows)) if rows else 0
    skipped, skipped_ids = 0, []
    if total > MAX_LINES:
        recent = list(recent_items(vendor)) if recent_items else []
        rows = lookups.reorder_lines(vendor, skip_open_po=True, exclude_items=recent)
        new_total = int(rows[0].get("total") or len(rows)) if rows else 0
        gone = lookups.reorder_skipped(vendor, recent)
        skipped = int(gone[0].get("total") or len(gone)) if gone else max(0, total - new_total)
        skipped_ids = [str(r["item_id"]).strip() for r in gone][:REORDER_SKIPPED_SHOWN]
        total = new_total
    rows = rows[:MAX_LINES]
    out["reorder_total"] = total
    out["reorder_more"] = max(0, total - len(rows))
    out["reorder_skipped"] = skipped
    out["reorder_skipped_ids"] = skipped_ids
    out["lines"] = [{"item": r["item_id"].strip(), "qty": reorder_qty(r.get("on_hand"), r.get("min_inven"), r.get("max_inven")),
                     "reorder": {"on_hand": float(r.get("on_hand") or 0), "min": float(r.get("min_inven") or 0),
                                 "max": float(r.get("max_inven") or 0)}}
                    for r in rows]
    return out


def resolve_reorder_all(payload: dict, lookups: PoLookups) -> dict:
    """A typed "order everything that needs reordering from <vendor>" (payload["reorder_all"],
    set by the text extractor). The vendor hint is resolved like any text draft; when it names
    exactly one vendor the draft becomes a source=reorder draft for that vendor (lines filled by
    resolve_reorder, as the Needs attention button does). When the vendor is not resolved, the
    draft stays empty with the hint kept and source=menu, so no "create new vendor" is suggested
    for a name that was only a guess and the card asks the user to pick the vendor."""
    out = {k: v for k, v in payload.items() if k != "reorder_all"}
    out = resolve_hints(out, lookups)
    guess = out.get("vendor_matched_from")
    if guess and out.get("vendor"):
        # a name match is accepted only when the NORMALISED names are equal; "Acme Inc" must not
        # become a reorder draft for "Acme West" (resolve_hints's looser Q9 match is for typed POs)
        from drafts_bill import norm_name
        v = lookups.vendor(out["vendor"])
        if v is None or norm_name(vendor_display(v)) != norm_name(guess):
            out.pop("vendor")
            out["vendor_hint"] = out.pop("vendor_matched_from")
    if out.get("vendor"):
        out["source"] = "reorder"
        out["reorder_vendor"] = out["vendor"]
        return out
    out["source"] = "menu"
    return out


def resolve_hints(payload: dict, lookups: PoLookups) -> dict:
    """Turn model-extracted hints into real IDs where the match is unambiguous: exact ID
    first, then a name search. Ambiguous or missing hints stay as hints (the card blocks).
    Never guesses between several matches."""
    out = dict(payload)
    hint = out.get("vendor_hint")
    if hint and not out.get("vendor"):
        found, exact = dm.match_vendor(hint, lookups)
        if exact is not None:
            out["vendor"] = exact["id"]
            out.pop("vendor_hint")
        elif len(found) == 1:
            out["vendor"] = found[0]["id"]
            out["vendor_matched_from"] = out.pop("vendor_hint")
    lines = []
    # A document's lines: the supplier's part number through INVENDOR first (one item only)
    vparts = [ln["vendor_part"] for ln in out.get("lines", []) if ln.get("vendor_part") and not ln.get("item")]
    by_part = lookups.vendor_part_items(out["vendor"], vparts) if (vparts and out.get("vendor")) else {}
    hinted = [ln["item_hint"] for ln in out.get("lines", []) if ln.get("item_hint") and not ln.get("item")]
    exact = lookups.items(hinted) if hinted else {}
    for ln in out.get("lines", []):
        ln = dict(ln)
        h = ln.get("item_hint")
        if h and not ln.get("item"):
            via_part = by_part.get((ln.get("vendor_part") or "").strip().upper()) or []
            hit = exact.get(h.strip().upper())
            if len(via_part) == 1:
                # The supplier's part number is set up on this part's vendor record in EBMS
                # (INVENDOR): an exact, configured link, so no "check it's the right part" flag.
                ln["item"] = via_part[0]
                ln.pop("item_hint")
            elif hit is not None:
                ln["item"] = hit["id"]
                ln.pop("item_hint")
                vp = (ln.get("vendor_part") or "").strip()
                if vp and h.strip().upper() == vp.upper():
                    # found by the supplier's own number equal to our ID, not through INVENDOR
                    ln["their_part"] = True
                    ln["matched_from"] = vp
            else:
                found = lookups.item_search(h)
                if not found and ln.get("description") and ln["description"] != h:
                    found = lookups.item_search(ln["description"])
                if len(found) == 1:
                    ln["item"] = found[0]["id"]
                    ln["matched_from"] = ln.pop("item_hint")
        lines.append(ln)
    out["lines"] = lines
    # No vendor named: suggest the parts' shared primary vendor.
    if not out.get("vendor") and not out.get("vendor_hint") and lines and all(ln.get("item") for ln in lines):
        items = lookups.items([ln["item"] for ln in lines])
        pris = {(items.get(ln["item"].upper()) or {}).get("pri_vendor", "").strip().upper() for ln in lines}
        if len(pris) == 1 and "" not in pris:
            v = lookups.vendor(pris.pop())
            if v is not None:
                out["vendor"] = v["id"]
                out["vendor_suggested"] = True
    return out


def build_po_card(payload: dict, lookups: PoLookups, *, today: date, can_create: dict | None = None,
                  options: dict | None = None) -> dict:
    """The card body (everything except the envelope: id, status, saved, may_lag, where,
    created_at, updated_at) plus "_api": the header and lines (and new parts to create first)
    to send to EBMS when the card is not blocking. Pure given the lookups."""
    checks: list[dict] = []
    can = can_create or {}
    new_fields, new_records, records = [], [], []   # records: the card's new-record blocks

    def check(level, text, ebms=None, lines=None):
        # ebms: the EBMS record the check is about, as an ebms_links reference (86e1x1xkr)
        # lines: optional list of strings the card lists under the check
        checks.append({"level": level, "text": text, **({"ebms": ebms} if ebms else {}),
                       **({"lines": list(lines)} if lines else {})})

    # ---- vendor
    vendor_id = (payload.get("vendor") or "").strip()
    vendor = lookups.vendor(vendor_id) if vendor_id else None
    vname = vendor_display(vendor) if vendor else ""
    vendor_tag = None
    vendor_hint_text = None
    nv = payload.get("new_vendor")
    vendor_fields = []     # the new vendor's own fields, shown under the vendor
    from_doc = payload.get("source") == "document"
    edited = set(payload.get("edited") or [])
    if vendor_id and vendor is None:
        check("block", f"{vendor_id} isn't a vendor in EBMS")
        vendor_hint_text = "Not found in EBMS"
    elif vendor is None and nv:
        if can.get("vendor"):
            vname = nv.get("name") or payload.get("vendor_hint") or ""
            vendor_tag = dict(dm.NEW_TAG)
            vendor_fields = dm.record_fields("vendor", nv, "new_vendor", options)
            rc = dm.record_checks("vendor", nv, lookups, what="new vendor")
            # an inactive vendor of the same name: "Create new" would duplicate it (vwzfx)
            text = dm.new_vendor_name_block(nv.get("name") or payload.get("vendor_hint") or "", lookups)
            if text:
                rc.append(("block", text))
            for lv, text in rc:
                check(lv, text)
            records.append(dm.record_meta("vendor", nv, "new_vendor", options, rc, field="vendor"))
            new_records.append({"kind": "vendor", "tag": "V", "rec": dict(nv)})
            if vname and getattr(lookups, "customer_search", None) and lookups.customer_search(vname):
                check("warn", f"{vname} is a customer in EBMS. Is this a sales order rather than a purchase order?")
        else:
            check("block", dm.blocked_text(payload.get("vendor_hint") or nv.get("name") or "This vendor", "vendor", can))
    elif vendor is None:
        hint = payload.get("vendor_hint")
        if hint:
            found, _ = dm.match_vendor(hint, lookups)
            if found:
                names = ", ".join(vendor_display(v) + (" (inactive)" if v.get("inactive") is True else "")
                                  for v in found[:3])
                more = "" if len(found) <= 3 else f" and {len(found) - 3} more"
                check("block", f"“{hint}” matches {_plural(len(found), 'vendor')}: {names}{more}. Pick one.")
            else:
                check("block", f"No vendor in EBMS matches “{hint}”")
            vendor_hint_text = f"You said “{hint}”"
        else:
            check("block", "Pick a vendor")
            vendor_hint_text = "Vendor ID or name"
    else:
        if vendor.get("inactive") is True:
            check("block", f"{vendor_name_id(vendor)} is inactive in EBMS. Make it active in EBMS, then open "
                           "this draft again, or pick another vendor.")
        if payload.get("vendor_matched_from"):
            vendor_tag = {"kind": "matched", "text": f"Matched “{payload['vendor_matched_from']}”"}
            check("warn", f"Matched “{payload['vendor_matched_from']}” to {vname} ({vendor['id']}). Check it's the right vendor.")
        elif payload.get("vendor_suggested"):
            vendor_tag = {"kind": "suggested", "text": "Primary vendor"}
        else:
            vendor_tag = dict(TAG_FOUND)

    # ---- lines
    raw_lines = payload.get("lines") or []
    ids = [ln["item"] for ln in raw_lines if ln.get("item")]
    items = lookups.items(ids) if ids else {}
    vcosts = lookups.vendor_costs(ids, vendor["id"]) if (ids and vendor) else {}
    card_lines, api_lines = [], []
    subtotal = 0.0
    resolved = []          # (line, item_row)
    missing_cost, cost_diffs = [], []
    amounts: dict[int, float | None] = {}     # line number -> its amount, for the "too large" check
    for i, ln in enumerate(raw_lines, 1):
        qty = None if ln.get("qty") is None else float(ln["qty"])     # None: the document showed none
        item_id = (ln.get("item") or "").strip()
        row = items.get(item_id.upper()) if item_id else None
        np = ln.get("new_part")
        if row is None and np and not item_id:
            if can.get("part"):
                label = f"new part on line {i}"
                setup = lookups.folder_setup(np.get("folder"))
                new_fields += dm.record_fields("part", np, f"new_part.{i}", options, setup=setup)
                rc = dm.record_checks("part", np, lookups, what=label, setup=setup,
                                      pending_vendor=(nv or {}).get("id") if (nv and vendor is None and can.get("vendor")) else None)
                for lv, text in rc:
                    check(lv, text)
                records.append(dm.record_meta("part", np, f"new_part.{i}", options, rc, setup=setup))
                new_records.append({"kind": "part", "tag": f"P{i}", "rec": dict(np), "line": i})
                cost = ln.get("cost")
                if cost is None and np.get("cost") not in (None, ""):
                    cost = float(np["cost"])
                amount = round(qty * float(cost), 2) if (cost is not None and qty is not None) else None
                amounts[i] = amount
                subtotal += amount or 0.0
                card_lines.append({"item": np.get("id") or "", "description": "New part: " + (np.get("description") or ""),
                                   "qty": fmt_qty_or_blank(qty), "cost": fmt_money(cost, unit=True) if cost is not None else "",
                                   "amount": fmt_money(amount) if amount is not None else "", "editable": ["qty", "cost"],
                                   "record": f"new_part.{i}"})
                api_lines.append({"item": np.get("id") or "", "qty": qty, "cost": None if cost is None else float(cost)})
                continue
            check("block", dm.blocked_text(np.get("id") or f"Line {i}'s part", "part", can))
            card_lines.append({"item": np.get("id") or "", "description": np.get("description") or "",
                               "qty": fmt_qty_or_blank(qty), "cost": "", "amount": "", "editable": ["item", "qty", "cost"],
                               "lookup": "part", "query": np.get("id") or "", "can_create": False})
            continue
        if row is None:
            if item_id:
                check("block", f"{item_id} isn't an item in EBMS")
                display, desc = item_id, "Not found in EBMS"
            else:
                h = ln.get("item_hint") or ""
                found = lookups.item_search(h) if h else []
                if not h:
                    check("block", NO_TEXT_TEXT.format(n=i))
                elif found:
                    names = ", ".join(r["id"] for r in found[:3])
                    more = "" if len(found) <= 3 else f" and {len(found) - 3} more"
                    check("block", f"“{h}” matches {_plural(len(found), 'part')}: {names}{more}. Pick one.")
                else:
                    check("block", f"No part in EBMS matches “{h}”")
                display, desc = h, ln.get("description") or "Not matched to a part yet"
            card_lines.append({"item": display, "description": desc, "qty": fmt_qty_or_blank(qty), "cost": "",
                               "amount": "", "editable": ["item", "qty", "cost"],
                               "lookup": "part", "query": display or "", "can_create": bool(can.get("part"))})
            continue
        real_id = row["id"].strip()
        if row.get("inactive") is True:
            check("block", f"{real_id} is inactive in EBMS")
        their = bool(ln.get("their_part"))
        if their:
            lv, text = their_part_check(i, ln.get("matched_from") or ln.get("vendor_part") or "", real_id,
                                        ln.get("description"), row)
            check(lv, text)
        elif ln.get("matched_from"):
            check("warn", f"Matched “{ln['matched_from']}” to {real_id} {row.get('description') or ''}".rstrip()
                  + ". Check it's the right part.")
        current = vcosts.get(real_id.upper())
        if current is None and row.get("cost") is not None and float(row["cost"]) > 0:
            current = float(row["cost"])
        cost = ln.get("cost")
        if cost is None:
            cost = current
            if current is None:
                missing_cost.append(real_id)
        elif current is not None and abs(float(cost) - current) > COST_TOLERANCE:
            cost_diffs.append((real_id, float(cost), current))
        amount = round(qty * float(cost), 2) if (cost is not None and qty is not None) else None
        amounts[i] = amount
        subtotal += amount or 0.0
        card_lines.append({
            "item": real_id, "description": row.get("description") or "",
            "qty": fmt_qty_or_blank(qty), "cost": fmt_money(cost, unit=True) if cost is not None else "",
            "amount": fmt_money(amount) if amount is not None else "",
            "editable": ["item", "qty", "cost"] if their else ["qty", "cost"],
            "ebms": ebms_links.ref("INVENTRY", real_id),
            **({"lookup": "part", "query": real_id, "can_create": bool(can.get("part"))} if their else {}),
        })
        api_lines.append({"item": real_id, "qty": qty, "cost": None if cost is None else float(cost)})
        resolved.append((ln, row))

    if not raw_lines:
        check("block", "Add at least one part")
    for i, ln in enumerate(raw_lines, 1):
        q = None if ln.get("qty") is None else float(ln["qty"])
        for lv, text in qty_checks(i, q, amounts.get(i)):
            check(lv, text)
        if q is not None and q <= 0:
            check("block", f"Quantity for {ln.get('item') or ln.get('item_hint')} must be more than 0")
        # a PO line is always a part: a negative printed cost blocks (a discount row is a charge, D7)
        c = ln.get("cost")
        if c is None and ln.get("new_part") and _is_number((ln["new_part"] or {}).get("cost")):
            c = ln["new_part"]["cost"]
        if _is_number(c) and c < 0:
            check("block", f"Line {i} cost can't be negative for a part")
    # ---- cost (only a cost the user or the document gave can differ from EBMS's;
    # a part with no cost on file is left to EBMS's own default, no warning)
    if resolved:
        for item_id, cost, current in cost_diffs:
            check("warn", f"{item_id} cost {fmt_money(cost, unit=True)} differs from its current cost {fmt_money(current, unit=True)}")
        if not cost_diffs and not missing_cost:
            check("good", "Costs match each part’s current cost in EBMS")

    # ---- open POs
    if resolved:
        open_rows = lookups.open_pos([row["id"] for _, row in resolved])
        if not open_rows:
            check("good", "No open PO already covers " + ("these parts" if len(resolved) > 1 else "this part"))
        else:
            by_doc: dict[str, list[str]] = {}
            vend_of: dict[str, str] = {}
            link_of: dict[str, dict | None] = {}
            for r in open_rows:
                by_doc.setdefault(r["doc"], []).append(r["item"])
                vend_of[r["doc"]] = r.get("vendor_id") or ""
                link_of[r["doc"]] = ebms_links.ref("APINV", r.get("vendor_id"), r.get("invoice"), autoid=r.get("doc_id"))
            for doc, its in list(by_doc.items())[:5]:
                frm = f" ({vend_of[doc]})" if vend_of[doc] else ""
                ids = sorted(set(its))
                shown = ", ".join(ids[:OPEN_PO_IDS_SHOWN]) + (
                    f" and {len(ids) - OPEN_PO_IDS_SHOWN} more" if len(ids) > OPEN_PO_IDS_SHOWN else "")
                check("warn", f"Open PO {doc}{frm} already has {shown} on order",
                      ebms=link_of.get(doc))
            if len(by_doc) > 5:
                check("warn", f"and {len(by_doc) - 5} more open purchase orders already have some of these parts on order")

    # ---- the document's own PO number (source=document)
    doc_po = (payload.get("doc_po") or "").strip()
    if doc_po:
        dups = lookups.pos_by_number(doc_po)
        if dups:
            d = dups[0]
            frm = f" for {d['vendor_id']}" if d.get("vendor_id") else ""
            check("warn", f"PO {doc_po} is already in EBMS{frm}. Saving creates a second purchase order; "
                          "skip it if this PDF was printed from EBMS.",
                  ebms=ebms_links.ref("APINV", d.get("vendor_id"), d.get("invoice"), autoid=d.get("doc_id")))
        else:
            check("good", f"No PO {doc_po} in EBMS yet. EBMS gives the new PO its own number; "
                          f"{doc_po} goes in the memo.")

    if len(new_records) > MAX_NEW_RECORDS:
        check("block", f"A draft can create at most {MAX_NEW_RECORDS} new records. Add some in EBMS first.")
    dups, dup_keys = dm.duplicate_id_checks(new_records)
    for level, text in dups:
        check(level, text)
    for rec in records:
        if rec["key"] in dup_keys:
            rec["expand"] = True

    # ---- lines past the cap: kept, listed, and they block (D5)
    cut = surplus_check("purchase order", MAX_LINES, payload.get("doc_line_count") or 0,
                        payload.get("surplus_lines") or [])
    if cut:
        check(cut["level"], cut["text"], lines=cut["lines"])

    # ---- a reorder PO that could not hold every part below its reorder point
    if payload.get("source") == "reorder" and (payload.get("reorder_more") or payload.get("reorder_skipped")):
        who = vname or payload.get("reorder_vendor")
        more, total = int(payload.get("reorder_more") or 0), int(payload.get("reorder_total") or 0)
        skipped = int(payload.get("reorder_skipped") or 0)
        bits = []
        if more:
            bits.append(f"{who} has {total} parts below their reorder point; only the first {MAX_LINES} "
                        "(by part ID) fit on this PO. Save this one, then order the rest separately.")
        if skipped:
            ids = list(payload.get("reorder_skipped_ids") or [])
            named = ", ".join(ids) + (f" and {skipped - len(ids)} more" if skipped > len(ids) else "")
            bits.append(f"{_plural(skipped, 'part')} below their reorder point "
                        f"{'was' if skipped == 1 else 'were'} left off because a purchase order for "
                        f"{'it is' if skipped == 1 else 'them is'} already open or was just saved"
                        + (f" ({named})." if ids else "."))
        check("warn", " ".join(bits))

    # ---- what the document shows that the PO doesn't carry: freight, discounts, other charges (D7)
    not_carried = charges_text(payload.get("not_on_order"))
    if not_carried:
        listed = [_charge_line(c) for c in (payload["not_on_order"].get("charges") or [])]
        check("warn", not_carried, lines=listed)

    # ---- fields
    lead_days = None
    if vendor is not None and vendor.get("lead_days") is not None:
        try:
            lead_days = int(float(vendor["lead_days"]))
        except (TypeError, ValueError):
            lead_days = None
    expected = today + timedelta(days=lead_days) if lead_days and lead_days > 0 else None
    memo = payload.get("memo") or ""
    new_vendor_id = (nv or {}).get("id") if new_records and nv and vendor is None else None
    fields = [
        {"key": "vendor", "label": "Vendor", "value": vendor["id"] if vendor else (new_vendor_id or vendor_id),
         "display": vname or vendor_id or (payload.get("vendor_hint") or ""), "tag": vendor_tag,
         "editable": True, "input": "text", "hint": vendor_hint_text,
         # Picker (GET /lookup/vendor); "Create new" when the user may add vendors
         "lookup": "vendor", "can_create": can.get("vendor") is True,
         **({"query": payload.get("vendor_hint") or vendor_id} if vendor is None else {}),
         **({"ebms": ebms_links.ref("APVENDOR", vendor["id"])} if vendor else {})},
        {"key": "order_date", "label": "Order date", "value": today.isoformat(), "display": fmt_date(today),
         "tag": None, "editable": False, "input": "date", "hint": None},
        {"key": "expected", "label": "Expected", "value": expected.isoformat() if expected else None,
         "display": fmt_date(expected) if expected else "Not set",
         "tag": {"kind": "suggested", "text": f"{lead_days}-day lead time"} if expected else None,
         "editable": False, "input": "date",
         "hint": None if expected else "No lead time on file for this vendor"},
        *vendor_fields,
        {"key": "memo", "label": "Memo", "value": memo, "display": memo,
         "tag": (dict(TAG_PDF) if from_doc and "memo" not in edited else None) if memo else dict(TAG_OPTIONAL),
         "editable": True, "input": "text", "hint": None},
    ]
    fields += new_fields

    n_parts = len(raw_lines)
    total_text = fmt_money(subtotal)
    if vname:
        title = f"{vname}, {_plural(n_parts, 'part')}" if n_parts else vname
    else:
        title = "New purchase order"
    source = payload.get("source") or "menu"
    if source == "reorder":
        if n_parts:
            if payload.get("reorder_more"):
                what = f"the first {n_parts} of {payload.get('reorder_total')} parts below their reorder point"
            else:
                what = "the part below its reorder point" if n_parts == 1 else f"the {n_parts} parts below their reorder point"
            lead = f"Here is a purchase order for {what} from {vname or payload.get('reorder_vendor')}."
        elif payload.get("reorder_skipped"):
            k = int(payload["reorder_skipped"])
            lead = (f"{'The part' if k == 1 else f'All {k} parts'} below the reorder point for "
                    f"{vname or payload.get('reorder_vendor')} {'is' if k == 1 else 'are'} already on order "
                    "(on an open purchase order or one that was just saved).")
        else:
            lead = f"None of {vname or payload.get('reorder_vendor')}’s parts are at or below their reorder point right now."
    elif source == "text":
        lead = "Here is a purchase order from your request."
    elif source == "document":
        name = (payload.get("document") or {}).get("name")
        lead = f"Here is a purchase order read from {name}." if name else "Here is a purchase order read from your document."
    else:
        lead = f"Here is a purchase order for {vname}." if vname else "Here is a new purchase order. Pick a vendor and add parts."
    blocking = any(c["level"] == "block" for c in checks)
    if blocking and source != "reorder":
        lead += " A few things need a look before you can save it."

    return {
        "type": "po",
        "type_tile": TYPE_TILE,
        "type_label": TYPE_LABEL,
        "title": title,
        "lead": lead,
        "fields": fields,
        "line_columns": [dict(c) for c in LINE_COLUMNS],
        "lines": card_lines,
        "totals": [{"label": "Subtotal (before tax)", "value": total_text}],
        "checks": checks,
        "blocking": blocking,
        "records": records,
        "note": ("Saves as an unprocessed purchase order. Nothing goes to "
                 f"{vname or 'the vendor'} until you process or send it from EBMS."),
        "save_label": SAVE_LABEL,
        "amount": total_text,
        # kept on the saved card (server.py reads core["_notes"]) so it is there when the bill arrives
        **({"_notes": [not_carried]} if not_carried else {}),
        "_api": None if blocking else {
            "header": {"vendor": vendor["id"] if vendor else new_vendor_id, "memo": memo, "order_date": today.isoformat(),
                       "expected_date": expected.isoformat() if expected else None,
                       "warehouse": lookups.default_warehouse()},
            "lines": api_lines, "new_records": new_records,
        },
        "_summary": {"vendor": vendor["id"] if vendor else (new_vendor_id or vendor_id), "vendor_name": vname,
                     "parts": n_parts, "total": total_text,
                     "new_records": [{"kind": r["kind"], "id": r["rec"].get("id")} for r in new_records],
                     "lines": [{"item": a["item"], "qty": a["qty"], "cost": a["cost"]} for a in api_lines]},
    }


def _where(created_at: str | None, today: date) -> str:
    try:
        created = datetime.fromisoformat(created_at).astimezone().date() if created_at else today
    except (TypeError, ValueError):
        created = today
    return "Not saved yet" if created >= today else f"Started {created:%b} {created.day}"


def _iso_z(ts: str | None) -> str | None:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts).strftime("%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        return ts


def finish_card(core: dict, draft: dict, *, today: date, may_lag: bool = False) -> dict:
    """Wrap a card body with the draft's envelope. Strips the internal _api/_summary keys."""
    card = {k: v for k, v in core.items() if not k.startswith("_")}
    status = draft["status"]
    # Any line can be removed (PATCH without it) while the draft is open.
    card["lines"] = [dict(ln, removable=status in ("draft", "failed")) for ln in card.get("lines") or []]
    saved = None
    if status == "saved":
        saved = {"doc_number": draft.get("ebms_doc_number"), "saved_by": draft.get("saved_by"),
                 "saved_at": _iso_z(draft.get("saved_at")), "undo_available": True,
                 "undo_title": core.get("_undo_title") or UNDO_TITLE}
    card.update({
        "id": draft["id"],
        "status": status,
        "saved": saved,
        "may_lag": bool(may_lag) if status == "saved" else False,
        "where": _where(draft.get("created_at"), today),
        "created_at": _iso_z(draft.get("created_at")),
        "updated_at": _iso_z(draft.get("updated_at")),
    })
    # Order of keys follows the contract (cosmetic; JSON consumers don't care).
    return card


def stored_card(core: dict) -> dict:
    """What drafts_store keeps in drafts.card: the body plus the summary (no _api)."""
    return {k: v for k, v in core.items() if k != "_api"}
