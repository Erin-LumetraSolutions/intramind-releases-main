"""Purchase-order drafts: input validation, read-only EBMS lookups, and the draft card.

v3 Phase 4 (ClickUp 86e3q4zc9), purchase orders (86e3q4ze6). Contract:
docs/design/v3-drafts-contract.md. Spec 8.9 (card), 11.3 (validation and enrichment), 11.6
(PO checks: primary vendor for each item, cost matches current cost).

Pure: no FastAPI, no psycopg import, does not import server.py. Every lookup goes through a
`query(sql, params) -> list[dict]` function that server.py supplies; server.py's version runs
enforce_permissions() on the SQL and executes on get_conn() (read-only transaction,
statement_timeout). Nothing here writes anywhere.

Customer strings (vendor names, descriptions, hints) are returned RAW in the card. ui.html
escapes everything it renders (spec section 3).

RULES DOCUMENTED HERE
  Current cost (11.6 "cost matches current cost"): the most recent INVENDOR row for this item
    AND this vendor with COST > 0 (the vendor's own purchase record, server.py SYSTEM_PROMPT
    "INVENDOR"), else INVENTRY.COST when > 0 (the item's "current unit cost"; the prompt warns
    it is often blank, never 0-as-real), else unknown (warn, the user enters it).
  Expected date: order date + APVENDOR.LEAD_DAYS, tagged Suggested. INVENDOR.LEAD_DAYS is
    per item and "blank on most rows" (SYSTEM_PROMPT), so the vendor default is used.
  Reorder quantity (source=reorder): parts at or below their reorder point for that primary
    vendor, using the same "low" rule as /attention (warehouse-aware: on INVENWH installs the
    SUM of INVENWH.COUNT vs MAX(MIN_INVEN), else INVENTRY.COUNT vs MIN_INVEN; active,
    track-count C_TYPEs only, no '($)' folder items). qty = MAX_INVEN - on_hand when MAX_INVEN
    is set (> 0) and above on_hand (order up to max), else MIN_INVEN - on_hand, rounded up,
    at least 1.
  Physical type: INVENTRY.C_TYPE in TRACK_COUNT_C_TYPES (EBMS's own "Product Order Sheet"
    definition, same constant as server.py) else a warn: it isn't a stocked part.
  Open PO: an APINV with STATUS 'U' (unprocessed = purchase order) that has an APINVDET line
    for the same item (joined on DOC_AID = AUTOID, never INVOICE). Warn, not block.
"""

from __future__ import annotations

import drafts_masters as dm
import ebms_links

import math
import re
from datetime import date, datetime, timedelta

# Same values as server.TRACK_COUNT_C_TYPES (tests/test_drafts_po.py asserts they match).
TRACK_COUNT_C_TYPES = (2, 3, 4, 7, 9, 11)

SOURCES = ("menu", "reorder", "text", "document")
MAX_LINES = 100
MAX_QTY = 10_000_000
MAX_COST = 1_000_000_000
ID_MAX = 40
HINT_MAX = 100
MEMO_MAX = 1000
SEARCH_LIMIT = 6
MAX_NEW_RECORDS = 5            # new vendor + new parts a single draft may create
COST_TOLERANCE = 0.005

TYPE_TILE = "PO"
TYPE_LABEL = "Purchase order"
SAVE_LABEL = "Save PO, unprocessed"
UNDO_TITLE = "Deletes the PO. Only possible while it is unprocessed."
LINE_COLUMNS = [
    {"key": "item", "label": "Item"},
    {"key": "qty", "label": "Qty", "num": True},
    {"key": "cost", "label": "Cost", "num": True},
    {"key": "amount", "label": "Amount", "num": True},
]
NEW_VALUE = "__new__"          # PATCH value: the line's part picker chose "Create new part"
TAG_FOUND = {"kind": "found", "text": "Found in EBMS"}
TAG_PDF = {"kind": "pdf", "text": "From PDF"}
TAG_OPTIONAL = {"kind": "optional", "text": "Optional"}


# ---------------------------------------------------------------------------
# Formatting (CAD, "$" with thousands separators, cents always on documents)
# ---------------------------------------------------------------------------

def fmt_money(amount, *, unit: bool = False) -> str:
    """$1,234.50. unit=True keeps up to 4 decimals when a unit cost needs them ($0.1235)."""
    a = float(amount)
    sign = "-" if a < 0 else ""
    a = abs(a)
    if unit and round(a, 2) != round(a, 4):
        text = f"{a:,.4f}".rstrip("0")
    else:
        text = f"{a:,.2f}"
    return f"{sign}${text}"


def fmt_qty(q) -> str:
    f = float(q)
    if f.is_integer():
        return f"{int(f):,}" if abs(f) >= 10000 else str(int(f))
    return f"{f:.4f}".rstrip("0").rstrip(".")


def fmt_date(d: date) -> str:
    return f"{d:%b} {d.day}, {d.year}"


def _plural(n: int, one: str, many: str | None = None) -> str:
    return f"{n} {one if n == 1 else (many or one + 's')}"


def _num(value, name: str, *, minimum=None, maximum=None, allow_zero=True) -> float:
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number.")
    try:
        f = float(str(value).replace(",", "").replace("$", "").strip()) if isinstance(value, str) else float(value)
    except (TypeError, ValueError):
        raise ValueError(f"{name} must be a number.")
    if not math.isfinite(f):
        raise ValueError(f"{name} must be a number.")
    if not allow_zero and f <= 0:
        raise ValueError(f"{name} must be more than 0.")
    if minimum is not None and f < minimum:
        raise ValueError(f"{name} can't be negative.")
    if maximum is not None and f > maximum:
        raise ValueError(f"{name} is too large.")
    return f


def _short(value, name: str, max_len: int) -> str:
    if value is None:
        return ""
    if not isinstance(value, str):
        raise ValueError(f"{name} must be text.")
    value = value.strip()
    if len(value) > max_len:
        raise ValueError(f"{name} must be {max_len} characters or fewer.")
    return value


# ---------------------------------------------------------------------------
# Input normalisation (POST /drafts, PATCH, from-text). ValueError text is safe to show.
# ---------------------------------------------------------------------------

def normalize_lines(lines) -> list[dict]:
    if lines is None:
        return []
    if not isinstance(lines, list):
        raise ValueError("Lines must be a list.")
    if len(lines) > MAX_LINES:
        raise ValueError(f"A purchase order can have up to {MAX_LINES} lines.")
    out = []
    for i, ln in enumerate(lines, 1):
        if not isinstance(ln, dict):
            raise ValueError(f"Line {i} is not valid.")
        want_new = ln.get("item") == NEW_VALUE
        item = "" if want_new else _short(ln.get("item"), f"Line {i} item", ID_MAX)
        hint = _short(ln.get("item_hint"), f"Line {i} item", HINT_MAX)
        if not item and not hint and not want_new:
            raise ValueError(f"Line {i} needs an item.")
        qty = _num(ln.get("qty", 1), f"Line {i} quantity", maximum=MAX_QTY, allow_zero=False)
        row = {"item": item, "qty": qty}
        if want_new:
            # "Create new part" from the line's picker: resolve_new_parts makes the block
            # (server.py checks the user may add parts)
            row["want_new"] = True
        if hint and not item:
            row["item_hint"] = hint
        if ln.get("cost") not in (None, ""):
            row["cost"] = _num(ln.get("cost"), f"Line {i} cost", minimum=0, maximum=MAX_COST)
        matched = _short(ln.get("matched_from"), "matched_from", HINT_MAX)
        if matched and item:
            row["matched_from"] = matched
        out.append(row)
    return out


def normalize_po_input(body: dict) -> dict:
    """POST /drafts body -> the stored payload. Raises ValueError (safe to show)."""
    if not isinstance(body, dict):
        raise ValueError("Draft input must be an object.")
    source = body.get("source") or "menu"
    if source not in SOURCES:
        raise ValueError("Unknown draft source.")
    payload = {
        "type": "po",
        "source": source,
        "vendor": _short(body.get("vendor"), "Vendor", ID_MAX),
        "memo": _short(body.get("memo"), "Memo", MEMO_MAX),
        "lines": normalize_lines(body.get("lines")),
    }
    hint = _short(body.get("vendor_hint"), "Vendor", HINT_MAX)
    if hint and not payload["vendor"]:
        payload["vendor_hint"] = hint
    rv = _short(body.get("reorder_vendor"), "Reorder vendor", ID_MAX)
    if source == "reorder":
        rv = rv or payload["vendor"]
        if not rv:
            raise ValueError("Pick the vendor to reorder from.")
        payload["reorder_vendor"] = rv
        payload["vendor"] = payload["vendor"] or rv
    return payload


def _bare_po_no(text) -> str:
    """"PO#4637", "PO 4637", "#4637", "PO-1001" -> "4637" / "1001" (EBMS keeps PO_NO bare)."""
    t = str(text or "").strip()
    return re.sub(r"^(?:P\.?O\.?)?\s*(?:NO\.?|NUMBER)?\s*[#:\-]*\s*", "", t, flags=re.I).strip() or t


def payload_from_extraction(ext: dict, document: dict | None = None) -> dict:
    """A purchase order read from a document (bill_document kind purchase_order): this
    company's own PO to a supplier, or the supplier's order confirmation. Lines carry the
    supplier's part number (matched through INVENDOR once the vendor is known) and the
    printed description as a fallback search."""
    lines = []
    for ln in (ext.get("lines") or [])[:MAX_LINES]:
        part = (ln.get("vendor_part_number") or "").strip()[:HINT_MAX]
        desc = (ln.get("description") or "").strip()[:200]
        if not part and not desc:
            continue
        qty = ln.get("quantity")
        row = {"item": "", "item_hint": (part or desc)[:HINT_MAX],
               "qty": float(qty) if isinstance(qty, (int, float)) and 0 < qty <= MAX_QTY else 1.0}
        price = ln.get("unit_price")
        if isinstance(price, (int, float)) and 0 <= price <= MAX_COST:
            row["cost"] = float(price)
        if part:
            row["vendor_part"] = part
        if desc:
            row["description"] = desc
        folder = (ln.get("suggested_folder") or "")[:60]
        if folder:
            row["pdf_folder"] = folder
        lines.append(row)
    po_no = _bare_po_no(ext.get("po_number"))[:ID_MAX]
    supplier_order = (ext.get("invoice_number") or "").strip()[:ID_MAX]
    memo = "; ".join(x for x in (f"PO {po_no} (from PDF)" if po_no else "",
                                 f"Supplier order {supplier_order}" if supplier_order else "") if x)
    payload = {"type": "po", "source": "document", "vendor": "", "memo": memo[:MEMO_MAX], "lines": lines,
               "pdf": {"vendor_name": (ext.get("vendor_name") or "").strip()[:HINT_MAX],
                       "po_number": po_no, "supplier_order": supplier_order},
               "edited": [], "new_vendor": None}
    hint = (ext.get("vendor_name") or "").strip()[:HINT_MAX]
    if hint:
        payload["vendor_hint"] = hint
    if po_no:
        payload["doc_po"] = po_no
    if document:
        payload["document"] = {"name": document.get("name"), "pages": document.get("pages")}
    return payload


def apply_patch(payload: dict, fields, lines, options: dict | None = None) -> dict:
    """PATCH /drafts/{id}: fields {vendor?, memo?, "new_vendor.<name>"?, "new_part.<line #>.<name>"?};
    lines replaces every line when given (a new part's block stays with its line). A field the
    user changed is remembered in payload["edited"] so it loses its "From PDF" tag."""
    new = dict(payload)
    edited = set(new.get("edited") or [])
    groups = {}
    if fields is not None:
        if not isinstance(fields, dict):
            raise ValueError("Fields must be an object.")
        fields, groups = dm.split_new_fields(fields)
        unknown = set(fields) - {"vendor", "memo"}
        if unknown:
            raise ValueError("Only the vendor, memo, a new vendor and new parts can be changed here.")
        if "vendor" in fields:
            edited.add("vendor")
            new.pop("vendor_hint", None)
            new.pop("vendor_matched_from", None)
            new.pop("vendor_suggested", None)
            if fields["vendor"] == NEW_VALUE:
                # "Create new" from the vendor picker (server.py checks the user may add vendors);
                # resolve_new_vendor builds the block, seeded from the name the document printed
                name = (payload.get("vendor_hint") or payload.get("vendor_matched_from")
                        or (payload.get("pdf") or {}).get("vendor_name") or "").strip()[:HINT_MAX]
                new.update(vendor="", new_vendor=None, want_new_vendor=True)
                if name:
                    new["vendor_hint"] = name
            else:
                v = _short(fields["vendor"], "Vendor", ID_MAX)
                nv = new.get("new_vendor") or {}
                if not (nv and v.upper() == (nv.get("id") or "").upper()):
                    new["vendor"] = v
                    new["new_vendor"] = None
                    new.pop("want_new_vendor", None)
        if "memo" in fields:
            memo = _short(fields["memo"], "Memo", MEMO_MAX)
            if memo != new.get("memo"):
                edited.add("memo")
            new["memo"] = memo
    if lines is not None:
        new["lines"] = normalize_lines(lines)
        _carry_line_values(payload.get("lines") or [], lines, new["lines"])
    new["edited"] = sorted(edited)
    for prefix, values in groups.items():
        if prefix == "new_vendor":
            if new.get("new_vendor"):
                new["new_vendor"] = dm.apply_fields("vendor", new["new_vendor"], values, options)
            continue
        parts = prefix.split(".")
        if len(parts) == 2 and parts[0] == "new_part" and parts[1].isdigit():
            i = int(parts[1]) - 1
            cur = new.get("lines") or []
            if 0 <= i < len(cur) and cur[i].get("new_part"):
                ln = dict(cur[i])
                ln["new_part"] = dm.apply_fields("part", ln["new_part"], values, options)
                new["lines"] = cur[:i] + [ln] + cur[i + 1:]
            continue
        raise ValueError("That field can't be changed here.")
    return new


def _carry_line_values(old: list[dict], sent: list, normalized: list[dict]) -> None:
    """Edits send each line's card position ("line", 1-based like sales orders and bills);
    keep what the card doesn't send back: the stored cost (a document's printed price) unless
    a new one was typed, and a document line's supplier part # / description while it is
    still the same hint. A page cached before 2026-10-15 counted PO lines from 0; a "line": 0
    can only come from such a page, so then every position is read the old way, never shifted
    onto the next line."""
    refs = [raw.get("line") for raw in sent if isinstance(raw, dict)]
    shift = 0 if any(r == 0 and not isinstance(r, bool) for r in refs) else 1
    for raw, ln in zip(sent, normalized):
        idx = raw.get("line") if isinstance(raw, dict) else None
        if not isinstance(idx, int) or isinstance(idx, bool):
            continue
        idx -= shift
        if not 0 <= idx < len(old):
            continue
        base = old[idx]
        if "cost" not in ln and base.get("cost") is not None:
            ln["cost"] = base["cost"]
        np = base.get("new_part")
        if ln.get("want_new"):
            # Seed the new part from what the line had (its text, the document's description)
            seed = base.get("item_hint") or base.get("item") or (np or {}).get("id") or ""
            if seed:
                ln["item_hint"] = seed
            for k in ("vendor_part", "description"):
                if base.get(k):
                    ln[k] = base[k]
            continue
        if np and (ln.get("item") or ln.get("item_hint") or "").upper() == (np.get("id") or "").upper():
            # The card shows a new part's ID in the item column; it stays a new part
            ln.pop("item_hint", None)
            ln.update(item="", new_part=np)
            for k in ("vendor_part", "description"):
                if base.get(k):
                    ln[k] = base[k]
            continue
        same = (ln.get("item_hint") and ln["item_hint"] == base.get("item_hint")) or \
               (ln.get("item") and ln["item"] == base.get("item"))
        if same:
            for k in ("vendor_part", "description"):
                if base.get(k):
                    ln[k] = base[k]


# ---------------------------------------------------------------------------
# Read-only lookups (SQL on the EBMS mirror)
# ---------------------------------------------------------------------------

def _like(term: str) -> str:
    """ILIKE pattern for a user term with %, _ and backslash escaped (Postgres default escape)."""
    t = term.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
    return f"%{t}%"


class PoLookups(dm.MasterLookupsMixin):
    """Every method is one parameterised SELECT through `query`. IDs are fixed-width char
    fields in EBMS, so every comparison is upper(trim(...)) on both sides (an equality, not
    ILIKE, so an ID containing % or _ can't act as a wildcard), and every table gets
    "__deleted" IS NOT TRUE."""

    def __init__(self, schema: str, query, reorder_low_sql=None):
        self.s = schema
        self.query = query
        # server.py supplies the /attention reorder "low" CTE body (with quantity columns).
        self.reorder_low_sql = reorder_low_sql

    def _t(self, table: str) -> str:
        return f'"{self.s}"."{table}"'

    def vendor(self, vendor_id: str) -> dict | None:
        rows = self.query(
            f'SELECT trim({self._t("APVENDOR")}."ID") AS id,'
            f' trim(COALESCE({self._t("APVENDOR")}."L_NAME", \'\')) AS l_name,'
            f' trim(COALESCE({self._t("APVENDOR")}."F_NAME", \'\')) AS f_name,'
            f' {self._t("APVENDOR")}."INACTIVE" AS inactive,'
            f' {self._t("APVENDOR")}."LEAD_DAYS" AS lead_days'
            f' FROM {self._t("APVENDOR")}'
            f' WHERE upper(trim({self._t("APVENDOR")}."ID")) = upper(trim(%s))'
            f' AND {self._t("APVENDOR")}."__deleted" IS NOT TRUE LIMIT 1',
            (vendor_id,),
        )
        return rows[0] if rows else None

    def vendor_search(self, hint: str) -> list[dict]:
        p = _like(hint)
        return self.query(
            f'SELECT trim({self._t("APVENDOR")}."ID") AS id,'
            f' trim(COALESCE({self._t("APVENDOR")}."L_NAME", \'\')) AS l_name,'
            f' trim(COALESCE({self._t("APVENDOR")}."F_NAME", \'\')) AS f_name,'
            f' {self._t("APVENDOR")}."INACTIVE" AS inactive,'
            f' {self._t("APVENDOR")}."LEAD_DAYS" AS lead_days'
            f' FROM {self._t("APVENDOR")}'
            f' WHERE ({self._t("APVENDOR")}."L_NAME" ILIKE %s OR {self._t("APVENDOR")}."F_NAME" ILIKE %s'
            f' OR trim({self._t("APVENDOR")}."ID") ILIKE %s)'
            f' AND {self._t("APVENDOR")}."INACTIVE" IS NOT TRUE'
            f' AND {self._t("APVENDOR")}."__deleted" IS NOT TRUE'
            f' ORDER BY trim({self._t("APVENDOR")}."L_NAME"), trim({self._t("APVENDOR")}."ID") LIMIT {SEARCH_LIMIT}',
            (p, p, p),
        )

    _ITEM_COLS = (
        'trim({t}."ID") AS id, trim(COALESCE({t}."DESCR_1", \'\')) AS description,'
        ' {t}."INACTIVE" AS inactive, {t}."C_TYPE" AS c_type,'
        ' trim(COALESCE({t}."PRI_VENDOR", \'\')) AS pri_vendor, {t}."COST" AS cost'
    )

    def items(self, ids: list[str]) -> dict[str, dict]:
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        if not keys:
            return {}
        t = self._t("INVENTRY")
        rows = self.query(
            f'SELECT {self._ITEM_COLS.format(t=t)} FROM {t}'
            f' WHERE upper(trim({t}."ID")) = ANY(%s) AND {t}."__deleted" IS NOT TRUE',
            (keys,),
        )
        return {r["id"].strip().upper(): r for r in rows}

    def item_search(self, hint: str) -> list[dict]:
        t = self._t("INVENTRY")
        p = _like(hint)
        return self.query(
            f'SELECT {self._ITEM_COLS.format(t=t)} FROM {t}'
            f' WHERE ({t}."DESCR_1" ILIKE %s OR trim({t}."ID") ILIKE %s)'
            f' AND {t}."INACTIVE" IS NOT TRUE AND {t}."__deleted" IS NOT TRUE'
            f" AND {t}.\"ID\" NOT LIKE '($)%%'"
            f' ORDER BY trim({t}."ID") LIMIT {SEARCH_LIMIT}',
            (p, p),
        )

    def vendor_costs(self, ids: list[str], vendor_id: str) -> dict[str, float]:
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        if not keys or not vendor_id:
            return {}
        t = self._t("INVENDOR")
        rows = self.query(
            f'SELECT DISTINCT ON (upper(trim({t}."ID"))) upper(trim({t}."ID")) AS item, {t}."COST" AS cost'
            f' FROM {t}'
            f' WHERE upper(trim({t}."ID")) = ANY(%s) AND upper(trim({t}."VENDOR_ID")) = upper(trim(%s))'
            f' AND {t}."COST" > 0 AND {t}."__deleted" IS NOT TRUE'
            f' ORDER BY upper(trim({t}."ID")), {t}."DATE" DESC NULLS LAST',
            (keys, vendor_id),
        )
        return {r["item"]: float(r["cost"]) for r in rows if r.get("cost") is not None}

    def vendor_part_items(self, vendor_id: str, part_nos: list[str]) -> dict[str, list[str]]:
        """{PART_NO (upper): [item ids]} from INVENDOR rows of THIS vendor."""
        keys = sorted({p.strip().upper() for p in part_nos if p and p.strip()})
        if not keys or not vendor_id:
            return {}
        t = self._t("INVENDOR")
        rows = self.query(
            f'SELECT DISTINCT upper(trim({t}."PART_NO")) AS part_no, trim({t}."ID") AS item FROM {t}'
            f' WHERE upper(trim({t}."VENDOR_ID")) = upper(trim(%s)) AND upper(trim({t}."PART_NO")) = ANY(%s)'
            f' AND {t}."__deleted" IS NOT TRUE ORDER BY 1, 2 LIMIT 1000',
            (vendor_id, keys),
        )
        out: dict[str, list[str]] = {}
        for r in rows:
            out.setdefault(r["part_no"], [])
            if r["item"] not in out[r["part_no"]]:
                out[r["part_no"]].append(r["item"])
        return out

    def pos_by_number(self, po_no: str) -> list[dict]:
        """EBMS documents already carrying this PO number (PO_NO, or INVOICE "PO#<n>")."""
        t = self._t("APINV")
        return self.query(
            f'SELECT trim(COALESCE({t}."PO_NO", \'\')) AS po_no, trim({t}."INVOICE") AS invoice,'
            f' trim({t}."ID") AS vendor_id, {t}."STATUS" AS status, trim({t}."AUTOID") AS doc_id FROM {t}'
            f' WHERE (upper(trim({t}."PO_NO")) = upper(trim(%s)) OR upper(trim({t}."INVOICE")) = upper(%s))'
            f' AND {t}."__deleted" IS NOT TRUE LIMIT 5',
            (po_no, "PO#" + str(po_no).strip()),
        )

    def open_pos(self, ids: list[str]) -> list[dict]:
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        if not keys:
            return []
        h, d = self._t("APINV"), self._t("APINVDET")
        return self.query(
            f'SELECT DISTINCT upper(trim({d}."INVEN")) AS item,'
            f' COALESCE(NULLIF(trim({h}."PO_NO"), \'\'), trim({h}."INVOICE")) AS doc,'
            f' trim({h}."ID") AS vendor_id, trim({h}."INVOICE") AS invoice, trim({h}."AUTOID") AS doc_id'
            f' FROM {h} JOIN {d} ON {h}."AUTOID" = {d}."DOC_AID"'
            f" WHERE {h}.\"STATUS\" = 'U' AND {h}.\"__deleted\" IS NOT TRUE AND {d}.\"__deleted\" IS NOT TRUE"
            f' AND upper(trim({d}."INVEN")) = ANY(%s)'
            f' ORDER BY 2, 1 LIMIT 50',
            (keys,),
        )

    def reorder_lines(self, vendor_id: str) -> list[dict]:
        """Rows {item_id, on_hand, min_inven, max_inven} for this primary vendor."""
        if self.reorder_low_sql is None:
            return []
        # The shared CTE carries a literal '($)%' pattern; with a bound parameter psycopg
        # treats a bare % as a placeholder, so double it.
        low = self.reorder_low_sql().replace("%", "%%")
        return self.query(
            f"WITH low AS ({low}\n) SELECT trim(low.item_id) AS item_id, low.on_hand, low.min_inven, low.max_inven"
            f" FROM low WHERE upper(low.vendor_id) = upper(trim(%s)) ORDER BY trim(low.item_id) LIMIT {MAX_LINES}",
            (vendor_id,),
        )


def resolve_new_vendor(payload: dict, lookups, can_create: dict | None) -> dict:
    """The new-vendor block for a PO (same rule as a bill): when the picker chose "Create new",
    or a document/text vendor name matches no vendor in EBMS, and the user may add vendors. The
    block is seeded from the name (ID suggested from it, the usual folder). Runs on every build,
    edits included, and is idempotent."""
    out = dict(payload)
    want = out.pop("want_new_vendor", None)
    if out.get("new_vendor") and (can_create or {}).get("vendor"):
        out["new_vendor"] = dm.refresh_auto_id(out["new_vendor"], lambda i: lookups.record_exists("vendor", i), 10)
    if not (can_create or {}).get("vendor") or out.get("vendor") or out.get("new_vendor"):
        return out
    hint = (out.get("vendor_hint") or "").strip()
    if not hint and not want:
        return out
    if want or (out.get("source") in ("document", "text") and not lookups.vendor_search(hint)):
        out["new_vendor"] = dm.new_record(
            "vendor", name=hint[:50], id=dm.suggest_id(hint, lambda i: lookups.record_exists("vendor", i), 10),
            folder=lookups.common_folder("vendor") or "")
    return out


def resolve_new_parts(payload: dict, lookups, can_create: dict | None) -> dict:
    """New-part blocks for a PO's lines (86e3q4ze8), only when the user may add parts. A line whose
    picker chose "Create new part" always gets one. A line read from a DOCUMENT gets one by itself
    when it has a supplier part # and nothing in EBMS matches it or its description (several
    matches stay a "pick one"; a line with no part # is often a charge like freight, so the user
    decides). At most MAX_NEW_RECORDS records per draft, a new vendor counting as one; lines past
    that stay unmatched. The block is seeded from the line: ID from the supplier part # or text,
    description, folder of the most similar part, cost, and this PO's vendor as primary."""
    if not (can_create or {}).get("part"):
        out = dict(payload)
        out["lines"] = [{k: v for k, v in ln.items() if k != "want_new"} for ln in payload.get("lines") or []]
        return out
    out = dict(payload)
    lines = []
    used = ((1 if payload.get("new_vendor") and can_create.get("vendor") else 0)
            + sum(1 for ln in payload.get("lines") or [] if ln.get("new_part") or ln.get("want_new")))
    for ln in payload.get("lines") or []:
        ln = dict(ln)
        want = ln.pop("want_new", False)
        if (not want and payload.get("source") == "document" and used < MAX_NEW_RECORDS
                and not ln.get("item") and not ln.get("new_part") and (ln.get("vendor_part") or "").strip()):
            texts = [t for t in ((ln.get("item_hint") or "").strip(), (ln.get("description") or "").strip()) if t]
            if texts and not any(lookups.item_search(t) for t in texts):
                want = True
                used += 1
        if want and not ln.get("new_part"):
            seed = ln.get("vendor_part") or ln.get("item_hint") or ln.get("description") or ""
            desc = ln.get("description") or ln.get("item_hint") or ""
            ln["new_part"] = dm.new_record(
                "part", id=dm.suggest_id(seed, lambda i: lookups.record_exists("part", i), 24),
                description=desc[:80], folder=lookups.suggested_part_folder(desc, ln.get("pdf_folder")) or "",
                cost=ln.get("cost") if ln.get("cost") is not None else "",
                vendor=(payload.get("vendor") or (payload.get("new_vendor") or {}).get("id") or "")[:10])
            ln["item"] = ""
            ln.pop("item_hint", None)
        lines.append(ln)
    out["lines"] = lines
    return out


def reorder_qty(on_hand, min_inven, max_inven) -> float:
    """MAX_INVEN - on_hand when MAX_INVEN is set (> 0) and above on_hand, else MIN_INVEN -
    on_hand; rounded up to a whole unit; never less than 1."""
    oh = float(on_hand or 0)
    mn = float(min_inven or 0)
    mx = float(max_inven or 0)
    need = mx - oh if (mx > 0 and mx > oh) else mn - oh
    return float(max(1, math.ceil(need - 1e-9)))


def vendor_display(v: dict) -> str:
    l_name = (v.get("l_name") or "").strip()
    f_name = (v.get("f_name") or "").strip()
    name = f"{f_name} {l_name}".strip() if f_name else l_name
    return name or (v.get("id") or "").strip()


# ---------------------------------------------------------------------------
# Resolution (hints -> real IDs) and the card
# ---------------------------------------------------------------------------

def resolve_reorder(payload: dict, lookups: PoLookups) -> dict:
    """source=reorder at creation: fill lines from the reorder rule (stored, so later edits stick)."""
    out = dict(payload)
    rows = lookups.reorder_lines(payload["reorder_vendor"])
    out["lines"] = [{"item": r["item_id"].strip(), "qty": reorder_qty(r.get("on_hand"), r.get("min_inven"), r.get("max_inven")),
                     "reorder": {"on_hand": float(r.get("on_hand") or 0), "min": float(r.get("min_inven") or 0),
                                 "max": float(r.get("max_inven") or 0)}}
                    for r in rows]
    return out


def resolve_hints(payload: dict, lookups: PoLookups) -> dict:
    """Turn model-extracted hints into real IDs where the match is unambiguous: exact ID
    first, then a name search. Ambiguous or missing hints stay as hints (the card blocks).
    Never guesses between several matches."""
    out = dict(payload)
    hint = out.get("vendor_hint")
    if hint and not out.get("vendor"):
        v = lookups.vendor(hint)
        if v is not None:
            out["vendor"] = v["id"]
            out.pop("vendor_hint")
        else:
            found = lookups.vendor_search(hint)
            if len(found) == 1:
                out["vendor"] = found[0]["id"]
                out["vendor_matched_from"] = out.pop("vendor_hint")
    lines = []
    # A document's lines: the supplier's part number through INVENDOR first (one item only)
    vparts = [ln["vendor_part"] for ln in out.get("lines", []) if ln.get("vendor_part") and not ln.get("item")]
    by_part = lookups.vendor_part_items(out["vendor"], vparts) if (vparts and out.get("vendor")) else {}
    hinted = [ln["item_hint"] for ln in out.get("lines", []) if ln.get("item_hint") and not ln.get("item")]
    exact = lookups.items(hinted) if hinted else {}
    for ln in out.get("lines", []):
        ln = dict(ln)
        h = ln.get("item_hint")
        if h and not ln.get("item"):
            via_part = by_part.get((ln.get("vendor_part") or "").strip().upper()) or []
            hit = exact.get(h.strip().upper())
            if len(via_part) == 1:
                # The supplier's part number is set up on this part's vendor record in EBMS
                # (INVENDOR): an exact, configured link, so no "check it's the right part" flag.
                ln["item"] = via_part[0]
                ln.pop("item_hint")
            elif hit is not None:
                ln["item"] = hit["id"]
                ln.pop("item_hint")
            else:
                found = lookups.item_search(h)
                if not found and ln.get("description") and ln["description"] != h:
                    found = lookups.item_search(ln["description"])
                if len(found) == 1:
                    ln["item"] = found[0]["id"]
                    ln["matched_from"] = ln.pop("item_hint")
        lines.append(ln)
    out["lines"] = lines
    # No vendor named: suggest the parts' shared primary vendor.
    if not out.get("vendor") and not out.get("vendor_hint") and lines and all(ln.get("item") for ln in lines):
        items = lookups.items([ln["item"] for ln in lines])
        pris = {(items.get(ln["item"].upper()) or {}).get("pri_vendor", "").strip().upper() for ln in lines}
        if len(pris) == 1 and "" not in pris:
            v = lookups.vendor(pris.pop())
            if v is not None:
                out["vendor"] = v["id"]
                out["vendor_suggested"] = True
    return out


def build_po_card(payload: dict, lookups: PoLookups, *, today: date, can_create: dict | None = None,
                  options: dict | None = None) -> dict:
    """The card body (everything except the envelope: id, status, saved, may_lag, where,
    created_at, updated_at) plus "_api": the header and lines (and new parts to create first)
    to send to EBMS when the card is not blocking. Pure given the lookups."""
    checks: list[dict] = []
    can = can_create or {}
    new_fields, new_records, records = [], [], []   # records: the card's new-record blocks

    def check(level, text, ebms=None):
        # ebms: the EBMS record the check is about, as an ebms_links reference (86e1x1xkr)
        checks.append({"level": level, "text": text, **({"ebms": ebms} if ebms else {})})

    # ---- vendor
    vendor_id = (payload.get("vendor") or "").strip()
    vendor = lookups.vendor(vendor_id) if vendor_id else None
    vname = vendor_display(vendor) if vendor else ""
    vendor_tag = None
    vendor_hint_text = None
    nv = payload.get("new_vendor")
    vendor_fields = []     # the new vendor's own fields, shown under the vendor
    from_doc = payload.get("source") == "document"
    edited = set(payload.get("edited") or [])
    if vendor_id and vendor is None:
        check("block", f"{vendor_id} isn't a vendor in EBMS")
        vendor_hint_text = "Not found in EBMS"
    elif vendor is None and nv:
        if can.get("vendor"):
            vname = nv.get("name") or payload.get("vendor_hint") or ""
            vendor_tag = dict(dm.NEW_TAG)
            vendor_fields = dm.record_fields("vendor", nv, "new_vendor", options)
            rc = dm.record_checks("vendor", nv, lookups, what="new vendor")
            for lv, text in rc:
                check(lv, text)
            records.append(dm.record_meta("vendor", nv, "new_vendor", options, rc, field="vendor"))
            new_records.append({"kind": "vendor", "tag": "V", "rec": dict(nv)})
            if vname and getattr(lookups, "customer_search", None) and lookups.customer_search(vname):
                check("warn", f"{vname} is a customer in EBMS. Is this a sales order rather than a purchase order?")
        else:
            check("block", dm.blocked_text(payload.get("vendor_hint") or nv.get("name") or "This vendor", "vendor", can))
    elif vendor is None:
        hint = payload.get("vendor_hint")
        if hint:
            found = lookups.vendor_search(hint)
            if found:
                names = ", ".join(vendor_display(v) for v in found[:3])
                more = "" if len(found) <= 3 else f" and {len(found) - 3} more"
                check("block", f"“{hint}” matches {_plural(len(found), 'vendor')}: {names}{more}. Pick one.")
            else:
                check("block", f"No vendor in EBMS matches “{hint}”")
            vendor_hint_text = f"You said “{hint}”"
        else:
            check("block", "Pick a vendor")
            vendor_hint_text = "Vendor ID or name"
    else:
        if vendor.get("inactive") is True:
            check("block", f"{vname} is inactive in EBMS")
        if payload.get("vendor_matched_from"):
            vendor_tag = {"kind": "matched", "text": f"Matched “{payload['vendor_matched_from']}”"}
            check("warn", f"Matched “{payload['vendor_matched_from']}” to {vname} ({vendor['id']}). Check it's the right vendor.")
        elif payload.get("vendor_suggested"):
            vendor_tag = {"kind": "suggested", "text": "Primary vendor"}
        else:
            vendor_tag = dict(TAG_FOUND)

    # ---- lines
    raw_lines = payload.get("lines") or []
    ids = [ln["item"] for ln in raw_lines if ln.get("item")]
    items = lookups.items(ids) if ids else {}
    vcosts = lookups.vendor_costs(ids, vendor["id"]) if (ids and vendor) else {}
    card_lines, api_lines = [], []
    subtotal = 0.0
    resolved = []          # (line, item_row)
    missing_cost, cost_diffs = [], []
    for i, ln in enumerate(raw_lines, 1):
        qty = float(ln.get("qty") or 0)
        item_id = (ln.get("item") or "").strip()
        row = items.get(item_id.upper()) if item_id else None
        np = ln.get("new_part")
        if row is None and np and not item_id:
            if can.get("part"):
                label = f"new part on line {i}"
                setup = lookups.folder_setup(np.get("folder"))
                new_fields += dm.record_fields("part", np, f"new_part.{i}", options, setup=setup)
                rc = dm.record_checks("part", np, lookups, what=label, setup=setup,
                                      pending_vendor=(nv or {}).get("id") if (nv and vendor is None and can.get("vendor")) else None)
                for lv, text in rc:
                    check(lv, text)
                records.append(dm.record_meta("part", np, f"new_part.{i}", options, rc, setup=setup))
                new_records.append({"kind": "part", "tag": f"P{i}", "rec": dict(np), "line": i})
                cost = ln.get("cost")
                if cost is None and np.get("cost") not in (None, ""):
                    cost = float(np["cost"])
                amount = round(qty * float(cost), 2) if cost is not None else 0.0
                subtotal += amount
                card_lines.append({"item": np.get("id") or "", "description": "New part: " + (np.get("description") or ""),
                                   "qty": fmt_qty(qty), "cost": fmt_money(cost, unit=True) if cost is not None else "",
                                   "amount": fmt_money(amount) if cost is not None else "", "editable": ["qty", "cost"],
                                   "record": f"new_part.{i}"})
                api_lines.append({"item": np.get("id") or "", "qty": qty, "cost": None if cost is None else float(cost)})
                continue
            check("block", dm.blocked_text(np.get("id") or f"Line {i}'s part", "part", can))
            card_lines.append({"item": np.get("id") or "", "description": np.get("description") or "",
                               "qty": fmt_qty(qty), "cost": "", "amount": "", "editable": ["item", "qty", "cost"],
                               "lookup": "part", "query": np.get("id") or "", "can_create": False})
            continue
        if row is None:
            if item_id:
                check("block", f"{item_id} isn't an item in EBMS")
                display, desc = item_id, "Not found in EBMS"
            else:
                h = ln.get("item_hint") or ""
                found = lookups.item_search(h) if h else []
                if found:
                    names = ", ".join(r["id"] for r in found[:3])
                    more = "" if len(found) <= 3 else f" and {len(found) - 3} more"
                    check("block", f"“{h}” matches {_plural(len(found), 'part')}: {names}{more}. Pick one.")
                else:
                    check("block", f"No part in EBMS matches “{h}”")
                display, desc = h, ln.get("description") or "Not matched to a part yet"
            card_lines.append({"item": display, "description": desc, "qty": fmt_qty(qty), "cost": "",
                               "amount": "", "editable": ["item", "qty", "cost"],
                               "lookup": "part", "query": display or "", "can_create": bool(can.get("part"))})
            continue
        real_id = row["id"].strip()
        if row.get("inactive") is True:
            check("block", f"{real_id} is inactive in EBMS")
        if ln.get("matched_from"):
            check("warn", f"Matched “{ln['matched_from']}” to {real_id} {row.get('description') or ''}".rstrip()
                  + ". Check it's the right part.")
        current = vcosts.get(real_id.upper())
        if current is None and row.get("cost") is not None and float(row["cost"]) > 0:
            current = float(row["cost"])
        cost = ln.get("cost")
        if cost is None:
            cost = current
            if current is None:
                missing_cost.append(real_id)
        elif current is not None and abs(float(cost) - current) > COST_TOLERANCE:
            cost_diffs.append((real_id, float(cost), current))
        amount = round(qty * float(cost), 2) if cost is not None else 0.0
        subtotal += amount
        card_lines.append({
            "item": real_id, "description": row.get("description") or "",
            "qty": fmt_qty(qty), "cost": fmt_money(cost, unit=True) if cost is not None else "",
            "amount": fmt_money(amount) if cost is not None else "", "editable": ["qty", "cost"],
            "ebms": ebms_links.ref("INVENTRY", real_id),
        })
        api_lines.append({"item": real_id, "qty": qty, "cost": None if cost is None else float(cost)})
        resolved.append((ln, row))

    if not raw_lines:
        check("block", "Add at least one part")
    for ln in raw_lines:
        if float(ln.get("qty") or 0) <= 0:
            check("block", f"Quantity for {ln.get('item') or ln.get('item_hint')} must be more than 0")
    # ---- cost (only a cost the user or the document gave can differ from EBMS's;
    # a part with no cost on file is left to EBMS's own default, no warning)
    if resolved:
        for item_id, cost, current in cost_diffs:
            check("warn", f"{item_id} cost {fmt_money(cost, unit=True)} differs from its current cost {fmt_money(current, unit=True)}")
        if not cost_diffs and not missing_cost:
            check("good", "Costs match each part’s current cost in EBMS")

    # ---- open POs
    if resolved:
        open_rows = lookups.open_pos([row["id"] for _, row in resolved])
        if not open_rows:
            check("good", "No open PO already covers " + ("these parts" if len(resolved) > 1 else "this part"))
        else:
            by_doc: dict[str, list[str]] = {}
            vend_of: dict[str, str] = {}
            link_of: dict[str, dict | None] = {}
            for r in open_rows:
                by_doc.setdefault(r["doc"], []).append(r["item"])
                vend_of[r["doc"]] = r.get("vendor_id") or ""
                link_of[r["doc"]] = ebms_links.ref("APINV", r.get("vendor_id"), r.get("invoice"), autoid=r.get("doc_id"))
            for doc, its in list(by_doc.items())[:5]:
                frm = f" ({vend_of[doc]})" if vend_of[doc] else ""
                check("warn", f"Open PO {doc}{frm} already has {', '.join(sorted(set(its)))} on order",
                      ebms=link_of.get(doc))

    # ---- the document's own PO number (source=document)
    doc_po = (payload.get("doc_po") or "").strip()
    if doc_po:
        dups = lookups.pos_by_number(doc_po)
        if dups:
            d = dups[0]
            frm = f" for {d['vendor_id']}" if d.get("vendor_id") else ""
            check("warn", f"PO {doc_po} is already in EBMS{frm}. Saving creates a second purchase order; "
                          "skip it if this PDF was printed from EBMS.",
                  ebms=ebms_links.ref("APINV", d.get("vendor_id"), d.get("invoice"), autoid=d.get("doc_id")))
        else:
            check("good", f"No PO {doc_po} in EBMS yet. EBMS gives the new PO its own number; "
                          f"{doc_po} goes in the memo.")

    if len(new_records) > MAX_NEW_RECORDS:
        check("block", f"A draft can create at most {MAX_NEW_RECORDS} new records. Add some in EBMS first.")

    # ---- fields
    lead_days = None
    if vendor is not None and vendor.get("lead_days") is not None:
        try:
            lead_days = int(float(vendor["lead_days"]))
        except (TypeError, ValueError):
            lead_days = None
    expected = today + timedelta(days=lead_days) if lead_days and lead_days > 0 else None
    memo = payload.get("memo") or ""
    new_vendor_id = (nv or {}).get("id") if new_records and nv and vendor is None else None
    fields = [
        {"key": "vendor", "label": "Vendor", "value": vendor["id"] if vendor else (new_vendor_id or vendor_id),
         "display": vname or vendor_id or (payload.get("vendor_hint") or ""), "tag": vendor_tag,
         "editable": True, "input": "text", "hint": vendor_hint_text,
         # Picker (GET /lookup/vendor); "Create new" when the user may add vendors
         "lookup": "vendor", "can_create": can.get("vendor") is True,
         **({"query": payload.get("vendor_hint") or vendor_id} if vendor is None else {}),
         **({"ebms": ebms_links.ref("APVENDOR", vendor["id"])} if vendor else {})},
        {"key": "order_date", "label": "Order date", "value": today.isoformat(), "display": fmt_date(today),
         "tag": None, "editable": False, "input": "date", "hint": None},
        {"key": "expected", "label": "Expected", "value": expected.isoformat() if expected else None,
         "display": fmt_date(expected) if expected else "Not set",
         "tag": {"kind": "suggested", "text": f"{lead_days}-day lead time"} if expected else None,
         "editable": False, "input": "date",
         "hint": None if expected else "No lead time on file for this vendor"},
        *vendor_fields,
        {"key": "memo", "label": "Memo", "value": memo, "display": memo,
         "tag": (dict(TAG_PDF) if from_doc and "memo" not in edited else None) if memo else dict(TAG_OPTIONAL),
         "editable": True, "input": "text", "hint": None},
    ]
    fields += new_fields

    n_parts = len(raw_lines)
    total_text = fmt_money(subtotal)
    if vname:
        title = f"{vname}, {_plural(n_parts, 'part')}" if n_parts else vname
    else:
        title = "New purchase order"
    source = payload.get("source") or "menu"
    if source == "reorder":
        if n_parts:
            what = "the part below its reorder point" if n_parts == 1 else f"the {n_parts} parts below their reorder point"
            lead = f"Here is a purchase order for {what} from {vname or payload.get('reorder_vendor')}."
        else:
            lead = f"None of {vname or payload.get('reorder_vendor')}’s parts are at or below their reorder point right now."
    elif source == "text":
        lead = "Here is a purchase order from your request."
    elif source == "document":
        name = (payload.get("document") or {}).get("name")
        lead = f"Here is a purchase order read from {name}." if name else "Here is a purchase order read from your document."
    else:
        lead = f"Here is a purchase order for {vname}." if vname else "Here is a new purchase order. Pick a vendor and add parts."
    blocking = any(c["level"] == "block" for c in checks)
    if blocking and source != "reorder":
        lead += " A few things need a look before you can save it."

    return {
        "type": "po",
        "type_tile": TYPE_TILE,
        "type_label": TYPE_LABEL,
        "title": title,
        "lead": lead,
        "fields": fields,
        "line_columns": [dict(c) for c in LINE_COLUMNS],
        "lines": card_lines,
        "totals": [{"label": "Subtotal", "value": total_text}, {"label": "Total", "value": total_text}],
        "checks": checks,
        "blocking": blocking,
        "records": records,
        "note": ("Saves as an unprocessed purchase order. Nothing goes to "
                 f"{vname or 'the vendor'} until you process or send it from EBMS."),
        "save_label": SAVE_LABEL,
        "amount": total_text,
        "_api": None if blocking else {
            "header": {"vendor": vendor["id"] if vendor else new_vendor_id, "memo": memo, "order_date": today.isoformat(),
                       "expected_date": expected.isoformat() if expected else None,
                       "warehouse": lookups.default_warehouse()},
            "lines": api_lines, "new_records": new_records,
        },
        "_summary": {"vendor": vendor["id"] if vendor else (new_vendor_id or vendor_id), "vendor_name": vname,
                     "parts": n_parts, "total": total_text,
                     "new_records": [{"kind": r["kind"], "id": r["rec"].get("id")} for r in new_records],
                     "lines": [{"item": a["item"], "qty": a["qty"], "cost": a["cost"]} for a in api_lines]},
    }


def _where(created_at: str | None, today: date) -> str:
    try:
        created = datetime.fromisoformat(created_at).astimezone().date() if created_at else today
    except (TypeError, ValueError):
        created = today
    return "Not saved yet" if created >= today else f"Started {created:%b} {created.day}"


def _iso_z(ts: str | None) -> str | None:
    if not ts:
        return None
    try:
        return datetime.fromisoformat(ts).strftime("%Y-%m-%dT%H:%M:%SZ")
    except ValueError:
        return ts


def finish_card(core: dict, draft: dict, *, today: date, may_lag: bool = False) -> dict:
    """Wrap a card body with the draft's envelope. Strips the internal _api/_summary keys."""
    card = {k: v for k, v in core.items() if not k.startswith("_")}
    status = draft["status"]
    # Any line can be removed (PATCH without it) while the draft is open.
    card["lines"] = [dict(ln, removable=status in ("draft", "failed")) for ln in card.get("lines") or []]
    saved = None
    if status == "saved":
        saved = {"doc_number": draft.get("ebms_doc_number"), "saved_by": draft.get("saved_by"),
                 "saved_at": _iso_z(draft.get("saved_at")), "undo_available": True,
                 "undo_title": core.get("_undo_title") or UNDO_TITLE}
    card.update({
        "id": draft["id"],
        "status": status,
        "saved": saved,
        "may_lag": bool(may_lag) if status == "saved" else False,
        "where": _where(draft.get("created_at"), today),
        "created_at": _iso_z(draft.get("created_at")),
        "updated_at": _iso_z(draft.get("updated_at")),
    })
    # Order of keys follows the contract (cosmetic; JSON consumers don't care).
    return card


def stored_card(core: dict) -> dict:
    """What drafts_store keeps in drafts.card: the body plus the summary (no _api)."""
    return {k: v for k, v in core.items() if k != "_api"}
