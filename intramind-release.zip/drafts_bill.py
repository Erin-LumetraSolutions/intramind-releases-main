"""Vendor-bill drafts: payload from an extracted bill, read-only EBMS lookups, and the card.

ClickUp 86e3q4zeb. Contract: docs/design/v3-drafts-contract.md ("Vendor bill"). Spec 8.9
(card), 11.2 (uploads are untrusted; every value from the document is tagged "From PDF"),
11.6 (bills: duplicate vendor + invoice #, match to the PO, total matches the document).

Pure, like drafts_po.py: no FastAPI, no psycopg, does not import server.py. Every lookup is one
parameterised SELECT through the `query(sql, params)` server.py supplies (enforce_permissions,
read-only transaction, statement timeout). Nothing here writes anywhere.

WHAT A "BILL" IS IN EBMS (research C3)
  An unprocessed APINV. Saving one creates a document that shows as an open purchase order
  until someone processes it in EBMS, which posts it to accounts payable. IntraMind never
  processes it. The card's note says exactly that.

RULES DOCUMENTED HERE
  Vendor: the vendor name printed on the bill. Exact vendor ID first; then a name search on
    active vendors (L_NAME / F_NAME / ID ILIKE); one hit -> matched. Several hits -> the one
    whose name equals the printed name once both are normalised (case, punctuation, and the
    words Inc, Ltd, Limited, LLC, Corp, Co, Company, The, Ltee dropped), if exactly one does.
    No hit -> the same search on the normalised core name. Anything else blocks with "Pick
    the vendor". A name match is tagged `matched` and always warns.
  Lines, in order, for each printed line (once the vendor is known):
    1. the vendor's part number -> INVENDOR.PART_NO for THIS vendor (upper/trim equality); used
       only when it points at exactly one item;
    2. the vendor's part number equal to an INVENTRY ID (exact, upper/trim);
    3. the printed description -> one active part whose description or ID contains it
       (ILIKE); fuzzy, so it warns;
    4. otherwise a non-inventory line. It needs a GL account: APVENDOR.GL_CODE (the vendor's
       default expense account in EBMS) when set, tagged as the vendor default, else the line
       blocks until the user types one.
  Amounts: qty = printed quantity (1 when not printed); cost = printed unit price, else
    printed amount / qty. Line amount = round(qty x cost, 2).
  Duplicate: an APINV for this vendor whose trimmed INVOICE equals the invoice number (any
    status) blocks.
  Totals: lines vs printed subtotal, and lines + freight + tax vs the bill total, warn when
    off by more than 1 cent. Each line's qty x cost vs its printed amount, same tolerance.
  PO: an unprocessed APINV (STATUS 'U') for this vendor whose PO_NO equals the printed PO
    number, or that has any of the bill's parts on it, warns: this saves a separate bill;
    receiving the PO comes later.
  Invoice date: after today, or more than old_invoice_days (company setting, default 90) before today, warns.
  New part (86e3q4ze8): only when the user picks "Create new part" on a line (an unmatched
    line is a non-inventory line by default: freight, fees and services are common on bills).
    The block is seeded from the vendor part # / description, the printed cost and this vendor.
    A Track Count or serialized new part warns that the quantity goes into inventory on save
    (research K.4: an unprocessed bill receives stock). Not offered with a PO match: the
    receive-a-PO save doesn't create records.
  New vendor (86e3q4ze8): no vendor matches the printed name at all -> a NEW vendor block
    (drafts_masters) when the user may add vendors, else a block telling them to ask someone
    who can. Lines are then matched by part ID and description only (no vendor part numbers).
  Cross-check: no vendor matched but the printed name matches an ARCUST customer -> warn "X is
    a customer in EBMS — is this an order rather than a bill?".
"""

from __future__ import annotations

import re
from datetime import date, timedelta

import drafts_masters as dm
import ebms_links
from drafts_po import (PoLookups, _like, _plural, _short, fmt_date, fmt_money, fmt_qty,
                       vendor_display, ID_MAX, HINT_MAX, MEMO_MAX, MAX_QTY, MAX_COST, SEARCH_LIMIT)

TYPE_TILE = "BILL"
TYPE_LABEL = "Vendor bill"
SAVE_LABEL = "Save bill, unprocessed"
UNDO_TITLE = ("Deletes the bill from EBMS. Only possible while it is unprocessed. A PDF attached "
              "to it stays in EBMS's document storage.")
# Live test 2026-10-14: saving an unprocessed bill with received quantities raised on-hand
# stock immediately (MS170 0 -> 1), and deleting it put it back. Say so before Save.
NOTE = ("Saves the bill in EBMS as unprocessed and receives the items into stock now. It appears "
        "as an open purchase order until someone processes it in EBMS, which posts it to accounts "
        "payable. EBMS calculates the tax itself.")
LINE_COLUMNS = [
    {"key": "item", "label": "Item"},
    {"key": "qty", "label": "Qty", "num": True},
    {"key": "cost", "label": "Cost", "num": True},
    {"key": "amount", "label": "Amount", "num": True},
]
TAG_FOUND = {"kind": "found", "text": "Found in EBMS"}
TAG_PDF = {"kind": "pdf", "text": "From PDF"}
TAG_OPTIONAL = {"kind": "optional", "text": "Optional"}
TAG_VENDOR_DEFAULT = {"kind": "default", "text": "Vendor default"}

INVOICE_MAX = 15            # APINV.INVOICE MaxLength (research K.1); ebms_api checks it again
ACCOUNT_MAX = 20
DESCR_MAX = 200
MAX_LINES = 200
TOLERANCE = 0.01
OLD_INVOICE_DAYS = 90
EDITABLE_FIELDS = ("vendor", "invoice_number", "invoice_date", "memo", "freight", "tax", "total", "po_match")
NEW_VALUE = "__new__"          # PATCH value that turns a picker slot into a new-record block
PO_OPTIONS_MAX = 5
COST_TOLERANCE = 0.005
TOTAL_CHECK_TOLERANCE = 0.05   # EBMS's total vs the document's, after save
_SUFFIXES = {"inc", "incorporated", "ltd", "limited", "llc", "corp", "corporation", "co", "company",
             "the", "ltee", "ltée", "lp", "llp"}


def _r2(x) -> float:
    return round(float(x) + 0.0, 2)


def _money_in(value, name: str, *, allow_negative: bool = True):
    """A money field from the user ('' -> None). ValueError text is safe to show."""
    if value is None:
        return None
    if isinstance(value, bool):
        raise ValueError(f"{name} must be a number.")
    if isinstance(value, str):
        v = value.replace(",", "").replace("$", "").strip()
        if not v:
            return None
        try:
            f = float(v)
        except ValueError:
            raise ValueError(f"{name} must be a number.")
    elif isinstance(value, (int, float)):
        f = float(value)
    else:
        raise ValueError(f"{name} must be a number.")
    if f != f or abs(f) > MAX_COST:
        raise ValueError(f"{name} is too large.")
    if f < 0 and not allow_negative:
        raise ValueError(f"{name} can't be negative.")
    return f


def _iso(value) -> str | None:
    if not value:
        return None
    m = re.fullmatch(r"(\d{4})-(\d{2})-(\d{2})", str(value).strip())
    if not m:
        return None
    try:
        return date(int(m.group(1)), int(m.group(2)), int(m.group(3))).isoformat()
    except ValueError:
        return None


def norm_name(name: str) -> str:
    words = re.sub(r"[^\w\s]", " ", (name or "").lower()).split()
    return " ".join(w for w in words if w not in _SUFFIXES)


# ---------------------------------------------------------------------------
# Payload from the extraction (bill_document.validate_extraction output)
# ---------------------------------------------------------------------------

def payload_from_extraction(ext: dict, document: dict | None = None) -> dict:
    """The stored payload. Every printed value is kept untouched under "pdf" (provenance), and
    copied into the editable fields. `document`: {name, pages} of the stored upload."""
    pdf = {k: ext.get(k) for k in ("vendor_name", "vendor_address", "invoice_number", "invoice_date",
                                   "due_date", "terms_text", "po_number", "currency", "subtotal",
                                   "freight", "tax", "total")}
    lines = []
    for ln in (ext.get("lines") or [])[:MAX_LINES]:
        qty = ln.get("quantity")
        price = ln.get("unit_price")
        amount = ln.get("amount")
        q = float(qty) if isinstance(qty, (int, float)) and qty else 1.0
        if isinstance(price, (int, float)):
            cost = float(price)
        elif isinstance(amount, (int, float)) and q:
            cost = round(float(amount) / q, 4)
        else:
            cost = None
        lines.append({
            "description": (ln.get("description") or "")[:DESCR_MAX],
            "vendor_part": (ln.get("vendor_part_number") or "")[:HINT_MAX],
            "item": "", "match": None, "qty": q, "cost": cost, "account": "", "account_source": None,
            "pdf_qty": qty, "pdf_cost": price, "pdf_amount": amount,
        })
    invoice = (ext.get("invoice_number") or "").strip()
    payload = {
        "type": "bill", "source": "document", "pdf": pdf,
        "vendor": "", "vendor_hint": (ext.get("vendor_name") or "").strip()[:HINT_MAX],
        "invoice_number": invoice, "invoice_date": _iso(ext.get("invoice_date")) or "",
        "memo": "", "freight": ext.get("freight"), "tax": ext.get("tax"), "total": ext.get("total"),
        "edited": [], "lines": lines,
    }
    if not payload["vendor_hint"]:
        payload.pop("vendor_hint")
    if document:
        payload["document"] = {"name": document.get("name"), "pages": document.get("pages")}
    return payload


def apply_bill_patch(payload: dict, fields, lines, options: dict | None = None) -> dict:
    """PATCH /drafts/{id} for a bill. fields: any of EDITABLE_FIELDS plus "new_vendor.<name>"
    for a new vendor's block. lines are positional (the card's order): {item|item_hint, qty,
    cost?, account?}; extra lines are new parts."""
    new = dict(payload)
    edited = set(new.get("edited") or [])
    if fields is not None:
        if not isinstance(fields, dict):
            raise ValueError("Fields must be an object.")
        fields, groups = dm.split_new_fields(fields)
        nv = new.get("new_vendor")
        if nv and str(fields.get("vendor") or "").strip().upper() == (nv.get("id") or "").upper():
            fields.pop("vendor", None)     # the vendor field shows the new vendor's ID
        part_groups = {}
        for prefix, values in groups.items():
            parts = prefix.split(".")
            if len(parts) == 2 and parts[0] == "new_part" and parts[1].isdigit():
                part_groups[int(parts[1]) - 1] = values   # applied after the lines below
                continue
            if prefix != "new_vendor":
                raise ValueError("That field can't be changed here.")
            if new.get("new_vendor"):
                new["new_vendor"] = dm.apply_fields("vendor", new["new_vendor"], values, options)
        if set(fields) - set(EDITABLE_FIELDS):
            raise ValueError("Only the vendor, invoice number, invoice date, memo, freight, tax, total and "
                             "purchase order can be changed here.")
        if fields.get("vendor") == NEW_VALUE:
            # "Create new" from the picker: a new-vendor block prefilled from the printed name.
            # server.py checks the user may add vendors before this runs.
            fields = dict(fields)
            fields.pop("vendor")
            name = (new.get("vendor_hint") or new.get("vendor_matched_from")
                    or (new.get("pdf") or {}).get("vendor_name") or "").strip()[:HINT_MAX]
            new.update(vendor="", new_vendor=None, want_new_vendor=True, po_match=None)
            new.pop("vendor_matched_from", None)
            if name:
                new["vendor_hint"] = name
            new["lines"] = _relined(new.get("lines") or [])
            edited.add("vendor")
        if "po_match" in fields:
            v = fields["po_match"]
            if v is None:
                v = ""
            if not isinstance(v, str) or len(v.strip()) > 32:
                raise ValueError("Pick a purchase order from the list.")
            new["po_match"] = v.strip()
        if "vendor" in fields:
            v = _short(fields["vendor"], "Vendor", ID_MAX)
            if v.upper() != (new.get("vendor") or "").upper():
                new["vendor"] = v
                new.pop("vendor_hint", None)
                new.pop("vendor_matched_from", None)
                new.pop("want_new_vendor", None)
                new["new_vendor"] = None
                new["po_match"] = None
                # Lines matched for the old vendor are matched again for the new one.
                new["lines"] = _relined(new.get("lines") or [])
                edited.add("vendor")
        if "invoice_number" in fields:
            v = _short(fields["invoice_number"], "Invoice number", 60)
            if v != new.get("invoice_number"):
                new["invoice_number"] = v
                edited.add("invoice_number")
        if "invoice_date" in fields:
            raw = _short(fields["invoice_date"], "Invoice date", 20)
            v = _iso(raw) if raw else ""
            if raw and v is None:
                raise ValueError("Invoice date must be a date (YYYY-MM-DD).")
            if v != new.get("invoice_date"):
                new["invoice_date"] = v
                edited.add("invoice_date")
        if "memo" in fields:
            new["memo"] = _short(fields["memo"], "Memo", MEMO_MAX)
        for key, label in (("freight", "Freight"), ("tax", "Tax"), ("total", "Total")):
            if key in fields:
                v = _money_in(fields[key], label)
                old = new.get(key)
                if (v is None) != (old is None) or (v is not None and abs(v - float(old)) > 0.0001):
                    new[key] = v
                    edited.add(key)
    else:
        part_groups = {}
    if lines is not None:
        new["lines"] = _patch_lines(new.get("lines") or [], lines)
    for i, values in part_groups.items():
        cur = new.get("lines") or []
        if 0 <= i < len(cur) and cur[i].get("new_part"):
            ln = dict(cur[i])
            ln["new_part"] = dm.apply_fields("part", ln["new_part"], values, options)
            new["lines"] = cur[:i] + [ln] + cur[i + 1:]
    new["edited"] = sorted(edited)
    return new


def _relined(lines: list[dict]) -> list[dict]:
    """Lines matched for the old vendor, made ready to match again for a new one."""
    out = []
    for ln in lines:
        ln = dict(ln)
        if ln.get("match") in ("part_no", "id", "description", "none"):
            ln.update(item="", match=None)
            ln.pop("matched_from", None)
        if ln.get("account_source") == "vendor_default":
            ln.update(account="", account_source=None)
        out.append(ln)
    return out


def line_bases(old: list[dict], lines: list, what: str = "bill") -> list[dict | None]:
    """The stored line each PATCH line edits. A line may carry "line": its 1-based position
    in the card it came from; then lines left out are removed and lines without "line" are new.
    When no line carries "line", lines are positional (the original contract): line i edits
    stored line i, extra lines are new. ValueError (safe to show) on a bad reference."""
    refs = [ln.get("line") for ln in lines if isinstance(ln, dict)]
    if not any(r is not None for r in refs):
        return [dict(old[i]) if i < len(old) else None for i in range(len(lines))]
    seen, out = set(), []
    for i, ln in enumerate(lines, 1):
        r = ln.get("line") if isinstance(ln, dict) else None
        if r is None:
            out.append(None)
            continue
        if isinstance(r, bool) or not isinstance(r, int) or not (1 <= r <= len(old)) or r in seen:
            raise ValueError(f"Line {i} doesn't match a line on this {what}. Refresh and try again.")
        seen.add(r)
        out.append(dict(old[r - 1]))
    return out


def _patch_lines(old: list[dict], lines) -> list[dict]:
    if not isinstance(lines, list):
        raise ValueError("Lines must be a list.")
    if len(lines) > MAX_LINES:
        raise ValueError(f"A bill can have up to {MAX_LINES} lines.")
    bases = line_bases(old, lines)
    out = []
    for i, ln in enumerate(lines, 1):
        if not isinstance(ln, dict):
            raise ValueError(f"Line {i} is not valid.")
        base = bases[i - 1] or {
            "description": "", "vendor_part": "", "item": "", "match": None, "qty": 1.0, "cost": None,
            "account": "", "account_source": None, "pdf_qty": None, "pdf_cost": None, "pdf_amount": None,
            "added": True}
        np = base.get("new_part") or {}
        if ln.get("item") == NEW_VALUE:
            # "Create new part" from the line's picker: resolve_bill makes the block (server.py
            # checks the user may add parts). It is a part line now, not a GL line.
            seed = base.get("item_hint") or base.get("item") or ""
            base.pop("matched_from", None)
            base.update(item="", new_part=None, match="want_new", account="", account_source=None)
            if seed:
                base["item_hint"] = seed
            ln = {k: v for k, v in ln.items() if k != "item"}
        if np and str(ln.get("item") or ln.get("item_hint") or "").strip().upper() == (np.get("id") or "").upper():
            ln = {k: v for k, v in ln.items() if k not in ("item", "item_hint")}   # the card shows its ID
        elif np and ("item" in ln or "item_hint" in ln):
            base["new_part"] = None
        if "item_hint" in ln:
            hint = _short(ln.get("item_hint"), f"Line {i} item", HINT_MAX)
            if hint != (base.get("item_hint") or base.get("item") or ""):
                base.pop("matched_from", None)
                if hint:
                    base.update(item="", item_hint=hint, match="user")
                else:
                    base.update(item="", match="none")
                    base.pop("item_hint", None)
        elif "item" in ln:
            item = _short(ln.get("item"), f"Line {i} item", ID_MAX)
            if item.upper() != (base.get("item") or "").upper():
                base.pop("matched_from", None)
                base.pop("item_hint", None)
                base.update(item=item, match="user" if item else "none")
        if "qty" in ln:
            q = _money_in(ln.get("qty"), f"Line {i} quantity", allow_negative=False)
            if q is None or q <= 0:
                raise ValueError(f"Line {i} quantity must be more than 0.")
            if q > MAX_QTY:
                raise ValueError(f"Line {i} quantity is too large.")
            base["qty"] = q
        if ln.get("cost") not in (None, ""):
            base["cost"] = _money_in(ln.get("cost"), f"Line {i} cost")
        if "account" in ln:
            acct = _short(ln.get("account"), f"Line {i} account", ACCOUNT_MAX)
            if acct != (base.get("account") or ""):
                base["account"] = acct
                base["account_source"] = "user" if acct else None
        out.append(base)
    return out


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------

class BillLookups(PoLookups):
    """PoLookups plus the vendor's default GL account and the bill-only reads."""

    def _vendor_cols(self) -> str:
        t = self._t("APVENDOR")
        return (f'trim({t}."ID") AS id, trim(COALESCE({t}."L_NAME", \'\')) AS l_name,'
                f' trim(COALESCE({t}."F_NAME", \'\')) AS f_name, {t}."INACTIVE" AS inactive,'
                f' {t}."LEAD_DAYS" AS lead_days, trim(COALESCE({t}."GL_CODE", \'\')) AS gl_code')

    def vendor(self, vendor_id: str) -> dict | None:
        t = self._t("APVENDOR")
        rows = self.query(
            f'SELECT {self._vendor_cols()} FROM {t}'
            f' WHERE upper(trim({t}."ID")) = upper(trim(%s)) AND {t}."__deleted" IS NOT TRUE LIMIT 1',
            (vendor_id,),
        )
        return rows[0] if rows else None

    def vendor_search(self, hint: str) -> list[dict]:
        t = self._t("APVENDOR")
        p = _like(hint)
        return self.query(
            f'SELECT {self._vendor_cols()} FROM {t}'
            f' WHERE ({t}."L_NAME" ILIKE %s OR {t}."F_NAME" ILIKE %s OR trim({t}."ID") ILIKE %s)'
            f' AND {t}."INACTIVE" IS NOT TRUE AND {t}."__deleted" IS NOT TRUE'
            f' ORDER BY trim({t}."L_NAME"), trim({t}."ID") LIMIT {SEARCH_LIMIT}',
            (p, p, p),
        )

    def duplicate_bills(self, vendor_id: str, invoice: str) -> list[dict]:
        t = self._t("APINV")
        return self.query(
            f'SELECT trim({t}."INVOICE") AS invoice, {t}."STATUS" AS status, trim(COALESCE({t}."PO_NO", \'\')) AS po_no,'
            f' trim({t}."AUTOID") AS doc_id'
            f' FROM {t} WHERE upper(trim({t}."ID")) = upper(trim(%s)) AND upper(trim({t}."INVOICE")) = upper(trim(%s))'
            f' AND {t}."__deleted" IS NOT TRUE LIMIT 5',
            (vendor_id, invoice),
        )

    def open_vendor_pos(self, vendor_id: str) -> list[dict]:
        """Unprocessed APINV rows for this vendor, one row per (document, item)."""
        h, d = self._t("APINV"), self._t("APINVDET")
        return self.query(
            f'SELECT trim(COALESCE({h}."PO_NO", \'\')) AS po_no, trim({h}."INVOICE") AS invoice,'
            f' upper(trim(COALESCE({d}."INVEN", \'\'))) AS item'
            f' FROM {h} LEFT JOIN {d} ON {h}."AUTOID" = {d}."DOC_AID" AND {d}."__deleted" IS NOT TRUE'
            f" WHERE {h}.\"STATUS\" = 'U' AND upper(trim({h}.\"ID\")) = upper(trim(%s)) AND {h}.\"__deleted\" IS NOT TRUE"
            f' ORDER BY 1, 2, 3 LIMIT 500',
            (vendor_id,),
        )


    def open_po_lines(self, vendor_id: str) -> list[dict]:
        """Match to PO: this vendor's open purchase orders, one row per line. Open = STATUS 'U',
        nothing paid, and INVOICE still "PO#<PO_NO>" (a PO no bill has been entered on yet; an
        unprocessed bill keeps the vendor's invoice # there). APINVDET.QUAN is the ordered qty,
        UNIT the cost; lines joined on DOC_AID = AUTOID."""
        h, d = self._t("APINV"), self._t("APINVDET")
        return self.query(
            f'SELECT trim({h}."AUTOID") AS doc_id, trim(COALESCE({h}."PO_NO", \'\')) AS po_no,'
            f' {h}."ORDER_DATE" AS order_date, {h}."TOTAL_PO" AS total_po,'
            f' trim({d}."AUTOID") AS line_id, upper(trim(COALESCE({d}."INVEN", \'\'))) AS item,'
            f' {d}."QUAN" AS ordered, {d}."UNIT" AS unit'
            f' FROM {h} LEFT JOIN {d} ON {h}."AUTOID" = {d}."DOC_AID" AND {d}."__deleted" IS NOT TRUE'
            f" WHERE {h}.\"STATUS\" = 'U' AND upper(trim({h}.\"ID\")) = upper(trim(%s))"
            f' AND {h}."__deleted" IS NOT TRUE AND COALESCE({h}."TOTAL_PAID", 0) = 0'
            f" AND trim({h}.\"INVOICE\") LIKE 'PO#%%'"
            f' ORDER BY {h}."ORDER_DATE" DESC NULLS LAST, 1, 5 LIMIT 500',
            (vendor_id,),
        )


def _bare_po(text: str) -> str:
    return re.sub(r"^P\.?O\.?\s*#?\s*", "", (text or "").strip().upper()).strip()


def po_candidates(rows: list[dict], printed_po: str, bill_items: list[str], keep: str | None = None) -> list[dict]:
    """Open POs that look like this bill: PO_NO equal to the printed PO # first, then by how
    many of the bill's parts are on them, newest first. At most PO_OPTIONS_MAX, plus `keep`
    (the PO the user already picked) whenever it is still open."""
    docs: dict[str, dict] = {}
    for r in rows:
        doc = docs.setdefault(r["doc_id"], {"doc_id": r["doc_id"], "po_no": r.get("po_no") or "",
                                            "order_date": r.get("order_date"), "total": r.get("total_po"),
                                            "lines": []})
        if r.get("line_id"):
            doc["lines"].append({"line_id": r["line_id"], "item": r.get("item") or "",
                                 "ordered": float(r.get("ordered") or 0), "unit": float(r.get("unit") or 0)})
    want = _bare_po(printed_po)
    items = {i.upper() for i in bill_items if i}
    out = []
    for i, doc in enumerate(docs.values()):
        hit = bool(want) and _bare_po(doc["po_no"]) == want
        overlap = len(items & {ln["item"] for ln in doc["lines"] if ln["item"]})
        if hit or overlap or doc["doc_id"] == keep:
            out.append(dict(doc, po_hit=hit, overlap=overlap, _order=i))
    out.sort(key=lambda d: (d["doc_id"] != keep, not d["po_hit"], -d["overlap"], d["_order"]))
    out = out[:PO_OPTIONS_MAX]
    out.sort(key=lambda d: (not d["po_hit"], -d["overlap"], d["_order"]))
    return [{k: v for k, v in d.items() if k != "_order"} for d in out]


def po_option_label(doc: dict) -> str:
    n = len(doc["lines"])
    bits = [f"PO {doc['po_no']}", _plural(n, "line")]
    if doc.get("total") is not None:
        bits.append(fmt_money(doc["total"]))
    od = doc.get("order_date")
    if od:
        try:
            d = od if isinstance(od, date) else date.fromisoformat(str(od)[:10])
            bits.append(f"ordered {d:%b} {d.day}")
        except ValueError:
            pass
    return " · ".join(bits)


def match_lines(po: dict, api_lines: list[dict]) -> tuple[list[tuple[dict, dict]], list[dict], list[dict]]:
    """(matched [(bill line, PO line)], bill lines not on the PO, PO lines not on the bill).
    A bill part line takes the first unused PO line for the same item, in order."""
    free = list(po["lines"])
    matched, added = [], []
    for a in api_lines:
        item = (a.get("item") or "").upper()
        pl = next((p for p in free if item and p["item"] == item), None)
        if pl is None:
            added.append(a)
        else:
            free.remove(pl)
            matched.append((a, pl))
    return matched, added, free


def ebms_total_check(ebms_total, document_total) -> dict | None:
    """After save: EBMS's own total vs the bill's printed (or edited) total."""
    if ebms_total is None or document_total is None:
        return None
    if abs(float(ebms_total) - float(document_total)) > TOTAL_CHECK_TOLERANCE:
        return {"level": "warn", "text": f"EBMS total {fmt_money(ebms_total)} differs from the bill's "
                                         f"{fmt_money(document_total)} (EBMS calculates tax itself). "
                                         "Check before processing."}
    return {"level": "good", "text": f"EBMS total {fmt_money(ebms_total)} matches the bill"}


# ---------------------------------------------------------------------------
# Resolution (creation, and after edits that clear a match)
# ---------------------------------------------------------------------------

def _resolve_vendor(out: dict, lookups) -> None:
    hint = out.get("vendor_hint")
    if not hint or out.get("vendor") or out.get("new_vendor"):
        return
    v = lookups.vendor(hint)
    if v is not None:
        out["vendor"] = v["id"]
        out.pop("vendor_hint")
        return
    found = lookups.vendor_search(hint)
    core = norm_name(hint)
    if not found and core and core != hint.strip().lower():
        found = lookups.vendor_search(core)
    if len(found) > 1 and core:
        same = [f for f in found if norm_name(vendor_display(f)) == core]
        found = same if len(same) == 1 else found
    if len(found) == 1:
        out["vendor"] = found[0]["id"]
        out["vendor_matched_from"] = out.pop("vendor_hint")


def resolve_bill(payload: dict, lookups, *, can_create: dict | None = None) -> dict:
    """Fill the vendor and the lines' items where the match is safe (see module docstring).
    Never guesses between several matches. Idempotent: lines already decided stay. Offers a new
    vendor when nothing matches the printed name and the user may add vendors."""
    out = dict(payload)
    if out.pop("want_new_vendor", None) and (can_create or {}).get("vendor") and not out.get("new_vendor"):
        # "Create new" from the vendor picker: no name matching, the block is prefilled
        name = out.get("vendor_hint") or ""
        out["new_vendor"] = dm.new_record(
            "vendor", name=name[:50], id=dm.suggest_id(name, lambda i: lookups.record_exists("vendor", i), 10),
            folder=lookups.common_folder("vendor") or "")
    _resolve_vendor(out, lookups)
    hint = out.get("vendor_hint")
    if (hint and not out.get("vendor") and not out.get("new_vendor") and (can_create or {}).get("vendor")
            and not lookups.vendor_search(hint) and not lookups.vendor_search(norm_name(hint) or hint)):
        out["new_vendor"] = dm.new_record(
            "vendor", name=hint[:50], id=dm.suggest_id(hint, lambda i: lookups.record_exists("vendor", i), 10),
            folder=lookups.common_folder("vendor") or "")
    vendor = lookups.vendor(out["vendor"]) if out.get("vendor") else None
    lines = [dict(ln) for ln in out.get("lines") or []]
    for ln in lines:
        if ln.get("match") == "want_new" and not ln.get("new_part"):
            if (can_create or {}).get("part"):
                seed = ln.get("vendor_part") or ln.get("item_hint") or ln.get("description") or ""
                desc = ln.get("description") or ln.get("item_hint") or ""
                ln["new_part"] = dm.new_record(
                    "part", id=dm.suggest_id(seed, lambda i: lookups.record_exists("part", i), 24),
                    description=desc[:80], folder=lookups.part_folder_for(desc) or "",
                    cost=ln.get("cost") if ln.get("cost") is not None else "",
                    vendor=(vendor["id"] if vendor else "")[:10])
                ln["match"] = "new"
                ln.pop("item_hint", None)
            else:
                ln["match"] = "user" if ln.get("item_hint") else "none"
    matchable = vendor is not None or bool(out.get("new_vendor"))
    todo = [ln for ln in lines if not ln.get("item")
            and (ln.get("match") == "user" or (ln.get("match") is None and matchable))]
    by_part = lookups.vendor_part_items(vendor["id"], [ln.get("vendor_part") or "" for ln in todo]) \
        if (todo and vendor is not None) else {}
    exact_keys = [ln.get("item_hint") or ln.get("vendor_part") or "" for ln in todo]
    exact = lookups.items([k for k in exact_keys if k]) if todo else {}
    for ln in todo:
        if ln.get("match") == "user":   # the user typed a part: exact ID, then one search hit
            h = ln.get("item_hint") or ""
            hit = exact.get(h.strip().upper())
            if hit is not None:
                ln.update(item=hit["id"].strip())
                ln.pop("item_hint", None)
            else:
                found = lookups.item_search(h) if h else []
                if len(found) == 1:
                    ln.update(item=found[0]["id"].strip(), matched_from=ln.pop("item_hint"))
            continue
        part = (ln.get("vendor_part") or "").strip().upper()
        ids = by_part.get(part) or []
        if part and len(ids) == 1:
            ln.update(item=ids[0], match="part_no")
        elif part and part in exact:
            ln.update(item=exact[part]["id"].strip(), match="id")
        else:
            desc = (ln.get("description") or "").strip()
            found = lookups.item_search(desc) if len(desc) >= 3 else []
            if len(found) == 1:
                ln.update(item=found[0]["id"].strip(), match="description", matched_from=desc)
            else:
                ln.update(match="none")
    for ln in lines:
        if not ln.get("item") and not ln.get("item_hint") and not ln.get("account") and vendor \
                and vendor.get("gl_code") and not ln.get("new_part"):
            ln.update(account=vendor["gl_code"].strip()[:ACCOUNT_MAX], account_source="vendor_default")
    out["lines"] = lines
    return out


# ---------------------------------------------------------------------------
# The card
# ---------------------------------------------------------------------------

def _part_lookup(query: str, can_create: bool = False) -> dict:
    """Picker keys for a line whose item can be edited; can_create offers "Create new part"."""
    return {"lookup": "part", "query": (query or "").strip(), "can_create": bool(can_create)}


def _tag(payload: dict, key: str):
    return None if key in (payload.get("edited") or []) else dict(TAG_PDF)


def _num_value(x) -> str:
    return "" if x is None else f"{float(x):.2f}"


def build_bill_card(payload: dict, lookups, *, today: date, can_create: dict | None = None,
                    options: dict | None = None, po_match_enabled: bool = False,
                    old_invoice_days: int = OLD_INVOICE_DAYS) -> dict:
    """Card body plus "_api" (header + lines for ebms_api.create_bill when not blocking, and
    new_records), "_summary" and "_undo_title". Pure given the lookups. can_create None means
    "not known" (no new-record offers, the original messages)."""
    checks: list[dict] = []
    can = can_create or {}
    new_records, new_fields, records = [], [], []   # records: the card's new-record blocks

    def check(level, text, ebms=None):
        # ebms: the EBMS record the check is about, as an ebms_links reference (86e1x1xkr)
        checks.append({"level": level, "text": text, **({"ebms": ebms} if ebms else {})})

    pdf = payload.get("pdf") or {}

    # ---- vendor
    vendor_id = (payload.get("vendor") or "").strip()
    vendor = lookups.vendor(vendor_id) if vendor_id else None
    vname = vendor_display(vendor) if vendor else ""
    vendor_tag, vendor_hint_text = None, None
    printed = pdf.get("vendor_name")
    if vendor_id and vendor is None:
        check("block", f"{vendor_id} isn't a vendor in EBMS. Pick the vendor.")
        vendor_hint_text = "Not found in EBMS"
    elif vendor is None and payload.get("new_vendor") and can.get("vendor"):
        nv = payload["new_vendor"]
        vname = nv.get("name") or payload.get("vendor_hint") or ""
        vendor_tag = dict(dm.NEW_TAG)
        new_fields = dm.record_fields("vendor", nv, "new_vendor", options)
        rc = dm.record_checks("vendor", nv, lookups, what="new vendor")
        for lv, text in rc:
            check(lv, text)
        records.append(dm.record_meta("vendor", nv, "new_vendor", options, rc, field="vendor"))
        new_records.append({"kind": "vendor", "tag": "V", "rec": dict(nv)})
        hint = payload.get("vendor_hint") or nv.get("name") or ""
        if hint and getattr(lookups, "customer_search", None) and lookups.customer_search(hint):
            check("warn", f"{hint} is a customer in EBMS — is this an order rather than a bill?")
    elif vendor is None:
        hint = payload.get("vendor_hint")
        if hint:
            found = lookups.vendor_search(hint)
            if found:
                names = ", ".join(f"{vendor_display(v)} ({v['id']})" for v in found[:3])
                more = "" if len(found) <= 3 else f" and {len(found) - 3} more"
                check("block", f"Pick the vendor: “{hint}” on the bill matches {_plural(len(found), 'vendor')}: {names}{more}")
            elif can_create is not None and not can.get("vendor"):
                check("block", dm.blocked_text(hint, "vendor", can))
            else:
                check("block", f"Pick the vendor: no vendor in EBMS matches “{hint}” on the bill")
            if not found and getattr(lookups, "customer_search", None) and lookups.customer_search(hint):
                check("warn", f"{hint} is a customer in EBMS — is this an order rather than a bill?")
        else:
            check("block", "Pick the vendor: the bill doesn't show a vendor name")
        vendor_hint_text = f"The bill says “{printed}”" if printed else "Vendor ID"
    else:
        if vendor.get("inactive") is True:
            check("block", f"{vname} is inactive in EBMS")
        if payload.get("vendor_matched_from"):
            vendor_tag = {"kind": "matched", "text": f"Matched “{payload['vendor_matched_from']}”"}
            check("warn", f"Matched “{payload['vendor_matched_from']}” on the bill to {vname} ({vendor['id']}). "
                          "Check it's the right vendor.")
        else:
            vendor_tag = dict(TAG_FOUND)

    # ---- invoice number + duplicate
    invoice = (payload.get("invoice_number") or "").strip()
    if not invoice:
        check("block", "Enter the vendor's invoice number")
    elif len(invoice) > INVOICE_MAX:
        check("block", f"Invoice number “{invoice}” is longer than EBMS allows ({INVOICE_MAX} characters). "
                       "Edit it to fit.")
    elif vendor is not None:
        dups = lookups.duplicate_bills(vendor["id"], invoice)
        if dups:
            st = {"U": "unprocessed", "O": "outstanding", "X": "paid"}.get(str(dups[0].get("status") or "").strip(), "")
            check("block", f"{vname} invoice {invoice} is already in EBMS" + (f" ({st})" if st else "")
                  + ". Don't enter it twice.",
                  ebms=ebms_links.ref("APINV", vendor["id"], dups[0].get("invoice") or invoice, autoid=dups[0].get("doc_id")))
        else:
            check("good", f"No bill {invoice} from {vname} in EBMS yet")

    # ---- dates
    inv_date = _iso(payload.get("invoice_date"))
    if inv_date:
        d = date.fromisoformat(inv_date)
        if d > today:
            check("warn", f"Invoice date {fmt_date(d)} is in the future")
        elif d < today - timedelta(days=old_invoice_days):
            check("warn", f"Invoice date {fmt_date(d)} is more than {old_invoice_days} days ago")
    elif pdf.get("invoice_date"):
        check("warn", f"Couldn't read the invoice date “{pdf['invoice_date']}”. Enter it, or EBMS uses today.")
    else:
        check("warn", "No invoice date on the bill. Enter it, or EBMS uses today.")

    # ---- currency
    cur = (pdf.get("currency") or "").upper()
    if cur and cur != "CAD":
        check("warn", f"The bill is in {cur}. EBMS records the amounts as printed; check the vendor's currency in EBMS.")

    # ---- lines
    raw_lines = payload.get("lines") or []
    item_ids = [ln["item"] for ln in raw_lines if ln.get("item")]
    items = lookups.items(item_ids) if item_ids else {}
    card_lines, api_lines = [], []
    subtotal = 0.0
    by_part_no, fuzzy, need_account, mism = 0, [], [], []
    resolved_items = []
    for i, ln in enumerate(raw_lines, 1):
        qty = float(ln.get("qty") or 0)
        cost = ln.get("cost")
        amount = _r2(qty * float(cost)) if cost is not None else None
        if amount is not None:
            subtotal += amount
        pa = ln.get("pdf_amount")
        if amount is not None and isinstance(pa, (int, float)) and round(abs(amount - float(pa)), 4) > TOLERANCE:
            mism.append(f"Line {i}: {fmt_qty(qty)} × {fmt_money(cost, unit=True)} = {fmt_money(amount)}, "
                        f"but the bill shows {fmt_money(pa)}")
        if qty <= 0:
            check("block", f"Line {i} quantity must be more than 0")
        if cost is None:
            check("block", f"Enter a cost for line {i}")
        item_id = (ln.get("item") or "").strip()
        desc = ln.get("description") or ""
        row = {"qty": fmt_qty(qty), "cost": fmt_money(cost, unit=True) if cost is not None else "",
               "amount": fmt_money(amount) if amount is not None else ""}
        if item_id:
            it = items.get(item_id.upper())
            if it is None:
                check("block", f"{item_id} isn't an item in EBMS")
                card_lines.append(dict(row, item=item_id, description="Not found in EBMS",
                                       editable=["item", "qty", "cost"], **_part_lookup(item_id)))
                continue
            real = it["id"].strip()
            if it.get("inactive") is True:
                check("block", f"{real} is inactive in EBMS")
            if ln.get("match") == "part_no":
                by_part_no += 1
            elif ln.get("match") == "description":
                fuzzy.append(f"Matched “{ln.get('matched_from') or desc}” to {real} {it.get('description') or ''}".rstrip()
                             + ". Check it's the right part.")
            elif ln.get("matched_from"):
                fuzzy.append(f"Matched “{ln['matched_from']}” to {real} {it.get('description') or ''}".rstrip()
                             + ". Check it's the right part.")
            resolved_items.append(real.upper())
            card_lines.append(dict(row, item=real, description=it.get("description") or desc,
                                   editable=["qty", "cost"], ebms=ebms_links.ref("INVENTRY", real)))
            api_lines.append({"item": real, "qty": qty, "cost": cost})
            continue
        np = ln.get("new_part")
        if np:
            if can.get("part"):
                label = f"new part on line {i}"
                setup = lookups.folder_setup(np.get("folder"))
                new_fields += dm.record_fields("part", np, f"new_part.{i}", options, setup=setup)
                rc = dm.record_checks("part", np, lookups, what=label, setup=setup, receives_stock=True)
                for lv, text in rc:
                    check(lv, text)
                records.append(dm.record_meta("part", np, f"new_part.{i}", options, rc, setup=setup))
                new_records.append({"kind": "part", "tag": f"P{i}", "rec": dict(np), "line": i})
                card_lines.append(dict(row, item=np.get("id") or "", description="New part: " + (np.get("description") or ""),
                                       editable=["item", "qty", "cost"], record=f"new_part.{i}",
                                       **_part_lookup(np.get("id"), True)))
                api_lines.append({"item": np.get("id") or "", "qty": qty, "cost": cost})
            else:
                check("block", dm.blocked_text(np.get("id") or desc or f"Line {i}'s part", "part", can))
                card_lines.append(dict(row, item=np.get("id") or "", description=desc,
                                       editable=["item", "qty", "cost"], **_part_lookup(np.get("id"))))
            continue
        hint = ln.get("item_hint")
        if hint:
            found = lookups.item_search(hint)
            if found:
                names = ", ".join(r["id"] for r in found[:3])
                more = "" if len(found) <= 3 else f" and {len(found) - 3} more"
                check("block", f"“{hint}” matches {_plural(len(found), 'part')}: {names}{more}. Pick one, or clear it "
                               "to enter the line without a part.")
            else:
                check("block", f"No part in EBMS matches “{hint}”. Fix it, or clear it to enter the line without a part.")
            card_lines.append(dict(row, item=hint, description=desc or "Not matched to a part yet",
                                   editable=["item", "qty", "cost"], **_part_lookup(hint, can.get("part") is True)))
            continue
        account = (ln.get("account") or "").strip()
        if not account:
            need_account.append(i)
        label = desc or (f"Vendor part {ln['vendor_part']}" if ln.get("vendor_part") else f"Line {i}")
        card_lines.append(dict(row, item="", description=label, account=account,
                               editable=["item", "qty", "cost", "account"],
                               **_part_lookup(ln.get("vendor_part") or desc, can.get("part") is True)))
        api_lines.append({"item": "", "description": desc or label, "qty": qty, "cost": cost, "account": account})

    if not raw_lines:
        check("block", "The bill has no lines. Add at least one.")
    if by_part_no:
        check("good", f"{_plural(by_part_no, 'line')} matched to parts by {vname or 'the vendor'}'s part number")
    for text in fuzzy:
        check("warn", text)
    noninv = [ln for ln in raw_lines if not ln.get("item") and not ln.get("item_hint") and not ln.get("new_part")]
    if noninv:
        defaults = [ln for ln in noninv if ln.get("account_source") == "vendor_default" and ln.get("account")]
        if defaults:
            check("warn", f"{_plural(len(defaults), 'line')} not matched to a part will post to {vname}'s default "
                          f"account {defaults[0]['account']}. Change the account if that's wrong.")
    if need_account:
        nums = ", ".join(str(n) for n in need_account[:6])
        check("block", f"Enter a GL account for line{'s' if len(need_account) > 1 else ''} {nums} "
                       f"(not matched to a part, and {vname or 'the vendor'} has no default account in EBMS)")

    # ---- totals
    freight = payload.get("freight")
    tax = payload.get("tax")
    total = payload.get("total")
    subtotal = _r2(subtotal)
    computed = _r2(subtotal + float(freight or 0) + float(tax or 0))
    for text in mism[:5]:
        check("warn", text)
    pdf_sub = pdf.get("subtotal")
    totals_ok = True
    if isinstance(pdf_sub, (int, float)) and round(abs(subtotal - float(pdf_sub)), 4) > TOLERANCE:
        totals_ok = False
        check("warn", f"Lines add up to {fmt_money(subtotal)}, but the bill's subtotal is {fmt_money(pdf_sub)}")
    if total is None:
        totals_ok = False
        check("warn", "The bill doesn't show a total. Check the amounts against the vendor's document.")
    elif round(abs(computed - float(total)), 4) > TOLERANCE:
        totals_ok = False
        check("warn", f"Lines, freight and tax add up to {fmt_money(computed)}, but the bill total is {fmt_money(total)}")
    if totals_ok and raw_lines and not mism:
        check("good", f"Lines, freight and tax add up to the bill total of {fmt_money(total)}")

    # ---- PO: match the bill to an open PO (receive it), or warn that one looks like it
    po_field, po_api, matched_po = None, None, None
    if vendor is not None and po_match_enabled:
        picked = payload.get("po_match")
        cands = po_candidates(lookups.open_po_lines(vendor["id"]), pdf.get("po_number") or "", resolved_items,
                              keep=picked or None)
        choice = picked if picked is not None else (cands[0]["doc_id"] if cands else "")
        if choice:
            matched_po = next((c for c in cands if c["doc_id"] == choice), None)
            if matched_po is None:
                # picked earlier but no longer open (processed, paid or billed): never save onto it
                check("block", "The purchase order picked for this bill isn't open any more. "
                               "Pick another option under Purchase order.")
                choice = ""
        options_list = [{"value": "", "label": "Don't match — save a separate bill"}] + \
            [{"value": c["doc_id"], "label": po_option_label(c)} for c in cands]
        if cands or payload.get("po_match"):
            po_field = {"key": "po_match", "label": "Purchase order", "value": choice,
                        "display": next((o["label"] for o in options_list if o["value"] == choice), options_list[0]["label"]),
                        "tag": ({"kind": "suggested", "text": "Suggested"} if (matched_po and payload.get("po_match") is None)
                                else None),
                        "editable": True, "input": "select", "options": options_list, "hint": None}
            if matched_po is not None:
                po_field["ebms"] = ebms_links.po_ref(vendor["id"], matched_po["po_no"], matched_po["doc_id"])
        if matched_po is not None and any(r["kind"] == "part" for r in new_records):
            check("block", f"A new part can't be added while this bill is matched to PO {matched_po['po_no']}. "
                           "Add the part in EBMS first, or pick “Don't match” under Purchase order.")
        if matched_po is not None:
            pno = matched_po["po_no"]
            pairs, added, untouched = match_lines(matched_po, api_lines)
            issues = 0
            for a, pl in pairs:
                q, o = float(a["qty"]), float(pl["ordered"])
                if q > o + 1e-9:
                    issues += 1
                    check("warn", f"{a['item']}: billed {fmt_qty(q)}, but PO {pno} ordered {fmt_qty(o)}")
                elif q < o - 1e-9:
                    issues += 1
                    check("warn", f"{a['item']}: {fmt_qty(o - q)} left on order on PO {pno}")
                if a.get("cost") is not None and abs(float(a["cost"]) - pl["unit"]) > COST_TOLERANCE:
                    issues += 1
                    check("warn", f"{a['item']}: billed cost {fmt_money(a['cost'], unit=True)} differs from "
                                  f"the PO cost {fmt_money(pl['unit'], unit=True)}")
            for a in added:
                issues += 1
                what = a.get("item") or a.get("description") or "A line"
                check("warn", f"{what} isn't on PO {pno}; it will be added to the PO")
            if untouched:
                issues += 1
                check("warn", f"{_plural(len(untouched), 'line')} on PO {pno} "
                              f"{'isn’t' if len(untouched) == 1 else 'aren’t'} on this bill and stay on order")
            if not issues:
                check("good", f"Bill lines match PO {pno}")
            po_api = {"doc_id": matched_po["doc_id"], "po_no": pno,
                      "matched": [{"line_id": pl["line_id"], "item": a["item"], "qty": a["qty"], "cost": a["cost"]}
                                  for a, pl in pairs],
                      "added": added}
    elif vendor is not None:
        rows = lookups.open_vendor_pos(vendor["id"])
        po_no = (pdf.get("po_number") or "").strip().upper()
        docs: dict[str, set] = {}
        for r in rows:
            key = r.get("po_no") or r.get("invoice") or ""
            docs.setdefault(key, set())
            if r.get("item"):
                docs[key].add(r["item"])
        hits = []
        for key, its in docs.items():
            bare = re.sub(r"^PO\s*#?\s*", "", po_no)
            if (po_no and key.upper() in (po_no, bare)) or (its & set(resolved_items)):
                hits.append(key)
        for key in hits[:3]:
            check("warn", f"PO {key} looks like this order. This saves a separate bill; receiving the PO comes later.")

    # ---- fields
    memo = payload.get("memo") or ""
    due = pdf.get("due_date")
    new_vendor_id = (payload.get("new_vendor") or {}).get("id") if new_records else None
    fields = [
        {"key": "vendor", "label": "Vendor", "value": vendor["id"] if vendor else (new_vendor_id or vendor_id),
         "display": vname or vendor_id or (payload.get("vendor_hint") or ""), "tag": vendor_tag,
         "editable": True, "input": "text", "hint": vendor_hint_text,
         "lookup": "vendor", "can_create": can.get("vendor") is True,
         **({"query": payload.get("vendor_hint") or printed or vendor_id or ""} if vendor is None else {}),
         **({"ebms": ebms_links.ref("APVENDOR", vendor["id"])} if vendor else {})},
        *[f for f in new_fields if not f["key"].startswith("new_part.")],
        {"key": "invoice_number", "label": "Invoice #", "value": invoice, "display": invoice,
         "tag": _tag(payload, "invoice_number") if invoice else None, "editable": True, "input": "text",
         "hint": None if invoice else "Vendor's invoice number"},
        {"key": "invoice_date", "label": "Invoice date", "value": inv_date,
         "display": fmt_date(date.fromisoformat(inv_date)) if inv_date else "",
         "tag": _tag(payload, "invoice_date") if inv_date else None, "editable": True, "input": "date",
         "hint": None if inv_date else (f"The bill says “{pdf['invoice_date']}”" if pdf.get("invoice_date") else None)},
        {"key": "due_date", "label": "Due date", "value": _iso(due) or due,
         "display": fmt_date(date.fromisoformat(_iso(due))) if _iso(due) else (due or ""),
         "tag": dict(TAG_PDF) if due else None, "editable": False, "input": "date",
         "hint": "EBMS sets the due date from the vendor's terms"},
    ]
    if po_field is not None:
        fields.append(po_field)
    if pdf.get("po_number"):
        fields.append({"key": "po_number", "label": "Vendor's PO ref", "value": pdf["po_number"],
                       "display": pdf["po_number"], "tag": dict(TAG_PDF), "editable": False, "input": "text",
                       "hint": None})
    for key, label in (("freight", "Freight"), ("tax", "Tax"), ("total", "Bill total")):
        v = payload.get(key)
        fields.append({"key": key, "label": label, "value": _num_value(v),
                       "display": fmt_money(v) if v is not None else "",
                       "tag": _tag(payload, key) if v is not None else None, "editable": True, "input": "text",
                       "hint": None})
    fields.append({"key": "memo", "label": "Memo", "value": memo, "display": memo,
                   "tag": None if memo else dict(TAG_OPTIONAL), "editable": True, "input": "text", "hint": None})
    fields += [f for f in new_fields if f["key"].startswith("new_part.")]

    totals = [{"label": "Subtotal", "value": fmt_money(subtotal)}]
    if freight:
        totals.append({"label": "Freight", "value": fmt_money(freight)})
    if tax:
        totals.append({"label": "Tax", "value": fmt_money(tax)})
    totals.append({"label": "Total", "value": fmt_money(computed)})

    n = len(raw_lines)
    title = f"{vname or printed or 'Vendor bill'}" + (f", invoice {invoice}" if invoice else "")
    lead = (f"Here is the bill from {vname} I read from the document." if vname
            else "Here is the bill I read from the document.")
    lead += " Values taken from the document are marked From PDF."
    blocking = any(c["level"] == "block" for c in checks)
    if blocking:
        lead += " A few things need a look before you can save it."
    amount_text = fmt_money(total if total is not None else computed)

    note, save_label, undo_title = NOTE, SAVE_LABEL, UNDO_TITLE
    if po_api is not None:
        pno = po_api["po_no"]
        note = (f"Receives PO {pno} as this bill: sets the vendor's invoice # and the billed quantities and "
                "costs. Stays unprocessed.")
        save_label = f"Save bill on PO {pno}"
        undo_title = (f"Puts PO {pno} back as it was (invoice #, billed quantities and costs) and removes lines "
                      "this bill added. Only possible while it is unprocessed and nothing is paid.")
    return {
        "type": "bill",
        "type_tile": TYPE_TILE,
        "type_label": TYPE_LABEL,
        "title": title,
        "lead": lead,
        "fields": fields,
        "line_columns": [dict(c) for c in LINE_COLUMNS],
        "lines": card_lines,
        "totals": totals,
        "checks": checks,
        "blocking": blocking,
        "records": records,
        "note": note,
        "save_label": save_label,
        "amount": amount_text,
        "_undo_title": undo_title,
        "_api": None if blocking else {
            "header": {"vendor": vendor["id"] if vendor else new_vendor_id, "invoice": invoice, "inv_date": inv_date,
                       "memo": memo, "freight": freight, "tax": tax, "total": total},
            "lines": api_lines,
            "new_records": new_records,
            "po_match": po_api,
        },
        "_document_total": total if payload.get("source") == "document" else None,
        "_summary": {"vendor": vendor["id"] if vendor else (new_vendor_id or vendor_id), "vendor_name": vname or (printed or ""),
                     **({"po": po_api["po_no"]} if po_api else {}),
                     "new_records": [{"kind": r["kind"], "id": r["rec"].get("id")} for r in new_records],
                     "invoice": invoice, "parts": n, "total": amount_text,
                     "lines": [{"item": a.get("item") or None, "account": a.get("account") or None,
                                "qty": a["qty"], "cost": a["cost"]} for a in api_lines]},
    }
