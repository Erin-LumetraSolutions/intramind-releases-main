"""New master records inside a draft: customer, vendor, part (ClickUp 86e3q4ze8).

Contract: docs/design/v3-drafts-contract.md ("New records inside a draft"). When a draft names a
customer, vendor or part that isn't in EBMS, the card shows a "new" block (tag kind "new") with
editable fields instead of a hard block. On Save, server.py creates the record(s) FIRST through
ebms_api (as the signed-in user), then the document; if the document fails, it deletes the
records it just made. Undo removes the document, then each record this draft created while the
mirror shows it unused.

Pure: no FastAPI, no psycopg, does not import server.py. Lookups are parameterised SELECTs
through the `query` server.py supplies (enforce_permissions, read-only). Nothing here writes.

PERMISSION (owner decision 2026-10-14, IntraMind-side UX pre-check; EBMS still enforces on save)
  Only users whose EBMS security level for the record's module can add records get "create new":
  vendors need AP, customers AR, parts IN. USERS module columns hold the level labels
  (server._KNOWN_PERMISSION_LEVELS: Administrator, Manager, Advanced Entry, Basic Entry, Viewer,
  No Access). The EBMS knowledge base doesn't document what Basic vs Advanced Entry may do, so
  this fails closed: adding master records is taken as Advanced Entry and up; Basic Entry is
  treated as document entry only. Blank, unknown or custom labels can't create.
  Without permission the field blocks with "<Name> isn't in EBMS. Ask someone who can add
  <customers|vendors|parts> to create it, then try again."

FIELDS (keys "<prefix>.<name>"; prefix "new_customer", "new_vendor" or "new_part.<line #>")
  customer: id, name, address1, address2, city, state, zip, phone, email, terms (select from
            APTERM), price_level (select from INPRICE)
  vendor:   the same without price_level. APVENDOR exposes no phone, email or terms property on
            the gateway (docs/design/ebms-api-metadata.xml), so those are kept but not sent and
            not on the card; the block's note says to add them in EBMS (customer phone / email
            the same, live test K.5).
  part:     id, description, folder (select from INVENTRE; suggested from the most similar
            existing part's folder), count type, cost, price, vendor (sent as PRI_VENDOR, research
            K.2 row 7), unit
  The ID is suggested from the name (letters and digits, upper case, cut to the field length)
  and unique-checked on the mirror; a taken ID gets a number appended.

PART SETUP COMES FROM THE FOLDER (live test 2026-10-15, research K.7 / K.8)
  An API-created part takes its count type (C_TYPE) and every GL account from its folder's
  default item ("($)" + TREE_ID), and its price level rows (INVPRICE: formula + sales GL per
  level) are copied from that item too. So the folder IS the setup: the card shows what the
  folder gives the part (folder_setup / setup_text). Count type defaults to "Same as folder" and
  C_TYPE is sent only when the user picks a different one. The item's sales / asset / adjustment
  GL are not on the gateway, so only a different folder changes them.
"""

from __future__ import annotations

import re

NEW_TAG = {"kind": "new", "text": "New — will be created in EBMS"}

NEW_CUSTOMER_PERMISSION_LEVELS = frozenset({"Administrator", "Manager", "Advanced Entry"})
NEW_VENDOR_PERMISSION_LEVELS = frozenset({"Administrator", "Manager", "Advanced Entry"})
NEW_PART_PERMISSION_LEVELS = frozenset({"Administrator", "Manager", "Advanced Entry"})
_PERMISSION = {"customer": ("AR", NEW_CUSTOMER_PERMISSION_LEVELS),
               "vendor": ("AP", NEW_VENDOR_PERMISSION_LEVELS),
               "part": ("IN", NEW_PART_PERMISSION_LEVELS)}
PLURAL = {"customer": "customers", "vendor": "vendors", "part": "parts"}
TABLES = {"customer": "ARCUST", "vendor": "APVENDOR", "part": "INVENTRY"}
MONEY_MAX = 1_000_000_000

# (name, label, input, max length)
SPECS = {
    "customer": (("id", "Customer ID", "text", 10), ("name", "Name", "text", 50),
                 ("folder", "Folder", "select", 5),
                 ("address1", "Address", "text", 35), ("address2", "Address line 2", "text", 35),
                 ("city", "City", "text", 30), ("state", "Province/state", "text", 3),
                 ("zip", "Postal/zip code", "text", 11), ("phone", "Phone", "text", 25),
                 ("email", "Email", "text", 60), ("terms", "Terms", "select", 10),
                 ("price_level", "Price level", "select", 15)),
    "vendor": (("id", "Vendor ID", "text", 10), ("name", "Name", "text", 50),
               ("folder", "Folder", "select", 5),
               ("address1", "Address", "text", 35), ("address2", "Address line 2", "text", 35),
               ("city", "City", "text", 30), ("state", "Province/state", "text", 3),
               ("zip", "Postal/zip code", "text", 11), ("phone", "Phone", "text", 25),
               ("email", "Email", "text", 60), ("terms", "Terms", "select", 10)),
    "part": (("id", "Part ID", "text", 24), ("description", "Description", "text", 80),
             ("folder", "Folder", "select", 5), ("count_type", "Count type", "select", None),
             ("cost", "Cost", "money", None),
             ("price", "Price", "money", None), ("vendor", "Primary vendor", "text", 10),
             ("unit", "Unit", "text", 10)),
}
VENDOR_NOT_SENT = ("phone", "email", "terms")
# Live test 2026-10-14 (K.5): the gateway refuses customer PHONE/EMAIL on a company without
# writable contact fields, so they're not sent, like the vendor's (and not on the card).
CUSTOMER_NOT_SENT = ("phone", "email")
NOT_SENT = {"customer": CUSTOMER_NOT_SENT, "vendor": VENDOR_NOT_SENT, "part": ()}
# The card's record block (draft card UX, 2026-10-15): REQUIRED fields show when the block is
# open and decide whether it opens by itself; MORE fields sit behind "More details". NOT_SENT
# fields are not on the card at all; the block's note says to add them in EBMS.
REQUIRED = {"customer": ("name", "folder"), "vendor": ("id", "name", "folder"),
            "part": ("id", "description", "folder")}
MORE = {"customer": ("address1", "address2", "city", "state", "zip", "terms", "price_level"),
        "vendor": ("address1", "address2", "city", "state", "zip"),
        "part": ("cost", "price", "vendor", "unit")}
# EBMS numbers a new customer itself: the card never asks for an ID, the save sends none and uses
# the one EBMS returns (ebms_api.AUTO_ID_KINDS must match). Vendors and parts are given an ID.
AUTO_ID = frozenset({"customer"})
NOT_SENT_NOTE = {"customer": "Add phone and email in EBMS after saving",
                 "vendor": "Add phone, email and terms in EBMS after saving"}
_OPTION_SOURCE = {"terms": "terms", "price_level": "price_levels", "folder": "folders"}
# Folders are per record type: INVENTRE (parts), ARCUSTRE (customers), APVENTRE (vendors)
_FOLDER_SOURCE = {"part": "folders", "customer": "customer_folders", "vendor": "vendor_folders"}
_EMPTY_OPTION = {"terms": "EBMS default", "price_level": "EBMS default", "folder": "Pick a folder",
                 "count_type": "Same as folder"}

# EBMS's names for INVENTRY.C_TYPE, as the gateway's Classification returns them (test company,
# 2026-10-15). These are the types a new part can be given here; other codes (4, 9, 11 ...) exist
# on some installs and are shown as "Type N" when a folder uses one, never offered as a choice.
COUNT_TYPES = {0: "Service", 1: "No Count", 2: "Track Count", 3: "Serialized Items",
               7: "Non-inventory Serialized Items"}
SERIALIZED_TYPES = frozenset({3, 7})
STOCK_TYPES = frozenset({2, 3})       # received into stock on a bill / PO receipt


def count_type_name(code) -> str:
    try:
        c = int(code)
    except (TypeError, ValueError):
        return ""
    return COUNT_TYPES.get(c) or f"Type {c}"


def effective_count_type(rec: dict, setup: dict | None):
    """The C_TYPE the part will have: the user's pick, else the folder's, else None."""
    v = str(rec.get("count_type") or "").strip()
    if v.isdigit():
        return int(v)
    c = (setup or {}).get("c_type")
    return int(c) if isinstance(c, (int, float)) or str(c or "").strip().isdigit() else None


def setup_text(setup: dict | None) -> str:
    """What the folder gives a new part, in plain words: "Track Count · Purchase GL 50100-100 ·
    Taxable · Sales GL Retail 51000, Wholesale 52000". "" when the folder has no default item."""
    if not setup:
        return ""
    bits = []
    if setup.get("c_type") is not None:
        bits.append(count_type_name(setup["c_type"]))
    if (setup.get("pur_acc") or "").strip():
        bits.append(f"Purchase GL {setup['pur_acc'].strip()}")
    if (setup.get("tax_group") or "").strip():
        bits.append(setup["tax_group"].strip())
    levels = [lv for lv in setup.get("levels") or [] if (lv.get("gl") or "").strip()]
    if levels:
        bits.append("Sales GL " + ", ".join(f"{lv['level'].strip()} {lv['gl'].strip()}" for lv in levels))
    return " · ".join(bits)


def can_create(permissions: dict | None, *, unproven: tuple = ()) -> dict[str, bool | None]:
    """{kind: True | False | None}. `unproven` kinds the user may add are None: allowed by
    EBMS security but not turned on for this server (server.py passes customer / vendor on a
    real gateway until research K.5 passes)."""
    perms = permissions or {}
    out = {}
    for kind, (mod, levels) in _PERMISSION.items():
        ok = perms.get(mod) in levels
        out[kind] = None if (ok and kind in unproven) else ok
    return out


def no_permission_text(name: str, kind: str) -> str:
    return f"{name} isn't in EBMS. Ask someone who can add {PLURAL[kind]} to create it, then try again."


def blocked_text(name: str, kind: str, can: dict | None) -> str:
    """Why a missing record can't be created here. can[kind] None = the user may, but this
    server doesn't create that record type yet (not live-proven, research K.5)."""
    if can and kind in can and can[kind] is None:
        return f"{name} isn't in EBMS. Add the {kind} in EBMS first, then try again."
    return no_permission_text(name, kind)


def suggest_id(name: str, taken, max_len: int) -> str:
    """Letters and digits of the name, upper case, cut to max_len; a number appended while
    `taken(id)` says the ID is used."""
    base = re.sub(r"[^A-Za-z0-9]", "", name or "").upper()[:max_len] or "NEW"
    if not taken(base):
        return base
    for n in range(1, 100):
        cand = base[:max_len - len(str(n))] + str(n)
        if not taken(cand):
            return cand
    return base


def refresh_auto_id(rec: dict, taken, max_len: int) -> dict:
    """A new vendor started from the picker has no name yet, so its suggested ID is the placeholder
    "NEW". Once a name is typed, and while the ID is still that placeholder, suggest one from the name."""
    if rec and (rec.get("id") or "").strip().upper() in ("", "NEW") and (rec.get("name") or "").strip():
        return dict(rec, id=suggest_id(rec["name"], taken, max_len))
    return rec


def new_record(kind: str, **values) -> dict:
    rec = {name: "" for name, *_ in SPECS[kind]}
    rec.update({k: v for k, v in values.items() if k in rec and v is not None})
    return rec


def _options(name: str, options: dict | None, kind: str = "part", setup: dict | None = None) -> list[dict]:
    if name == "count_type":
        c = (setup or {}).get("c_type")
        first = f"Same as folder ({count_type_name(c)})" if c is not None else _EMPTY_OPTION[name]
        return [{"value": "", "label": first}] + [{"value": str(k), "label": v} for k, v in COUNT_TYPES.items()]
    key = _FOLDER_SOURCE.get(kind, "folders") if name == "folder" else _OPTION_SOURCE[name]
    src = (options or {}).get(key) or []
    return [{"value": "", "label": _EMPTY_OPTION[name]}] + [dict(o) for o in src]


def _money_text(v) -> str:
    return "" if v in (None, "") else f"{float(v):.2f}"


def _line_of(prefix: str) -> int | None:
    parts = prefix.split(".")
    return int(parts[1]) if len(parts) == 2 and parts[0] == "new_part" and parts[1].isdigit() else None


def record_fields(kind: str, rec: dict, prefix: str, options: dict | None, *, label_prefix: str = "",
                  setup: dict | None = None) -> list[dict]:
    """Card fields for a new record's block. The first field carries the "new" tag. For a part,
    `setup` is lookups.folder_setup(folder): the folder field's hint says what it sets up.
    Each field also names its block ("record" = prefix, plus "line" for a part), whether it is
    "required" and whether it sits behind "More details" ("more"). Fields the EBMS API doesn't
    take (NOT_SENT) are left out; record_meta's note covers them."""
    out = []
    line = _line_of(prefix)
    for i, (name, label, inp, _max) in enumerate(SPECS[kind]):
        if name in NOT_SENT.get(kind, ()):
            continue
        v = rec.get(name)
        f = {"key": f"{prefix}.{name}", "label": label_prefix + label,
             "value": _money_text(v) if inp == "money" else (v or ""),
             "display": _money_text(v) if inp == "money" else (v or ""),
             "tag": dict(NEW_TAG) if i == 0 else None, "editable": True,
             "input": "select" if inp == "select" else "text", "hint": None}
        if inp == "select":
            opts = _options(name, options, kind, setup)
            f["options"] = opts
            f["display"] = next((o["label"] for o in opts if o["value"] == (v or "") and v), v or "")
        f.update(record=prefix, required=name in REQUIRED[kind], more=name in MORE[kind])
        if name == "id" and kind in AUTO_ID and not v:
            f.update(display="Assigned by EBMS when saved", editable=False)
        if line is not None:
            f["line"] = line
        if kind == "part" and name == "folder" and (v or "").strip():
            text = setup_text(setup)
            f["hint"] = f"Sets up: {text}" if text else None
        out.append(f)
    return out


def apply_fields(kind: str, rec: dict, values: dict, options: dict | None) -> dict:
    """Edits from PATCH (values keyed by field name, prefix removed). ValueError is safe to show."""
    new = dict(rec)
    specs = {name: (label, inp, mx) for name, label, inp, mx in SPECS[kind]}
    for name, raw in values.items():
        if name not in specs:
            raise ValueError("That field can't be changed here.")
        label, inp, mx = specs[name]
        if raw is None:
            raw = ""
        if inp == "money":
            if isinstance(raw, bool) or not isinstance(raw, (str, int, float)):
                raise ValueError(f"{label} must be a number.")
            t = str(raw).replace(",", "").replace("$", "").strip()
            if not t:
                new[name] = ""
                continue
            try:
                f = float(t)
            except ValueError:
                raise ValueError(f"{label} must be a number.")
            if f != f or f < 0 or f > MONEY_MAX:
                raise ValueError(f"{label} must be a number from 0 up.")
            new[name] = round(f, 4)
            continue
        if not isinstance(raw, str):
            raise ValueError(f"{label} must be text.")
        v = " ".join(raw.split())
        if inp == "select":
            if not v:
                new[name] = ""
                continue
            # Option values can carry EBMS's padding (folder "    5"); the browser trims them.
            match = next((o["value"] for o in _options(name, options, kind) if str(o["value"]).strip() == v), None)
            if match is None:
                raise ValueError(f"Pick a {label.lower()} from the list.")
            new[name] = match
            continue
        if mx and len(v) > mx:
            raise ValueError(f"{label} must be {mx} characters or fewer.")
        if name == "id":
            v = v.upper()
        new[name] = v
    return new


def split_new_fields(fields: dict) -> tuple[dict, dict]:
    """(plain fields, {prefix: {name: value}}) for keys like "new_customer.name" or
    "new_part.2.price"."""
    plain, groups = {}, {}
    for k, v in (fields or {}).items():
        if isinstance(k, str) and k.startswith("new_") and "." in k:
            prefix, _, name = k.rpartition(".")
            groups.setdefault(prefix, {})[name] = v
        else:
            plain[k] = v
    return plain, groups


def record_checks(kind: str, rec: dict, lookups, *, what: str, setup: dict | None = None,
                  receives_stock: bool = False, pending_vendor: str | None = None) -> list[tuple[str, str]]:
    """Checks for one new record. `what` names it in the text ("new customer", "new part on
    line 2"). Blocks: no ID, ID already used, no name/description, a part with no folder.
    For a part, `setup` is the folder's setup and `receives_stock` is True on a bill (EBMS
    receives the quantity into stock when the bill is saved, research K.4). `pending_vendor` is the
    ID of a vendor this same draft creates first: a part may name it as its primary vendor."""
    out = []
    rid = (rec.get("id") or "").strip()
    if not rid and kind in AUTO_ID:
        pass       # EBMS assigns it on save
    elif not rid:
        out.append(("block", f"Enter an ID for the {what}"))
    elif lookups.record_exists(kind, rid):
        out.append(("block", f"ID {rid} is already used in EBMS. Pick another ID for the {what}."))
    if not str(rec.get("folder") or "").strip():
        # Every new record needs a folder: EBMS takes the record's defaults from it (K.5)
        out.append(("block", f"Pick a folder for the {what}"))
    if kind == "part":
        if not (rec.get("description") or "").strip():
            out.append(("block", f"Enter a description for the {what}"))
        v = (rec.get("vendor") or "").strip()
        if v and v.upper() != (pending_vendor or "").strip().upper() and lookups.vendor(v) is None:
            out.append(("block", f"{v} isn't a vendor in EBMS. Fix the primary vendor for the {what}."))
        folder = str(rec.get("folder") or "").strip()
        if folder and setup is None:
            out.append(("warn", f"Couldn't read the folder's default setup for the {what}. EBMS still applies "
                                "it; check the part's count type and GL accounts in EBMS after saving."))
        ct = effective_count_type(rec, setup)
        if ct in SERIALIZED_TYPES:
            out.append(("warn", f"The {what} is {count_type_name(ct)}: enter its serial numbers in EBMS."))
        if receives_stock and ct in STOCK_TYPES:
            out.append(("warn", f"The {what} is {count_type_name(ct)}, so its quantity goes into inventory "
                                "when this is saved."))
    elif not (rec.get("name") or "").strip():
        out.append(("block", f"Enter a name for the {what}"))
    # Phone / email (and a vendor's terms) aren't sent: record_meta's note says so, not a check
    return out


def _option_label(name: str, value, options: dict | None, kind: str) -> str:
    v = str(value or "").strip()
    if not v:
        return ""
    return next((o.get("label") or v for o in _options(name, options, kind)
                 if o["value"] and str(o["value"]).strip() == v), v)


def record_summary(kind: str, rec: dict, options: dict | None, setup: dict | None = None) -> str:
    """One line for the closed block: "Acme Supply (ACMESUPPLY) · Retail folder · Net 30", or
    for a part "Filters folder → Track Count · Purchase GL 50100-100"."""
    # Folder labels are paths ("Customers > Ontario > Retail"); the last name keeps it to one line
    folder = _option_label("folder", rec.get("folder"), options, kind).split(" > ")[-1].strip()
    where = f"{folder} folder" if folder else "No folder yet"
    if kind == "part":
        ct = effective_count_type(rec, setup)      # the user's count type wins over the folder's
        text = setup_text(dict(setup or {}, c_type=ct) if (setup or ct is not None) else None)
        return f"{where} → {text}" if folder and text else where
    name, rid = (rec.get("name") or "").strip(), (rec.get("id") or "").strip()
    bits = [f"{name} ({rid})" if name and rid else (name or rid or "No name yet"), where]
    if kind == "customer":
        bits += [t for t in (_option_label("terms", rec.get("terms"), options, kind),
                             _option_label("price_level", rec.get("price_level"), options, kind)) if t]
    return " · ".join(bits)


def record_note(kind: str, rec: dict) -> str | None:
    """The short note for what isn't sent to EBMS (customer phone and email; vendor phone,
    email and terms), with any values the document gave so they aren't lost."""
    base = NOT_SENT_NOTE.get(kind)
    if not base:
        return None
    known = [f"{n} {' '.join(str(rec[n]).split())}" for n in NOT_SENT[kind] if str(rec.get(n) or "").strip()]
    return f"{base} ({', '.join(known)})" if known else base


def record_meta(kind: str, rec: dict, prefix: str, options: dict | None, checks, *,
                setup: dict | None = None, field: str | None = None) -> dict:
    """The card's "records" entry for one new record's block: key (its fields' "record"), kind,
    field (the card field it stands for: "customer" / "vendor") or line (a part's line #),
    summary, note, and expand: true when a check blocks on it or a required field is empty, so
    the block opens by itself. `checks` is what record_checks returned for it."""
    missing = any(not str(rec.get(n) or "").strip() for n in REQUIRED[kind])
    return {"key": prefix, "kind": kind, "field": field, "line": _line_of(prefix),
            "summary": record_summary(kind, rec, options, setup), "note": record_note(kind, rec),
            "expand": missing or any(lv == "block" for lv, _ in checks)}


class MasterLookupsMixin:
    """Read-only lookups for new records and customer matching. Needs self._t and self.query."""

    def record_exists(self, kind: str, rid: str) -> bool:
        t = self._t(TABLES[kind])
        return bool(self.query(
            f'SELECT 1 AS hit FROM {t} WHERE upper(trim({t}."ID")) = upper(trim(%s))'
            f' AND {t}."__deleted" IS NOT TRUE LIMIT 1', (rid,)))

    def _customer_cols(self) -> str:
        t = self._t("ARCUST")
        return (f'trim({t}."ID") AS id, trim(COALESCE({t}."L_NAME", \'\')) AS l_name,'
                f' trim(COALESCE({t}."F_NAME", \'\')) AS f_name, {t}."INACTIVE" AS inactive')

    def customer(self, cust_id: str) -> dict | None:
        t = self._t("ARCUST")
        rows = self.query(f'SELECT {self._customer_cols()} FROM {t} WHERE upper(trim({t}."ID")) = upper(trim(%s))'
                          f' AND {t}."__deleted" IS NOT TRUE LIMIT 1', (cust_id,))
        return rows[0] if rows else None

    def customer_search(self, hint: str) -> list[dict]:
        from drafts_po import _like, SEARCH_LIMIT
        t = self._t("ARCUST")
        p = _like(hint)
        return self.query(
            f'SELECT {self._customer_cols()} FROM {t}'
            f' WHERE ({t}."L_NAME" ILIKE %s OR {t}."F_NAME" ILIKE %s OR trim({t}."ID") ILIKE %s)'
            f' AND {t}."INACTIVE" IS NOT TRUE AND {t}."__deleted" IS NOT TRUE'
            f' ORDER BY trim({t}."L_NAME"), trim({t}."ID") LIMIT {SEARCH_LIMIT}', (p, p, p))

    def common_folder(self, kind: str) -> str | None:
        """The folder (raw TREE_ID) most used by active customers or vendors: the default for a
        new one (the user can pick another)."""
        t = self._t("ARCUST" if kind == "customer" else "APVENDOR")
        rows = self.query(
            f'SELECT {t}."TREE_ID" AS tree_id, COUNT(*) AS n FROM {t}'
            f' WHERE {t}."INACTIVE" IS NOT TRUE AND {t}."__deleted" IS NOT TRUE'
            f" AND {t}.\"ID\" NOT LIKE '($)%%' AND trim(COALESCE({t}.\"TREE_ID\", '')) <> ''"
            f' GROUP BY {t}."TREE_ID" ORDER BY 2 DESC LIMIT 1')
        return rows[0]["tree_id"] if rows and rows[0].get("tree_id") else None

    def default_warehouse(self) -> str | None:
        """The warehouse to put on a new sales order, purchase order or bill, but ONLY on an
        install where EBMS's warehouse module is actually in use (86e3q4zeb). `INVENWH` exists
        only on those installs -- server.py's own `_schema_has_invenwh` checks the same table
        for the same reason, and its comment confirms the table is absent entirely (not just
        empty) on both `eagcan:legacy` and `erintest0805:legacy`. Sending `WAREHOUSE` on an
        install without the module would be guessing at a field EBMS was never configured for,
        not fixing anything -- confirmed the hard way: adding it unconditionally did not stop
        eagcan:legacy's new-part sales order from aborting (ClickUp 1dfk76vqbnf). On an install
        that DOES have the module, a Track Count line with no warehouse to post its stock
        movement against is a real, separate way for EBMS to abort a document; when there's
        only one warehouse that is unambiguously the answer, and with more than one this falls
        back to whichever is used most on recent sales lines rather than guessing."""
        cache = self.__dict__.setdefault("_warehouse_cache", {})
        if "default" in cache:
            return cache["default"]
        has_module = self.query(
            "SELECT 1 FROM information_schema.tables WHERE table_schema = %s AND table_name = 'INVENWH' LIMIT 1",
            (self.s,))
        if not has_module:
            cache["default"] = None
            return None
        t = self._t("INWH")
        rows = self.query(f'SELECT trim({t}."WAREHOUSE") AS wh FROM {t}'
                          f' WHERE trim(COALESCE({t}."WAREHOUSE", \'\')) <> \'\' ORDER BY 1')
        result = None
        if len(rows) == 1:
            result = rows[0]["wh"]
        elif rows:
            t2 = self._t("ARINVDET")
            freq = self.query(
                f'SELECT trim({t2}."WAREHOUSE") AS wh, COUNT(*) AS n FROM {t2}'
                f' WHERE trim(COALESCE({t2}."WAREHOUSE", \'\')) <> \'\' AND {t2}."__deleted" IS NOT TRUE'
                f' GROUP BY 1 ORDER BY 2 DESC LIMIT 1')
            result = freq[0]["wh"] if freq and freq[0].get("wh") else rows[0]["wh"]
        cache["default"] = result
        return result

    def folder_setup(self, tree_id: str) -> dict | None:
        """What a new part in this folder gets from the folder's default item ($)<TREE_ID>:
        {c_type, pur_acc, tax_group, levels: [{level, markup, gl}]}, or None when the folder has
        no default item. INVPRICE is read on a best-effort basis (levels [] if unavailable)."""
        tid = str(tree_id or "")
        if not tid.strip():
            return None
        cache = self.__dict__.setdefault("_folder_setup_cache", {})
        if tid in cache:
            return cache[tid]
        t = self._t("INVENTRY")
        rows = self.query(
            f'SELECT trim({t}."ID") AS id, {t}."C_TYPE" AS c_type, trim(COALESCE({t}."PUR_ACC", \'\')) AS pur_acc,'
            f' trim(COALESCE({t}."TAX_GROUP", \'\')) AS tax_group FROM {t}'
            f" WHERE trim({t}.\"TREE_ID\") = trim(%s) AND {t}.\"ID\" LIKE '($)%%'"
            f' AND {t}."__deleted" IS NOT TRUE LIMIT 1', (tid,))
        out = None
        if rows:
            r = rows[0]
            out = {"c_type": int(r["c_type"]) if r.get("c_type") is not None else None,
                   "pur_acc": r.get("pur_acc") or "", "tax_group": r.get("tax_group") or "", "levels": []}
            try:
                # One shared read-only transaction: a failing statement would abort every lookup
                # after it, so check the table is mirrored before touching it.
                p = self._t("INVPRICE")
                ok = self.query("SELECT to_regclass(%s) IS NOT NULL AS ok", (p,))
                if ok and ok[0].get("ok"):
                    out["levels"] = self.query(
                        f'SELECT trim({p}."LEVEL") AS level, trim(COALESCE({p}."MARKUP", \'\')) AS markup,'
                        f' trim(COALESCE({p}."GL_CODE", \'\')) AS gl FROM {p}'
                        f' WHERE trim({p}."ID") = %s AND {p}."__deleted" IS NOT TRUE ORDER BY trim({p}."LEVEL")',
                        (r["id"],))
            except Exception:   # permission check refused it before it ran: no level summary
                out["levels"] = []
        cache[tid] = out
        return out

    def _first_with_setup(self, tree_ids) -> str | None:
        """The first of `tree_ids` that has a working default item (folder_setup), or None if
        every candidate is missing one. A folder can be real -- a genuine row in the tree table
        -- and still have no ($)<TREE_ID> default item configured in EBMS, which EBMS refuses to
        create a new part against (confirmed live, ClickUp 86e3q4zec: "2154 POWER DRIVERS +
        FASTENERS" existed but had no default item; EBMS's 422 said so plainly). Existing isn't
        enough to suggest a folder for a brand-new part -- it has to actually work."""
        for tid in tree_ids:
            setup = self.folder_setup(tid)
            # A "No Count" default item is where a new part failed to save (live 2026-10-30, EBMS
            # "valid G/L account"), so it is never suggested on its own; the user can still pick it
            if setup is not None and setup.get("c_type") != 1:
                return tid
        return None

    def part_folder_for(self, description: str) -> str | None:
        """The folder (raw TREE_ID) most used by active parts whose description shares the
        longest word of this one, or None. Skips any candidate with no working default item."""
        from drafts_po import _like
        words = sorted(re.findall(r"[A-Za-z0-9]{4,}", description or ""), key=len, reverse=True)
        if not words:
            return None
        t, f = self._t("INVENTRY"), self._t("INVENTRE")
        # Only a NAMED folder is suggested: an unnamed one shows as a bare number on the card and was
        # the folder a new part failed to save in (live 2026-10-30, EBMS "valid G/L account")
        rows = self.query(
            f'SELECT {t}."TREE_ID" AS tree_id, COUNT(*) AS n FROM {t}'
            f' JOIN {f} ON trim({f}."TREE_ID") = trim({t}."TREE_ID") AND {f}."__deleted" IS NOT TRUE'
            f" AND trim(COALESCE({f}.\"TREE_DESCR\", '')) <> ''"
            f' WHERE {t}."DESCR_1" ILIKE %s AND {t}."INACTIVE" IS NOT TRUE AND {t}."__deleted" IS NOT TRUE'
            f" AND {t}.\"ID\" NOT LIKE '($)%%' GROUP BY {t}.\"TREE_ID\" ORDER BY 2 DESC LIMIT 5",
            (_like(words[0]),))
        return self._first_with_setup(r["tree_id"] for r in rows if r.get("tree_id"))

    def part_folder_named(self, label: str) -> str | None:
        """The TREE_ID of the part folder whose own name (not the full path) matches `label`
        exactly, ignoring case and padding, or None. Turns an AI-suggested folder name -- picked
        from the real folder list given to it as prompt context (bill_document.py) -- back into
        the raw TREE_ID a new part needs. A name that matches nothing (hallucinated, or the
        document named no folder) is just ignored by the caller, and so is one that matches only
        folders with no working default item."""
        label = str(label or "").strip()
        if not label:
            return None
        t = self._t("INVENTRE")
        rows = self.query(
            f'SELECT {t}."TREE_ID" AS tree_id FROM {t}'
            f' WHERE trim(COALESCE({t}."TREE_DESCR", \'\')) ILIKE %s AND {t}."__deleted" IS NOT TRUE LIMIT 5',
            (label,))
        return self._first_with_setup(r["tree_id"] for r in rows if r.get("tree_id"))

    def suggested_part_folder(self, description: str, ai_folder: str | None) -> str | None:
        """The folder to default a brand-new part to: the document-reading AI's suggestion when
        it names a real folder (ai_folder comes from the upload, so it's checked against the
        actual list, not trusted outright), else the folder most used by similar existing parts
        (part_folder_for), else None (the user picks one)."""
        return self.part_folder_named(ai_folder) or self.part_folder_for(description)
