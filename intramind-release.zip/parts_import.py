"""Part imports: add new parts or update existing ones from a spreadsheet (ClickUp 86e3q4zek).

Spec: docs/design/intramind-redesign-spec.md section 8.11. Contract: docs/design/v3-drafts-contract.md
("Part import"). Live mechanics: research K.7 (a new part takes its setup from its folder) and K.8
(a price level is a formula: a fixed price is MARKUP_ID 4IS + MARKUP "Is $x", sent through the
part's INVPRICEs@delta; PRICE itself is refused).

Pure, like drafts_po.py: no FastAPI, no psycopg, does not import server.py. Lookups are
parameterised SELECTs through the `query` server.py supplies. Nothing here writes.

THE FILE
  CSV (comma, semicolon or tab; UTF-8 or Windows-1252) or .xlsx (first sheet, read with the
  standard library: an .xlsx is a zip of XML). Old .xls is refused with "save it as .xlsx or CSV".
  The header row is the first of the top 10 rows with at least two text cells. At most MAX_ROWS
  data rows and MAX_COLS columns are kept; blank rows are dropped.

EXPLICIT BY DESIGN (owner decision 2026-10-15)
  - The user picks the mode first: "add" (new parts only; rows already in EBMS are skipped and
    listed) or "update" (existing parts only; rows not in EBMS are skipped and listed). Never both.
  - Columns are suggested from the headers; the user can change every one.
  - Update: nothing changes unless the user ticks it (change.<target> = "yes"): base price
    (INVENTRY.BASE), cost (INVENTRY.COST) and each price level (INVPRICE, by level name).
  - Save names the action and the count ("Update base price on 214 parts") and the user types
    the count to confirm (server.py checks it).
  - Bad rows (no part #, a value that isn't a number) are skipped and listed, never guessed.

FLAGS (warn): a change over 25%, a value going to 0, a price below cost, a calculated level
  (any formula but 4IS "Is $") becoming a fixed price, cost on a part EBMS updates from purchases
  (AUTO_COST / UPDATECOST), inactive parts, base price changes that calculated levels follow.
"""

from __future__ import annotations

import csv
import io
import logging
import re
import zipfile
from xml.etree import ElementTree as ET

import drafts_masters as dm
from drafts_po import PoLookups, fmt_money, _plural

log = logging.getLogger("ebms_live.parts_import")

TYPE_TILE = "XLS"
TYPE_LABEL = "Part import"
MAX_FILE_BYTES = 10 * 1024 * 1024
MAX_XML_BYTES = 40 * 1024 * 1024          # uncompressed size of the sheet / shared strings
MAX_ROWS = 2000
MAX_COLS = 40
MAX_CELL = 200
SHOWN_LINES = 200                          # rows shown in the card's table
BIG_CHANGE = 0.25
FIXED_PRICE_FORMULA = "4IS"               # FORMULA "Is $____" (research K.8)
MONEY_MAX = 1_000_000_000
EXTENSIONS = (".csv", ".txt", ".xlsx")
MODES = ("add", "update")

TARGETS = ("part", "description", "cost", "base", "vendor_part")
TARGET_LABELS = {"part": "Part #", "description": "Description", "cost": "Cost", "base": "Base price",
                 "vendor_part": "Vendor part #"}
# Header words that suggest each column (lower case, punctuation removed). First match wins.
_HEADER_HINTS = {
    "part": ("part", "part number", "part no", "part #", "item", "item number", "item no", "item #", "sku",
             "product", "product id", "product code", "inventory id", "id", "code", "stock code"),
    "description": ("description", "desc", "descr", "name", "product name", "item description"),
    "cost": ("cost", "unit cost", "our cost", "net cost", "dealer cost", "your cost"),
    "base": ("base", "base price", "price", "list", "list price", "retail", "retail price", "sell price",
             "selling price", "msrp", "sale price"),
    "vendor_part": ("vendor part", "vendor part number", "vendor part #", "supplier part", "supplier part number",
                    "mfg part", "manufacturer part"),
}


class ImportRejected(ValueError):
    """The file can't be used. The text is safe to show."""

    def __init__(self, text: str, status: int = 422):
        super().__init__(text)
        self.status = status


# ---------------------------------------------------------------------------
# Reading the file
# ---------------------------------------------------------------------------

def _cell(v) -> str:
    return " ".join(str(v if v is not None else "").split())[:MAX_CELL]


def _read_csv(data: bytes) -> list[list[str]]:
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = data.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:
        raise ImportRejected("The file isn't readable text. Save it as CSV or .xlsx and try again.")
    sample = text[:20000]
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=",;\t")
    except csv.Error:
        dialect = csv.excel
    return [list(r) for r in csv.reader(io.StringIO(text), dialect)]


_NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
       "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
       "rel": "http://schemas.openxmlformats.org/package/2006/relationships"}


def _xml(z: zipfile.ZipFile, name: str):
    try:
        info = z.getinfo(name)
    except KeyError:
        return None
    if info.file_size > MAX_XML_BYTES:
        raise ImportRejected("The spreadsheet is too large. Split it into smaller files.", status=413)
    raw = z.read(name)
    if b"<!DOCTYPE" in raw[:2048] or b"<!ENTITY" in raw[:4096]:
        raise ImportRejected("The spreadsheet couldn't be read. Save it again from Excel and try again.")
    return ET.fromstring(raw)


def _col_index(ref: str) -> int:
    n = 0
    for ch in ref:
        if not ch.isalpha():
            break
        n = n * 26 + (ord(ch.upper()) - 64)
    return n - 1


def _read_xlsx(data: bytes) -> list[list[str]]:
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        raise ImportRejected("The spreadsheet couldn't be read. Save it again as .xlsx or CSV and try again.")
    with z:
        wb = _xml(z, "xl/workbook.xml")
        if wb is None:
            raise ImportRejected("The spreadsheet couldn't be read. Save it again as .xlsx or CSV and try again.")
        sheet = wb.find("m:sheets/m:sheet", _NS)
        target = "xl/worksheets/sheet1.xml"
        rels = _xml(z, "xl/_rels/workbook.xml.rels")
        if sheet is not None and rels is not None:
            rid = sheet.get(f"{{{_NS['r']}}}id")
            for rel in rels.findall("rel:Relationship", _NS):
                if rel.get("Id") == rid:
                    t = rel.get("Target") or ""
                    target = t.lstrip("/") if t.startswith("/") else "xl/" + t
                    break
        shared = []
        ss = _xml(z, "xl/sharedStrings.xml")
        if ss is not None:
            for si in ss.findall("m:si", _NS):
                shared.append("".join(t.text or "" for t in si.iter(f"{{{_NS['m']}}}t")))
        ws = _xml(z, target)
        if ws is None:
            raise ImportRejected("The spreadsheet has no sheet to read.")
    rows = []
    for row in ws.iter(f"{{{_NS['m']}}}row"):
        out: dict[int, str] = {}
        for i, c in enumerate(row.findall("m:c", _NS)):
            ref = c.get("r") or ""
            col = _col_index(ref) if ref else i
            if col < 0 or col >= MAX_COLS:
                continue
            t = c.get("t")
            v = c.find("m:v", _NS)
            if t == "s" and v is not None:
                try:
                    val = shared[int(v.text)]
                except (ValueError, IndexError, TypeError):
                    val = ""
            elif t == "inlineStr":
                val = "".join(x.text or "" for x in c.iter(f"{{{_NS['m']}}}t"))
            elif t == "b":
                val = "TRUE" if (v is not None and v.text == "1") else "FALSE"
            else:
                val = v.text if v is not None and v.text is not None else ""
            out[col] = val
        if out:
            rows.append([out.get(i, "") for i in range(max(out) + 1)])
        if len(rows) > MAX_ROWS + 20:
            break
    return rows


def read_table(filename: str, data: bytes) -> dict:
    """{"headers": [...], "rows": [[...]], "skipped_rows": n, "truncated": bool}.
    Raises ImportRejected (text safe to show)."""
    name = (filename or "").strip().lower()
    if len(data) > MAX_FILE_BYTES:
        raise ImportRejected("The file is too large (10 MB at most). Split it into smaller files.", status=413)
    if name.endswith(".xls"):
        raise ImportRejected("Old Excel files (.xls) can't be read. Save it as .xlsx or CSV and try again.", status=415)
    if name.endswith(".xlsx") or data[:2] == b"PK":
        raw = _read_xlsx(data)
    elif name.endswith((".csv", ".txt")) or not name:
        raw = _read_csv(data)
    else:
        raise ImportRejected("Use a spreadsheet: .xlsx or CSV.", status=415)
    raw = [[_cell(v) for v in r[:MAX_COLS]] for r in raw]
    head_at = None
    for i, r in enumerate(raw[:10]):
        texts = [v for v in r if v and _number(v) is None]
        if len(texts) >= 2:
            head_at = i
            break
    if head_at is None:
        raise ImportRejected("Couldn't find a header row (column names like Part #, Description, Price) in the "
                             "first 10 rows.")
    headers = raw[head_at]
    width = len(headers)
    while width and not headers[width - 1]:
        width -= 1
    headers = [h or f"Column {_letters(i)}" for i, h in enumerate(headers[:width])]
    rows, blank = [], 0
    for r in raw[head_at + 1:]:
        r = (r + [""] * width)[:width]
        if not any(r):
            blank += 1
            continue
        rows.append(r)
    if not rows:
        raise ImportRejected("The file has a header row but no rows under it.")
    return {"headers": headers, "rows": rows[:MAX_ROWS], "truncated": len(rows) > MAX_ROWS}


def _letters(i: int) -> str:
    s = ""
    i += 1
    while i:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _norm_header(h: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9#% ]", " ", (h or "").lower())).strip()


def suggest_mapping(headers: list[str], levels: list[str]) -> dict:
    """{target: column index} from the header names. Price levels map by their own name
    ("Wholesale", "Wholesale price"). Each column is used once."""
    norm = [_norm_header(h) for h in headers]
    used, out = set(), {}
    for lv in levels:
        key = _norm_header(lv)
        for i, h in enumerate(norm):
            if i not in used and h in (key, f"{key} price", f"price {key}", f"{key} level"):
                out[f"level:{lv}"] = i
                used.add(i)
                break
    for target in ("vendor_part", "part", "description", "cost", "base"):
        for hint in _HEADER_HINTS[target]:
            hit = next((i for i, h in enumerate(norm) if i not in used and h == hint), None)
            if hit is not None:
                out[target] = hit
                used.add(hit)
                break
    return out


def payload_from_table(table: dict, filename: str, levels: list[str]) -> dict:
    return {"type": "import", "source": "import", "file": {"name": (filename or "")[:120]},
            "headers": table["headers"], "rows": table["rows"], "truncated": bool(table.get("truncated")),
            "mapping": suggest_mapping(table["headers"], levels), "mode": "", "change": [],
            "folder": "", "count_type": "", "vendor": ""}


# ---------------------------------------------------------------------------
# AI folder suggestion (86e3q4zec): an "add" import has ONE folder for every new part in the
# file (the field server.py's _import_core prefills from this), so unlike a document upload's
# per-line suggestion, one cheap call looking at a sample of the descriptions is enough -- never
# one call per row. A forced tool call, not output_config.format: Haiku 5.5 has thinking on by
# default, billed against max_tokens, UNLESS tool_choice forces one tool (CLAUDE.md, confirmed
# live by server.py's own _extract_po_from_text) -- that keeps a tiny max_tokens safe here too.
# The real folder list is the tool's enum: the model can only answer with a name from it (or
# ""), so there is nothing to validate afterward.
# ---------------------------------------------------------------------------

FOLDER_SUGGEST_MODEL = "claude-haiku-5-5"
FOLDER_SUGGEST_TIMEOUT = 30.0
FOLDER_SUGGEST_MAX_TOKENS = 1024
FOLDER_SUGGEST_SAMPLE = 40   # a sample is enough to tell what kind of parts these are
_FOLDER_SUGGEST_TOOL = "pick_folder"


def _folder_suggest_tool(folders: list[str]) -> dict:
    return {"name": _FOLDER_SUGGEST_TOOL,
            "description": "Pick the one folder that best fits most of the given product descriptions.",
            "input_schema": {"type": "object",
                             "properties": {"folder": {"type": "string", "enum": [*folders, ""]}},
                             "required": ["folder"]}}


def suggest_import_folder(client, descriptions: list[str], folders: list[str]) -> str | None:
    """The one folder (its name, not a TREE_ID) that best fits most of `descriptions`, from the
    real `folders` list, or None when nothing was suggested. Never raises -- any problem here
    just means no suggestion, same as before this existed; the user still picks a folder."""
    sample = [d.strip() for d in (descriptions or []) if d and d.strip()][:FOLDER_SUGGEST_SAMPLE]
    folders = [f for f in (folders or []) if f]
    if not sample or not folders or client is None:
        return None
    try:
        msg = client.with_options(timeout=FOLDER_SUGGEST_TIMEOUT, max_retries=1).messages.create(
            model=FOLDER_SUGGEST_MODEL,
            max_tokens=FOLDER_SUGGEST_MAX_TOKENS,
            tools=[_folder_suggest_tool(folders)],
            tool_choice={"type": "tool", "name": _FOLDER_SUGGEST_TOOL},
            messages=[{"role": "user", "content": (
                "These are product descriptions from a spreadsheet of new parts about to be added to "
                "an inventory system:\n" + "\n".join(f"- {d[:120]}" for d in sample) + "\n\n"
                "Pick the one folder, from this company's real folders below, that best fits MOST of "
                "these products. If they're too mixed to share one folder, or none fits reasonably "
                "well, answer with an empty string. Folders: " + ", ".join(folders) + "."
            )}],
        )
    except Exception as e:
        log.warning(f"Import folder suggestion call failed: {type(e).__name__}: {e}")
        return None
    folder = None
    for block in msg.content or []:
        if getattr(block, "type", None) == "tool_use" and getattr(block, "name", None) == _FOLDER_SUGGEST_TOOL:
            data = block.input if isinstance(block.input, dict) else {}
            folder = data.get("folder")
            break
    log.info(f"Import folder suggestion: model={FOLDER_SUGGEST_MODEL} parts_sampled={len(sample)} "
             f"folders_offered={len(folders)} result={folder!r}")
    return folder or None


# ---------------------------------------------------------------------------
# Edits
# ---------------------------------------------------------------------------

def _level_targets(payload: dict) -> list[str]:
    return [k for k in payload.get("mapping") or {} if k.startswith("level:")]


def target_label(target: str) -> str:
    return target.split(":", 1)[1] + " price" if target.startswith("level:") else TARGET_LABELS[target]


def apply_import_patch(payload: dict, fields, options: dict | None, levels: list[str]) -> dict:
    """PATCH fields: mode, map.<target> (column index as text, "" = none), change.<target>
    ("yes" | ""), folder, count_type, vendor. ValueError (safe to show)."""
    if fields is None:
        return dict(payload)
    if not isinstance(fields, dict):
        raise ValueError("Fields must be an object.")
    new = dict(payload)
    new.pop("import_notice", None)      # an undo's outcome shows until the next edit
    mapping = dict(new.get("mapping") or {})
    change = set(new.get("change") or [])
    allowed_targets = set(TARGETS) | {f"level:{lv}" for lv in levels}
    for key, raw in fields.items():
        v = "" if raw is None else str(raw).strip()
        if key == "mode":
            if v not in ("",) + MODES:
                raise ValueError("Pick add new parts or update existing parts.")
            if v != new.get("mode"):
                new["mode"] = v
                change = set()          # switching mode never carries ticks over
        elif key.startswith("map."):
            target = key[4:]
            if target not in allowed_targets:
                raise ValueError("That column can't be set here.")
            if not v:
                mapping.pop(target, None)
                change.discard(target)
                continue
            if not v.isdigit() or int(v) >= len(new.get("headers") or []):
                raise ValueError(f"Pick a column for {target_label(target)} from the list.")
            col = int(v)
            for t, c in list(mapping.items()):
                if c == col and t != target:
                    mapping.pop(t)
                    change.discard(t)
            mapping[target] = col
        elif key.startswith("change."):
            target = key[7:]
            if target not in allowed_targets or target in ("part", "description", "vendor_part"):
                raise ValueError("That can't be changed by an import.")
            if v not in ("", "yes"):
                raise ValueError("Pick update or don't change.")
            (change.add if v == "yes" else change.discard)(target)
        elif key in ("folder", "count_type", "vendor"):
            rec = dm.apply_fields("part", {"folder": new.get("folder") or "", "count_type": new.get("count_type") or "",
                                           "vendor": new.get("vendor") or ""}, {key: v}, options)
            new[key] = rec[key]
        else:
            raise ValueError("That field can't be changed here.")
    new["mapping"] = mapping
    new["change"] = sorted(t for t in change if t in mapping)
    return new


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------

class ImportLookups(PoLookups):
    """Current values of many parts at once, for the before/after table."""

    def parts(self, ids: list[str]) -> dict[str, dict]:
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        if not keys:
            return {}
        t = self._t("INVENTRY")
        out = {}
        for n in range(0, len(keys), 500):
            rows = self.query(
                f'SELECT trim({t}."ID") AS id, trim(COALESCE({t}."DESCR_1", \'\')) AS description,'
                f' {t}."BASE" AS base, {t}."COST" AS cost, {t}."INACTIVE" AS inactive,'
                f' {t}."AUTO_COST" AS auto_cost, {t}."UPDATECOST" AS updatecost FROM {t}'
                f' WHERE upper(trim({t}."ID")) = ANY(%s) AND {t}."__deleted" IS NOT TRUE'
                f" AND {t}.\"ID\" NOT LIKE '($)%%'", (keys[n:n + 500],))
            out.update({r["id"].upper(): r for r in rows})
        return out

    def has_level_table(self) -> bool:
        ok = self.query("SELECT to_regclass(%s) IS NOT NULL AS ok", (self._t("INVPRICE"),))
        return bool(ok and ok[0].get("ok"))

    def level_rows(self, ids: list[str], levels: list[str]) -> dict[str, dict[str, dict]]:
        """{PART: {LEVEL: {level, markup, markup_id, price}}}. Call has_level_table() first."""
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        lv = sorted({x.strip().upper() for x in levels if x and x.strip()})
        if not keys or not lv:
            return {}
        p = self._t("INVPRICE")
        out: dict[str, dict[str, dict]] = {}
        for n in range(0, len(keys), 500):
            rows = self.query(
                f'SELECT trim({p}."ID") AS id, trim({p}."LEVEL") AS level, trim(COALESCE({p}."MARKUP", \'\')) AS markup,'
                f' trim(COALESCE({p}."MARKUP_ID", \'\')) AS markup_id, {p}."PRICE" AS price FROM {p}'
                f' WHERE upper(trim({p}."ID")) = ANY(%s) AND upper(trim({p}."LEVEL")) = ANY(%s)'
                f' AND {p}."__deleted" IS NOT TRUE', (keys[n:n + 500], lv))
            for r in rows:
                out.setdefault(r["id"].upper(), {})[r["level"].upper()] = r
        return out


# ---------------------------------------------------------------------------
# The card
# ---------------------------------------------------------------------------

def _number(v):
    """A money value from a cell: "$1,234.50", "1234.5", "12,50" (decimal comma). None if not."""
    t = str(v or "").strip().replace("$", "").replace(" ", "").replace(" ", "")
    if not t:
        return None
    if "," in t and "." not in t and re.fullmatch(r"-?\d+,\d{1,2}", t):
        t = t.replace(",", ".")
    t = t.replace(",", "")
    try:
        f = float(t)
    except ValueError:
        return None
    if f != f or abs(f) > MONEY_MAX:
        return None
    return round(f, 2)


def _f(v) -> float | None:
    try:
        return None if v is None else round(float(v), 2)
    except (TypeError, ValueError):
        return None


def _pct(now, new) -> str:
    if now in (None, 0):
        return "new" if new else ""
    d = (new - now) / now
    return f"{d * 100:+.1f}%"


def _examples(items: list[str], n: int = 5) -> str:
    more = "" if len(items) <= n else f" and {len(items) - n} more"
    return ", ".join(items[:n]) + more


def _column_options(headers: list[str]) -> list[dict]:
    return [{"value": "", "label": "Not in this file"}] + [
        {"value": str(i), "label": f"{_letters(i)}: {h}"} for i, h in enumerate(headers)]


def build_import_card(payload: dict, lookups, *, can_create: dict | None = None,
                      options: dict | None = None) -> dict:
    """The card plus "_api" (what save does, when not blocking) and "_summary"."""
    checks: list[dict] = [dict(c) for c in payload.get("import_notice") or []
                          if isinstance(c, dict) and c.get("level") in ("good", "warn")]

    def check(level, text):
        checks.append({"level": level, "text": text})

    can = can_create or {}
    headers = payload.get("headers") or []
    rows = payload.get("rows") or []
    mapping = payload.get("mapping") or {}
    mode = payload.get("mode") or ""
    change = [t for t in payload.get("change") or [] if t in mapping]
    levels = [o["value"] for o in (options or {}).get("price_levels") or []]
    col_opts = _column_options(headers)

    if can.get("part") is not True:
        check("block", "Your EBMS user can't add or change parts (Inventory, Advanced Entry or higher). "
                       "Ask someone who can to run this import.")
    if payload.get("truncated"):
        check("warn", f"The file has more than {MAX_ROWS} rows; only the first {MAX_ROWS} are used. "
                      "Split it to import the rest.")

    # ---- fields
    def colfield(target, label):
        c = mapping.get(target)
        return {"key": f"map.{target}", "label": f"{label} column", "value": "" if c is None else str(c),
                "display": next((o["label"] for o in col_opts if o["value"] == ("" if c is None else str(c))), ""),
                "tag": {"kind": "suggested", "text": "From the header"} if c is not None else None,
                "editable": True, "input": "select", "options": col_opts, "hint": None}

    mode_opts = [{"value": "", "label": "Pick one"}, {"value": "add", "label": "Add new parts"},
                 {"value": "update", "label": "Update existing parts"}]
    fields = [{"key": "mode", "label": "This import will", "value": mode,
               "display": next(o["label"] for o in mode_opts if o["value"] == mode) if mode else "",
               "tag": None, "editable": True, "input": "select", "options": mode_opts,
               "hint": "Pick add or update"}]
    fields.append(colfield("part", "Part #"))
    fields.append(colfield("description", "Description"))
    fields.append(colfield("cost", "Cost"))
    fields.append(colfield("base", "Base price"))
    for lv in levels:
        fields.append(colfield(f"level:{lv}", f"{lv} price"))
    if mode == "add":
        fields.append(colfield("vendor_part", "Vendor part #"))
    if mode == "update":
        yes_no = [{"value": "", "label": "Don't change"}, {"value": "yes", "label": "Update"}]
        for t in [t for t in ("cost", "base") if t in mapping] + [t for t in _level_targets(payload)
                                                                   if t.split(":", 1)[1] in levels]:
            on = t in change
            fields.append({"key": f"change.{t}", "label": f"Change {target_label(t).lower()}",
                           "value": "yes" if on else "", "display": "Update" if on else "Don't change",
                           "tag": None, "editable": True, "input": "select", "options": yes_no, "hint": None})
    if mode == "add":
        setup = lookups.folder_setup(payload.get("folder")) if payload.get("folder") else None
        part_rec = {"folder": payload.get("folder") or "", "count_type": payload.get("count_type") or "",
                    "vendor": payload.get("vendor") or ""}
        for f in dm.record_fields("part", dict(dm.new_record("part"), **part_rec), "imp", options, setup=setup):
            name = f["key"].split(".", 1)[1]
            if name in ("folder", "count_type", "vendor"):
                # Plain import settings, not a new-record block (no record / line / more keys)
                f = {k: v for k, v in f.items() if k not in ("record", "line", "required", "more")}
                f.update(key=name, tag=None)
                if name == "vendor":
                    f["label"] = "Primary vendor (all rows)"
                fields.append(f)

    # ---- rows
    part_col = mapping.get("part")
    if not mode:
        check("block", "Pick what this import does: add new parts or update existing parts.")
    if part_col is None:
        check("block", "Pick the column that holds the part numbers.")
    if mode == "update" and not change:
        check("block", "Pick at least one thing to change (cost, base price or a price level).")

    no_part, bad, dups, seen = [], [], [], {}
    parsed = []   # (row #, part, {target: value}, description, vendor_part)
    value_targets = change if mode == "update" else [t for t in ("cost", "base") if t in mapping]
    if part_col is not None:
        for n, r in enumerate(rows, 2):
            part = (r[part_col] if part_col < len(r) else "").strip().upper()
            if not part:
                no_part.append(str(n))
                continue
            if part in seen:
                dups.append(part)
                continue
            seen[part] = n
            vals, ok = {}, True
            for t in value_targets:
                cell = r[mapping[t]] if mapping[t] < len(r) else ""
                num = _number(cell)
                if num is None or num < 0:
                    if cell.strip() or mode == "update":
                        bad.append(f"row {n} ({target_label(t).lower()} “{cell}”)" if cell.strip()
                                   else f"row {n} (no {target_label(t).lower()})")
                        ok = False
                    continue
                vals[t] = num
            if not ok:
                continue
            desc = r[mapping["description"]].strip() if "description" in mapping and mapping["description"] < len(r) else ""
            vpart = r[mapping["vendor_part"]].strip() if "vendor_part" in mapping and mapping["vendor_part"] < len(r) else ""
            parsed.append((n, part, vals, desc, vpart))
    if no_part:
        check("warn", f"{_plural(len(no_part), 'row')} {'has' if len(no_part) == 1 else 'have'} no part number "
                      f"and {'is' if len(no_part) == 1 else 'are'} skipped: {'row' if len(no_part) == 1 else 'rows'} {_examples(no_part)}.")
    if dups:
        check("block", f"These part numbers are in the file more than once: {_examples(sorted(set(dups)))}. "
                       "Keep one row for each part and upload it again.")
    if bad:
        check("warn", f"{_plural(len(bad), 'row')} skipped because a value isn't a number: {_examples(bad)}.")

    lines, api_items, new_descriptions = [], [], []
    existing = lookups.parts([p for _, p, _, _, _ in parsed]) if parsed and mode else {}

    if mode == "update" and parsed and change:
        lv_targets = [t for t in change if t.startswith("level:")]
        lvl = {}
        if lv_targets:
            if not lookups.has_level_table():
                check("block", "Price levels can't be checked on this server yet (INVPRICE isn't copied to "
                               "IntraMind). Update base price or cost, or set the levels in EBMS.")
                lv_targets = []
            else:
                lvl = lookups.level_rows([p for _, p, _, _, _ in parsed], [t.split(":", 1)[1] for t in lv_targets])
        missing, unchanged, inactive = [], 0, []
        big, to_zero, below_cost, auto_cost, no_level_row = [], [], [], [], {}
        to_fixed: dict[str, list[str]] = {}
        follow_base = 0
        for n, part, vals, desc, _ in parsed:
            cur = existing.get(part)
            if cur is None:
                missing.append(part)
                continue
            pid = cur["id"].strip()
            sets, before = {}, {}
            for t in change:
                if t not in vals:
                    continue
                if t in ("cost", "base"):
                    now = _f(cur.get(t))
                else:
                    level = t.split(":", 1)[1]
                    row = (lvl.get(part) or {}).get(level.upper())
                    if row is None:
                        no_level_row.setdefault(level, []).append(pid)
                        continue
                    now = _f(row.get("price"))
                    before[t] = {"markup_id": row.get("markup_id") or "", "markup": row.get("markup") or ""}
                new = vals[t]
                if now is not None and abs(now - new) < 0.005 and (
                        t in ("cost", "base") or (before[t]["markup_id"] or "").upper() == FIXED_PRICE_FORMULA):
                    before.pop(t, None)
                    continue
                sets[t] = new
                before.setdefault(t, {"value": now})
                before[t]["value"] = now
                if len(lines) < SHOWN_LINES:
                    lines.append({"item": pid, "description": desc or cur.get("description") or "",
                                  "field": target_label(t), "now": fmt_money(now) if now is not None else "",
                                  "new": fmt_money(new), "pct": _pct(now, new), "editable": [], "removable": False})
                if now and abs(new - now) / now > BIG_CHANGE:
                    big.append(pid)
                if new == 0:
                    to_zero.append(pid)
                if t.startswith("level:") and (before[t]["markup_id"] or "").upper() != FIXED_PRICE_FORMULA:
                    to_fixed.setdefault(t.split(":", 1)[1], []).append(f"{pid} ({before[t]['markup'] or 'calculated'})")
            if not sets:
                unchanged += 1
                continue
            cost_after = sets.get("cost", _f(cur.get("cost")))
            for t, v in sets.items():
                if t != "cost" and cost_after and v < cost_after:
                    below_cost.append(f"{pid} {target_label(t).lower()} {fmt_money(v)} < cost {fmt_money(cost_after)}")
            if "cost" in sets and (cur.get("auto_cost") is True or cur.get("updatecost") is True):
                auto_cost.append(pid)
            if cur.get("inactive") is True:
                inactive.append(pid)
            if "base" in sets:
                follow_base += 1
            api_items.append({"row": n, "part": pid, "set": sets, "mirror_before": before})
        if missing:
            check("warn", f"{_plural(len(missing), 'part')} in the file {'isn’t' if len(missing) == 1 else 'aren’t'} "
                          f"in EBMS and {'is' if len(missing) == 1 else 'are'} skipped: {_examples(missing)}. "
                          "Use “Add new parts” for those.")
        for level, ids in no_level_row.items():
            check("warn", f"{_plural(len(ids), 'part')} {'has' if len(ids) == 1 else 'have'} no {level} price in EBMS "
                          f"and {'is' if len(ids) == 1 else 'are'} skipped for {level}: {_examples(ids)}.")
        if unchanged:
            check("good", f"{_plural(unchanged, 'part')} already {'has' if unchanged == 1 else 'have'} these values "
                          "and won't be touched.")
        if big:
            check("warn", f"{_plural(len(big), 'part')} change by more than {int(BIG_CHANGE * 100)}%: {_examples(big)}.")
        if to_zero:
            check("warn", f"{_plural(len(to_zero), 'part')} go to $0.00: {_examples(to_zero)}.")
        if below_cost:
            check("warn", f"{_plural(len(below_cost), 'price')} would be below cost: {_examples(below_cost, 3)}.")
        for level, ids in to_fixed.items():
            check("warn", f"{level} is calculated today on {_plural(len(ids), 'part')} ({_examples(ids, 3)}). "
                          f"It becomes a fixed price on {'that part' if len(ids) == 1 else 'those parts'} and stops "
                          "following its formula.")
        if auto_cost:
            check("warn", f"{_plural(len(auto_cost), 'part')} update their cost from purchases in EBMS, so the next "
                          f"bill can replace the cost imported here: {_examples(auto_cost)}.")
        if inactive:
            check("warn", f"{_plural(len(inactive), 'part')} {'is' if len(inactive) == 1 else 'are'} inactive in EBMS: "
                          f"{_examples(inactive)}.")
        if follow_base:
            check("good", "Price levels calculated from base price (like “Equal to”) follow the new base price "
                          "on their own.")
        if api_items:
            check("good", f"{_plural(len(api_items), 'part')} will change. Old values are kept so Undo can put them back.")

    if mode == "add" and parsed:
        taken = [p for _, p, _, _, _ in parsed if p in existing]
        if taken:
            check("warn", f"{_plural(len(taken), 'part')} {'is' if len(taken) == 1 else 'are'} already in EBMS and "
                          f"{'is' if len(taken) == 1 else 'are'} skipped: {_examples(taken)}. "
                          "Use “Update existing parts” for those.")
        folder = (payload.get("folder") or "").strip()
        if not folder:
            check("block", "Pick the folder for the new parts. The folder sets their count type and GL accounts.")
        setup = lookups.folder_setup(payload.get("folder")) if folder else None
        if folder and setup is None:
            check("warn", "Couldn't read the folder's default setup. EBMS still applies it; check a new part's "
                          "count type and GL accounts in EBMS after saving.")
        ct = dm.effective_count_type({"count_type": payload.get("count_type")}, setup)
        if ct in dm.SERIALIZED_TYPES:
            check("warn", f"The new parts are {dm.count_type_name(ct)}: enter serial numbers in EBMS.")
        vendor = (payload.get("vendor") or "").strip()
        if vendor and lookups.vendor(vendor) is None:
            check("block", f"{vendor} isn't a vendor in EBMS. Fix the primary vendor.")
        long_ids, no_desc = [], []
        for n, part, vals, desc, vpart in parsed:
            if part in existing:
                continue
            if len(part) > 24:
                long_ids.append(part[:30])
                continue
            if not desc:
                no_desc.append(f"row {n}")
                continue
            new_descriptions.append(desc)
            rec = dm.new_record("part", id=part, description=desc[:80], folder=payload.get("folder") or "",
                                count_type=payload.get("count_type") or "", vendor=vendor,
                                cost=vals.get("cost", ""), price=vals.get("base", ""))
            api_items.append({"row": n, "part": part, "rec": rec, "vendor_part": vpart[:24]})
            if len(lines) < SHOWN_LINES:
                lines.append({"item": part, "description": desc, "cost": fmt_money(vals["cost"]) if "cost" in vals else "",
                              "price": fmt_money(vals["base"]) if "base" in vals else "", "editable": [], "removable": False})
        if long_ids:
            check("warn", f"{_plural(len(long_ids), 'part number')} {'is' if len(long_ids) == 1 else 'are'} longer than "
                          f"24 characters and skipped: {_examples(long_ids)}.")
        if no_desc:
            check("warn", f"{_plural(len(no_desc), 'row')} {'has' if len(no_desc) == 1 else 'have'} no description and "
                          f"{'is' if len(no_desc) == 1 else 'are'} skipped: {_examples(no_desc)}.")
        if api_items:
            check("good", f"{_plural(len(api_items), 'new part')} will be added. Undo removes the ones no document uses yet.")

    count = len(api_items)
    if mode and part_col is not None and parsed is not None and count == 0 and not any(
            c["level"] == "block" for c in checks):
        check("block", "Nothing to change: no row in the file changes anything in EBMS.")
    blocking = any(c["level"] == "block" for c in checks)

    if mode == "update":
        what = " and ".join(target_label(t).lower() for t in change) if len(change) <= 2 else f"{len(change)} fields"
        save_label = f"Update {what} on {_plural(count, 'part')}" if count else "Update parts"
        columns = [{"key": "item", "label": "Part"}, {"key": "field", "label": "Field"},
                   {"key": "now", "label": "Now", "num": True}, {"key": "new", "label": "New", "num": True},
                   {"key": "pct", "label": "Change", "num": True}]
        note = ("Each part changes in EBMS as soon as it's saved (parts have no draft state). Old values are kept, "
                "so Undo can put them back.")
    elif mode == "add":
        save_label = f"Add {_plural(count, 'part')}" if count else "Add parts"
        columns = [{"key": "item", "label": "Part"}, {"key": "cost", "label": "Cost", "num": True},
                   {"key": "price", "label": "Price", "num": True}]
        note = ("New parts are live in inventory as soon as they're added. Undo removes the ones no document "
                "uses yet.")
    else:
        save_label, columns, note = "Save", [], None
    if count > SHOWN_LINES:
        note = (note or "") + f" The table shows the first {SHOWN_LINES} of {count}."
    name = (payload.get("file") or {}).get("name") or "your file"
    return {
        "type": "import", "type_tile": TYPE_TILE, "type_label": TYPE_LABEL,
        "title": f"{name}, {_plural(len(rows), 'row')}",
        "lead": f"Here is what {name} would do in EBMS." if mode else
                f"I read {_plural(len(rows), 'row')} from {name}. Pick what the import does, then check the columns.",
        "fields": fields, "line_columns": columns, "lines": lines, "totals": [],
        "checks": checks, "blocking": blocking, "note": note, "save_label": save_label, "amount": "",
        "confirm_count": count if not blocking else None,
        "_api": None if blocking else {"mode": mode, "items": api_items, "change": change,
                                       "confirm_count": count},
        "_summary": {"mode": mode, "parts": count, "change": change, "file": name, "rows": len(rows)},
        # New-part descriptions even while blocking (no folder picked yet): server.py uses these,
        # once, to suggest the one folder for the whole import (86e3q4zec) -- _api is None then.
        "_new_descriptions": new_descriptions,
    }
