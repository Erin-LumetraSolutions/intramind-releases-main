# EBMS Live - pull latest release from GitHub and restart the server
# Runs automatically every 6 hours via Windows Task Scheduler (as SYSTEM).
# Can also be run manually as Administrator.

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ErrorActionPreference = "Stop"
$INSTALL_DIR   = "C:\Program Files\IntraMind"
$DATA_DIR      = "C:\ProgramData\IntraMind"
$AGENT_SERVICE = "EBMSLiveAgent"
$CF_SERVICE_NAME = "IntramindCloudServices"
$CF_SYS_DIR    = "C:\Windows\System32\config\systemprofile\.cloudflared"
$LOG_FILE           = "$DATA_DIR\update.log"
$TASK_NAME          = "IntraMindAutoUpdate"
$LOCK_FILE          = "$DATA_DIR\update.lock"
$ADMIN_ACTION_FILE  = "$DATA_DIR\last_admin_action.json"
$INSTALLED_MANIFEST_VERSION_FILE = "$DATA_DIR\installed_manifest_version.txt"

$MANIFEST_URLS = @{
    stable = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases/main/manifest.json"
    beta   = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases-beta/main/manifest.json"
    main   = "https://raw.githubusercontent.com/Erin-LumetraSolutions/intramind-releases-main/main/manifest.json"
}

function Log($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Cyan
}
function Warn($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') WARNING: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Yellow
}
function Complete-AdminAction($result, $detail, $version) {
    # Records the outcome of this run (scheduled or portal-triggered) for the
    # IntraMind admin portal's /health poll to surface, and clears the
    # in-progress lock /admin/update creates before launching this script.
    # Every exit path below must go through this so a customer never gets
    # stuck locked out of a retry. See docs/superpowers/specs/
    # 2026-08-07-portal-remote-admin-design.md §4.
    Remove-Item -Path $LOCK_FILE -Force -ErrorAction SilentlyContinue
    $action = @{
        action  = "update"
        result  = $result
        detail  = $detail
        version = $version
        at      = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    } | ConvertTo-Json -Compress
    Set-Content -Path $ADMIN_ACTION_FILE -Value $action -NoNewline -Encoding utf8 -ErrorAction SilentlyContinue
}
function Fail($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ERROR: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Red
    Complete-AdminAction -result "error" -detail $msg -version $null
    exit 1
}

Log "EBMS Live Updater starting"

# --- Register scheduled task if not already present ---
$task = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
if (-not $task) {
    Log "Registering auto-update scheduled task (every 6 hours)..."
    try {
        $action    = New-ScheduledTaskAction -Execute "powershell.exe" `
                       -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$INSTALL_DIR\update.ps1`""
        $trigger   = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Hours 6) -Once -At "00:00"
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
        $settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 10) `
                       -StartWhenAvailable -MultipleInstances IgnoreNew
        Register-ScheduledTask -TaskName $TASK_NAME -Action $action -Trigger $trigger `
            -Principal $principal -Settings $settings -Force | Out-Null
        Log "Scheduled task registered."
    } catch {
        Fail "Failed to register scheduled task: $_"
    }
}

# --- Ensure both services have crash-recovery actions configured ---
# Backfill for machines whose services were registered before this was added
# to install.ps1/deploy.ps1 -- idempotent and cheap, so this runs every
# 6-hour cycle (deliberately placed before the version-check early return
# below, unlike the Cloudflared-name migration further down, which only gets
# one shot per version bump). See Known_Issues.md / 86e2nuxz5: EBMSLiveAgent
# had no recovery actions at all, and its uvicorn subprocess crashing left
# the service showing "Running" in Windows with nothing actually listening.
#
# EBMSLiveAgent also needs FAILURE_ACTIONS_ON_NONCRASH_FAILURES enabled for
# the restart actions above to actually fire -- live-verified 2026-08-07 on
# ErinTest that without it, its own crash handling (a clean SERVICE_STOPPED
# report with a nonzero exit code, not an unhandled process crash) is
# treated by Windows as a "non-crash failure," which sc.exe failure's
# restart actions ignore by default. With the flag set, the service
# actually restarted within ~7s of the child dying; without it, it stayed
# Stopped indefinitely. Scoped to EBMSLiveAgent only, not the tunnel service
# -- $CF_SERVICE_NAME runs cloudflared.exe directly with no wrapper reporting
# a clean stop, so it doesn't hit this same case, and this wasn't tested
# against it.
foreach ($svcName in @($AGENT_SERVICE, $CF_SERVICE_NAME)) {
    if (Get-Service $svcName -ErrorAction SilentlyContinue) {
        sc.exe failure $svcName reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    }
}
if (Get-Service $AGENT_SERVICE -ErrorAction SilentlyContinue) {
    sc.exe failureflag $AGENT_SERVICE 1 | Out-Null
}

# --- Ensure the IntraMind cloudflared tunnel service is actually running ---
# Deliberately placed here (before the version-check early return below), same
# reasoning as the crash-recovery backfill above: this must run every 6-hour
# cycle, not just on a cycle that happens to install a new version. It was
# previously placed later in this script, after the early return, so it only
# ever ran during an actual update -- meaning a tunnel stopped for any reason
# other than a crash (sc.exe failure only catches crashes, not e.g. a manual
# Stop-Service) stayed down until the next real version bump shipped, possibly
# weeks later. Found via a real incident on 2026-08-07. Ownership-verified via
# binPath first, same as the Cloudflared-name migration below -- never touch a
# service just because it has this name; see that block's own comment for the
# incident this protects against.
$svcInfo = Get-CimInstance Win32_Service -Filter "Name='$CF_SERVICE_NAME'" -ErrorAction SilentlyContinue
if ($svcInfo -and $svcInfo.PathName -like "*$CF_SYS_DIR*") {
    $cfSvc = Get-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue
    if ($cfSvc.Status -ne "Running") {
        Log "$CF_SERVICE_NAME was not running - starting it..."
        Start-Service $cfSvc.Name -ErrorAction SilentlyContinue
        Log "$CF_SERVICE_NAME started."
    }
} elseif ($svcInfo) {
    Warn "Service '$CF_SERVICE_NAME' exists but is not owned by IntraMind (binPath: $($svcInfo.PathName)). Not touching it."
} else {
    Warn "IntraMind's own cloudflared tunnel service not found - tunnel may be down."
}

# --- Read config from .env ---
$PORT = "8767"; $CHANNEL = "stable"
if (Test-Path "$DATA_DIR\.env") {
    foreach ($line in Get-Content "$DATA_DIR\.env") {
        if ($line -match "^EBMS_LIVE_PORT=(.+)$")    { $PORT    = $Matches[1].Trim() }
        if ($line -match "^EBMS_LIVE_CHANNEL=(.+)$") { $CHANNEL = $Matches[1].Trim().ToLower() }
    }
}
if (-not $MANIFEST_URLS.ContainsKey($CHANNEL)) {
    # Was silent before -- a box configured for a channel this copy of
    # update.ps1 doesn't know about (e.g. "main" on a box whose update.ps1
    # predates that channel existing) fell back to stable with zero trace
    # anywhere. Live-confirmed on ErinTest 2026-08-10 (86e2kj0kn): that
    # silent substitution combined with stable's real published version
    # being older than what was actually running made an unannounced
    # channel fallback look identical to a routine same-channel update,
    # and it took real debugging to even notice the channel had changed.
    Warn "Configured channel '$CHANNEL' is not recognized by this copy of update.ps1 (known: $($MANIFEST_URLS.Keys -join ', ')) -- falling back to stable. This usually means this box's update.ps1 is older than its configured channel; the fallback itself is intentional (a safe default), but if you didn't expect this channel to be unrecognized, update.ps1 on this box may be stale."
    $CHANNEL = "stable"
}
$MANIFEST_URL = $MANIFEST_URLS[$CHANNEL]
Log "Channel: $CHANNEL"

# --- Check current running version ---
$versionBefore = "unknown"
try {
    $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 5
    $versionBefore = ($resp.Content | ConvertFrom-Json).version
} catch {}

# --- Fetch manifest from latest release (no auth required) ---
$manifest = $null
try {
    $raw = Invoke-WebRequest -Uri $MANIFEST_URL -UseBasicParsing -TimeoutSec 15
    $manifest = $raw.Content | ConvertFrom-Json
} catch {
    Fail "Could not fetch update manifest from $MANIFEST_URL -- check network connection."
}

$latestVersion = $manifest.version
$zipUrl        = $manifest.zip_url
$expectedSha   = $manifest.sha256
$whatsNew      = $manifest.whats_new

# The beta manifest tags versions as "x.y.z-beta", but /health reports the bare
# "x.y.z" from server.py. Strip any pre-release suffix from both sides before
# comparing so a beta box doesn't see itself as perpetually out of date and
# re-install (and restart the service) on every cycle.
#
# The main channel is different: its manifest version carries a commit-SHA
# build suffix ("x.y.z-main.<sha>") specifically so two pushes with an
# unchanged VERSION are still distinguishable -- but /health always reports
# the bare VERSION regardless of channel, so comparing against it the same
# way as beta/stable would make main-channel boxes install on literally every
# 6-hour cycle even when nothing changed (the manifest version never equals
# the bare /health version, since one always has a suffix and the other never
# does). So for a "-main." manifest version, compare the FULL string against
# the full manifest version this box last successfully installed (persisted
# to $INSTALLED_MANIFEST_VERSION_FILE below), not against /health's version.
if ($latestVersion -match '-main\.') {
    $installedManifestVersion = ""
    if (Test-Path $INSTALLED_MANIFEST_VERSION_FILE) {
        $installedManifestVersion = (Get-Content $INSTALLED_MANIFEST_VERSION_FILE -Raw).Trim()
    }
    if ($latestVersion -eq $installedManifestVersion) {
        Log "Already up to date (version $latestVersion) -- skipping."
        Complete-AdminAction -result "ok" -detail "Already up to date" -version $versionBefore
        exit 0
    }
} else {
    $latestCompare = ($latestVersion -split '-')[0]
    $beforeCompare = ($versionBefore -split '-')[0]

    if ($latestCompare -eq $beforeCompare) {
        Log "Already up to date (version $versionBefore) -- skipping."
        Complete-AdminAction -result "ok" -detail "Already up to date" -version $versionBefore
        exit 0
    }
}

Log "Updating: $versionBefore -> $latestVersion"

# --- Download release zip ---
$zipPath = "$env:TEMP\intramind-release.zip"
try {
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
    Log "Downloaded release zip."
} catch {
    Fail "Failed to download release zip from $zipUrl"
}

# --- Verify SHA256 checksum ---
$actualSha = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
if ($actualSha -ne $expectedSha.ToLower()) {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    Fail "Checksum mismatch. Expected: $expectedSha  Got: $actualSha -- aborting update."
}
Log "Checksum verified."

# --- Extract to install dir ---
try {
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    foreach ($entry in $zip.Entries) {
        $destPath = Join-Path $INSTALL_DIR $entry.FullName
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destPath, $true)
        Log "  Extracted $($entry.FullName)"
    }
    $zip.Dispose()
} catch {
    Fail "Failed to extract release zip: $_"
} finally {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
}

# --- Write pending update notification for UI ---
$pending = @{ version = $latestVersion; whats_new = $whatsNew } | ConvertTo-Json -Compress
Set-Content "$DATA_DIR\pending_update.txt" $pending -NoNewline -ErrorAction SilentlyContinue
Log "Pending update notification written for version $latestVersion"

# --- Migrate legacy "Cloudflared" service name to "IntramindCloudServices" ---
# Renamed to avoid colliding with other Cloudflare Tunnel products (e.g. Koble)
# that use the default service name. install.ps1 does this migration on a fresh
# reinstall, but most customers only ever get auto-updated and never re-run the
# installer, so do it here too. NEVER touch a service just because it's named
# "Cloudflared": on a shared machine that name might belong to another product.
# Verify ownership by binPath first -- this runs unattended every 6 hours, so an
# unverified assumption here means silently deleting someone else's service on a
# schedule. See docs/cloudflared-tunnel-setup.md Troubleshooting for the
# 2026-07-16 mmp-ebms incident this check exists to prevent.
$legacyCfSvc = Get-CimInstance Win32_Service -Filter "Name='Cloudflared'" -ErrorAction SilentlyContinue
if ($legacyCfSvc -and $legacyCfSvc.PathName -like "*$CF_SYS_DIR*") {
    Log "Found legacy IntraMind 'Cloudflared' service - migrating to $CF_SERVICE_NAME..."
    $legacyBinPath = $legacyCfSvc.PathName
    $wasRunning = ($legacyCfSvc.State -eq "Running")
    Stop-Service "Cloudflared" -Force -ErrorAction SilentlyContinue
    sc.exe delete Cloudflared | Out-Null
    sc.exe create $CF_SERVICE_NAME binPath= $legacyBinPath start= auto DisplayName= "IntraMind Cloud Services" | Out-Null
    sc.exe failure $CF_SERVICE_NAME reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    if ($wasRunning) { Start-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue }
    Log "Migrated to $CF_SERVICE_NAME."
} elseif ($legacyCfSvc) {
    Warn "A 'Cloudflared' service exists but is not owned by IntraMind (binPath: $($legacyCfSvc.PathName)). Leaving it untouched."
}

# --- Restart agent service ---
Log "Restarting $AGENT_SERVICE..."
try {
    Restart-Service $AGENT_SERVICE -ErrorAction Stop
    Log "Service restarted."
} catch {
    Fail "Failed to restart $AGENT_SERVICE`: $_"
}

# --- Verify new version ---
Start-Sleep -Seconds 5
$versionAfter = "unknown"
for ($i = 0; $i -lt 10; $i++) {
    try {
        $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
        if ($resp.StatusCode -eq 200) {
            $versionAfter = ($resp.Content | ConvertFrom-Json).version
            break
        }
    } catch {}
    Start-Sleep -Seconds 2
}

if ($versionAfter -eq "unknown") {
    Warn "Server not responding after restart -- check $DATA_DIR\agent.log"
    Complete-AdminAction -result "error" -detail "Server not responding after restart -- check agent.log" -version $versionBefore
} else {
    Log "Update complete. Version: $versionAfter"
    Set-Content -Path $INSTALLED_MANIFEST_VERSION_FILE -Value $latestVersion -NoNewline
    Complete-AdminAction -result "ok" -detail $null -version $versionAfter
}
