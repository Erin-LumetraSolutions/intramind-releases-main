# EBMS Live - pull latest release from GitHub and restart the server
# Runs automatically every 6 hours via Windows Task Scheduler (as SYSTEM).
# Can also be run manually as Administrator.

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ErrorActionPreference = "Stop"
# 86e3gevzm A8-F4 (Batch Y7): started first thing so the two deadline gates
# below measure (nearly) the whole run, as the task's ExecutionTimeLimit does.
$script:RunStopwatch = [System.Diagnostics.Stopwatch]::StartNew()

# Move this process's own working directory off $INSTALL_DIR before doing
# anything else. If this script is launched by a process whose CWD is
# $INSTALL_DIR (e.g. the portal's admin/update launcher, which likely
# inherits the agent service's own working directory), Windows holds a
# directory handle that would block the rename-swap further down with a
# sharing violation -- deterministically, on that launch path.
# Set-Location alone does not move the actual process working directory;
# SetCurrentDirectory does. See 86e2rrzj2.
[System.IO.Directory]::SetCurrentDirectory($env:SystemRoot)
Set-Location $env:SystemRoot

$INSTALL_DIR   = "C:\Program Files\IntraMind"
$DATA_DIR      = "C:\ProgramData\IntraMind"
# 86e33krzt final-review I1: EBMSLiveAgent's real binPath is
# pythonservice.exe under THIS directory, not under $INSTALL_DIR -- a
# sibling, not a subdirectory. Kept in sync by hand with install.ps1:122,
# migrate.ps1:19, and onboarding/deploy.ps1:145's own identical copies of
# this same literal (same hand-sync convention $MANIFEST_URLS below uses).
$PY_DIR        = "C:\Program Files\IntraMindPython"
$AGENT_SERVICE = "EBMSLiveAgent"
$CF_SERVICE_NAME = "IntramindCloudServices"
$CF_SYS_DIR    = "C:\Windows\System32\config\systemprofile\.cloudflared"
$LOG_FILE           = "$DATA_DIR\update.log"
$TASK_NAME          = "IntraMindAutoUpdate"
$LOCK_FILE          = "$DATA_DIR\update.lock"
$RUN_LOCK_FILE      = "$DATA_DIR\update.running.lock"
$ADMIN_ACTION_FILE  = "$DATA_DIR\last_admin_action.json"
$INSTALLED_MANIFEST_VERSION_FILE = "$DATA_DIR\installed_manifest_version.txt"
# 86e2zbm5q: live-observed 2026-08-25 -- a directory rename during the
# atomic swap can neither succeed nor throw for 10+ minutes under real
# conditions (suspected but unconfirmed: an active antivirus real-time
# scan holding a handle open), well past what Rename-DirectoryWithRetry's
# own fast-failure-oriented retry loop expects. Generous relative to the
# sub-second normal case, bounded well short of "forever".
$RENAME_TIMEOUT_SECONDS = 90
# 86e3gevzm A8-F2 (Batch Y2): how long the post-start /health check waits for
# the service to answer, as a Stopwatch deadline. It was a 10-try loop that
# really lasted about 55 s (a refused localhost connect can take about 3 s on
# Windows). Used by the main verify step and by Invoke-Rollback, through
# Wait-ForHealth.
$VERIFY_TIMEOUT_SECONDS = 90
# 86e3gevzm A8-F2 (Batch Y3): a version that failed (it rolled back, or its
# dependencies failed to install) is recorded in $FAILED_RELEASE_FILE and
# scheduled runs skip it for $FAILED_RELEASE_SKIP_HOURS h. A portal "Update
# Now" bypasses the skip: it is recognised by $LOCK_FILE (server.py's
# admin_update creates it right before `schtasks /run`, nothing else does)
# being younger than $PORTAL_LOCK_MAX_AGE_SECONDS (the same 1800 s ceiling as
# server.py's _UPDATE_LOCK_STALE_AFTER_SECONDS).
$FAILED_RELEASE_FILE = "$DATA_DIR\failed_release.json"
$FAILED_RELEASE_SKIP_HOURS = 24
$PORTAL_LOCK_MAX_AGE_SECONDS = 1800
# 86e3gevjc (Batch Y5): pip runs on update unless the release's
# requirements_live.txt equals BOTH the recorded installed hash
# ($REQ_HASH_FILE) and the current install's requirements_live.txt (see
# Get-RequirementsDecision). There is no venv: pip installs into the shared
# site-packages of the full CPython in $PY_DIR (the interpreter
# pythonservice.exe runs), so a directory swap does not undo packages;
# Invoke-Rollback and the swap failure paths re-run pip for that (Batch Y6
# and the Final Review fix wave). The wheelhouse and the pip log live under
# $DATA_DIR (SYSTEM and Administrators only), never in a temp folder another
# account can write to. pip's own -q --log replaces any stdout capture (see
# Invoke-ProcessWithTimeout).
# Final Review fix wave (I1): pip runs as SYSTEM and would otherwise read the
# machine-wide config file C:\ProgramData\pip\pip.ini, which any local user
# can create (C:\ProgramData lets Users create folders), so a planted
# index-url would feed an attacker's wheels into the service. Every pip child
# gets PIP_CONFIG_FILE=nul in its own environment (Invoke-ProcessWithTimeout),
# which makes pip skip ALL config files; --isolated also makes it ignore PIP_*
# environment variables and the user config. Never "-I" here: for pip install
# and pip download that means --ignore-installed.
$PY_EXE = "$PY_DIR\python.exe"
$REQ_HASH_FILE = "$DATA_DIR\installed_requirements.sha256"
$PIP_WHEELHOUSE = "$DATA_DIR\pip-wheelhouse"
$PIP_LOG_FILE = "$DATA_DIR\update-pip.log"
$PIP_COMMON_ARGS = @("-m", "pip", "--isolated", "--disable-pip-version-check", "--no-input", "-q", "--log", $PIP_LOG_FILE)
$PIP_DOWNLOAD_TIMEOUT_SECONDS = 180
$PIP_INSTALL_TIMEOUT_SECONDS = 120
$PIP_ROLLBACK_TIMEOUT_SECONDS = 120
# 86e3gevzm A8-F4 (Batch Y7): the scheduled task's ExecutionTimeLimit is
# $TASK_TIME_LIMIT_MINUTES (it was 10, and the worst case before pip was
# already about 17 minutes). Two deadline gates on $script:RunStopwatch keep
# a run inside it: gate 1 defers the update (no stop, no downtime) when the
# steps before the stop took more than $PRE_STOP_BUDGET_SECONDS; gate 2 skips
# the best-effort dependency re-install when fewer than
# $REPIP_MIN_REMAINING_SECONDS remain. 20 minutes alone does not cover the
# worst case with pip (about 25 minutes). With the gates the worst case with
# no rename timeout is about 975 s (pre-stop 300, stop 60, Phase B 120,
# start 60, verify about 95, then a rollback: stop 60, re-pip about 125,
# start 60, verify about 95). Each directory rename that hits its 90 s
# timeout and still succeeds adds about 98 s; the gate-2 floor of 300 s
# keeps the run inside the limit unless all four renames (two in the swap,
# two in the rollback) do, a case the crash-recovery block handles on the
# next run. Both 1800 s lock-stale ceilings (here and in server.py) stay
# above the limit.
$TASK_TIME_LIMIT_MINUTES = 20
$RUN_TIME_LIMIT_SECONDS = $TASK_TIME_LIMIT_MINUTES * 60
$PRE_STOP_BUDGET_SECONDS = 300
# Final Review fix wave (M1): was 150 s, which cannot cover the re-pip cap
# (120 s, about 125 s with the kill wait) plus the start (60 s) and the
# verify (about 95 s) that follow: about 275 s, so 300 s.
$REPIP_MIN_REMAINING_SECONDS = 300

# 86e2ykh2a: kept in sync by hand with install.ps1's and
# onboarding/deploy.ps1's own copies of this same dict, and with
# server.py's CHANNELS constant / portal/server.py's own MANIFEST_URLS --
# 4 copies total.
$MANIFEST_URLS = @{
    stable = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases/main/manifest.json"
    beta   = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases-beta/main/manifest.json"
    main   = "https://raw.githubusercontent.com/Erin-LumetraSolutions/intramind-releases-main/main/manifest.json"
}

function Rotate-LogIfNeeded($Path, $MaxBytes = 1MB, $BackupCount = 3) {
    # update.ps1 is a fresh process every 6-hour scheduled run (unlike
    # service.py's agent.log, which stays open for the life of a long-running
    # service) -- Add-Content opens/writes/closes $LOG_FILE per call, so there
    # is no persistent handle to worry about here. A simple check-and-shift at
    # the top of each run is enough; no periodic re-check needed mid-run.
    # Best-effort throughout, matching this script's established philosophy
    # (icacls, sc.exe config, the temp-file sweep) -- a rotation failure must
    # never block an update cycle. See 86e30r39b.
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return }
        if ((Get-Item -LiteralPath $Path).Length -lt $MaxBytes) { return }
        $oldest = "$Path.$BackupCount"
        if (Test-Path -LiteralPath $oldest) {
            Remove-Item -LiteralPath $oldest -Force -ErrorAction SilentlyContinue
        }
        for ($i = $BackupCount - 1; $i -ge 1; $i--) {
            $src = "$Path.$i"
            if (Test-Path -LiteralPath $src) {
                Move-Item -LiteralPath $src -Destination "$Path.$($i + 1)" -Force -ErrorAction SilentlyContinue
            }
        }
        Move-Item -LiteralPath $Path -Destination "$Path.1" -Force -ErrorAction SilentlyContinue
    } catch {
        # Swallow -- the next Add-Content call below recreates $Path fresh
        # regardless of whether rotation itself fully succeeded.
    }
}

function Log($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    # 86e30bg1w: Write-Host -ForegroundColor can throw ("No process is on the
    # other end of the pipe", Win32 0xE9) in this script's real execution
    # context -- spawned by server.py with no real console attached, via
    # subprocess.Popen(stdout=DEVNULL) -- observed live 2026-08-27 mid-update,
    # after a dozen+ earlier calls in the same run had already succeeded (so
    # this is timing-dependent, not deterministic; interactive testing can't
    # reproduce it). The file-based log line above already wrote
    # unconditionally, so the console echo below is optional -- never let its
    # failure propagate into the caller and abort real update logic.
    try { Write-Host $line -ForegroundColor Cyan } catch { }
}
function Warn($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') WARNING: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    try { Write-Host $line -ForegroundColor Yellow } catch { }
}
function Stop-ServiceWithTimeout($ServiceName, $TimeoutSeconds = 60) {
    # 86e31dqfh: neither Stop-Service nor Start-Service accepts a timeout
    # parameter -- a hang inside SCM itself could block this script
    # indefinitely. System.ServiceProcess.ServiceController.WaitForStatus
    # is an in-process .NET call bounded by a real TimeSpan, immune to the
    # Start-Job console-pipe failure this codebase already proved out
    # twice (see Rename-DirectoryWithRetry's own comment history). Throws
    # System.ServiceProcess.TimeoutException on a bound violation -- every
    # call site already has a defined error path for a Stop-Service/
    # Start-Service failure, so this is a drop-in replacement, not a new
    # failure mode to design for.
    $sc = New-Object System.ServiceProcess.ServiceController($ServiceName)
    $sc.Stop()
    $sc.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Stopped,
        [TimeSpan]::FromSeconds($TimeoutSeconds))
}

function Start-ServiceWithTimeout($ServiceName, $TimeoutSeconds = 60) {
    $sc = New-Object System.ServiceProcess.ServiceController($ServiceName)
    $sc.Start()
    $sc.WaitForStatus([System.ServiceProcess.ServiceControllerStatus]::Running,
        [TimeSpan]::FromSeconds($TimeoutSeconds))
}
# 86e31dqfh follow-up: [System.ServiceProcess.ServiceController] et al. are
# NOT guaranteed loaded just because the type is referenced -- confirmed
# live in a fresh -NonInteractive session (matching this script's real
# scheduled-task invocation) that only Test-Path/Get-ChildItem/Remove-Item
# ran first: "Cannot find type [System.ServiceProcess.ServiceController]".
# Only an actual Get-Service/Stop-Service/Start-Service-family cmdlet call
# implicitly loads the assembly, and this script's own interrupted-prior-
# swap crash-recovery branch (further down) can reach
# Start-ServiceWithTimeout after nothing but rename/Test-Path operations --
# no such cmdlet call guaranteed first. Load the assembly explicitly and
# unconditionally here, before any code path (including that branch) can
# reach either helper above. Guarded in its own try/catch, same reasoning
# as the IntraMind.Native.JobObject Add-Type block just below: with
# $ErrorActionPreference = "Stop" active script-wide and no try/catch
# anywhere above this point, an unguarded failure here would abort the
# ENTIRE update run before Fail()/Complete-AdminAction() ever executes --
# invisible to both agent.log and the portal. Guarding it degrades back to
# exactly the pre-fix gap (each of the 11 WithTimeout call sites already
# has its own error handling for a failed helper call) instead of a full-
# script silent kill switch.
try {
    Add-Type -AssemblyName System.ServiceProcess
} catch {
    Warn "Could not load System.ServiceProcess ($_) -- Stop-ServiceWithTimeout/Start-ServiceWithTimeout calls will fail at their own call sites, each already guarded."
}
function Complete-AdminAction($result, $detail, $version) {
    # Records the outcome of this run (scheduled or portal-triggered) for the
    # IntraMind admin portal's /health poll to surface, and clears the
    # in-progress lock /admin/update creates before launching this script.
    # Every exit path below must go through this so a customer never gets
    # stuck locked out of a retry. See docs/superpowers/specs/
    # 2026-08-07-portal-remote-admin-design.md §4.
    #
    # Also releases $RUN_LOCK_FILE (this script's own mutual-exclusion lock,
    # see 86e2t0g09) -- gated on $script:ownsRunLock. A run that lost the
    # lock-contention race exits before ever reaching Complete-AdminAction
    # (see the acquire-or-exit block near the top of the script) EXCEPT for
    # every "denied" (ACL-verification-failed) return from either
    # New-RunLock or Repair-RunLock, which warn and proceed without ever
    # genuinely owning the lock (added across 86e31dqfw/86e31jhz9/86e33ktb3).
    # Stated generically -- as "every 'denied' return," not a fixed count or
    # named list -- because this exact comment has already gone stale twice
    # (once caught at Batch Q3's own final review, finding M7; once caught
    # as 86e35ug93): grep this file for `return "denied"` to get the real,
    # current count rather than trusting a number written here. Deleting
    # $RUN_LOCK_FILE unconditionally on any of these paths could delete a
    # still-live run's lock file out from under it (parent-directory
    # delete-child ACL rights can exist independently of the file's own
    # denied read/write ACL). $script:ownsRunLock is only ever set true on
    # a path that genuinely acquired or reclaimed the lock.
    Remove-Item -Path $LOCK_FILE -Force -ErrorAction SilentlyContinue
    if ($script:ownsRunLock) {
        Remove-Item -Path $RUN_LOCK_FILE -Force -ErrorAction SilentlyContinue
    }
    $action = @{
        action  = "update"
        result  = $result
        detail  = $detail
        version = $version
        at      = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    } | ConvertTo-Json -Compress
    Set-Content -Path $ADMIN_ACTION_FILE -Value $action -NoNewline -Encoding utf8 -ErrorAction SilentlyContinue
}

# 86e2zr28u: orphan protection for Rename-DirectoryWithRetry's retry-child
# process, mirroring service.py's own 86e2z2u1b protection for the uvicorn
# child (JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE via pywin32 there). PowerShell
# has no pywin32 equivalent, so this is raw P/Invoke instead -- struct
# layouts and flag values were checked against service.py's own working
# win32job usage rather than freshly guessed. Declared once here at
# script scope (not inside the function) so it's defined once per run, not
# once per rename call; guarded with the same "-as [type]" idempotency
# check already used elsewhere in this file for Add-Type (this only
# prevents re-registration WITHIN one process -- update.ps1 is a fresh
# process every scheduled run, so this compiles fresh each run either way,
# same as the pre-existing System.IO.Compression.FileSystem Add-Type
# below).
#
# WRAPPED IN TRY/CATCH (independent review finding, 2026-08-26): Add-Type
# -MemberDefinition invokes the C# compiler as a real subprocess -- a far
# more fragile operation than a plain assembly load, and one this exact
# environment already has a documented plausible-AV-interference history
# with (86e2zbm5q). With $ErrorActionPreference = "Stop" active script-wide
# and no try/catch anywhere above this point, an unguarded failure here
# would abort the ENTIRE update run before Fail()/Complete-AdminAction()
# ever executes -- invisible to both agent.log and the portal, and
# defeating this whole feature's own "best-effort, never blocks the
# rename" design intent by blocking far more than just the rename. Placed
# here (after Warn() is defined, not at the very top of the script) so
# this catch block can actually call it -- PowerShell does not hoist
# function definitions, confirmed live: a Warn call from code positioned
# before Warn's own "function Warn" statement fails with
# "term not recognized," even though it's within the same script.
try {
    if (-not ("IntraMind.Native.JobObject" -as [type])) {
        Add-Type -Namespace IntraMind.Native -Name JobObject -MemberDefinition @'
[StructLayout(LayoutKind.Sequential)]
public struct JOBOBJECT_BASIC_LIMIT_INFORMATION {
    public Int64 PerProcessUserTimeLimit;
    public Int64 PerJobUserTimeLimit;
    public UInt32 LimitFlags;
    public UIntPtr MinimumWorkingSetSize;
    public UIntPtr MaximumWorkingSetSize;
    public UInt32 ActiveProcessLimit;
    public UIntPtr Affinity;
    public UInt32 PriorityClass;
    public UInt32 SchedulingClass;
}

[StructLayout(LayoutKind.Sequential)]
public struct IO_COUNTERS {
    public UInt64 ReadOperationCount;
    public UInt64 WriteOperationCount;
    public UInt64 OtherOperationCount;
    public UInt64 ReadTransferCount;
    public UInt64 WriteTransferCount;
    public UInt64 OtherTransferCount;
}

[StructLayout(LayoutKind.Sequential)]
public struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION {
    public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
    public IO_COUNTERS IoInfo;
    public UIntPtr ProcessMemoryLimit;
    public UIntPtr JobMemoryLimit;
    public UIntPtr PeakProcessMemoryUsed;
    public UIntPtr PeakJobMemoryUsed;
}

public const uint JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000;
public const int JobObjectExtendedLimitInformation = 9;

[DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
public static extern IntPtr CreateJobObject(IntPtr lpJobAttributes, string lpName);

[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool SetInformationJobObject(IntPtr hJob, int JobObjectInfoClass, ref JOBOBJECT_EXTENDED_LIMIT_INFORMATION lpJobObjectInfo, uint cbJobObjectInfoLength);

[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool AssignProcessToJobObject(IntPtr hJob, IntPtr hProcess);

[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool CloseHandle(IntPtr hObject);
'@
    }
} catch {
    # Best-effort, matching the design's own stated philosophy: if the type
    # can't be registered at all, Rename-DirectoryWithRetry's own job-
    # binding block (the try/catch wrapping its CreateJobObject call, see
    # that function's own comments) catches the RuntimeException an
    # undefined-type reference throws at the call site and Warns/continues
    # without job-object protection -- the rename itself is completely
    # unaffected either way.
    Warn "Could not register the IntraMind.Native.JobObject P/Invoke type ($_) -- rename retry-child orphan protection (86e2zr28u) will be unavailable this run, rename itself unaffected."
}

function Rename-DirectoryWithRetry($Path, $NewName, $Attempts = 3, $DelaySeconds = 2, $TimeoutSeconds = $RENAME_TIMEOUT_SECONDS) {
    # A directory rename can transiently fail right after Stop-Service
    # returns (Windows can report STOPPED slightly before all file handles
    # are released). A short retry absorbs that instead of aborting the
    # update over a race that resolves itself within a couple seconds.
    # See 86e2rrzj2.
    #
    # Defined up here (moved from mid-script in round 2 of 86e2rrzj2) so the
    # crash-recovery block below -- which runs before the extraction/swap
    # logic that originally motivated this helper -- can use it too, instead
    # of a bare unretried Rename-Item.
    #
    # 86e2zbm5q: the retry loop above only protects against a FAST-failing
    # sharing violation -- the case it was designed for. A live incident
    # (2026-08-25) showed Rename-Item can also simply hang, neither
    # succeeding nor throwing, for 10+ minutes under real conditions
    # (suspected but unconfirmed cause: an active antivirus real-time scan
    # holding a handle open). Without a hard ceiling on that, this function
    # -- and the live service it's usually mid-updating -- can be stuck
    # forever with nothing to report anywhere.
    #
    # CORRECTION 2026-08-26: the first fix here used a Start-Job background
    # job for the wall-clock timeout. That worked in every interactive test
    # but is broken in this script's REAL execution context -- a child of
    # the LocalSystem EBMSLiveAgent service, no console/desktop session.
    # Live-confirmed twice on ErinTest: Start-Job threw "No process is on
    # the other end of the pipe" (0xE9, "...while getting console output
    # buffer information") -- PowerShell's job infrastructure talks to a
    # console host to stream job output, which doesn't exist in a
    # non-interactive session. Worse than merely failing: the underlying
    # rename had ALREADY SUCCEEDED both times this fired, so the Start-Job
    # error made this function report a successful rename as a failure,
    # which fed wrong information into every caller's own recovery logic
    # and once left $INSTALL_DIR renamed away with nothing put back.
    #
    # Replaced with System.Diagnostics.Process (a real child process,
    # started via CreateProcess with UseShellExecute=$false and
    # CreateNoWindow=$true) instead of a PowerShell job. This is the same
    # console-free spawn mechanism Windows services use to launch child
    # processes in the first place (service.py's own subprocess.Popen call
    # for the uvicorn child works the same way, non-interactively, right
    # now) -- it never touches a console output buffer, so it doesn't hit
    # Start-Job's failure mode. The retry loop itself runs in that child
    # (via a temp .ps1 file, so $Path/$NewName never need to survive
    # command-line quoting through -Command/-EncodedCommand argument
    # binding) and reports its outcome back through a small JSON result
    # file rather than a job's own output stream, since that stream is
    # exactly what was unreliable here. Process.WaitForExit(ms) bounds the
    # wait; Process.Kill() on timeout force-terminates the child the same
    # way Stop-Job did -- confirmed to still work on a genuinely separate
    # OS process, not merely abandon a thread still holding the real lock.
    #
    # 86e2zr28u: the child is now bound to a kill-on-close Job Object (see
    # the IntraMind.Native.JobObject Add-Type block just above this
    # function), the same protection service.py gives the uvicorn child
    # (86e2z2u1b/86e2zk7p3). If THIS process (update.ps1 itself) is killed
    # externally while the child is still inside Rename-Item, the OS
    # closing this process's job handle now kills the child with it
    # instead of leaving it to complete the rename as an orphan at an
    # arbitrary later time -- for the window AFTER AssignProcessToJobObject
    # has actually run. Best-effort, not airtight: a job-object setup
    # failure (or the narrow gap between Process.Start() and the
    # assignment call a few lines below, before the child is bound yet)
    # Warn()s and continues without this protection rather than blocking
    # the rename itself -- this is defense-in-depth, not a new hard
    # dependency, and does not fully close the startup-window race. Closing
    # that fully would need CREATE_SUSPENDED + assign + ResumeThread
    # instead of an immediately-running Process.Start(), out of scope here.
    #
    # Defensive guard: $Path/$NewName get wrapped in double quotes below to
    # build the child's command line. An embedded '"' or a trailing '\'
    # right before that closing quote would corrupt Win32 argument
    # parsing -- neither occurs in any of this script's own real call
    # sites today, but fail loudly rather than silently mis-parsing if a
    # future caller ever passes one.
    foreach ($v in @($Path, $NewName)) {
        if ($v -match '"') {
            throw "Rename-DirectoryWithRetry: '$v' contains a double-quote character, which this function cannot safely pass to its retry child process."
        }
        if ($v.EndsWith('\')) {
            throw "Rename-DirectoryWithRetry: '$v' ends with a backslash, which would corrupt Win32 argument quoting when passed to this function's retry child process."
        }
    }

    $tempDir = [System.IO.Path]::GetTempPath()
    $guid = [Guid]::NewGuid().ToString('N')
    $scriptFile = Join-Path $tempDir "rename_retry_$guid.ps1"
    $resultFile = Join-Path $tempDir "rename_retry_$guid.json"
    # Single-quoted here-string: no variable interpolation, so $Path/
    # $NewName never touch this script's own text -- they're bound as real
    # parameters via -File below instead, so nothing about their content
    # (spaces, quotes, whatever) can corrupt the script being run.
    $innerScript = @'
param(
    [Parameter(Mandatory)][string]$Path,
    [Parameter(Mandatory)][string]$NewName,
    [Parameter(Mandatory)][int]$Attempts,
    [Parameter(Mandatory)][int]$DelaySeconds,
    [Parameter(Mandatory)][string]$ResultFile
)
$result = @{ ok = $false; error = $null }
for ($i = 1; $i -le $Attempts; $i++) {
    try {
        Rename-Item -Path $Path -NewName $NewName -ErrorAction Stop
        $result.ok = $true
        break
    } catch {
        if ($i -eq $Attempts) {
            $result.error = $_.Exception.Message
        } else {
            Start-Sleep -Seconds $DelaySeconds
        }
    }
}
($result | ConvertTo-Json -Compress) | Set-Content -LiteralPath $ResultFile -Encoding UTF8
'@

    # Declared before the try block (not just inside it) so the finally
    # block below can always safely check it, even if an exception is
    # thrown before Process.Start() itself is reached.
    $hJob = [IntPtr]::Zero
    try {
        Set-Content -LiteralPath $scriptFile -Value $innerScript -Encoding UTF8

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = "powershell.exe"
        $psi.Arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "{0}" -Path "{1}" -NewName "{2}" -Attempts {3} -DelaySeconds {4} -ResultFile "{5}"' -f `
            $scriptFile, $Path, $NewName, $Attempts, $DelaySeconds, $resultFile
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true

        $proc = [System.Diagnostics.Process]::Start($psi)

        # 86e2zr28u: best-effort job-object binding so this child can't
        # outlive update.ps1 itself as an orphan. Never blocks the rename
        # on failure -- Warn() and continue unprotected instead.
        $hJob = [IntPtr]::Zero
        try {
            $hJob = [IntraMind.Native.JobObject]::CreateJobObject([IntPtr]::Zero, $null)
            if ($hJob -ne [IntPtr]::Zero) {
                # Build the nested BasicLimitInformation substruct as its own
                # local variable and assign the WHOLE substruct to
                # $limitInfo.BasicLimitInformation, rather than drilling
                # straight into "$limitInfo.BasicLimitInformation.LimitFlags =
                # ...". Live-verified 2026-08-26: the drill-through form
                # silently discards the write -- PowerShell's property-get on
                # a nested value-type field returns a COPY, so setting
                # .LimitFlags on that temporary copy never reaches the real
                # $limitInfo. SetInformationJobObject/AssignProcessToJobObject
                # both still report success either way (nothing about the
                # call itself is wrong), so this failed completely silently:
                # the job object gets created and the child gets assigned to
                # it, but with LimitFlags=0 -- no limits configured at all --
                # so closing the job handle never kills anything. Confirmed
                # via QueryInformationJobObject read-back and an end-to-end
                # CloseHandle test both ways before and after this fix.
                $basicLimit = New-Object IntraMind.Native.JobObject+JOBOBJECT_BASIC_LIMIT_INFORMATION
                $basicLimit.LimitFlags = [IntraMind.Native.JobObject]::JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                $limitInfo = New-Object IntraMind.Native.JobObject+JOBOBJECT_EXTENDED_LIMIT_INFORMATION
                $limitInfo.BasicLimitInformation = $basicLimit
                $infoSize = [System.Runtime.InteropServices.Marshal]::SizeOf($limitInfo)
                $setOk = [IntraMind.Native.JobObject]::SetInformationJobObject($hJob, [IntraMind.Native.JobObject]::JobObjectExtendedLimitInformation, [ref]$limitInfo, $infoSize)
                if ($setOk) {
                    $assignOk = [IntraMind.Native.JobObject]::AssignProcessToJobObject($hJob, $proc.Handle)
                    if (-not $assignOk) {
                        Warn "Rename-DirectoryWithRetry: could not bind retry-child process to a kill-on-close Job Object (AssignProcessToJobObject failed, Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- continuing without orphan protection (86e2zr28u)."
                    }
                } else {
                    Warn "Rename-DirectoryWithRetry: could not configure kill-on-close Job Object limits (Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- continuing without orphan protection (86e2zr28u)."
                }
            } else {
                # Independent review finding, 2026-08-26: this was the one
                # silent failure branch in this block -- every other
                # failure (SetInformationJobObject, AssignProcessToJobObject)
                # already Warned; CreateJobObject failing left no trace at
                # all in a file whose entire recent incident history is
                # about invisible failures.
                Warn "Rename-DirectoryWithRetry: CreateJobObject failed (Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- continuing without orphan protection (86e2zr28u)."
            }
        } catch {
            Warn "Rename-DirectoryWithRetry: Job Object setup threw ($_) -- continuing without orphan protection (86e2zr28u)."
        }

        $exited = $proc.WaitForExit($TimeoutSeconds * 1000)

        if (-not $exited -and (Test-Path -LiteralPath $resultFile)) {
            # The child had already written its result and was in the
            # process of exiting right at the timeout boundary -- give it
            # a brief grace window instead of killing it and discarding a
            # real result. A narrower version of exactly the "successful
            # rename misreported as failed" bug this replaced Start-Job
            # for would be no improvement at all.
            $exited = $proc.WaitForExit(3000)
        }

        # 86e31dqfm: the grace-period fix above only covers the case where
        # the result file already exists right at the timeout boundary. It
        # misses two related windows with the identical false-failure
        # shape: (a) Rename-Item already succeeded on disk, but the child
        # hadn't yet reached its own Set-Content call before being killed
        # below; (b) the child exited normally (not killed) but
        # crashed/was killed by something else between Rename-Item
        # succeeding and Set-Content running. Both would otherwise report
        # a SUCCESSFUL rename as a failure. Filesystem ground truth --
        # $Path gone AND a directory named $NewName present at $Path's
        # original parent -- is definitive proof the rename already
        # happened, independent of anything the child self-reported.
        $destPath = Join-Path (Split-Path -Parent $Path) $NewName
        $renameSucceededOnDisk = { (-not (Test-Path -LiteralPath $Path)) -and (Test-Path -LiteralPath $destPath) }

        if (-not $exited) {
            try {
                $proc.Kill()
                $proc.WaitForExit(5000) | Out-Null
            } catch {
                Warn "Rename-DirectoryWithRetry: failed to terminate timed-out child process (PID $($proc.Id)): $_"
            }
            if (& $renameSucceededOnDisk) {
                Log "Rename-DirectoryWithRetry: retry-child timed out after $TimeoutSeconds seconds, but the rename had already succeeded on disk ('$Path' is gone, '$destPath' exists) -- treating as success rather than misreporting a completed rename as failed (86e31dqfm)."
                return
            }
            throw "Rename of '$Path' to '$NewName' timed out after $TimeoutSeconds seconds -- the operation neither completed nor failed within the timeout (see 86e2zbm5q)."
        }

        if (-not (Test-Path -LiteralPath $resultFile)) {
            if (& $renameSucceededOnDisk) {
                Log "Rename-DirectoryWithRetry: retry-child exited (code $($proc.ExitCode)) without writing a result, but the rename had already succeeded on disk ('$Path' is gone, '$destPath' exists) -- treating as success rather than misreporting a completed rename as failed (86e31dqfm)."
                return
            }
            throw "Rename of '$Path' to '$NewName' failed: the retry-attempt child process exited (code $($proc.ExitCode)) without writing a result -- treating as failed rather than assuming success."
        }

        # Batch Q final review (2026-08-31): a result file that EXISTS but is
        # truncated (non-empty, unparseable JSON) can happen if the
        # retry-child was killed mid-write to $resultFile -- after
        # Rename-Item already succeeded, but before Set-Content finished. An
        # empty file already parses fine (ConvertFrom-Json returns $null,
        # caught by "-not $result.ok" below); only a TRUNCATED-BUT-NONEMPTY
        # file throws here, and it would do so BEFORE $renameSucceededOnDisk
        # ever gets consulted -- a third distinct cause needing the same
        # ground-truth treatment as the two branches above.
        try {
            $result = Get-Content -LiteralPath $resultFile -Raw | ConvertFrom-Json
        } catch {
            if (& $renameSucceededOnDisk) {
                Log "Rename-DirectoryWithRetry: retry-child's result file could not be parsed ($_ -- likely truncated by a mid-write kill), but the rename had already succeeded on disk ('$Path' is gone, '$destPath' exists) -- treating as success rather than trusting an unparseable self-report over ground truth (86e31dqfm)."
                return
            }
            throw "Rename of '$Path' to '$NewName' failed: the retry-child's result file exists but could not be parsed ($_) -- treating as failed rather than assuming success."
        }
        if (-not $result.ok) {
            if (& $renameSucceededOnDisk) {
                Log "Rename-DirectoryWithRetry: retry-child reported failure ($($result.error)), but the rename had already succeeded on disk ('$Path' is gone, '$destPath' exists) -- treating as success rather than trusting a stale self-report over ground truth (86e31dqfm)."
                return
            }
            throw "Rename of '$Path' to '$NewName' failed: $($result.error)"
        }
    } finally {
        # 86e2zr28u: close the job handle once the rename has either
        # completed or been abandoned via timeout+Kill() above. This does
        # not affect an already-exited/already-killed child -- it just
        # releases this process's own reference to the job object.
        if ($hJob -ne [IntPtr]::Zero) {
            [IntraMind.Native.JobObject]::CloseHandle($hJob) | Out-Null
        }
        Remove-Item -LiteralPath $scriptFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $resultFile -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-ProcessWithTimeout {
    # 86e3gevjc (Batch Y4): runs one external program (pip, through $PY_EXE)
    # with a hard wall-clock limit, in the same console-free way
    # Rename-DirectoryWithRetry runs its retry child: System.Diagnostics.Process
    # with UseShellExecute=$false and CreateNoWindow=$true. Never a PowerShell
    # background job (AP-001: that fails in this script's real non-interactive
    # context). A sibling of Rename-DirectoryWithRetry on purpose, not a
    # refactor of it.
    #
    # stdout/stderr are NOT redirected: a redirected pipe that nobody reads
    # fills up and deadlocks the child (measured: a child writing about 1 MB
    # timed out at 15 s). pip writes its own log through --log instead, and
    # only the exit code is used here.
    #
    # The child is bound to a kill-on-close Job Object (the same
    # IntraMind.Native.JobObject type; best-effort, Warn on failure), so if
    # this script is killed (for example by the task's ExecutionTimeLimit)
    # the child dies with it instead of finishing a half-done pip install
    # later. Closing the job handle in the finally block also ends any
    # grandchild the program started.
    #
    # The child's environment always has PIP_CONFIG_FILE=nul (Final Review fix
    # wave I1, see $PIP_COMMON_ARGS).
    #
    # Never throws. Returns an object: Ok (exit code 0), ExitCode (or $null),
    # TimedOut, Error (set when the program was not or could not be run),
    # Detail (a short text for log lines) and ProcessId.
    param(
        [Parameter(Mandatory)][string]$FilePath,
        [Parameter(Mandatory)][string[]]$ArgumentList,
        [Parameter(Mandatory)][int]$TimeoutSeconds
    )
    $outcome = [pscustomobject]@{ Ok = $false; ExitCode = $null; TimedOut = $false; Error = $null; Detail = $null; ProcessId = $null }
    $quotedArgs = New-Object System.Collections.Generic.List[string]
    foreach ($arg in $ArgumentList) {
        if ($arg -match '"') {
            $outcome.Error = "argument contains a double-quote character: $arg"
            $outcome.Detail = "not started ($($outcome.Error))"
            return $outcome
        }
        if ($arg -eq "" -or $arg -match '\s') {
            if ($arg.EndsWith('\')) {
                $outcome.Error = "argument with spaces ends with a backslash, which would corrupt Win32 argument quoting: $arg"
                $outcome.Detail = "not started ($($outcome.Error))"
                return $outcome
            }
            $quotedArgs.Add('"' + $arg + '"')
        } else {
            $quotedArgs.Add($arg)
        }
    }
    $child = $null
    $jobHandle = [IntPtr]::Zero
    try {
        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = $FilePath
        $psi.Arguments = ($quotedArgs -join ' ')
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true
        # Final Review fix wave (I1): every program run here is pip. "nul" is
        # Windows' os.devnull, which makes pip skip every config file
        # (global C:\ProgramData\pip\pip.ini included). Set on the child's own
        # environment only; this script's environment is not changed.
        $psi.EnvironmentVariables["PIP_CONFIG_FILE"] = "nul"
        $child = [System.Diagnostics.Process]::Start($psi)
        $outcome.ProcessId = $child.Id
        try {
            $jobHandle = [IntraMind.Native.JobObject]::CreateJobObject([IntPtr]::Zero, $null)
            if ($jobHandle -ne [IntPtr]::Zero) {
                # Whole-substruct assignment, never a drill-through write into
                # .BasicLimitInformation.LimitFlags: see Rename-DirectoryWithRetry
                # (a value-type copy silently drops that write).
                $jobBasicLimit = New-Object IntraMind.Native.JobObject+JOBOBJECT_BASIC_LIMIT_INFORMATION
                $jobBasicLimit.LimitFlags = [IntraMind.Native.JobObject]::JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                $jobLimitInfo = New-Object IntraMind.Native.JobObject+JOBOBJECT_EXTENDED_LIMIT_INFORMATION
                $jobLimitInfo.BasicLimitInformation = $jobBasicLimit
                $jobInfoSize = [System.Runtime.InteropServices.Marshal]::SizeOf($jobLimitInfo)
                if ([IntraMind.Native.JobObject]::SetInformationJobObject($jobHandle, [IntraMind.Native.JobObject]::JobObjectExtendedLimitInformation, [ref]$jobLimitInfo, $jobInfoSize)) {
                    if (-not [IntraMind.Native.JobObject]::AssignProcessToJobObject($jobHandle, $child.Handle)) {
                        Warn "Invoke-ProcessWithTimeout: AssignProcessToJobObject failed (Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- $FilePath runs without orphan protection."
                    }
                } else {
                    Warn "Invoke-ProcessWithTimeout: could not set kill-on-close Job Object limits (Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- $FilePath runs without orphan protection."
                }
            } else {
                Warn "Invoke-ProcessWithTimeout: CreateJobObject failed (Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- $FilePath runs without orphan protection."
            }
        } catch {
            Warn "Invoke-ProcessWithTimeout: Job Object setup threw ($_) -- $FilePath runs without orphan protection."
        }
        if ($child.WaitForExit($TimeoutSeconds * 1000)) {
            $outcome.ExitCode = $child.ExitCode
            $outcome.Ok = ($child.ExitCode -eq 0)
            $outcome.Detail = "exit code $($child.ExitCode)"
        } else {
            $outcome.TimedOut = $true
            $outcome.Detail = "timed out after $TimeoutSeconds s and was stopped"
            try {
                $child.Kill()
                $child.WaitForExit(5000) | Out-Null
            } catch {
                Warn "Invoke-ProcessWithTimeout: could not stop timed-out process $($child.Id): $_"
            }
        }
    } catch {
        $outcome.Error = "$_"
        $outcome.Detail = "could not be run ($_)"
    } finally {
        if ($jobHandle -ne [IntPtr]::Zero) {
            [IntraMind.Native.JobObject]::CloseHandle($jobHandle) | Out-Null
        }
        if ($child) { $child.Dispose() }
    }
    return $outcome
}

function Get-RequirementsDecision {
    # 86e3gevjc (Batch Y5): decides whether this update needs pip. Returns an
    # object: NeedPip (bool), StagedHash (lower-case SHA-256 of the staged
    # requirements file, or $null), KnownHash, and Source ("hash-file",
    # "seeded-from-current", "unknown" or "no-staged-file").
    #
    # Known hash = the trimmed contents of $HashFilePath when they are 64 hex
    # characters. Otherwise it is SEEDED from the hash of the CURRENT
    # requirements file in $INSTALL_DIR: no box has a hash file before this
    # change, so no box runs pip on its first upgrade unless the release
    # really changes the file. The current file is usually what the
    # installer last pip-installed, but not always: a box that auto-updated
    # through 8477725 got the pinned file swapped in without a pip run, so it
    # re-pins psycopg and python-dotenv on its first real requirements change
    # instead of never (harmless: those pins are what the code was tested
    # with). ("Missing means run pip" was rejected: boxes installed before
    # 8477725 may have an unpinned psycopg or python-dotenv, and a forced pip
    # run would silently re-pin them fleet-wide.) If the current file is
    # missing too, the state is unknown and pip runs. That is not free: Phase
    # A downloads every pin, so it needs the index reachable, and a Phase A
    # failure fails the run (no downtime) until a download succeeds. A
    # release with no requirements file needs no pip.
    param(
        [string]$StagedReqPath,
        [string]$CurrentReqPath,
        [string]$HashFilePath
    )
    $decision = [pscustomobject]@{ NeedPip = $false; StagedHash = $null; KnownHash = $null; Source = "no-staged-file" }
    if (-not (Test-Path -LiteralPath $StagedReqPath)) { return $decision }
    $decision.StagedHash = (Get-FileHash -LiteralPath $StagedReqPath -Algorithm SHA256).Hash.ToLower()
    $known = $null
    if (Test-Path -LiteralPath $HashFilePath) {
        $rawHash = Get-Content -LiteralPath $HashFilePath -Raw -ErrorAction SilentlyContinue
        if ($null -eq $rawHash) { $rawHash = "" }
        $rawHash = $rawHash.Trim().ToLower()
        if ($rawHash -match '^[0-9a-f]{64}$') {
            $known = $rawHash
            $decision.Source = "hash-file"
        }
    }
    if (-not $known) {
        if (Test-Path -LiteralPath $CurrentReqPath) {
            $known = (Get-FileHash -LiteralPath $CurrentReqPath -Algorithm SHA256).Hash.ToLower()
            $decision.Source = "seeded-from-current"
        } else {
            $decision.Source = "unknown"
        }
    }
    $decision.KnownHash = $known
    # Skip pip only when the staged hash equals BOTH the known hash AND the hash
    # of the CURRENT requirements file. The installers (install.ps1, migrate.ps1,
    # deploy.ps1) install packages without updating the hash file, so a stale
    # hash file can claim a set the box never installed. Running pip on a set
    # that is already installed changes no package (Phase A still downloads
    # every pin); an unreadable current file also runs pip.
    $needPip = ($known -ne $decision.StagedHash)
    if (-not $needPip -and (Test-Path -LiteralPath $CurrentReqPath)) {
        try {
            $curHash = (Get-FileHash -LiteralPath $CurrentReqPath -Algorithm SHA256).Hash.ToLower()
            if ($curHash -ne $decision.StagedHash) { $needPip = $true }
        } catch {
            $needPip = $true
        }
    }
    $decision.NeedPip = $needPip
    return $decision
}

function Set-RequirementsHashDirty {
    # 86e3kzhqa item 4: after a failed or skipped re-install the site-packages may hold the failed release's packages
    # while $REQ_HASH_FILE still names the last good set, so a later release with that same set would skip pip.
    # A hash that matches no real file forces the next update to run pip; a verified success rewrites the real hash.
    # Never throws.
    try {
        [System.IO.File]::WriteAllText($REQ_HASH_FILE, ("0" * 64), (New-Object System.Text.UTF8Encoding($false)))
    } catch {
        Warn "Could not mark $REQ_HASH_FILE for a pip re-run ($_) -- a later release with unchanged requirements may skip pip."
    }
}

function Restore-RequirementsHash {
    # 86e3mwwx1: Phase B marks $REQ_HASH_FILE dirty before pip (a kill between pip and the verify then forces pip on the
    # next run). After a SUCCESSFUL re-install of the requirements file in $INSTALL_DIR the packages are that set again,
    # so put back the hash this run read before pip ($script:reqHashBeforePip); without it every later release with that
    # same set would run pip needlessly. Does nothing when no hash was kept (pip did not run, or the known state was
    # unknown: the dirty marker stays, which only costs one extra pip run). Never throws.
    if (-not $script:reqHashBeforePip) { return }
    try {
        [System.IO.File]::WriteAllText($REQ_HASH_FILE, $script:reqHashBeforePip, (New-Object System.Text.UTF8Encoding($false)))
    } catch {
        Warn "Could not restore the requirements hash in $REQ_HASH_FILE ($_) -- the next update may run pip again needlessly."
    }
}

function Invoke-RequirementsReinstall {
    # 86e3gevjc (Batch Y6): best-effort re-install of the requirements file
    # that is in $INSTALL_DIR right now, after a failed dependency step:
    # in Invoke-Rollback (after the restore rename, so $INSTALL_DIR is the
    # previous install again; .previous no longer exists by then) and in the
    # Phase B failure path (no swap happened, so $INSTALL_DIR is still the
    # current install), and (Final Review fix wave I2) in
    # Undo-RequirementsAfterSwapFailure, for the swap failures after Phase B.
    # Both installs share one site-packages (no venv), so without this the
    # code in $INSTALL_DIR would run on the failed release's packages. Online
    # (a pinned downgrade comes from pip's cache or the index), capped at
    # $PIP_ROLLBACK_TIMEOUT_SECONDS. Packages the failed release added stay
    # installed, which is harmless. Never throws; returns $true on success.
    param([string]$Context)
    # 86e3gevzm A8-F4 (Batch Y7): deadline gate 2 -- skip this best-effort
    # step when too little of the run's time limit is left for it plus the
    # start and verify that follow: re-pip cap 120 s (about 125 s with the
    # kill wait) + start 60 s + verify about 95 s = about 275 s, so
    # $REPIP_MIN_REMAINING_SECONDS is 300 s (Final Review fix wave M1).
    $secondsLeft = [int]($RUN_TIME_LIMIT_SECONDS - $script:RunStopwatch.Elapsed.TotalSeconds)
    if ($secondsLeft -lt $REPIP_MIN_REMAINING_SECONDS) {
        Warn "$Context`: only $secondsLeft s of the $RUN_TIME_LIMIT_SECONDS s run limit remain (need $REPIP_MIN_REMAINING_SECONDS) -- skipping the dependency re-install."
        Set-RequirementsHashDirty
        return $false
    }
    $reqPath = Join-Path $INSTALL_DIR "requirements_live.txt"
    if (-not (Test-Path -LiteralPath $reqPath)) {
        Warn "$Context`: $reqPath not found -- skipping the dependency re-install."
        Set-RequirementsHashDirty
        return $false
    }
    Log "$Context`: re-installing the previous requirements from $reqPath..."
    $reinstallArgs = $PIP_COMMON_ARGS + @("install", "--timeout", "15", "--retries", "2", "--only-binary", ":all:", "-r", $reqPath)
    $reinstall = Invoke-ProcessWithTimeout -FilePath $PY_EXE -ArgumentList $reinstallArgs -TimeoutSeconds $PIP_ROLLBACK_TIMEOUT_SECONDS
    if ($reinstall.Ok) {
        Log "$Context`: previous requirements re-installed."
        Restore-RequirementsHash
        return $true
    }
    Warn "$Context`: re-installing the previous requirements failed (pip install $($reinstall.Detail); see $PIP_LOG_FILE) -- continuing; the install in $INSTALL_DIR may not start if a dependency changed incompatibly."
    Set-RequirementsHashDirty
    return $false
}

function Undo-RequirementsAfterSwapFailure([string]$Reason) {
    # Final Review fix wave (I2): called by the install-swap failure paths
    # (stale .previous not removable, either swap rename failing, and the swap
    # region's outer catch) right BEFORE they restart $AGENT_SERVICE and Fail.
    # When Phase B already installed the new release's packages, the code
    # about to be restarted would otherwise run on them, and with nothing
    # recorded every scheduled run would repeat the stop, pip and failure. So:
    # record $latestVersion as failed (same record as the Phase B failure
    # path: scheduled runs skip it for $FAILED_RELEASE_SKIP_HOURS h), then
    # re-install the requirements file that is in $INSTALL_DIR now (gate 2
    # applies). Does nothing when Phase B did not run. Runs at most once per
    # run (every caller Fails, which exits, right after). Never throws.
    # 86e3kzhqa item 1: does nothing either once the swap has completed (only
    # the outer catch can get here then): the new code is in place and runs on
    # the new packages, so recording the release as failed or re-installing the
    # OLD requirements would be wrong (after a completed swap $INSTALL_DIR holds
    # the NEW requirements file, so a re-install would read those); on the main
    # channel the next cycle reinstalls.
    if ($script:swapCompleted) { Log "Install swap already completed ($Reason) -- not recording $latestVersion as failed and not re-installing requirements."; return }
    if (-not $script:pipInstallRan -or $script:swapFailureUndone) { return }
    $script:swapFailureUndone = $true
    Write-FailedRelease -Version $latestVersion -Reason "install swap failed after the dependency install ($Reason)"
    Invoke-RequirementsReinstall -Context "Swap failure" | Out-Null
}

function Write-FailedRelease([string]$Version, [string]$Reason) {
    # 86e3gevzm A8-F2 (Batch Y3): records $Version as failed so scheduled runs
    # skip it for $FAILED_RELEASE_SKIP_HOURS h (see Get-FailedReleaseSkip).
    # No BOM ([IO.File] with UTF8Encoding($false), not Set-Content -Encoding
    # utf8). Never throws: a failed write only means the next scheduled run may
    # retry the version.
    try {
        $record = @{
            version = $Version
            at      = (Get-Date).ToUniversalTime().ToString("o")
            reason  = $Reason
        } | ConvertTo-Json -Compress
        [System.IO.File]::WriteAllText($FAILED_RELEASE_FILE, $record, (New-Object System.Text.UTF8Encoding($false)))
        Log "Recorded $Version as failed in $FAILED_RELEASE_FILE -- scheduled runs skip it for $FAILED_RELEASE_SKIP_HOURS h; a portal Update Now retries it sooner."
    } catch {
        Warn "Could not record the failed release in $FAILED_RELEASE_FILE ($_) -- the next scheduled run may retry $Version."
    }
}

function Get-FailedReleaseSkip {
    # 86e3gevzm A8-F2 (Batch Y3): decides whether this run skips
    # $LatestVersion because it failed recently. Reads only the two files;
    # returns an object with Skip (bool), Message (a line to log, or $null),
    # IsWarning (bool) and Detail (the Complete-AdminAction text when Skip is
    # true). Never throws: an empty, unreadable or corrupt record, or one dated
    # in the future (clock change), is ignored with a warning so a damaged file
    # can never block updates. PowerShell 5.1's ConvertFrom-Json returns "at"
    # as a string, so it is parsed explicitly (invariant culture, round-trip).
    param(
        [string]$LatestVersion,
        [string]$FailedReleasePath,
        [string]$PortalLockPath,
        [datetime]$NowUtc
    )
    $result = [pscustomobject]@{ Skip = $false; Message = $null; IsWarning = $false; Detail = $null }
    if (-not (Test-Path -LiteralPath $FailedReleasePath)) { return $result }
    try {
        # Final Review fix wave (M4): read as UTF-8 (the file is written as UTF-8
        # without a BOM; Get-Content without an encoding reads it as ANSI in
        # PowerShell 5.1 and garbles a non-ASCII reason). A BOM, if present, is
        # still detected and skipped.
        $raw = [System.IO.File]::ReadAllText($FailedReleasePath, [System.Text.Encoding]::UTF8)
        if ($null -eq $raw) { $raw = "" }
        $raw = $raw.Trim()
        if (-not $raw) { throw "the file is empty" }
        $record = $raw | ConvertFrom-Json
        if ($record.at -is [datetime]) {
            $failedAt = $record.at.ToUniversalTime()
        } else {
            $failedAt = [DateTime]::Parse([string]$record.at, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::RoundtripKind).ToUniversalTime()
        }
    } catch {
        $result.Message = "Ignoring $FailedReleasePath (empty, unreadable or corrupt: $_) -- not skipping anything."
        $result.IsWarning = $true
        return $result
    }
    if ($record.version -ne $LatestVersion) { return $result }
    $fmt = "yyyy-MM-dd HH:mm:ss'Z'"
    $inv = [System.Globalization.CultureInfo]::InvariantCulture
    $atText = $failedAt.ToString($fmt, $inv)
    $untilText = $failedAt.AddHours($FAILED_RELEASE_SKIP_HOURS).ToString($fmt, $inv)
    $age = $NowUtc - $failedAt
    if ($age.TotalSeconds -lt 0) {
        $result.Message = "$FailedReleasePath records $LatestVersion as failed at $atText, which is in the future (clock change?) -- ignoring it, not skipping."
        $result.IsWarning = $true
        return $result
    }
    if ($age.TotalHours -ge $FAILED_RELEASE_SKIP_HOURS) {
        $result.Message = "$LatestVersion failed at $atText, more than $FAILED_RELEASE_SKIP_HOURS h ago -- retrying it."
        return $result
    }
    $lockItem = Get-Item -LiteralPath $PortalLockPath -ErrorAction SilentlyContinue
    if ($lockItem) {
        $lockAge = ($NowUtc - $lockItem.LastWriteTimeUtc).TotalSeconds
        if ($lockAge -lt $PORTAL_LOCK_MAX_AGE_SECONDS) {
            $result.Message = "$LatestVersion failed at $atText, but this run was started by the portal (Update Now; $PortalLockPath is $([int]$lockAge) s old) -- retrying it now instead of skipping."
            return $result
        }
    }
    $reason = if ($record.reason) { $record.reason } else { "no reason recorded" }
    $result.Skip = $true
    # Final Review fix wave (M5): reason-neutral ("it failed at"), since the
    # record can come from a rollback or from a dependency install failure; the
    # reason in parentheses says which.
    $result.Detail = "Skipped $LatestVersion`: it failed at $atText ($reason); skipped until $untilText; use Update Now to retry sooner."
    $result.Message = "Skipping $LatestVersion`: it failed at $atText ($reason). Scheduled runs skip it until $untilText. A portal Update Now retries it sooner; it is recognised by $PortalLockPath being younger than $PORTAL_LOCK_MAX_AGE_SECONDS s, so if the portal could not create that file the run counts as scheduled."
    return $result
}

function Wait-ForHealth([int]$TimeoutSeconds = $VERIFY_TIMEOUT_SECONDS) {
    # 86e3gevzm A8-F2 (Batch Y2): waits for http://localhost:$PORT/health to
    # answer 200 and returns the version it reports, or "unknown" if it does
    # not answer within $TimeoutSeconds. A Stopwatch deadline, not an
    # iteration count, so the real window no longer depends on how long each
    # failed attempt takes. The initial 5 s settle delay counts toward the
    # deadline. A 200 whose body is not JSON counts as no answer (as in the
    # old main verify loop). The last attempt can start just before the
    # deadline, so the worst case is about $TimeoutSeconds + 5 s.
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    Start-Sleep -Seconds 5
    while ($sw.Elapsed.TotalSeconds -lt $TimeoutSeconds) {
        try {
            $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
            if ($resp.StatusCode -eq 200) {
                return ($resp.Content | ConvertFrom-Json).version
            }
        } catch {}
        Start-Sleep -Seconds 2
    }
    return "unknown"
}

function Invoke-Rollback($Reason) {
    # Restores $previousDir into $INSTALL_DIR after a failed post-swap
    # service start or failed version verification. Renames the broken tree
    # aside first rather than deleting it outright, so a failed delete never
    # leaves $INSTALL_DIR completely gone -- and re-verifies the restored
    # version actually responds before reporting success rather than
    # asserting it blindly. See 86e2rrzj2.
    #
    # Round 2 (2026-08-20): the outer catch below deliberately does NOT
    # attempt a blind Start-Service on its own rename failure. Tracing both
    # possible failure points shows neither leaves anything worth starting
    # under $INSTALL_DIR's real name:
    #   - If the FIRST rename (move the broken $INSTALL_DIR aside to
    #     .failed) is what throws, the rename never happened, so
    #     $INSTALL_DIR still exists -- but it still holds the BROKEN build
    #     that triggered this rollback in the first place. Starting the
    #     service here would just run the broken version; that is not a
    #     recovery, it actively hides the failure.
    #   - If the SECOND rename (restore .previous into $INSTALL_DIR) is what
    #     throws, the first rename already succeeded, so $INSTALL_DIR does
    #     not exist under that name at all. There is nothing there to
    #     start.
    # Either way a Start-Service call in the catch can't help, so the fix is
    # a stage-specific error message that says exactly which directory holds
    # which version and what manual step restores service.
    Warn "$Reason -- rolling back to previous install."
    # 86e3gevzm A8-F2 (Batch Y3): record the failed version first, before
    # anything below can Fail/exit, so every rollback outcome (start failure
    # and verify failure) stops scheduled runs retrying it for 24 h.
    Write-FailedRelease -Version $latestVersion -Reason $Reason
    $failedDir = "$INSTALL_DIR.failed"
    if (Test-Path $failedDir) {
        Remove-Item $failedDir -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path $failedDir) {
            # Best-effort stop before bailing out: whichever call site got us
            # here, $INSTALL_DIR currently holds the version that triggered
            # this rollback (either the swap's new build that failed to
            # start, or one that started but never verified) -- don't leave
            # it silently running while reporting an error that needs manual
            # attention.
            try { Stop-ServiceWithTimeout $AGENT_SERVICE } catch { }
            Fail "$Reason -- AND could not remove stale $failedDir before attempting rollback -- manual cleanup of $failedDir needed before rollback can proceed. $AGENT_SERVICE has been stopped as a precaution; $INSTALL_DIR still holds the version that triggered this rollback -- do not start the service again until that is manually confirmed safe."
        }
    }
    $renameStage = $null
    try {
        try { Stop-ServiceWithTimeout $AGENT_SERVICE } catch { }
        $renameStage = "move-broken-aside"
        Rename-DirectoryWithRetry -Path $INSTALL_DIR -NewName (Split-Path $failedDir -Leaf)
        $renameStage = "restore-previous"
        Rename-DirectoryWithRetry -Path $previousDir -NewName (Split-Path $INSTALL_DIR -Leaf)
        $renameStage = $null
        # 86e3gevjc (Batch Y6): Phase B changed the shared site-packages, so
        # put the previous install's requirements back before starting it.
        # Best-effort: a failure only Warns.
        if ($script:pipInstallRan) {
            Invoke-RequirementsReinstall -Context "Rollback" | Out-Null
        }
        $started = $false
        try {
            Start-ServiceWithTimeout $AGENT_SERVICE
            $started = $true
        } catch {
            Warn "Rollback: restored $INSTALL_DIR to the previous version but failed to start $AGENT_SERVICE`: $_"
        }
        $rollbackVerified = $false
        if ($started) {
            # 86e3gevzm A8-F2 (Batch Y2): the same 90 s deadline as the main
            # verify step (this loop was the same ~55 s shape).
            $rollbackVerified = ((Wait-ForHealth) -ne "unknown")
        }
        Remove-Item $failedDir -Recurse -Force -ErrorAction SilentlyContinue
        if ($rollbackVerified) {
            Complete-AdminAction -result "error" -detail "$Reason -- rolled back to previous install ($versionBefore) and confirmed it is responding." -version $versionBefore
        } else {
            Complete-AdminAction -result "error" -detail "$Reason -- rolled back to previous install ($versionBefore) but could not confirm it is responding afterward. Manual check needed." -version $versionBefore
        }
    } catch {
        if ($renameStage -eq "move-broken-aside") {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed while moving the failed install aside: $_ -- $INSTALL_DIR still holds the BROKEN version that triggered this rollback, and no start was attempted (starting it would just run the broken build). $previousDir still holds the last known-good version, untouched. Manual recovery once whatever is locking $INSTALL_DIR clears: move or remove $INSTALL_DIR, rename $previousDir to $INSTALL_DIR, then start $AGENT_SERVICE." -version $null
        } elseif ($renameStage -eq "restore-previous") {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed while restoring the previous install: $_ -- $INSTALL_DIR does not currently exist (the broken build was already moved aside to $failedDir); $previousDir still holds the last known-good version under its own name. Manual recovery: rename $previousDir to $INSTALL_DIR and start $AGENT_SERVICE." -version $null
        } else {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed: $_ -- manual intervention needed." -version $null
        }
    }
}
function Fail($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ERROR: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    # 86e30bg1w: same Write-Host hazard as Log()/Warn() above, but more
    # important to guard here -- an uncaught throw at this exact line would
    # skip Complete-AdminAction entirely, leaving $RUN_LOCK_FILE wedged
    # (matches what was actually observed live 2026-08-27: a stale run-lock
    # from a crashed prior PID, found by the next run 71 minutes later) and
    # the portal never told the update failed.
    try { Write-Host $line -ForegroundColor Red } catch { }
    Complete-AdminAction -result "error" -detail $msg -version $null
    exit 1
}

Rotate-LogIfNeeded -Path $LOG_FILE

Log "EBMS Live Updater starting"

# --- Read config from .env ---
# 86e33ktc5: moved here (was originally just before the "Check current
# running version" section, much further down) so $PORT is in scope for
# the crash-recovery block's own best-effort health check -- this block
# now runs BEFORE the crash-recovery block, which needs $PORT already set
# by the time it gets there. Pure relocation -- a config read with an
# established default ("8767") and nothing earlier in the script depends
# on running before it.
$PORT = "8767"; $CHANNEL = "stable"
if (Test-Path "$DATA_DIR\.env") {
    foreach ($line in Get-Content "$DATA_DIR\.env") {
        if ($line -match "^EBMS_LIVE_PORT=(.+)$")    { $PORT    = $Matches[1].Trim() }
        if ($line -match "^EBMS_LIVE_CHANNEL=(.+)$") { $CHANNEL = $Matches[1].Trim().ToLower() }
    }
}
if (-not $MANIFEST_URLS.ContainsKey($CHANNEL)) {
    # Was silent before -- a box configured for a channel this copy of
    # update.ps1 doesn't know about (e.g. "main" on a box whose update.ps1
    # predates that channel existing) fell back to stable with zero trace
    # anywhere. Live-confirmed on ErinTest 2026-08-10 (86e2kj0kn): that
    # silent substitution combined with stable's real published version
    # being older than what was actually running made an unannounced
    # channel fallback look identical to a routine same-channel update,
    # and it took real debugging to even notice the channel had changed.
    Warn "Configured channel '$CHANNEL' is not recognized by this copy of update.ps1 (known: $($MANIFEST_URLS.Keys -join ', ')) -- falling back to stable. This usually means this box's update.ps1 is older than its configured channel; the fallback itself is intentional (a safe default), but if you didn't expect this channel to be unrecognized, update.ps1 on this box may be stale."
    $CHANNEL = "stable"
}
$MANIFEST_URL = $MANIFEST_URLS[$CHANNEL]
Log "Channel: $CHANNEL"

# --- Mutual-exclusion: prevent a scheduled run and a portal-triggered run (or
# two scheduled runs somehow overlapping) from executing concurrently and
# colliding on the shared $zipPath download further down. Distinct from
# $LOCK_FILE above, which is the portal's own "one admin action in flight" UI
# signal, not a real mutex -- this script never checked it, and a concurrent
# run could still race on the same temp zip file. See 86e2t0g09/CR-14.
#
# 86e31dqfw: acquisition used to be Test-Path (check) then Set-Content (act)
# -- a classic TOCTOU gap two racing runs could both pass through. Replaced
# with [System.IO.File]::Open(..., FileMode.CreateNew, ...), which is atomic
# at the OS level: it throws IOException immediately if the file already
# exists, with no window between check and act. The lock's own content is
# now JSON ({pid, startTime}) instead of a bare PID string, so a stale
# lock's owner can be distinguished from an unrelated process that now
# happens to share the same (Windows-reused) PID -- matching PID alone was
# never sufficient on its own. An independent age-based staleness ceiling
# (1800s) also reclaims a lock whose owner can't be confirmed either way,
# mirroring server.py's own _UPDATE_LOCK_STALE_AFTER_SECONDS constant and
# its identical rationale ("longer than update.ps1's own 20-min
# ExecutionTimeLimit, so a genuinely stuck run is distinguishable from a
# merely slow one") -- both trigger paths share that same 20-minute external
# ceiling (it was ten minutes before Batch Y7; shared since 86e31dqfh), so the same
# number applies uniformly here too.
$RUN_LOCK_STALE_AFTER_SECONDS = 1800

# 86e31dqfw fix-round-2: the first version's reclaim path (a pure
# Test-RunLockReclaimable check, decoupled from the Remove-Item + New-RunLock
# act with no re-verification in between) still had a TOCTOU window -- two
# racers could both see the same stale lock as reclaimable, both proceed,
# and both end up believing they hold the lock (Racer B's Remove-Item
# deletes Racer A's freshly-created valid lock, then Racer B creates its
# own). Live-reproduced during task review. Fixed by routing reclaim through
# Repair-RunLock, which holds a SINGLE exclusive (FileShare.None) handle
# across both the re-read and the rewrite -- no other process can open the
# same file for any purpose while that handle is open, closing the window
# entirely instead of narrowing it.
#
# Also: the original New-RunLock's `catch [System.IO.IOException]` does not
# catch System.UnauthorizedAccessException (a sibling of IOException under
# System.Exception, not a subclass) -- live-reproduced pointing it at an
# ACL-denied directory, which threw uncaught instead of returning cleanly.
# New-RunLock below catches both explicitly and returns "denied" for the
# ACL case, so an ACL failure warns and proceeds without lock protection
# rather than crashing the run before it ever reaches Fail()/Complete-
# AdminAction -- matching this file's established "never abort the actual
# update over a defensive check" philosophy.
function New-RunLock($LockPath) {
    # Returns "ok" (we now own the lock), "exists" (something's already
    # there -- caller should attempt reclaim), or "denied" (can't create
    # a lock file here at all, e.g. ACL -- caller should proceed without
    # lock protection rather than crash the update over a permissions
    # issue).
    try {
        $stream = [System.IO.File]::Open($LockPath, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write)
        try {
            $content = @{
                pid       = $PID
                startTime = (Get-Process -Id $PID).StartTime.ToUniversalTime().ToString("o")
            } | ConvertTo-Json -Compress
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
            $stream.Write($bytes, 0, $bytes.Length)
        } finally {
            $stream.Close()
        }
        return "ok"
    } catch [System.IO.IOException] {
        return "exists"
    } catch [System.UnauthorizedAccessException] {
        return "denied"
    }
}

function Test-LockContentReclaimable($raw, $ageSeconds, $StaleAfterSeconds) {
    # Pure decision function, no I/O of its own -- takes already-read
    # content + age, returns $true if reclaimable. Same 3 independent
    # conditions as before (age ceiling, missing process, PID-reuse via
    # StartTime mismatch), factored out so Repair-RunLock below can call
    # it against content read under an exclusive handle instead of a
    # separate Get-Content call.
    if ($ageSeconds -gt $StaleAfterSeconds) {
        Warn "Found a run-lock older than $StaleAfterSeconds s -- reclaiming regardless of its recorded owner."
        return $true
    }
    $trimmed = if ($null -eq $raw) { "" } else { $raw.Trim() }
    if (-not $trimmed) {
        Warn "Found an empty or corrupt run-lock -- a prior run likely crashed without cleaning up. Reclaiming."
        return $true
    }
    try {
        $lockInfo = $trimmed | ConvertFrom-Json
    } catch {
        Warn "Found a run-lock with unparseable content -- a prior run likely crashed without cleaning up. Reclaiming."
        return $true
    }
    if (-not ($lockInfo.pid -and $lockInfo.startTime)) {
        Warn "Found a run-lock missing pid/startTime -- treating as corrupt. Reclaiming."
        return $true
    }
    $existingProcess = Get-Process -Id $lockInfo.pid -ErrorAction SilentlyContinue
    if (-not $existingProcess) {
        Warn "Found a stale run-lock from PID $($lockInfo.pid), which is no longer running -- a prior run likely crashed without cleaning up. Reclaiming."
        return $true
    }
    $actualStartTime = $existingProcess.StartTime.ToUniversalTime().ToString("o")
    if ($actualStartTime -ne $lockInfo.startTime) {
        Warn "Found a run-lock from PID $($lockInfo.pid), but that PID now belongs to a different process (Windows PID reuse) -- reclaiming."
        return $true
    }
    return $false
}

function Repair-RunLock($LockPath, $StaleAfterSeconds) {
    # Atomically re-verify AND reclaim a lock that appeared reclaimable
    # on an earlier New-RunLock "exists" result -- closes the TOCTOU
    # window between "decided to reclaim" and "actually reclaimed" by
    # holding ONE exclusive handle (FileShare.None) across both the
    # re-read and the rewrite. While this handle is open, no other
    # process can open the same file for any purpose (including its own
    # reclaim attempt or a fresh CreateNew) -- they get an exception and
    # correctly back off, eliminating the double-acquisition race.
    # Returns "reclaimed" (we now own the lock, content already
    # rewritten), "still-running" (re-verified: genuinely still live,
    # caller should respect it), "retry" (the file no longer exists
    # -- another racer already reclaimed and released it first; caller
    # should attempt a fresh New-RunLock), or "denied" (the existing lock
    # file's ACL blocks even opening it for re-verification -- caller
    # should proceed without lock protection rather than crash the update
    # over a permissions issue).
    try {
        $stream = [System.IO.File]::Open($LockPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
    } catch [System.IO.FileNotFoundException] {
        return "retry"
    } catch [System.UnauthorizedAccessException] {
        # 86e31jhz9: distinct from the bare catch below -- an ACL-denied
        # existing lock file previously fell into the generic catch and
        # returned "still-running" forever (fail-safe, but blocks reclaim
        # indefinitely). Matches New-RunLock's own "denied" result for the
        # same exception type, so the caller can Warn-and-proceed-without-
        # lock-protection the same way it already does for New-RunLock's
        # "denied" (see the caller's own new "denied" branch).
        return "denied"
    } catch {
        # Someone else holds it open right now (another racer also
        # mid-reclaim, or an unexpected sharing violation). Safest
        # conservative choice: treat as still in use, respect it.
        return "still-running"
    }
    try {
        $reader = New-Object System.IO.StreamReader($stream)
        $raw = $reader.ReadToEnd()
        $ageSeconds = ((Get-Date) - (Get-Item -LiteralPath $LockPath).LastWriteTime).TotalSeconds
        if (-not (Test-LockContentReclaimable $raw $ageSeconds $StaleAfterSeconds)) {
            return "still-running"
        }
        # Still reclaimable under this fresh, exclusively-held read --
        # overwrite in place while still holding the handle, so no other
        # process can interleave between the decision and the write.
        $stream.SetLength(0)
        $stream.Position = 0
        $content = @{
            pid       = $PID
            startTime = (Get-Process -Id $PID).StartTime.ToUniversalTime().ToString("o")
        } | ConvertTo-Json -Compress
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($content)
        $stream.Write($bytes, 0, $bytes.Length)
        return "reclaimed"
    } finally {
        $stream.Close()
    }
}

$script:ownsRunLock = $false
$lockResult = New-RunLock $RUN_LOCK_FILE
if ($lockResult -eq "denied") {
    Warn "Could not create $RUN_LOCK_FILE (access denied) -- proceeding without run-lock protection rather than aborting the update over a permissions issue."
} elseif ($lockResult -eq "exists") {
    $reclaimResult = Repair-RunLock $RUN_LOCK_FILE $RUN_LOCK_STALE_AFTER_SECONDS
    if ($reclaimResult -eq "retry") {
        $lockResult2 = New-RunLock $RUN_LOCK_FILE
        if ($lockResult2 -eq "denied") {
            # 86e33ktb3: distinct from the "exists" branch below -- an ACL
            # problem here isn't lock contention, it's the same permissions
            # issue every other "denied" branch in this file already warns
            # and proceeds past rather than treating as "another run has
            # it." $script:ownsRunLock correctly stays $false: this run
            # never genuinely acquired the lock.
            Warn "Could not create $RUN_LOCK_FILE during reclaim (access denied) -- proceeding without run-lock protection rather than aborting the update over a permissions issue."
        } elseif ($lockResult2 -ne "ok") {
            # Another run won the re-acquisition race in the interim -- that
            # run is now genuinely in progress; respect it exactly like the
            # normal "still running" exit path below.
            Log "Another update run acquired $RUN_LOCK_FILE during reclaim -- exiting."
            exit 0
        } else {
            $script:ownsRunLock = $true
        }
    } elseif ($reclaimResult -eq "still-running") {
        # Another run owns this lock and is still in progress. This is
        # expected coordination, not a failure -- exit immediately WITHOUT
        # calling Fail() or Complete-AdminAction, and without touching
        # either lock file, both of which may belong to the still-running
        # other run.
        Log "Another update run is already in progress -- exiting."
        exit 0
    } elseif ($reclaimResult -eq "denied") {
        Warn "Could not verify/reclaim $RUN_LOCK_FILE (access denied) -- proceeding without run-lock protection rather than aborting the update over a permissions issue."
    } elseif ($reclaimResult -eq "reclaimed") {
        # We now own the lock -- Complete-AdminAction's cleanup below is safe.
        $script:ownsRunLock = $true
    }
} else {
    # $lockResult -eq "ok" -- we created the lock ourselves, genuinely own it.
    $script:ownsRunLock = $true
}

# 86e2zr28u: sweep leftover Rename-DirectoryWithRetry temp files from a
# crashed prior run. Normally these are removed by that function's own
# finally block, but a run that died before reaching finally (or whose
# retry-child was itself killed via the job-object protection above,
# mid-write) can leave one behind. One hour is generous relative to
# $RENAME_TIMEOUT_SECONDS (90s) -- anything older than that is definitely
# stale, not just a slow in-progress rename. Best-effort: never let this
# sweep block the update itself.
try {
    $staleCutoff = (Get-Date).AddHours(-1)
    Get-ChildItem -Path ([System.IO.Path]::GetTempPath()) -Filter "rename_retry_*" -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $staleCutoff } |
        ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
            Log "Swept stale leftover temp file from a crashed prior run: $($_.FullName)"
        }
} catch {
    Warn "Stale rename_retry_* temp-file sweep failed (non-fatal): $_"
}

# --- Crash recovery: detect an interrupted prior swap (86e2rrzj2) ---
# If a prior run died between the two renames in the swap step further
# down, $INSTALL_DIR won't exist but $INSTALL_DIR.previous (the last
# known-good version) will. Recover it before doing anything else --
# otherwise this run's own swap step would delete .previous (the only
# surviving copy) without ever checking whether it's actually needed.
$previousDirCheck = "$INSTALL_DIR.previous"
if (-not (Test-Path $INSTALL_DIR) -and (Test-Path $previousDirCheck)) {
    Warn "$INSTALL_DIR is missing but $previousDirCheck exists -- recovering from an interrupted prior update."
    try {
        Rename-DirectoryWithRetry -Path $previousDirCheck -NewName (Split-Path $INSTALL_DIR -Leaf)
        try {
            Start-ServiceWithTimeout $AGENT_SERVICE
        } catch {
            # 86e33krzt final-review I2: this was a bare silent swallow --
            # the one remaining completely invisible failure on a path that
            # now unconditionally reports "recovered" (green) below. Word
            # this to not read as alarming when the exception is simply
            # ServiceController.Start() throwing InvalidOperationException
            # because $AGENT_SERVICE was already Running (a harmless,
            # expected case) -- the health check right after this is the
            # real signal for whether the service actually came up.
            Warn "Could not (re)start $AGENT_SERVICE after recovering $INSTALL_DIR from $previousDirCheck`: $_. (This is expected/harmless if the service was already running; the health check right after this will show whether it's actually responding.)"
        }
        # 86e33ktc5: a successful recovery is not an error -- the box is
        # back to a known-good, working state. Fail() unconditionally
        # reports result: "error", which the portal renders identically
        # to a genuine unresolved failure (red "Update failed" flash),
        # a real alarm-fatigue risk for an operator scanning many
        # customer cards. Report "recovered" directly instead, bypassing
        # Fail(). Best-effort health check (3 quick tries, not a
        # correctness gate) so the portal can show a real version instead
        # of always null -- mirrors the "Verify new version" block's own
        # pattern further down this script, with a smaller retry budget
        # since this is a status-reporting nicety, not something the
        # update itself depends on.
        $recoveredVersion = $null
        for ($i = 0; $i -lt 3; $i++) {
            try {
                $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
                if ($resp.StatusCode -eq 200) { $recoveredVersion = ($resp.Content | ConvertFrom-Json).version; break }
            } catch {}
            Start-Sleep -Seconds 2
        }
        # 86e33krzt final-review I2: fold the health-check outcome into
        # $detail (and therefore into both update.log and
        # last_admin_action.json) so an operator reading either can tell
        # whether the restored install actually answered /health, rather
        # than always seeing the same reassuring text regardless of
        # whether the restart above actually worked.
        if ($recoveredVersion) {
            $healthNote = "health check after restart: responded (version $recoveredVersion)."
        } else {
            $healthNote = "health check after restart: did not respond in 3 tries -- $AGENT_SERVICE may still be starting up or may not have come back; will re-check next cycle."
        }
        $detail = "Recovered $INSTALL_DIR from $previousDirCheck after an interrupted prior update. Aborting this run -- the next scheduled cycle will retry the actual update. $healthNote"
        Log $detail
        Complete-AdminAction -result "recovered" -detail $detail -version $recoveredVersion
        exit 0
    } catch {
        Fail "CRITICAL: $INSTALL_DIR is missing and could not be recovered from $previousDirCheck`: $_. Manual recovery needed immediately."
    }
} elseif (-not (Test-Path $INSTALL_DIR)) {
    Fail "CRITICAL: $INSTALL_DIR is missing and $previousDirCheck does not exist either -- there is no install to recover from on this box (86e2x7m06). Manual reinstall needed immediately."
}

# --- Register (or reconcile) the auto-update scheduled task ---
# 86e31dqfv: task construction moved above the existence check so BOTH
# branches (register a new task, or reconcile an already-registered
# one) use the identical target settings -- matches the two adjacent
# backfill blocks below (crash-recovery actions, start-type), both of
# which run unconditionally every 6-hour cycle rather than gating
# reconciliation behind "only if it doesn't exist yet."
#
# Batch Q final review (2026-08-31): this construction runs unconditionally
# on EVERY 6-hour cycle now (not just first registration, as before
# 86e31dqfv moved it up here) -- same unguarded-top-level-statement-under-
# EAP=Stop failure shape as the System.ServiceProcess Add-Type block above
# (86e31dqfh): with no enclosing try/catch, a single failed New-ScheduledTask*
# call would abort the ENTIRE update run before Fail()/Complete-AdminAction()
# ever executes, invisible to both agent.log and the portal. Guard it the
# same way, and skip BOTH the registration and reconciliation branches below
# if construction itself failed -- there's nothing valid to register or
# reconcile with.
try {
    $action    = New-ScheduledTaskAction -Execute "powershell.exe" `
                   -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$INSTALL_DIR\update.ps1`""
    # 86e3kzhq1: a random first run in the first 6 hours of today (same idea as install.ps1/migrate.ps1), not midnight.
    $firstRun  = (Get-Date).Date.AddMinutes((Get-Random -Minimum 0 -Maximum 360))
    $trigger   = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Hours 6) -Once -At $firstRun
    $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
    # 86e3gevzm A8-F4 (Batch Y7): 20 minutes (was 10). This block runs every
    # cycle, so the reconcile below backfills every existing box; the run that
    # performs the reconcile still runs under its old limit.
    $settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes $TASK_TIME_LIMIT_MINUTES) `
                   -StartWhenAvailable -MultipleInstances IgnoreNew
} catch {
    Warn "Could not build scheduled-task definitions: $_ -- skipping scheduled-task registration/reconciliation this cycle."
    $action = $null
}

if ($action) {
    $task = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
    if (-not $task) {
        Log "Registering auto-update scheduled task (every 6 hours)..."
        try {
            Register-ScheduledTask -TaskName $TASK_NAME -Action $action -Trigger $trigger `
                -Principal $principal -Settings $settings -Force | Out-Null
            Log "Scheduled task registered."
        } catch {
            Fail "Failed to register scheduled task: $_"
        }
    } else {
        # Backfill for machines whose task was registered before this reconciliation
        # existed. Idempotent and cheap (a no-op once already at the target
        # settings) -- Set-ScheduledTask replaces Action/Settings/Principal
        # wholesale in one call, so no field-by-field diff is needed first.
        # Warn (not Fail) on failure, matching this script's established
        # backfill philosophy: an unattended script running every 6 hours must
        # never abort the actual update over a reconciliation call.
        #
        # 86e3gevzm A8-F4 (Batch Y7): an existing task's Trigger is NOT
        # reconciled while it has at least one ENABLED trigger. install.ps1 and
        # migrate.ps1 register the task with a random start time (86e31dqe3) so
        # the fleet does not all update at 00:00; passing the fixed 00:00
        # $trigger here reset that every cycle (reproduced on a scratch task).
        # A task with NO trigger, or only disabled triggers, would never fire on
        # schedule, so for that case the every-6-hours $trigger (random first run since 86e3kzhq1) is
        # passed to repair it (the pre-Y7 per-cycle behaviour). If reading the
        # triggers fails, treat it as "no enabled trigger" and repair. A task
        # this script registers itself (the branch above) starts at a random first run (86e3kzhq1).
        $hasEnabledTrigger = $false
        try {
            $hasEnabledTrigger = (@($task.Triggers | Where-Object { $_ -and $_.Enabled }).Count -gt 0)
        } catch {
            $hasEnabledTrigger = $false
        }
        $reconcileArgs = @{ TaskName = $TASK_NAME; Action = $action; Principal = $principal; Settings = $settings }
        if (-not $hasEnabledTrigger) { $reconcileArgs.Trigger = $trigger }
        try {
            Set-ScheduledTask @reconcileArgs | Out-Null
        } catch {
            Warn "Failed to reconcile scheduled task settings: $_ -- existing task left as-is."
        }
    }
}

# --- Ensure both services have crash-recovery actions configured ---
# Backfill for machines whose services were registered before this was added
# to install.ps1/deploy.ps1 -- idempotent and cheap, so this runs every
# 6-hour cycle (deliberately placed before the version-check early return
# below, unlike the Cloudflared-name migration further down, which only gets
# one shot per version bump). See Known_Issues.md / 86e2nuxz5: EBMSLiveAgent
# had no recovery actions at all, and its uvicorn subprocess crashing left
# the service showing "Running" in Windows with nothing actually listening.
#
# EBMSLiveAgent also needs FAILURE_ACTIONS_ON_NONCRASH_FAILURES enabled for
# the restart actions above to actually fire -- live-verified 2026-08-07 on
# ErinTest that without it, its own crash handling (a clean SERVICE_STOPPED
# report with a nonzero exit code, not an unhandled process crash) is
# treated by Windows as a "non-crash failure," which sc.exe failure's
# restart actions ignore by default. With the flag set, the service
# actually restarted within ~7s of the child dying; without it, it stayed
# Stopped indefinitely. The identical non-crash-failure gap was later found
# to ALSO apply to the tunnel service (86e2z2u1b, 2026-08-25) -- a
# config/auth error makes cloudflared.exe exit cleanly with a nonzero code
# rather than crash, which Windows also treats as a "non-crash failure"
# without this same flag. 86e36k7mj (2026-09-09) closed that gap here: the
# flag is now set on BOTH services below, and again in the
# legacy-Cloudflared migration path further down (which creates
# $CF_SERVICE_NAME *after* this block has already run, so it needs its own
# call). NOTE: the tunnel-service half is parse- and exit-code-verified
# only -- a full elevated end-to-end confirmation that the tunnel service
# actually self-heals from a real non-crash failure is still an
# outstanding live-verification follow-up.
foreach ($svcName in @($AGENT_SERVICE, $CF_SERVICE_NAME)) {
    if (Get-Service $svcName -ErrorAction SilentlyContinue) {
        sc.exe failure $svcName reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
        if ($LASTEXITCODE -ne 0) {
            Warn "sc.exe failure $svcName failed (exit code $LASTEXITCODE) -- crash-recovery restart actions may not be configured for this service."
        }
    }
}
if (Get-Service $AGENT_SERVICE -ErrorAction SilentlyContinue) {
    sc.exe failureflag $AGENT_SERVICE 1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Warn "sc.exe failureflag $AGENT_SERVICE failed (exit code $LASTEXITCODE) -- non-crash failures (a clean nonzero exit) will not trigger the restart actions above."
    }
}
if (Get-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue) {
    sc.exe failureflag $CF_SERVICE_NAME 1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Warn "sc.exe failureflag $CF_SERVICE_NAME failed (exit code $LASTEXITCODE) -- non-crash failures (a clean nonzero exit) will not trigger the restart actions above."
    }
}

# --- Ensure BOTH services are configured to start automatically at boot ---
# Backfill for every machine whose EBMSLiveAgent was registered before this
# was fixed (install.ps1/migrate.ps1/deploy.ps1 never passed --startup=auto
# to `service.py install`, for this project's entire history until now) --
# pywin32's win32serviceutil.InstallService() defaults startType to
# SERVICE_DEMAND_START ("Manual") when no --startup flag is given
# (confirmed by reading the deployed pywin32 source directly). A
# Manual-start service is never launched by Windows at boot; it only runs
# once something else explicitly starts it -- a fundamentally different
# gap from the crash-recovery backfill above, which only helps once the
# service has already started at least once. Live-confirmed on ErinTest,
# 2026-08-26: EBMSLiveAgent's StartMode was "Manual", exactly explaining
# why it (and evidently other live customers too, per Erin's own report)
# doesn't come back up after the machine itself is powered off and back
# on. $CF_SERVICE_NAME was NOT reproduced as Manual on ErinTest -- confirmed
# genuinely Auto there already -- but it's included in this backfill loop
# too (Erin: "we need to make both auto start"), both as cheap
# defense-in-depth against any older install path this session didn't
# audit, and so this block is the single place either service's start type
# ever needs fixing again.
# Idempotent and cheap (a no-op once already at the target start type), so
# this runs every 6-hour cycle the same way the crash-recovery backfill
# above does -- self-heals every existing install without needing a manual
# per-customer fix, the next time each box picks up a release containing
# this change.
# 86e30ye63 (follow-up to 86e30r3d2): EBMSLiveAgent and the tunnel service
# do NOT want the same start type. EBMSLiveAgent has no boot-time-race
# concern (it doesn't depend on external network reachability to start
# successfully) -- plain "auto" is correct. IntramindCloudServices races the
# network stack at boot (see 86e30r3d2's fix in install.ps1/migrate.ps1) and
# needs "delayed-auto". Before this fix, this loop applied a single blanket
# "start= auto" to both services every 6 hours -- which meant ANY customer
# whose tunnel service install.ps1/migrate.ps1 had correctly registered as
# delayed-auto got silently reverted back to auto on their very next
# update.ps1 cycle, actively undoing that fix in production.
foreach ($svcName in @($AGENT_SERVICE, $CF_SERVICE_NAME)) {
    if (Get-Service $svcName -ErrorAction SilentlyContinue) {
        # Explicit if/else rather than a hashtable lookup -- avoids any ambiguity
        # around PowerShell's hashtable-literal key-evaluation rules for a
        # variable-vs-bareword key, in a script with no PowerShell available to
        # actually test this in the dev environment it was written in.
        if ($svcName -eq $CF_SERVICE_NAME) { $targetStart = "delayed-auto" } else { $targetStart = "auto" }
        sc.exe config $svcName start= $targetStart | Out-Null
        if ($LASTEXITCODE -ne 0) {
            Warn "sc.exe config $svcName start= $targetStart failed (exit $LASTEXITCODE) -- this box's $svcName may still be Manual-start and won't come back up after a reboot."
        }
    }
}

# --- Ensure $AGENT_SERVICE is actually Running -- must run every cycle,
# not just a cycle that happens to install a new version. Mirrors the
# tunnel-service block immediately below, added for the identical reason
# (2026-08-07 incident, see that block's own history) but never had an
# equivalent here. See 86e33krx8: a clean Stop() interrupted mid-swap
# (e.g. the scheduled task's own 20-minute ExecutionTimeLimit firing, or a
# reboot) left this invisible to every later cycle once the box was
# already on the latest version -- without this block, the exact fallout
# is channel-dependent (86e33krzt final-review M4): on the "main" channel,
# the version compare below is against $INSTALLED_MANIFEST_VERSION_FILE,
# so $AGENT_SERVICE would stay Stopped indefinitely, until a genuine new
# release finally shipped or the machine rebooted. On "stable"/"beta", the
# compare is against /health instead, so a stopped agent yields
# $versionBefore = "unknown", which never matches -- the run instead does
# a full download+swap+restart every cycle until the service comes back,
# wastefully but self-correcting within one cycle. This block makes both
# cases heal cleanly instead of relying on either an eventual release or
# an accidental full reinstall.
#
# 86e38zdab Final Review (2026-09-17): the "main" channel's own fallout described above
# ("would stay Stopped indefinitely") is no longer fully accurate on its own -- this
# block's own Start attempt can itself throw and leave $AGENT_SERVICE stopped, and the
# main-channel version-compare block below (search this file for "86e38zdab") now ALSO
# re-checks $AGENT_SERVICE's status before exiting "Already up to date," as a second,
# independent net for exactly that sub-case. Keep both blocks -- this one still runs every
# cycle regardless of whether a version check happens at all (e.g. a manifest fetch
# failure earlier in the script), while the other check only fires inside the main-channel
# version-compare path specifically.
# 86e33krzt final-review I1: ownership is verified against EITHER
# $INSTALL_DIR or $PY_DIR, because the real binPath is pythonservice.exe
# under $PY_DIR (a sibling of $INSTALL_DIR, not a subdirectory of it) --
# live-confirmed on ErinTest: PathName =
# "C:\Program Files\IntraMindPython\pythonservice.exe". A single
# "*$INSTALL_DIR*" check happened to also match that path, but only by
# coincidence of "C:\Program Files\IntraMind" being a literal string
# prefix of "C:\Program Files\IntraMindPython" -- not by design, and not
# something to rely on again.
$agentSvcJustStarted = $false
$agentSvcInfo = Get-CimInstance Win32_Service -Filter "Name='$AGENT_SERVICE'" -ErrorAction SilentlyContinue
if ($agentSvcInfo -and ($agentSvcInfo.PathName -like "*$INSTALL_DIR*" -or $agentSvcInfo.PathName -like "*$PY_DIR*")) {
    $agentSvc = Get-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
    if ($agentSvc.Status -ne "Running") {
        Log "$AGENT_SERVICE was not running - starting it..."
        try {
            Start-ServiceWithTimeout $AGENT_SERVICE
            Log "$AGENT_SERVICE started."
            # 86e33uwfd: Start-ServiceWithTimeout only waits for SCM to
            # report Running -- it does NOT wait for service.py's uvicorn
            # child to actually be listening on /health yet. Flag this so
            # the version-check read below gives a slow-starting child a
            # fair chance instead of reading "unknown" and triggering a
            # wasteful redundant reinstall.
            $agentSvcJustStarted = $true
        } catch {
            Warn "Could not start $AGENT_SERVICE ($_) -- it remains stopped; will retry next cycle."
        }
    }
} elseif ($agentSvcInfo) {
    Warn "Service '$AGENT_SERVICE' exists but is not owned by IntraMind (binPath: $($agentSvcInfo.PathName)). Not touching it."
} else {
    # 86e33krzt final-review M3: a genuinely-absent service and a failed
    # Get-CimInstance query (e.g. a transient WMI outage) both leave
    # $agentSvcInfo $null and are indistinguishable here -- worded to not
    # assert the service is definitely missing.
    Warn "$AGENT_SERVICE was not found via WMI (either genuinely not registered on this box, or a transient WMI query failure) -- cannot self-heal without confirming which. If this persists across cycles, a manual reinstall is likely needed."
}

# --- Ensure the IntraMind cloudflared tunnel service is actually running ---
# Deliberately placed here (before the version-check early return below), same
# reasoning as the crash-recovery backfill above: this must run every 6-hour
# cycle, not just on a cycle that happens to install a new version. It was
# previously placed later in this script, after the early return, so it only
# ever ran during an actual update -- meaning a tunnel stopped for any reason
# other than a crash (sc.exe failure only catches crashes, not e.g. a manual
# Stop-Service) stayed down until the next real version bump shipped, possibly
# weeks later. Found via a real incident on 2026-08-07. Ownership-verified via
# binPath first, same as the Cloudflared-name migration below -- never touch a
# service just because it has this name; see that block's own comment for the
# incident this protects against.
$svcInfo = Get-CimInstance Win32_Service -Filter "Name='$CF_SERVICE_NAME'" -ErrorAction SilentlyContinue
if ($svcInfo -and $svcInfo.PathName -like "*$CF_SYS_DIR*") {
    $cfSvc = Get-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue
    if ($cfSvc.Status -ne "Running") {
        Log "$CF_SERVICE_NAME was not running - starting it..."
        try {
            Start-ServiceWithTimeout $cfSvc.Name
            Log "$CF_SERVICE_NAME started."
        } catch {
            Warn "Could not start $CF_SERVICE_NAME ($_) -- it remains stopped; will retry next cycle."
        }
    }
} elseif ($svcInfo) {
    Warn "Service '$CF_SERVICE_NAME' exists but is not owned by IntraMind (binPath: $($svcInfo.PathName)). Not touching it."
} else {
    Warn "IntraMind's own cloudflared tunnel service not found - tunnel may be down."
}

# --- Check current running version ---
$versionBefore = "unknown"
if ($agentSvcJustStarted) {
    # 86e33uwfd: the self-heal check above may have just started a
    # stopped $AGENT_SERVICE this same cycle -- a single fast read can
    # miss a slow-starting uvicorn child, leaving $versionBefore
    # "unknown" (never matches the manifest version) and triggering a
    # full wasted download+swap+restart cycle even though the box was
    # already current. Reuse the crash-recovery block's own retry shape
    # (:949-956) only on this path -- the common case (service was
    # already running) stays exactly as fast as before.
    for ($i = 0; $i -lt 3; $i++) {
        try {
            $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
            if ($resp.StatusCode -eq 200) { $versionBefore = ($resp.Content | ConvertFrom-Json).version; break }
        } catch {}
        Start-Sleep -Seconds 2
    }
} else {
    try {
        $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 5
        $versionBefore = ($resp.Content | ConvertFrom-Json).version
    } catch {}
}

# --- Fetch manifest from latest release (no auth required) ---
$manifest = $null
try {
    $raw = Invoke-WebRequest -Uri $MANIFEST_URL -UseBasicParsing -TimeoutSec 15
    $manifest = $raw.Content | ConvertFrom-Json
} catch {
    Fail "Could not fetch update manifest from $MANIFEST_URL -- check network connection."
}

# Validate required fields before using them -- a manifest missing any of these
# (malformed publish, truncated response, etc.) must not reach an unguarded
# access below (e.g. $manifest.sha256.ToLower() on $null), which would throw
# an uncaught error and terminate the script before Fail()/Complete-AdminAction
# ever runs -- leaving $LOCK_FILE (the portal's in-flight indicator) wedged
# forever. See 86e2rrypb.
#
# Trust boundary note (86e2rrzga, documented not fixed -- Erin's 2026-08-20
# decision): this manifest is fetched over HTTPS (defends against network
# tampering) and the zip below is checksummed against this manifest's own
# sha256 (defends against a corrupted/incomplete download) -- but nothing here
# defends against a compromised GitHub account or repo pushing a malicious,
# internally-consistent manifest+zip pair together. Closing that gap would
# need manifest signing or full code-signing, both out of scope for now.
$missingFields = @()
foreach ($field in @("version", "zip_url", "sha256")) {
    if ([string]::IsNullOrEmpty($manifest.$field)) { $missingFields += $field }
}
if ($missingFields.Count -gt 0) {
    Fail "Manifest from $MANIFEST_URL is missing required field(s): $($missingFields -join ', ') -- aborting update."
}

$latestVersion = $manifest.version
$zipUrl        = $manifest.zip_url
$expectedSha   = $manifest.sha256
$whatsNew      = $manifest.whats_new

# The beta manifest tags versions as "x.y.z-beta", but /health reports the bare
# "x.y.z" from server.py. Strip any pre-release suffix from both sides before
# comparing so a beta box doesn't see itself as perpetually out of date and
# re-install (and restart the service) on every cycle.
#
# The main channel is different: its manifest version carries a commit-SHA
# build suffix ("x.y.z-main.<sha>") specifically so two pushes with an
# unchanged VERSION are still distinguishable -- but /health always reports
# the bare VERSION regardless of channel, so comparing against it the same
# way as beta/stable would make main-channel boxes install on literally every
# 6-hour cycle even when nothing changed (the manifest version never equals
# the bare /health version, since one always has a suffix and the other never
# does). So for a "-main." manifest version, compare the FULL string against
# the full manifest version this box last successfully installed (persisted
# to $INSTALLED_MANIFEST_VERSION_FILE below), not against /health's version.
if ($latestVersion -match '-main\.') {
    $installedManifestVersion = ""
    if (Test-Path $INSTALLED_MANIFEST_VERSION_FILE) {
        # 86e2rrypb re-fix (same bug as the RUN_LOCK_FILE read above -- see that comment) +
        # 86e2x8m3p (this read was also missing -ErrorAction SilentlyContinue, unlike its sibling).
        $rawInstalledVersion = Get-Content $INSTALLED_MANIFEST_VERSION_FILE -Raw -ErrorAction SilentlyContinue
        if ($null -eq $rawInstalledVersion) { $rawInstalledVersion = "" }
        $installedManifestVersion = $rawInstalledVersion.Trim()
    }
    if ($latestVersion -eq $installedManifestVersion) {
        # 86e38zdab: don't trust this manifest-version match alone -- it says nothing about
        # whether $AGENT_SERVICE is actually running. The self-heal block above (lines
        # ~1165-1193) may have just tried and failed to start it (Start-ServiceWithTimeout
        # itself threw), in which case exiting "Already up to date" here would leave the
        # service down until a genuine new release finally ships. Re-check with a fresh
        # Get-Service call (not the stale $agentSvc read captured before that self-heal
        # attempt) and only take the early exit when it's genuinely Running.
        #
        # 86e38zdab Final Review fix (Important): only fall through to a reinstall when
        # $agentSvcInfo (the self-heal block's own CIM ownership result, still in scope --
        # PathName doesn't change mid-run, so re-using it here is safe) confirms this is
        # genuinely IntraMind's own service. update.ps1 has no code path that can (re)create
        # $AGENT_SERVICE from scratch -- only $CF_SERVICE_NAME ever gets an `sc.exe create`
        # -- so falling through on a foreign or unconfirmed (WMI-query-failed) service would
        # be futile (it can never recover) and contradicts the self-heal block's own "Not
        # touching it" rule for exactly this case. Exit early without repair in both cases
        # instead, same as the self-heal block above already does.
        $agentSvcNowStatus = (Get-Service $AGENT_SERVICE -ErrorAction SilentlyContinue).Status
        $agentSvcOwnedByUs = $agentSvcInfo -and ($agentSvcInfo.PathName -like "*$INSTALL_DIR*" -or $agentSvcInfo.PathName -like "*$PY_DIR*")
        if ($agentSvcNowStatus -eq "Running" -or -not $agentSvcOwnedByUs) {
            Log "Already up to date (version $latestVersion) -- skipping."
            Complete-AdminAction -result "ok" -detail "Already up to date" -version $versionBefore
            exit 0
        } else {
            Log "Manifest version matches (already up to date at $latestVersion), but $AGENT_SERVICE is not Running (status: $agentSvcNowStatus) and is owned by IntraMind -- the self-heal Start attempt above must have failed. Falling through to a full reinstall instead of exiting early."
        }
    }
} else {
    $latestCompare = ($latestVersion -split '-')[0]
    $beforeCompare = ($versionBefore -split '-')[0]

    if ($latestCompare -eq $beforeCompare) {
        Log "Already up to date (version $versionBefore) -- skipping."
        Complete-AdminAction -result "ok" -detail "Already up to date" -version $versionBefore
        exit 0
    }
}

# --- 86e3gevzm A8-F2 (Batch Y3): skip a release that failed recently ---
# A version recorded in $FAILED_RELEASE_FILE (it rolled back, or its
# dependencies failed to install) is not retried by scheduled runs for
# $FAILED_RELEASE_SKIP_HOURS h, so a broken release no longer costs a
# download, a stop and a rollback every 6 hours. A new main-channel push has
# a new version string, so it is never skipped. A portal Update Now bypasses
# the skip (see Get-FailedReleaseSkip). The result is "error" with a
# "Skipped ..." detail: the portal shows anything other than ok/recovered as
# "Update failed: <detail>", and a new result value would need a portal
# change (spec D6).
$failedReleaseCheck = Get-FailedReleaseSkip -LatestVersion $latestVersion -FailedReleasePath $FAILED_RELEASE_FILE -PortalLockPath $LOCK_FILE -NowUtc (Get-Date).ToUniversalTime()
if ($failedReleaseCheck.Message) {
    if ($failedReleaseCheck.IsWarning) { Warn $failedReleaseCheck.Message } else { Log $failedReleaseCheck.Message }
}
if ($failedReleaseCheck.Skip) {
    Complete-AdminAction -result "error" -detail $failedReleaseCheck.Detail -version $versionBefore
    exit 0
}

Log "Updating: $versionBefore -> $latestVersion"

# --- Download release zip ---
$zipPath = "$env:TEMP\intramind-release.zip"
try {
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
    Log "Downloaded release zip."
} catch {
    Fail "Failed to download release zip from $zipUrl"
}

# --- Verify SHA256 checksum ---
$actualSha = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
if ($actualSha -ne $expectedSha.ToLower()) {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    Fail "Checksum mismatch. Expected: $expectedSha  Got: $actualSha -- aborting update."
}
Log "Checksum verified."

# --- Extract to a staging directory, not $INSTALL_DIR directly (see
# 86e2rrzj2). An interruption here (crash, power loss) only ever leaves an
# incomplete staging directory -- the current install is untouched until the
# atomic swap below. ---
$stagingDir = "$INSTALL_DIR.new"
if (Test-Path $stagingDir) {
    Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $stagingDir) {
        Fail "Could not remove stale staging directory $stagingDir -- manual cleanup needed before update can proceed."
    }
}
$zip = $null
try {
    New-Item -ItemType Directory -Path $stagingDir -Force -ErrorAction Stop | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    # Path-containment check (Zip Slip defense, see 86e2t0ft8/CR-3). Sibling
    # copies of this exact check live in install.ps1's extraction block and
    # onboarding/deploy.ps1's extraction block -- keep all three in sync if
    # this logic ever needs to change.
    $stagingDirFull = [System.IO.Path]::GetFullPath($stagingDir) + [System.IO.Path]::DirectorySeparatorChar
    foreach ($entry in $zip.Entries) {
        $destPath = Join-Path $stagingDir $entry.FullName
        $destPathFull = [System.IO.Path]::GetFullPath($destPath)
        if (-not $destPathFull.StartsWith($stagingDirFull, [System.StringComparison]::OrdinalIgnoreCase)) {
            Fail "Release zip entry '$($entry.FullName)' resolves outside the staging directory -- aborting extraction (possible Zip Slip)."
        }
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destPath, $true)
        Log "  Extracted $($entry.FullName)"
    }
    $zip.Dispose()
    $zip = $null
    # 86e2xypqk: install.ps1/migrate.ps1/deploy.ps1 harden $INSTALL_DIR's ACL via
    # Protect-SecretsDir(), but Rename-Item (the atomic swap below) does not carry a
    # directory's DACL/inheritance-protected flag along with it -- $stagingDir starts
    # with the plain default ACL Windows gives a new directory, and swapping it into
    # $INSTALL_DIR's place would silently un-harden the live install after every
    # update cycle. Apply the identical restriction here too, AFTER extraction
    # completes (not before -- live-verified this session that hardening first
    # breaks the extraction itself for any account other than SYSTEM/Administrators,
    # since the process doing the writing loses its own just-granted access), so the
    # extracted tree carries the hardened ACL into the swap. A real box that predates
    # this fix (or has only ever been updated, never re-installed/migrated, since)
    # was confirmed this session to show exactly the un-hardened state this closes.
    #
    # Deliberately Warn(), not Fail(), on a non-zero icacls exit code -- this script
    # runs unattended every 6 hours; aborting a customer's update over an ACL call
    # would be worse than the gap being closed (see 86e2xypqk's own explicit note).
    icacls $stagingDir /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Warn "Could not fully apply permissions on $stagingDir (icacls exit code $LASTEXITCODE) -- proceeding with the update anyway; the swapped-in install may have a weaker ACL than intended. An Administrator can re-apply it later with icacls `"$INSTALL_DIR`" /inheritance:r /grant:r `"*S-1-5-18:(OI)(CI)F`" `"*S-1-5-32-544:(OI)(CI)F`"."
    }
} catch {
    if ($zip) { $zip.Dispose() }
    Fail "Failed to extract release zip: $_"
} finally {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
}

# --- Write pending update notification for UI ---
$pending = @{ version = $latestVersion; whats_new = $whatsNew } | ConvertTo-Json -Compress
Set-Content "$DATA_DIR\pending_update.txt" $pending -NoNewline -ErrorAction SilentlyContinue
Log "Pending update notification written for version $latestVersion"

# --- 86e3gevjc (Batch Y5): Phase A -- download this release's Python dependencies
# BEFORE stopping the service. update.ps1 never ran pip before this, so a
# release that added or bumped a dependency swapped the code in, the service
# failed its import, /health never answered and the run rolled back (then
# retried every 6 hours). Phase A (here, service still running) does all the
# network work with `pip download`; Phase B (after the stop, below) installs
# offline from the downloaded wheels, so a slow or unreachable index costs no
# downtime. --only-binary :all: because customer boxes have no compiler; every
# current pin ships a cp311 win_amd64 or pure-Python wheel. A failed download
# is NOT recorded in $FAILED_RELEASE_FILE: it is usually transient and cost no
# downtime. ---
$stagedReq = Join-Path $stagingDir "requirements_live.txt"
$currentReq = Join-Path $INSTALL_DIR "requirements_live.txt"
try {
    $reqDecision = Get-RequirementsDecision -StagedReqPath $stagedReq -CurrentReqPath $currentReq -HashFilePath $REQ_HASH_FILE
} catch {
    Remove-Item -LiteralPath $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
    Fail "Could not read the requirements files to decide whether $latestVersion needs pip ($_) -- update not applied."
}
$stagedReqHash = $reqDecision.StagedHash
$script:pipInstallRan = $false
$script:swapFailureUndone = $false
$script:swapCompleted = $false
$script:reqHashBeforePip = $null
if ($reqDecision.NeedPip) {
    Log "Requirements changed for $latestVersion (known hash source: $($reqDecision.Source)) -- downloading dependencies before stopping $AGENT_SERVICE..."
    Remove-Item -LiteralPath $PIP_WHEELHOUSE -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $PIP_LOG_FILE -Force -ErrorAction SilentlyContinue
    $pipDownloadArgs = $PIP_COMMON_ARGS + @("download", "--timeout", "15", "--retries", "2", "--only-binary", ":all:", "-d", $PIP_WHEELHOUSE, "-r", $stagedReq)
    $pipDownload = Invoke-ProcessWithTimeout -FilePath $PY_EXE -ArgumentList $pipDownloadArgs -TimeoutSeconds $PIP_DOWNLOAD_TIMEOUT_SECONDS
    if (-not $pipDownload.Ok) {
        Remove-Item -LiteralPath $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $PIP_WHEELHOUSE -Recurse -Force -ErrorAction SilentlyContinue
        Fail "Dependencies for $latestVersion could not be downloaded (pip download $($pipDownload.Detail); see $PIP_LOG_FILE) -- update not applied; $AGENT_SERVICE was not stopped."
    }
    Log "Dependencies for $latestVersion downloaded to $PIP_WHEELHOUSE."
} else {
    Log "Requirements unchanged for $latestVersion (known hash source: $($reqDecision.Source)) -- no pip step needed."
}

# --- 86e3gevzm A8-F4 (Batch Y7): deadline gate 1 -- defer instead of
# stopping the service when the steps before the stop (self-heal starts,
# version reads, manifest, zip download, pip download) already used more than
# $PRE_STOP_BUDGET_SECONDS of this run's $RUN_TIME_LIMIT_SECONDS, so the
# stop, swap, start, verify and a possible rollback keep enough time before
# the task's ExecutionTimeLimit. Nothing has been stopped yet: no downtime.
# Not recorded in $FAILED_RELEASE_FILE (nothing failed). ---
$preStopElapsed = [int]$script:RunStopwatch.Elapsed.TotalSeconds
if ($preStopElapsed -gt $PRE_STOP_BUDGET_SECONDS) {
    Remove-Item -LiteralPath $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
    Remove-Item -LiteralPath $PIP_WHEELHOUSE -Recurse -Force -ErrorAction SilentlyContinue
    $deferDetail = "Deferred $latestVersion`: the steps before stopping $AGENT_SERVICE took $preStopElapsed s (budget $PRE_STOP_BUDGET_SECONDS s of the $RUN_TIME_LIMIT_SECONDS s run limit) -- update not applied and $AGENT_SERVICE was not stopped; the next cycle retries."
    Warn $deferDetail
    Complete-AdminAction -result "error" -detail $deferDetail -version $versionBefore
    exit 0
}

# --- Stop the agent service before swapping directories -- a directory
# rename while the service's process may still hold open file handles inside
# $INSTALL_DIR is the risk this avoids. Does not add net downtime versus the
# previous Restart-Service call, which already stopped-then-started the
# service; this just moves the stop earlier. See 86e2rrzj2. ---
Log "Stopping $AGENT_SERVICE for install swap..."
try {
    Stop-ServiceWithTimeout $AGENT_SERVICE
} catch {
    # 86e38zdab Final Review fix (Critical): Stop-ServiceWithTimeout's raw
    # ServiceController.Stop() throws InvalidOperationException (Win32 1062) when the
    # service is already Stopped, or 1060 when it's absent entirely -- live-reproduced
    # against real services from this same non-elevated sandbox. Before this fix, EVERY
    # throw here was treated as fatal, but 86e38zdab's own new fall-through above can now
    # route here with the service already Stopped/absent, in which case Stop() throwing is
    # not a failure -- it's the expected outcome of trying to stop something already
    # stopped, and this catch used to abort the reinstall entirely instead of trying it.
    # Ground-truth check whether it's ACTUALLY stopped now before treating this as fatal --
    # a stop failure while the service is still genuinely Running (the original, still-real
    # failure mode this catch exists for) still aborts via Fail() below, unchanged.
    $stopStatus = (Get-Service $AGENT_SERVICE -ErrorAction SilentlyContinue).Status
    if ($null -eq $stopStatus -or $stopStatus -eq "Stopped") {
        Log "Stop-ServiceWithTimeout threw ($_) but $AGENT_SERVICE is $stopStatus -- already stopped (or absent), not a real failure. Proceeding with the install swap."
    } else {
        try { Start-ServiceWithTimeout $AGENT_SERVICE } catch { }
        Fail "Failed to stop $AGENT_SERVICE before install swap: $_"
    }
}

# --- 86e3gevjc (Batch Y5): Phase B -- install the downloaded dependencies
# offline, now that $AGENT_SERVICE is stopped (no .pyd file is in use) and
# before the swap. On failure nothing is swapped: the version is recorded in
# $FAILED_RELEASE_FILE (24 h skip, so a broken release does not stop and
# start the service every 6 hours), the service is restarted on the current
# install, and the run fails with "manual reinstall needed" (some packages may
# already be at the new versions). ---
if ($reqDecision.NeedPip) {
    # 86e3k7w27 / 86e3mwwx1: mark the hash file dirty BEFORE pip, so a kill anywhere between the dependency install and
    # the verify (old code left on new packages) forces pip on the next run even when the next release's requirements
    # equal the set from before the kill. A verified success writes the real hash (success tail); a successful re-install
    # puts back the hash read before pip (Restore-RequirementsHash); a failed one leaves the marker.
    if ($reqDecision.KnownHash -match '^[0-9a-f]{64}$') { $script:reqHashBeforePip = $reqDecision.KnownHash }
    Set-RequirementsHashDirty
    $script:pipInstallRan = $true
    Log "Installing the downloaded dependencies for $latestVersion (offline)..."
    $pipInstallArgs = $PIP_COMMON_ARGS + @("install", "--no-index", "--find-links", $PIP_WHEELHOUSE, "--only-binary", ":all:", "-r", $stagedReq)
    $pipInstall = Invoke-ProcessWithTimeout -FilePath $PY_EXE -ArgumentList $pipInstallArgs -TimeoutSeconds $PIP_INSTALL_TIMEOUT_SECONDS
    if (-not $pipInstall.Ok) {
        Write-FailedRelease -Version $latestVersion -Reason "dependency install failed (pip install $($pipInstall.Detail))"
        # 86e3gevjc (Batch Y6): a partly-done install may have changed some
        # packages; put the current install's requirements back first.
        $previousReqsReinstalled = Invoke-RequirementsReinstall -Context "Dependency install failure"
        try { Start-ServiceWithTimeout $AGENT_SERVICE } catch { }
        Remove-Item -LiteralPath $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $PIP_WHEELHOUSE -Recurse -Force -ErrorAction SilentlyContinue
        Fail "Dependency install for $latestVersion failed (pip install $($pipInstall.Detail); see $PIP_LOG_FILE) -- the install swap was NOT done and $INSTALL_DIR still holds $versionBefore; a restart of $AGENT_SERVICE was attempted after re-installing the previous requirements (re-install succeeded: $previousReqsReinstalled). If $AGENT_SERVICE does not answer /health, manual reinstall needed."
    }
    Remove-Item -LiteralPath $PIP_WHEELHOUSE -Recurse -Force -ErrorAction SilentlyContinue
    Log "Dependencies for $latestVersion installed."
}

# --- Atomic swap: current install -> .previous (one-generation rollback
# backup, removed only when the NEXT successful swap needs the slot), staging
# -> current. If the swap partially fails, attempt to restore .previous so
# the machine is never left with neither a working $INSTALL_DIR nor a
# recoverable backup. See 86e2rrzj2. ---
try {
$previousDir = "$INSTALL_DIR.previous"
if (Test-Path $previousDir) {
    Remove-Item $previousDir -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $previousDir) {
        # Final Review fix wave (I2): Phase B may have changed the packages.
        Undo-RequirementsAfterSwapFailure "could not remove stale $previousDir"
        try { Start-ServiceWithTimeout $AGENT_SERVICE } catch { }
        Fail "Could not remove stale $previousDir -- manual cleanup needed before update can proceed."
    }
}
try {
    Rename-DirectoryWithRetry -Path $INSTALL_DIR -NewName (Split-Path $previousDir -Leaf)
} catch {
    $moveAsideError = $_
    Undo-RequirementsAfterSwapFailure "could not move the current install aside: $moveAsideError"
    try { Start-ServiceWithTimeout $AGENT_SERVICE } catch { }
    Fail "Failed to move current install to $previousDir before swap: $moveAsideError"
}
try {
    Rename-DirectoryWithRetry -Path $stagingDir -NewName (Split-Path $INSTALL_DIR -Leaf)
} catch {
    Warn "Failed to swap staged install into place: $_ -- attempting to restore previous install."
    try {
        Rename-DirectoryWithRetry -Path $previousDir -NewName (Split-Path $INSTALL_DIR -Leaf)
        # After the restore rename, so the re-install reads the restored
        # install's requirements file.
        Undo-RequirementsAfterSwapFailure "could not move the new install into place; previous install restored"
        try { Start-ServiceWithTimeout $AGENT_SERVICE } catch { }
        Fail "Swap failed; restored previous install. Update aborted."
    } catch {
        Fail "Swap failed AND could not restore previous install -- $INSTALL_DIR may be missing. Manual recovery needed. Restore-attempt error (the original swap error was logged above): $_"
    }
}
Log "Install directory swapped."
$script:swapCompleted = $true

# --- Migrate legacy "Cloudflared" service name to "IntramindCloudServices" ---
# Renamed to avoid colliding with other Cloudflare Tunnel products (e.g. Koble)
# that use the default service name. install.ps1 does this migration on a fresh
# reinstall, but most customers only ever get auto-updated and never re-run the
# installer, so do it here too. NEVER touch a service just because it's named
# "Cloudflared": on a shared machine that name might belong to another product.
# Verify ownership by binPath first -- this runs unattended every 6 hours, so an
# unverified assumption here means silently deleting someone else's service on a
# schedule. See docs/cloudflared-tunnel-setup.md Troubleshooting for the
# 2026-07-16 mmp-ebms incident this check exists to prevent.
$legacyCfSvc = Get-CimInstance Win32_Service -Filter "Name='Cloudflared'" -ErrorAction SilentlyContinue
if ($legacyCfSvc -and $legacyCfSvc.PathName -like "*$CF_SYS_DIR*") {
    Log "Found legacy IntraMind 'Cloudflared' service - migrating to $CF_SERVICE_NAME..."
    $legacyBinPath = $legacyCfSvc.PathName
    $wasRunning = ($legacyCfSvc.State -eq "Running")
    # 86e33kt0x: deliberately NOT routed through Stop-ServiceWithTimeout,
    # unlike every other Stop/Start-Service call in this file --
    # ServiceController.Stop() has no -Force equivalent (won't auto-stop
    # dependent services first), and Erin's call was that keeping -Force's
    # dependent-service handling here (a one-time legacy-migration path,
    # not a recurring hot path) outweighs closing this one call site's
    # timeout gap. Accepted, documented trade-off -- see 86e33kt0x.
    Stop-Service "Cloudflared" -Force -ErrorAction SilentlyContinue
    sc.exe delete Cloudflared | Out-Null
    $cfDeleteExit = $LASTEXITCODE
    if ($cfDeleteExit -ne 0) {
        Warn "sc.exe delete Cloudflared exited with code $cfDeleteExit during service migration -- attempting to create $CF_SERVICE_NAME anyway."
    }
    # 86e30ye63 (follow-up to 86e30r3d2): matches install.ps1/migrate.ps1's fresh-install
    # registration -- start= delayed-auto, not auto, to avoid racing the network stack
    # at boot. This path re-creates the service with whatever binPath the legacy
    # "Cloudflared" service already had, so it must apply the same start type or a
    # customer migrating through THIS path (rather than a fresh install.ps1/migrate.ps1
    # run) would end up with the boot-time race 86e30r3d2 fixed everywhere else.
    sc.exe create $CF_SERVICE_NAME binPath= $legacyBinPath start= delayed-auto DisplayName= "IntraMind Cloud Services" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        # 86e3kzhqa: the agent was stopped for the swap; restart it before failing or it stays stopped until the next self-heal.
        try { Start-ServiceWithTimeout $AGENT_SERVICE } catch { }
        Fail "CRITICAL: cloudflared tunnel service migration failed -- 'Cloudflared' was deleted (sc.exe delete exit $cfDeleteExit) but sc.exe create $CF_SERVICE_NAME failed (exit $LASTEXITCODE). The tunnel service no longer exists on this box. The install swap had already completed and a restart of $AGENT_SERVICE was attempted. Manual recovery: sc.exe create $CF_SERVICE_NAME binPath= `"$legacyBinPath`" start= delayed-auto DisplayName= `"IntraMind Cloud Services`""
    }
    sc.exe failure $CF_SERVICE_NAME reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Warn "sc.exe failure $CF_SERVICE_NAME (configuring auto-restart) exited with code $LASTEXITCODE -- service created but crash auto-restart may not be configured."
    }
    sc.exe failureflag $CF_SERVICE_NAME 1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Warn "sc.exe failureflag $CF_SERVICE_NAME failed (exit code $LASTEXITCODE) -- non-crash failures (a clean nonzero exit) will not trigger the restart actions above."
    }
    if ($wasRunning) {
        try {
            Start-ServiceWithTimeout $CF_SERVICE_NAME
        } catch {
            Warn "Could not restart $CF_SERVICE_NAME after tunnel-service migration ($_) -- it remains stopped; will retry next cycle."
        }
    }
    Log "Migrated to $CF_SERVICE_NAME."
} elseif ($legacyCfSvc) {
    Warn "A 'Cloudflared' service exists but is not owned by IntraMind (binPath: $($legacyCfSvc.PathName)). Leaving it untouched."
}
} catch {
    # Catches only a genuinely unexpected, unhandled exception somewhere in
    # the swap/cloudflared-migration region above -- every existing Fail()
    # call site inside that region already exits directly (PowerShell's exit
    # bypasses catch blocks entirely) and is unaffected by this addition. See
    # 86e2rrzed: without this, an exception here (e.g. an unexpected
    # Get-CimInstance failure) would terminate the script with the agent left
    # stopped and no restart attempted, and Complete-AdminAction never called
    # (leaving the update lock wedged too).
    $swapError = $_
    # Final Review fix wave (I2): before the swap completed, re-installs the
    # requirements file in $INSTALL_DIR (the old one) so the code that restarts
    # matches its packages. After the swap completed this call does nothing: it
    # neither records the release as failed nor re-installs (the new code is in
    # place on the new packages).
    Undo-RequirementsAfterSwapFailure "unexpected error: $swapError"
    try { Start-ServiceWithTimeout $AGENT_SERVICE } catch { }
    if ($script:swapCompleted) {
        Fail "Unexpected failure after the install swap completed (the new install is in place; a restart of $AGENT_SERVICE was attempted): $swapError"
    }
    Fail "Unexpected failure during install swap: $swapError"
}

# --- Start agent service (already stopped above for the swap) ---
Log "Starting $AGENT_SERVICE..."
try {
    Start-ServiceWithTimeout $AGENT_SERVICE
    Log "Service started."
} catch {
    # 86e3bwmwj: mirrors the Stop-ServiceWithTimeout ground-truth-check fix above
    # (86e38zdab Final Review) -- ServiceController.Start() throws when the service is
    # already Running (e.g. a concurrent self-heal race via the per-cycle block at
    # ~1138-1203, 86e33krx8), symmetric to .Stop()
    # throwing when already Stopped. An unconditional Invoke-Rollback here could
    # destructively roll back an install that actually already succeeded. Ground-truth
    # check whether it's ACTUALLY running now before treating this as fatal -- a start
    # failure while the service is still genuinely not running (the original, still-real
    # failure mode this catch exists for) still rolls back via Invoke-Rollback below,
    # unchanged.
    $startStatus = (Get-Service $AGENT_SERVICE -ErrorAction SilentlyContinue).Status
    if ($startStatus -eq "Running") {
        Log "Start-ServiceWithTimeout threw ($_) but $AGENT_SERVICE is Running -- already started, not a real failure. Proceeding."
    } else {
        Invoke-Rollback "Failed to start $AGENT_SERVICE after swap: $_"
        # Invoke-Rollback already reports via Complete-AdminAction; exit here so
        # execution doesn't fall through into the version-verification block
        # below for a service that never started in the first place.
        exit 1
    }
}

# --- Verify new version ---
# 86e3gevzm A8-F2 (Batch Y2): a 90 s Stopwatch deadline (this was a 10-try
# loop that lasted about 55 s); see Wait-ForHealth.
$versionAfter = Wait-ForHealth

if ($versionAfter -eq "unknown") {
    Invoke-Rollback "Update to $latestVersion failed verification"
} else {
    Log "Update complete. Version: $versionAfter"
    # 86e3gevzm A8-F3 (Batch Y1): this write had no error handling. With
    # $ErrorActionPreference = "Stop" a locked or unwritable file threw a
    # terminating error here, so Complete-AdminAction below never ran:
    # update.lock stayed behind, the portal never got a result, and the main
    # channel reinstalled the same version on the next cycle. The write stays
    # BEFORE Complete-AdminAction (so it still happens inside the run lock,
    # which Complete-AdminAction releases); guarded, it can no longer skip
    # the completion call.
    try {
        Set-Content -Path $INSTALLED_MANIFEST_VERSION_FILE -Value $latestVersion -NoNewline -ErrorAction Stop
    } catch {
        Warn "Could not record the installed manifest version in $INSTALLED_MANIFEST_VERSION_FILE ($_) -- the update itself succeeded; on the main channel the next cycle may reinstall $latestVersion."
    }
    # 86e3gevjc (Batch Y5): record the installed requirements hash only now
    # that /health has verified the new install; guarded like the write above.
    if ($stagedReqHash) {
        try {
            [System.IO.File]::WriteAllText($REQ_HASH_FILE, $stagedReqHash, (New-Object System.Text.UTF8Encoding($false)))
        } catch {
            Warn "Could not record the requirements hash in $REQ_HASH_FILE ($_) -- the next update may run pip again needlessly."
        }
    }
    # 86e3gevzm A8-F2 (Batch Y3): a verified success clears any failed-release record.
    try { if (Test-Path -LiteralPath $FAILED_RELEASE_FILE) { Remove-Item -LiteralPath $FAILED_RELEASE_FILE -Force -ErrorAction Stop } } catch { Warn "Could not remove $FAILED_RELEASE_FILE ($_) -- a stale failed-release record can make the next scheduled run skip a good version for up to $FAILED_RELEASE_SKIP_HOURS h." }
    Complete-AdminAction -result "ok" -detail $null -version $versionAfter
}
