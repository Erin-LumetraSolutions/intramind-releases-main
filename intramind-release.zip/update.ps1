# EBMS Live - pull latest release from GitHub and restart the server
# Runs automatically every 6 hours via Windows Task Scheduler (as SYSTEM).
# Can also be run manually as Administrator.

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ErrorActionPreference = "Stop"

# Move this process's own working directory off $INSTALL_DIR before doing
# anything else. If this script is launched by a process whose CWD is
# $INSTALL_DIR (e.g. the portal's admin/update launcher, which likely
# inherits the agent service's own working directory), Windows holds a
# directory handle that would block the rename-swap further down with a
# sharing violation -- deterministically, on that launch path.
# Set-Location alone does not move the actual process working directory;
# SetCurrentDirectory does. See 86e2rrzj2.
[System.IO.Directory]::SetCurrentDirectory($env:SystemRoot)
Set-Location $env:SystemRoot

$INSTALL_DIR   = "C:\Program Files\IntraMind"
$DATA_DIR      = "C:\ProgramData\IntraMind"
$AGENT_SERVICE = "EBMSLiveAgent"
$CF_SERVICE_NAME = "IntramindCloudServices"
$CF_SYS_DIR    = "C:\Windows\System32\config\systemprofile\.cloudflared"
$LOG_FILE           = "$DATA_DIR\update.log"
$TASK_NAME          = "IntraMindAutoUpdate"
$LOCK_FILE          = "$DATA_DIR\update.lock"
$RUN_LOCK_FILE      = "$DATA_DIR\update.running.lock"
$ADMIN_ACTION_FILE  = "$DATA_DIR\last_admin_action.json"
$INSTALLED_MANIFEST_VERSION_FILE = "$DATA_DIR\installed_manifest_version.txt"

$MANIFEST_URLS = @{
    stable = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases/main/manifest.json"
    beta   = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases-beta/main/manifest.json"
    main   = "https://raw.githubusercontent.com/Erin-LumetraSolutions/intramind-releases-main/main/manifest.json"
}

function Log($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Cyan
}
function Warn($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') WARNING: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Yellow
}
function Complete-AdminAction($result, $detail, $version) {
    # Records the outcome of this run (scheduled or portal-triggered) for the
    # IntraMind admin portal's /health poll to surface, and clears the
    # in-progress lock /admin/update creates before launching this script.
    # Every exit path below must go through this so a customer never gets
    # stuck locked out of a retry. See docs/superpowers/specs/
    # 2026-08-07-portal-remote-admin-design.md §4.
    #
    # Also releases $RUN_LOCK_FILE (this script's own mutual-exclusion lock,
    # see 86e2t0g09) -- safe unconditionally here because a run that lost the
    # lock-contention race exits before ever reaching Complete-AdminAction
    # (see the acquire-or-exit block near the top of the script), so by the
    # time this function runs, this process is always the lock's true owner.
    Remove-Item -Path $LOCK_FILE -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $RUN_LOCK_FILE -Force -ErrorAction SilentlyContinue
    $action = @{
        action  = "update"
        result  = $result
        detail  = $detail
        version = $version
        at      = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    } | ConvertTo-Json -Compress
    Set-Content -Path $ADMIN_ACTION_FILE -Value $action -NoNewline -Encoding utf8 -ErrorAction SilentlyContinue
}
function Rename-DirectoryWithRetry($Path, $NewName, $Attempts = 3, $DelaySeconds = 2) {
    # A directory rename can transiently fail right after Stop-Service
    # returns (Windows can report STOPPED slightly before all file handles
    # are released). A short retry absorbs that instead of aborting the
    # update over a race that resolves itself within a couple seconds.
    # See 86e2rrzj2.
    #
    # Defined up here (moved from mid-script in round 2 of 86e2rrzj2) so the
    # crash-recovery block below -- which runs before the extraction/swap
    # logic that originally motivated this helper -- can use it too, instead
    # of a bare unretried Rename-Item.
    for ($i = 1; $i -le $Attempts; $i++) {
        try {
            Rename-Item -Path $Path -NewName $NewName -ErrorAction Stop
            return
        } catch {
            if ($i -eq $Attempts) { throw }
            Start-Sleep -Seconds $DelaySeconds
        }
    }
}

function Invoke-Rollback($Reason) {
    # Restores $previousDir into $INSTALL_DIR after a failed post-swap
    # service start or failed version verification. Renames the broken tree
    # aside first rather than deleting it outright, so a failed delete never
    # leaves $INSTALL_DIR completely gone -- and re-verifies the restored
    # version actually responds before reporting success rather than
    # asserting it blindly. See 86e2rrzj2.
    #
    # Round 2 (2026-08-20): the outer catch below deliberately does NOT
    # attempt a blind Start-Service on its own rename failure. Tracing both
    # possible failure points shows neither leaves anything worth starting
    # under $INSTALL_DIR's real name:
    #   - If the FIRST rename (move the broken $INSTALL_DIR aside to
    #     .failed) is what throws, the rename never happened, so
    #     $INSTALL_DIR still exists -- but it still holds the BROKEN build
    #     that triggered this rollback in the first place. Starting the
    #     service here would just run the broken version; that is not a
    #     recovery, it actively hides the failure.
    #   - If the SECOND rename (restore .previous into $INSTALL_DIR) is what
    #     throws, the first rename already succeeded, so $INSTALL_DIR does
    #     not exist under that name at all. There is nothing there to
    #     start.
    # Either way a Start-Service call in the catch can't help, so the fix is
    # a stage-specific error message that says exactly which directory holds
    # which version and what manual step restores service.
    Warn "$Reason -- rolling back to previous install."
    $failedDir = "$INSTALL_DIR.failed"
    if (Test-Path $failedDir) {
        Remove-Item $failedDir -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path $failedDir) {
            # Best-effort stop before bailing out: whichever call site got us
            # here, $INSTALL_DIR currently holds the version that triggered
            # this rollback (either the swap's new build that failed to
            # start, or one that started but never verified) -- don't leave
            # it silently running while reporting an error that needs manual
            # attention.
            Stop-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
            Fail "$Reason -- AND could not remove stale $failedDir before attempting rollback -- manual cleanup of $failedDir needed before rollback can proceed. $AGENT_SERVICE has been stopped as a precaution; $INSTALL_DIR still holds the version that triggered this rollback -- do not start the service again until that is manually confirmed safe."
        }
    }
    $renameStage = $null
    try {
        Stop-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
        $renameStage = "move-broken-aside"
        Rename-DirectoryWithRetry -Path $INSTALL_DIR -NewName (Split-Path $failedDir -Leaf)
        $renameStage = "restore-previous"
        Rename-DirectoryWithRetry -Path $previousDir -NewName (Split-Path $INSTALL_DIR -Leaf)
        $renameStage = $null
        $started = $false
        try {
            Start-Service $AGENT_SERVICE -ErrorAction Stop
            $started = $true
        } catch {
            Warn "Rollback: restored $INSTALL_DIR to the previous version but failed to start $AGENT_SERVICE`: $_"
        }
        $rollbackVerified = $false
        if ($started) {
            Start-Sleep -Seconds 5
            for ($i = 0; $i -lt 10; $i++) {
                try {
                    $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
                    if ($resp.StatusCode -eq 200) { $rollbackVerified = $true; break }
                } catch {}
                Start-Sleep -Seconds 2
            }
        }
        Remove-Item $failedDir -Recurse -Force -ErrorAction SilentlyContinue
        if ($rollbackVerified) {
            Complete-AdminAction -result "error" -detail "$Reason -- rolled back to previous install ($versionBefore) and confirmed it is responding." -version $versionBefore
        } else {
            Complete-AdminAction -result "error" -detail "$Reason -- rolled back to previous install ($versionBefore) but could not confirm it is responding afterward. Manual check needed." -version $versionBefore
        }
    } catch {
        if ($renameStage -eq "move-broken-aside") {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed while moving the failed install aside: $_ -- $INSTALL_DIR still holds the BROKEN version that triggered this rollback, and no start was attempted (starting it would just run the broken build). $previousDir still holds the last known-good version, untouched. Manual recovery once whatever is locking $INSTALL_DIR clears: move or remove $INSTALL_DIR, rename $previousDir to $INSTALL_DIR, then start $AGENT_SERVICE." -version $null
        } elseif ($renameStage -eq "restore-previous") {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed while restoring the previous install: $_ -- $INSTALL_DIR does not currently exist (the broken build was already moved aside to $failedDir); $previousDir still holds the last known-good version under its own name. Manual recovery: rename $previousDir to $INSTALL_DIR and start $AGENT_SERVICE." -version $null
        } else {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed: $_ -- manual intervention needed." -version $null
        }
    }
}
function Fail($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ERROR: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Red
    Complete-AdminAction -result "error" -detail $msg -version $null
    exit 1
}

Log "EBMS Live Updater starting"

# --- Mutual-exclusion: prevent a scheduled run and a portal-triggered run (or
# two scheduled runs somehow overlapping) from executing concurrently and
# colliding on the shared $zipPath download further down. Distinct from
# $LOCK_FILE above, which is the portal's own "one admin action in flight" UI
# signal, not a real mutex -- this script never checked it, and a concurrent
# run could still race on the same temp zip file. See 86e2t0g09/CR-14.
if (Test-Path $RUN_LOCK_FILE) {
    $existingPid = ([string](Get-Content $RUN_LOCK_FILE -Raw -ErrorAction SilentlyContinue)).Trim()
    $stillRunning = $false
    # Only check the process if $existingPid is a valid positive integer (guards against
    # "0" being permanently truthy and non-numeric content causing ParameterBindingException)
    if ($existingPid -match '^\d+$' -and [int]$existingPid -gt 0) {
        $stillRunning = [bool](Get-Process -Id ([int]$existingPid) -ErrorAction SilentlyContinue)
    }
    if ($stillRunning) {
        # Another run owns this lock and is still in progress. This is
        # expected coordination, not a failure -- exit immediately WITHOUT
        # calling Fail() or Complete-AdminAction, and without touching either
        # lock file, both of which may belong to the still-running other run.
        Log "Another update run (PID $existingPid) is already in progress -- exiting."
        exit 0
    }
    # Message distinguishes empty/corrupt lock from stale PID
    if ($existingPid) {
        Warn "Found a stale $RUN_LOCK_FILE from PID $existingPid, which is no longer running -- a prior run likely crashed without cleaning up. Proceeding."
    } else {
        Warn "Found an empty or corrupt $RUN_LOCK_FILE -- a prior run likely crashed without cleaning up. Proceeding."
    }
}
Set-Content -Path $RUN_LOCK_FILE -Value $PID -NoNewline -ErrorAction SilentlyContinue

# --- Crash recovery: detect an interrupted prior swap (86e2rrzj2) ---
# If a prior run died between the two renames in the swap step further
# down, $INSTALL_DIR won't exist but $INSTALL_DIR.previous (the last
# known-good version) will. Recover it before doing anything else --
# otherwise this run's own swap step would delete .previous (the only
# surviving copy) without ever checking whether it's actually needed.
$previousDirCheck = "$INSTALL_DIR.previous"
if (-not (Test-Path $INSTALL_DIR) -and (Test-Path $previousDirCheck)) {
    Warn "$INSTALL_DIR is missing but $previousDirCheck exists -- recovering from an interrupted prior update."
    try {
        Rename-DirectoryWithRetry -Path $previousDirCheck -NewName (Split-Path $INSTALL_DIR -Leaf)
        Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
        Fail "Recovered $INSTALL_DIR from $previousDirCheck after an interrupted prior update. Aborting this run -- the next scheduled cycle will retry the actual update."
    } catch {
        Fail "CRITICAL: $INSTALL_DIR is missing and could not be recovered from $previousDirCheck`: $_. Manual recovery needed immediately."
    }
}

# --- Register scheduled task if not already present ---
$task = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
if (-not $task) {
    Log "Registering auto-update scheduled task (every 6 hours)..."
    try {
        $action    = New-ScheduledTaskAction -Execute "powershell.exe" `
                       -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$INSTALL_DIR\update.ps1`""
        $trigger   = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Hours 6) -Once -At "00:00"
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
        $settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 10) `
                       -StartWhenAvailable -MultipleInstances IgnoreNew
        Register-ScheduledTask -TaskName $TASK_NAME -Action $action -Trigger $trigger `
            -Principal $principal -Settings $settings -Force | Out-Null
        Log "Scheduled task registered."
    } catch {
        Fail "Failed to register scheduled task: $_"
    }
}

# --- Ensure both services have crash-recovery actions configured ---
# Backfill for machines whose services were registered before this was added
# to install.ps1/deploy.ps1 -- idempotent and cheap, so this runs every
# 6-hour cycle (deliberately placed before the version-check early return
# below, unlike the Cloudflared-name migration further down, which only gets
# one shot per version bump). See Known_Issues.md / 86e2nuxz5: EBMSLiveAgent
# had no recovery actions at all, and its uvicorn subprocess crashing left
# the service showing "Running" in Windows with nothing actually listening.
#
# EBMSLiveAgent also needs FAILURE_ACTIONS_ON_NONCRASH_FAILURES enabled for
# the restart actions above to actually fire -- live-verified 2026-08-07 on
# ErinTest that without it, its own crash handling (a clean SERVICE_STOPPED
# report with a nonzero exit code, not an unhandled process crash) is
# treated by Windows as a "non-crash failure," which sc.exe failure's
# restart actions ignore by default. With the flag set, the service
# actually restarted within ~7s of the child dying; without it, it stayed
# Stopped indefinitely. Scoped to EBMSLiveAgent only, not the tunnel service
# -- $CF_SERVICE_NAME runs cloudflared.exe directly with no wrapper reporting
# a clean stop, so it doesn't hit this same case, and this wasn't tested
# against it.
foreach ($svcName in @($AGENT_SERVICE, $CF_SERVICE_NAME)) {
    if (Get-Service $svcName -ErrorAction SilentlyContinue) {
        sc.exe failure $svcName reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    }
}
if (Get-Service $AGENT_SERVICE -ErrorAction SilentlyContinue) {
    sc.exe failureflag $AGENT_SERVICE 1 | Out-Null
}

# --- Ensure the IntraMind cloudflared tunnel service is actually running ---
# Deliberately placed here (before the version-check early return below), same
# reasoning as the crash-recovery backfill above: this must run every 6-hour
# cycle, not just on a cycle that happens to install a new version. It was
# previously placed later in this script, after the early return, so it only
# ever ran during an actual update -- meaning a tunnel stopped for any reason
# other than a crash (sc.exe failure only catches crashes, not e.g. a manual
# Stop-Service) stayed down until the next real version bump shipped, possibly
# weeks later. Found via a real incident on 2026-08-07. Ownership-verified via
# binPath first, same as the Cloudflared-name migration below -- never touch a
# service just because it has this name; see that block's own comment for the
# incident this protects against.
$svcInfo = Get-CimInstance Win32_Service -Filter "Name='$CF_SERVICE_NAME'" -ErrorAction SilentlyContinue
if ($svcInfo -and $svcInfo.PathName -like "*$CF_SYS_DIR*") {
    $cfSvc = Get-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue
    if ($cfSvc.Status -ne "Running") {
        Log "$CF_SERVICE_NAME was not running - starting it..."
        Start-Service $cfSvc.Name -ErrorAction SilentlyContinue
        Log "$CF_SERVICE_NAME started."
    }
} elseif ($svcInfo) {
    Warn "Service '$CF_SERVICE_NAME' exists but is not owned by IntraMind (binPath: $($svcInfo.PathName)). Not touching it."
} else {
    Warn "IntraMind's own cloudflared tunnel service not found - tunnel may be down."
}

# --- Read config from .env ---
$PORT = "8767"; $CHANNEL = "stable"
if (Test-Path "$DATA_DIR\.env") {
    foreach ($line in Get-Content "$DATA_DIR\.env") {
        if ($line -match "^EBMS_LIVE_PORT=(.+)$")    { $PORT    = $Matches[1].Trim() }
        if ($line -match "^EBMS_LIVE_CHANNEL=(.+)$") { $CHANNEL = $Matches[1].Trim().ToLower() }
    }
}
if (-not $MANIFEST_URLS.ContainsKey($CHANNEL)) {
    # Was silent before -- a box configured for a channel this copy of
    # update.ps1 doesn't know about (e.g. "main" on a box whose update.ps1
    # predates that channel existing) fell back to stable with zero trace
    # anywhere. Live-confirmed on ErinTest 2026-08-10 (86e2kj0kn): that
    # silent substitution combined with stable's real published version
    # being older than what was actually running made an unannounced
    # channel fallback look identical to a routine same-channel update,
    # and it took real debugging to even notice the channel had changed.
    Warn "Configured channel '$CHANNEL' is not recognized by this copy of update.ps1 (known: $($MANIFEST_URLS.Keys -join ', ')) -- falling back to stable. This usually means this box's update.ps1 is older than its configured channel; the fallback itself is intentional (a safe default), but if you didn't expect this channel to be unrecognized, update.ps1 on this box may be stale."
    $CHANNEL = "stable"
}
$MANIFEST_URL = $MANIFEST_URLS[$CHANNEL]
Log "Channel: $CHANNEL"

# --- Check current running version ---
$versionBefore = "unknown"
try {
    $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 5
    $versionBefore = ($resp.Content | ConvertFrom-Json).version
} catch {}

# --- Fetch manifest from latest release (no auth required) ---
$manifest = $null
try {
    $raw = Invoke-WebRequest -Uri $MANIFEST_URL -UseBasicParsing -TimeoutSec 15
    $manifest = $raw.Content | ConvertFrom-Json
} catch {
    Fail "Could not fetch update manifest from $MANIFEST_URL -- check network connection."
}

# Validate required fields before using them -- a manifest missing any of these
# (malformed publish, truncated response, etc.) must not reach an unguarded
# access below (e.g. $manifest.sha256.ToLower() on $null), which would throw
# an uncaught error and terminate the script before Fail()/Complete-AdminAction
# ever runs -- leaving $LOCK_FILE (the portal's in-flight indicator) wedged
# forever. See 86e2rrypb.
#
# Trust boundary note (86e2rrzga, documented not fixed -- Erin's 2026-08-20
# decision): this manifest is fetched over HTTPS (defends against network
# tampering) and the zip below is checksummed against this manifest's own
# sha256 (defends against a corrupted/incomplete download) -- but nothing here
# defends against a compromised GitHub account or repo pushing a malicious,
# internally-consistent manifest+zip pair together. Closing that gap would
# need manifest signing or full code-signing, both out of scope for now.
$missingFields = @()
foreach ($field in @("version", "zip_url", "sha256")) {
    if ([string]::IsNullOrEmpty($manifest.$field)) { $missingFields += $field }
}
if ($missingFields.Count -gt 0) {
    Fail "Manifest from $MANIFEST_URL is missing required field(s): $($missingFields -join ', ') -- aborting update."
}

$latestVersion = $manifest.version
$zipUrl        = $manifest.zip_url
$expectedSha   = $manifest.sha256
$whatsNew      = $manifest.whats_new

# The beta manifest tags versions as "x.y.z-beta", but /health reports the bare
# "x.y.z" from server.py. Strip any pre-release suffix from both sides before
# comparing so a beta box doesn't see itself as perpetually out of date and
# re-install (and restart the service) on every cycle.
#
# The main channel is different: its manifest version carries a commit-SHA
# build suffix ("x.y.z-main.<sha>") specifically so two pushes with an
# unchanged VERSION are still distinguishable -- but /health always reports
# the bare VERSION regardless of channel, so comparing against it the same
# way as beta/stable would make main-channel boxes install on literally every
# 6-hour cycle even when nothing changed (the manifest version never equals
# the bare /health version, since one always has a suffix and the other never
# does). So for a "-main." manifest version, compare the FULL string against
# the full manifest version this box last successfully installed (persisted
# to $INSTALLED_MANIFEST_VERSION_FILE below), not against /health's version.
if ($latestVersion -match '-main\.') {
    $installedManifestVersion = ""
    if (Test-Path $INSTALLED_MANIFEST_VERSION_FILE) {
        $installedManifestVersion = ([string](Get-Content $INSTALLED_MANIFEST_VERSION_FILE -Raw)).Trim()
    }
    if ($latestVersion -eq $installedManifestVersion) {
        Log "Already up to date (version $latestVersion) -- skipping."
        Complete-AdminAction -result "ok" -detail "Already up to date" -version $versionBefore
        exit 0
    }
} else {
    $latestCompare = ($latestVersion -split '-')[0]
    $beforeCompare = ($versionBefore -split '-')[0]

    if ($latestCompare -eq $beforeCompare) {
        Log "Already up to date (version $versionBefore) -- skipping."
        Complete-AdminAction -result "ok" -detail "Already up to date" -version $versionBefore
        exit 0
    }
}

Log "Updating: $versionBefore -> $latestVersion"

# --- Download release zip ---
$zipPath = "$env:TEMP\intramind-release.zip"
try {
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
    Log "Downloaded release zip."
} catch {
    Fail "Failed to download release zip from $zipUrl"
}

# --- Verify SHA256 checksum ---
$actualSha = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
if ($actualSha -ne $expectedSha.ToLower()) {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    Fail "Checksum mismatch. Expected: $expectedSha  Got: $actualSha -- aborting update."
}
Log "Checksum verified."

# --- Extract to a staging directory, not $INSTALL_DIR directly (see
# 86e2rrzj2). An interruption here (crash, power loss) only ever leaves an
# incomplete staging directory -- the current install is untouched until the
# atomic swap below. ---
$stagingDir = "$INSTALL_DIR.new"
if (Test-Path $stagingDir) {
    Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $stagingDir) {
        Fail "Could not remove stale staging directory $stagingDir -- manual cleanup needed before update can proceed."
    }
}
$zip = $null
try {
    New-Item -ItemType Directory -Path $stagingDir -Force -ErrorAction Stop | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    # Path-containment check (Zip Slip defense, see 86e2t0ft8/CR-3). Sibling
    # copies of this exact check live in install.ps1's extraction block and
    # onboarding/deploy.ps1's extraction block -- keep all three in sync if
    # this logic ever needs to change.
    $stagingDirFull = [System.IO.Path]::GetFullPath($stagingDir) + [System.IO.Path]::DirectorySeparatorChar
    foreach ($entry in $zip.Entries) {
        $destPath = Join-Path $stagingDir $entry.FullName
        $destPathFull = [System.IO.Path]::GetFullPath($destPath)
        if (-not $destPathFull.StartsWith($stagingDirFull, [System.StringComparison]::OrdinalIgnoreCase)) {
            Fail "Release zip entry '$($entry.FullName)' resolves outside the staging directory -- aborting extraction (possible Zip Slip)."
        }
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destPath, $true)
        Log "  Extracted $($entry.FullName)"
    }
    $zip.Dispose()
    $zip = $null
} catch {
    if ($zip) { $zip.Dispose() }
    Fail "Failed to extract release zip: $_"
} finally {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
}

# --- Write pending update notification for UI ---
$pending = @{ version = $latestVersion; whats_new = $whatsNew } | ConvertTo-Json -Compress
Set-Content "$DATA_DIR\pending_update.txt" $pending -NoNewline -ErrorAction SilentlyContinue
Log "Pending update notification written for version $latestVersion"

# --- Stop the agent service before swapping directories -- a directory
# rename while the service's process may still hold open file handles inside
# $INSTALL_DIR is the risk this avoids. Does not add net downtime versus the
# previous Restart-Service call, which already stopped-then-started the
# service; this just moves the stop earlier. See 86e2rrzj2. ---
Log "Stopping $AGENT_SERVICE for install swap..."
try {
    Stop-Service $AGENT_SERVICE -ErrorAction Stop
} catch {
    Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
    Fail "Failed to stop $AGENT_SERVICE before install swap: $_"
}

# --- Atomic swap: current install -> .previous (one-generation rollback
# backup, removed only when the NEXT successful swap needs the slot), staging
# -> current. If the swap partially fails, attempt to restore .previous so
# the machine is never left with neither a working $INSTALL_DIR nor a
# recoverable backup. See 86e2rrzj2. ---
try {
$previousDir = "$INSTALL_DIR.previous"
if (Test-Path $previousDir) {
    Remove-Item $previousDir -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $previousDir) {
        Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
        Fail "Could not remove stale $previousDir -- manual cleanup needed before update can proceed."
    }
}
try {
    Rename-DirectoryWithRetry -Path $INSTALL_DIR -NewName (Split-Path $previousDir -Leaf)
} catch {
    Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
    Fail "Failed to move current install to $previousDir before swap: $_"
}
try {
    Rename-DirectoryWithRetry -Path $stagingDir -NewName (Split-Path $INSTALL_DIR -Leaf)
} catch {
    Warn "Failed to swap staged install into place: $_ -- attempting to restore previous install."
    try {
        Rename-DirectoryWithRetry -Path $previousDir -NewName (Split-Path $INSTALL_DIR -Leaf)
        Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
        Fail "Swap failed; restored previous install. Update aborted."
    } catch {
        Fail "Swap failed AND could not restore previous install -- $INSTALL_DIR may be missing. Manual recovery needed. Restore-attempt error (the original swap error was logged above): $_"
    }
}
Log "Install directory swapped."

# --- Migrate legacy "Cloudflared" service name to "IntramindCloudServices" ---
# Renamed to avoid colliding with other Cloudflare Tunnel products (e.g. Koble)
# that use the default service name. install.ps1 does this migration on a fresh
# reinstall, but most customers only ever get auto-updated and never re-run the
# installer, so do it here too. NEVER touch a service just because it's named
# "Cloudflared": on a shared machine that name might belong to another product.
# Verify ownership by binPath first -- this runs unattended every 6 hours, so an
# unverified assumption here means silently deleting someone else's service on a
# schedule. See docs/cloudflared-tunnel-setup.md Troubleshooting for the
# 2026-07-16 mmp-ebms incident this check exists to prevent.
$legacyCfSvc = Get-CimInstance Win32_Service -Filter "Name='Cloudflared'" -ErrorAction SilentlyContinue
if ($legacyCfSvc -and $legacyCfSvc.PathName -like "*$CF_SYS_DIR*") {
    Log "Found legacy IntraMind 'Cloudflared' service - migrating to $CF_SERVICE_NAME..."
    $legacyBinPath = $legacyCfSvc.PathName
    $wasRunning = ($legacyCfSvc.State -eq "Running")
    Stop-Service "Cloudflared" -Force -ErrorAction SilentlyContinue
    sc.exe delete Cloudflared | Out-Null
    sc.exe create $CF_SERVICE_NAME binPath= $legacyBinPath start= auto DisplayName= "IntraMind Cloud Services" | Out-Null
    sc.exe failure $CF_SERVICE_NAME reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    if ($wasRunning) { Start-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue }
    Log "Migrated to $CF_SERVICE_NAME."
} elseif ($legacyCfSvc) {
    Warn "A 'Cloudflared' service exists but is not owned by IntraMind (binPath: $($legacyCfSvc.PathName)). Leaving it untouched."
}
} catch {
    # Catches only a genuinely unexpected, unhandled exception somewhere in
    # the swap/cloudflared-migration region above -- every existing Fail()
    # call site inside that region already exits directly (PowerShell's exit
    # bypasses catch blocks entirely) and is unaffected by this addition. See
    # 86e2rrzed: without this, an exception here (e.g. an unexpected
    # Get-CimInstance failure) would terminate the script with the agent left
    # stopped and no restart attempted, and Complete-AdminAction never called
    # (leaving the update lock wedged too).
    Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
    Fail "Unexpected failure during install swap: $_"
}

# --- Start agent service (already stopped above for the swap) ---
Log "Starting $AGENT_SERVICE..."
try {
    Start-Service $AGENT_SERVICE -ErrorAction Stop
    Log "Service started."
} catch {
    Invoke-Rollback "Failed to start $AGENT_SERVICE after swap: $_"
    # Invoke-Rollback already reports via Complete-AdminAction; exit here so
    # execution doesn't fall through into the version-verification block
    # below for a service that never started in the first place.
    exit 1
}

# --- Verify new version ---
Start-Sleep -Seconds 5
$versionAfter = "unknown"
for ($i = 0; $i -lt 10; $i++) {
    try {
        $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
        if ($resp.StatusCode -eq 200) {
            $versionAfter = ($resp.Content | ConvertFrom-Json).version
            break
        }
    } catch {}
    Start-Sleep -Seconds 2
}

if ($versionAfter -eq "unknown") {
    Invoke-Rollback "Update to $latestVersion failed verification"
} else {
    Log "Update complete. Version: $versionAfter"
    Set-Content -Path $INSTALLED_MANIFEST_VERSION_FILE -Value $latestVersion -NoNewline
    Complete-AdminAction -result "ok" -detail $null -version $versionAfter
}
