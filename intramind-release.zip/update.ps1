# EBMS Live - pull latest release from GitHub and restart the server
# Runs automatically every 6 hours via Windows Task Scheduler (as SYSTEM).
# Can also be run manually as Administrator.

Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$ErrorActionPreference = "Stop"

# Move this process's own working directory off $INSTALL_DIR before doing
# anything else. If this script is launched by a process whose CWD is
# $INSTALL_DIR (e.g. the portal's admin/update launcher, which likely
# inherits the agent service's own working directory), Windows holds a
# directory handle that would block the rename-swap further down with a
# sharing violation -- deterministically, on that launch path.
# Set-Location alone does not move the actual process working directory;
# SetCurrentDirectory does. See 86e2rrzj2.
[System.IO.Directory]::SetCurrentDirectory($env:SystemRoot)
Set-Location $env:SystemRoot

$INSTALL_DIR   = "C:\Program Files\IntraMind"
$DATA_DIR      = "C:\ProgramData\IntraMind"
$AGENT_SERVICE = "EBMSLiveAgent"
$CF_SERVICE_NAME = "IntramindCloudServices"
$CF_SYS_DIR    = "C:\Windows\System32\config\systemprofile\.cloudflared"
$LOG_FILE           = "$DATA_DIR\update.log"
$TASK_NAME          = "IntraMindAutoUpdate"
$LOCK_FILE          = "$DATA_DIR\update.lock"
$RUN_LOCK_FILE      = "$DATA_DIR\update.running.lock"
$ADMIN_ACTION_FILE  = "$DATA_DIR\last_admin_action.json"
$INSTALLED_MANIFEST_VERSION_FILE = "$DATA_DIR\installed_manifest_version.txt"
# 86e2zbm5q: live-observed 2026-08-25 -- a directory rename during the
# atomic swap can neither succeed nor throw for 10+ minutes under real
# conditions (suspected but unconfirmed: an active antivirus real-time
# scan holding a handle open), well past what Rename-DirectoryWithRetry's
# own fast-failure-oriented retry loop expects. Generous relative to the
# sub-second normal case, bounded well short of "forever".
$RENAME_TIMEOUT_SECONDS = 90

# 86e2ykh2a: kept in sync by hand with install.ps1's and
# onboarding/deploy.ps1's own copies of this same dict, and with
# server.py's CHANNELS constant / portal/server.py's own MANIFEST_URLS --
# 4 copies total.
$MANIFEST_URLS = @{
    stable = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases/main/manifest.json"
    beta   = "https://raw.githubusercontent.com/ThatN3rd/intramind-releases-beta/main/manifest.json"
    main   = "https://raw.githubusercontent.com/Erin-LumetraSolutions/intramind-releases-main/main/manifest.json"
}

function Log($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Cyan
}
function Warn($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') WARNING: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Yellow
}
function Complete-AdminAction($result, $detail, $version) {
    # Records the outcome of this run (scheduled or portal-triggered) for the
    # IntraMind admin portal's /health poll to surface, and clears the
    # in-progress lock /admin/update creates before launching this script.
    # Every exit path below must go through this so a customer never gets
    # stuck locked out of a retry. See docs/superpowers/specs/
    # 2026-08-07-portal-remote-admin-design.md §4.
    #
    # Also releases $RUN_LOCK_FILE (this script's own mutual-exclusion lock,
    # see 86e2t0g09) -- safe unconditionally here because a run that lost the
    # lock-contention race exits before ever reaching Complete-AdminAction
    # (see the acquire-or-exit block near the top of the script), so by the
    # time this function runs, this process is always the lock's true owner.
    Remove-Item -Path $LOCK_FILE -Force -ErrorAction SilentlyContinue
    Remove-Item -Path $RUN_LOCK_FILE -Force -ErrorAction SilentlyContinue
    $action = @{
        action  = "update"
        result  = $result
        detail  = $detail
        version = $version
        at      = (Get-Date).ToUniversalTime().ToString("yyyy-MM-ddTHH:mm:ssZ")
    } | ConvertTo-Json -Compress
    Set-Content -Path $ADMIN_ACTION_FILE -Value $action -NoNewline -Encoding utf8 -ErrorAction SilentlyContinue
}

# 86e2zr28u: orphan protection for Rename-DirectoryWithRetry's retry-child
# process, mirroring service.py's own 86e2z2u1b protection for the uvicorn
# child (JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE via pywin32 there). PowerShell
# has no pywin32 equivalent, so this is raw P/Invoke instead -- struct
# layouts and flag values were checked against service.py's own working
# win32job usage rather than freshly guessed. Declared once here at
# script scope (not inside the function) so it's defined once per run, not
# once per rename call; guarded with the same "-as [type]" idempotency
# check already used elsewhere in this file for Add-Type (this only
# prevents re-registration WITHIN one process -- update.ps1 is a fresh
# process every scheduled run, so this compiles fresh each run either way,
# same as the pre-existing System.IO.Compression.FileSystem Add-Type
# below).
#
# WRAPPED IN TRY/CATCH (independent review finding, 2026-08-26): Add-Type
# -MemberDefinition invokes the C# compiler as a real subprocess -- a far
# more fragile operation than a plain assembly load, and one this exact
# environment already has a documented plausible-AV-interference history
# with (86e2zbm5q). With $ErrorActionPreference = "Stop" active script-wide
# and no try/catch anywhere above this point, an unguarded failure here
# would abort the ENTIRE update run before Fail()/Complete-AdminAction()
# ever executes -- invisible to both agent.log and the portal, and
# defeating this whole feature's own "best-effort, never blocks the
# rename" design intent by blocking far more than just the rename. Placed
# here (after Warn() is defined, not at the very top of the script) so
# this catch block can actually call it -- PowerShell does not hoist
# function definitions, confirmed live: a Warn call from code positioned
# before Warn's own "function Warn" statement fails with
# "term not recognized," even though it's within the same script.
try {
    if (-not ("IntraMind.Native.JobObject" -as [type])) {
        Add-Type -Namespace IntraMind.Native -Name JobObject -MemberDefinition @'
[StructLayout(LayoutKind.Sequential)]
public struct JOBOBJECT_BASIC_LIMIT_INFORMATION {
    public Int64 PerProcessUserTimeLimit;
    public Int64 PerJobUserTimeLimit;
    public UInt32 LimitFlags;
    public UIntPtr MinimumWorkingSetSize;
    public UIntPtr MaximumWorkingSetSize;
    public UInt32 ActiveProcessLimit;
    public UIntPtr Affinity;
    public UInt32 PriorityClass;
    public UInt32 SchedulingClass;
}

[StructLayout(LayoutKind.Sequential)]
public struct IO_COUNTERS {
    public UInt64 ReadOperationCount;
    public UInt64 WriteOperationCount;
    public UInt64 OtherOperationCount;
    public UInt64 ReadTransferCount;
    public UInt64 WriteTransferCount;
    public UInt64 OtherTransferCount;
}

[StructLayout(LayoutKind.Sequential)]
public struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION {
    public JOBOBJECT_BASIC_LIMIT_INFORMATION BasicLimitInformation;
    public IO_COUNTERS IoInfo;
    public UIntPtr ProcessMemoryLimit;
    public UIntPtr JobMemoryLimit;
    public UIntPtr PeakProcessMemoryUsed;
    public UIntPtr PeakJobMemoryUsed;
}

public const uint JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE = 0x00002000;
public const int JobObjectExtendedLimitInformation = 9;

[DllImport("kernel32.dll", SetLastError = true, CharSet = CharSet.Unicode)]
public static extern IntPtr CreateJobObject(IntPtr lpJobAttributes, string lpName);

[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool SetInformationJobObject(IntPtr hJob, int JobObjectInfoClass, ref JOBOBJECT_EXTENDED_LIMIT_INFORMATION lpJobObjectInfo, uint cbJobObjectInfoLength);

[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool AssignProcessToJobObject(IntPtr hJob, IntPtr hProcess);

[DllImport("kernel32.dll", SetLastError = true)]
public static extern bool CloseHandle(IntPtr hObject);
'@
    }
} catch {
    # Best-effort, matching the design's own stated philosophy: if the
    # type can't be registered at all, Rename-DirectoryWithRetry's own
    # existing "-as [type]" check inside its job-binding try/catch simply
    # never finds it and skips job-object protection entirely -- the
    # rename itself is completely unaffected either way.
    Warn "Could not register the IntraMind.Native.JobObject P/Invoke type ($_) -- rename retry-child orphan protection (86e2zr28u) will be unavailable this run, rename itself unaffected."
}

function Rename-DirectoryWithRetry($Path, $NewName, $Attempts = 3, $DelaySeconds = 2, $TimeoutSeconds = $RENAME_TIMEOUT_SECONDS) {
    # A directory rename can transiently fail right after Stop-Service
    # returns (Windows can report STOPPED slightly before all file handles
    # are released). A short retry absorbs that instead of aborting the
    # update over a race that resolves itself within a couple seconds.
    # See 86e2rrzj2.
    #
    # Defined up here (moved from mid-script in round 2 of 86e2rrzj2) so the
    # crash-recovery block below -- which runs before the extraction/swap
    # logic that originally motivated this helper -- can use it too, instead
    # of a bare unretried Rename-Item.
    #
    # 86e2zbm5q: the retry loop above only protects against a FAST-failing
    # sharing violation -- the case it was designed for. A live incident
    # (2026-08-25) showed Rename-Item can also simply hang, neither
    # succeeding nor throwing, for 10+ minutes under real conditions
    # (suspected but unconfirmed cause: an active antivirus real-time scan
    # holding a handle open). Without a hard ceiling on that, this function
    # -- and the live service it's usually mid-updating -- can be stuck
    # forever with nothing to report anywhere.
    #
    # CORRECTION 2026-08-26: the first fix here used a Start-Job background
    # job for the wall-clock timeout. That worked in every interactive test
    # but is broken in this script's REAL execution context -- a child of
    # the LocalSystem EBMSLiveAgent service, no console/desktop session.
    # Live-confirmed twice on ErinTest: Start-Job threw "No process is on
    # the other end of the pipe" (0xE9, "...while getting console output
    # buffer information") -- PowerShell's job infrastructure talks to a
    # console host to stream job output, which doesn't exist in a
    # non-interactive session. Worse than merely failing: the underlying
    # rename had ALREADY SUCCEEDED both times this fired, so the Start-Job
    # error made this function report a successful rename as a failure,
    # which fed wrong information into every caller's own recovery logic
    # and once left $INSTALL_DIR renamed away with nothing put back.
    #
    # Replaced with System.Diagnostics.Process (a real child process,
    # started via CreateProcess with UseShellExecute=$false and
    # CreateNoWindow=$true) instead of a PowerShell job. This is the same
    # console-free spawn mechanism Windows services use to launch child
    # processes in the first place (service.py's own subprocess.Popen call
    # for the uvicorn child works the same way, non-interactively, right
    # now) -- it never touches a console output buffer, so it doesn't hit
    # Start-Job's failure mode. The retry loop itself runs in that child
    # (via a temp .ps1 file, so $Path/$NewName never need to survive
    # command-line quoting through -Command/-EncodedCommand argument
    # binding) and reports its outcome back through a small JSON result
    # file rather than a job's own output stream, since that stream is
    # exactly what was unreliable here. Process.WaitForExit(ms) bounds the
    # wait; Process.Kill() on timeout force-terminates the child the same
    # way Stop-Job did -- confirmed to still work on a genuinely separate
    # OS process, not merely abandon a thread still holding the real lock.
    #
    # 86e2zr28u: the child is now bound to a kill-on-close Job Object (see
    # the IntraMind.Native.JobObject Add-Type block just above this
    # function), the same protection service.py gives the uvicorn child
    # (86e2z2u1b/86e2zk7p3). If THIS process (update.ps1 itself) is killed
    # externally while the child is still inside Rename-Item, the OS
    # closing this process's job handle now kills the child with it
    # instead of leaving it to complete the rename as an orphan at an
    # arbitrary later time -- for the window AFTER AssignProcessToJobObject
    # has actually run. Best-effort, not airtight: a job-object setup
    # failure (or the narrow gap between Process.Start() and the
    # assignment call a few lines below, before the child is bound yet)
    # Warn()s and continues without this protection rather than blocking
    # the rename itself -- this is defense-in-depth, not a new hard
    # dependency, and does not fully close the startup-window race. Closing
    # that fully would need CREATE_SUSPENDED + assign + ResumeThread
    # instead of an immediately-running Process.Start(), out of scope here.
    #
    # Defensive guard: $Path/$NewName get wrapped in double quotes below to
    # build the child's command line. An embedded '"' or a trailing '\'
    # right before that closing quote would corrupt Win32 argument
    # parsing -- neither occurs in any of this script's own real call
    # sites today, but fail loudly rather than silently mis-parsing if a
    # future caller ever passes one.
    foreach ($v in @($Path, $NewName)) {
        if ($v -match '"') {
            throw "Rename-DirectoryWithRetry: '$v' contains a double-quote character, which this function cannot safely pass to its retry child process."
        }
        if ($v.EndsWith('\')) {
            throw "Rename-DirectoryWithRetry: '$v' ends with a backslash, which would corrupt Win32 argument quoting when passed to this function's retry child process."
        }
    }

    $tempDir = [System.IO.Path]::GetTempPath()
    $guid = [Guid]::NewGuid().ToString('N')
    $scriptFile = Join-Path $tempDir "rename_retry_$guid.ps1"
    $resultFile = Join-Path $tempDir "rename_retry_$guid.json"
    # Single-quoted here-string: no variable interpolation, so $Path/
    # $NewName never touch this script's own text -- they're bound as real
    # parameters via -File below instead, so nothing about their content
    # (spaces, quotes, whatever) can corrupt the script being run.
    $innerScript = @'
param(
    [Parameter(Mandatory)][string]$Path,
    [Parameter(Mandatory)][string]$NewName,
    [Parameter(Mandatory)][int]$Attempts,
    [Parameter(Mandatory)][int]$DelaySeconds,
    [Parameter(Mandatory)][string]$ResultFile
)
$result = @{ ok = $false; error = $null }
for ($i = 1; $i -le $Attempts; $i++) {
    try {
        Rename-Item -Path $Path -NewName $NewName -ErrorAction Stop
        $result.ok = $true
        break
    } catch {
        if ($i -eq $Attempts) {
            $result.error = $_.Exception.Message
        } else {
            Start-Sleep -Seconds $DelaySeconds
        }
    }
}
($result | ConvertTo-Json -Compress) | Set-Content -LiteralPath $ResultFile -Encoding UTF8
'@

    # Declared before the try block (not just inside it) so the finally
    # block below can always safely check it, even if an exception is
    # thrown before Process.Start() itself is reached.
    $hJob = [IntPtr]::Zero
    try {
        Set-Content -LiteralPath $scriptFile -Value $innerScript -Encoding UTF8

        $psi = New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName = "powershell.exe"
        $psi.Arguments = '-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "{0}" -Path "{1}" -NewName "{2}" -Attempts {3} -DelaySeconds {4} -ResultFile "{5}"' -f `
            $scriptFile, $Path, $NewName, $Attempts, $DelaySeconds, $resultFile
        $psi.UseShellExecute = $false
        $psi.CreateNoWindow = $true

        $proc = [System.Diagnostics.Process]::Start($psi)

        # 86e2zr28u: best-effort job-object binding so this child can't
        # outlive update.ps1 itself as an orphan. Never blocks the rename
        # on failure -- Warn() and continue unprotected instead.
        $hJob = [IntPtr]::Zero
        try {
            $hJob = [IntraMind.Native.JobObject]::CreateJobObject([IntPtr]::Zero, $null)
            if ($hJob -ne [IntPtr]::Zero) {
                # Build the nested BasicLimitInformation substruct as its own
                # local variable and assign the WHOLE substruct to
                # $limitInfo.BasicLimitInformation, rather than drilling
                # straight into "$limitInfo.BasicLimitInformation.LimitFlags =
                # ...". Live-verified 2026-08-26: the drill-through form
                # silently discards the write -- PowerShell's property-get on
                # a nested value-type field returns a COPY, so setting
                # .LimitFlags on that temporary copy never reaches the real
                # $limitInfo. SetInformationJobObject/AssignProcessToJobObject
                # both still report success either way (nothing about the
                # call itself is wrong), so this failed completely silently:
                # the job object gets created and the child gets assigned to
                # it, but with LimitFlags=0 -- no limits configured at all --
                # so closing the job handle never kills anything. Confirmed
                # via QueryInformationJobObject read-back and an end-to-end
                # CloseHandle test both ways before and after this fix.
                $basicLimit = New-Object IntraMind.Native.JobObject+JOBOBJECT_BASIC_LIMIT_INFORMATION
                $basicLimit.LimitFlags = [IntraMind.Native.JobObject]::JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                $limitInfo = New-Object IntraMind.Native.JobObject+JOBOBJECT_EXTENDED_LIMIT_INFORMATION
                $limitInfo.BasicLimitInformation = $basicLimit
                $infoSize = [System.Runtime.InteropServices.Marshal]::SizeOf($limitInfo)
                $setOk = [IntraMind.Native.JobObject]::SetInformationJobObject($hJob, [IntraMind.Native.JobObject]::JobObjectExtendedLimitInformation, [ref]$limitInfo, $infoSize)
                if ($setOk) {
                    $assignOk = [IntraMind.Native.JobObject]::AssignProcessToJobObject($hJob, $proc.Handle)
                    if (-not $assignOk) {
                        Warn "Rename-DirectoryWithRetry: could not bind retry-child process to a kill-on-close Job Object (AssignProcessToJobObject failed, Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- continuing without orphan protection (86e2zr28u)."
                    }
                } else {
                    Warn "Rename-DirectoryWithRetry: could not configure kill-on-close Job Object limits (Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- continuing without orphan protection (86e2zr28u)."
                }
            } else {
                # Independent review finding, 2026-08-26: this was the one
                # silent failure branch in this block -- every other
                # failure (SetInformationJobObject, AssignProcessToJobObject)
                # already Warned; CreateJobObject failing left no trace at
                # all in a file whose entire recent incident history is
                # about invisible failures.
                Warn "Rename-DirectoryWithRetry: CreateJobObject failed (Win32 error $([Runtime.InteropServices.Marshal]::GetLastWin32Error())) -- continuing without orphan protection (86e2zr28u)."
            }
        } catch {
            Warn "Rename-DirectoryWithRetry: Job Object setup threw ($_) -- continuing without orphan protection (86e2zr28u)."
        }

        $exited = $proc.WaitForExit($TimeoutSeconds * 1000)

        if (-not $exited -and (Test-Path -LiteralPath $resultFile)) {
            # The child had already written its result and was in the
            # process of exiting right at the timeout boundary -- give it
            # a brief grace window instead of killing it and discarding a
            # real result. A narrower version of exactly the "successful
            # rename misreported as failed" bug this replaced Start-Job
            # for would be no improvement at all.
            $exited = $proc.WaitForExit(3000)
        }

        if (-not $exited) {
            try {
                $proc.Kill()
                $proc.WaitForExit(5000) | Out-Null
            } catch {
                Warn "Rename-DirectoryWithRetry: failed to terminate timed-out child process (PID $($proc.Id)): $_"
            }
            throw "Rename of '$Path' to '$NewName' timed out after $TimeoutSeconds seconds -- the operation neither completed nor failed within the timeout (see 86e2zbm5q)."
        }

        if (-not (Test-Path -LiteralPath $resultFile)) {
            throw "Rename of '$Path' to '$NewName' failed: the retry-attempt child process exited (code $($proc.ExitCode)) without writing a result -- treating as failed rather than assuming success."
        }

        $result = Get-Content -LiteralPath $resultFile -Raw | ConvertFrom-Json
        if (-not $result.ok) {
            throw "Rename of '$Path' to '$NewName' failed: $($result.error)"
        }
    } finally {
        # 86e2zr28u: close the job handle once the rename has either
        # completed or been abandoned via timeout+Kill() above. This does
        # not affect an already-exited/already-killed child -- it just
        # releases this process's own reference to the job object.
        if ($hJob -ne [IntPtr]::Zero) {
            [IntraMind.Native.JobObject]::CloseHandle($hJob) | Out-Null
        }
        Remove-Item -LiteralPath $scriptFile -Force -ErrorAction SilentlyContinue
        Remove-Item -LiteralPath $resultFile -Force -ErrorAction SilentlyContinue
    }
}

function Invoke-Rollback($Reason) {
    # Restores $previousDir into $INSTALL_DIR after a failed post-swap
    # service start or failed version verification. Renames the broken tree
    # aside first rather than deleting it outright, so a failed delete never
    # leaves $INSTALL_DIR completely gone -- and re-verifies the restored
    # version actually responds before reporting success rather than
    # asserting it blindly. See 86e2rrzj2.
    #
    # Round 2 (2026-08-20): the outer catch below deliberately does NOT
    # attempt a blind Start-Service on its own rename failure. Tracing both
    # possible failure points shows neither leaves anything worth starting
    # under $INSTALL_DIR's real name:
    #   - If the FIRST rename (move the broken $INSTALL_DIR aside to
    #     .failed) is what throws, the rename never happened, so
    #     $INSTALL_DIR still exists -- but it still holds the BROKEN build
    #     that triggered this rollback in the first place. Starting the
    #     service here would just run the broken version; that is not a
    #     recovery, it actively hides the failure.
    #   - If the SECOND rename (restore .previous into $INSTALL_DIR) is what
    #     throws, the first rename already succeeded, so $INSTALL_DIR does
    #     not exist under that name at all. There is nothing there to
    #     start.
    # Either way a Start-Service call in the catch can't help, so the fix is
    # a stage-specific error message that says exactly which directory holds
    # which version and what manual step restores service.
    Warn "$Reason -- rolling back to previous install."
    $failedDir = "$INSTALL_DIR.failed"
    if (Test-Path $failedDir) {
        Remove-Item $failedDir -Recurse -Force -ErrorAction SilentlyContinue
        if (Test-Path $failedDir) {
            # Best-effort stop before bailing out: whichever call site got us
            # here, $INSTALL_DIR currently holds the version that triggered
            # this rollback (either the swap's new build that failed to
            # start, or one that started but never verified) -- don't leave
            # it silently running while reporting an error that needs manual
            # attention.
            Stop-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
            Fail "$Reason -- AND could not remove stale $failedDir before attempting rollback -- manual cleanup of $failedDir needed before rollback can proceed. $AGENT_SERVICE has been stopped as a precaution; $INSTALL_DIR still holds the version that triggered this rollback -- do not start the service again until that is manually confirmed safe."
        }
    }
    $renameStage = $null
    try {
        Stop-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
        $renameStage = "move-broken-aside"
        Rename-DirectoryWithRetry -Path $INSTALL_DIR -NewName (Split-Path $failedDir -Leaf)
        $renameStage = "restore-previous"
        Rename-DirectoryWithRetry -Path $previousDir -NewName (Split-Path $INSTALL_DIR -Leaf)
        $renameStage = $null
        $started = $false
        try {
            Start-Service $AGENT_SERVICE -ErrorAction Stop
            $started = $true
        } catch {
            Warn "Rollback: restored $INSTALL_DIR to the previous version but failed to start $AGENT_SERVICE`: $_"
        }
        $rollbackVerified = $false
        if ($started) {
            Start-Sleep -Seconds 5
            for ($i = 0; $i -lt 10; $i++) {
                try {
                    $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
                    if ($resp.StatusCode -eq 200) { $rollbackVerified = $true; break }
                } catch {}
                Start-Sleep -Seconds 2
            }
        }
        Remove-Item $failedDir -Recurse -Force -ErrorAction SilentlyContinue
        if ($rollbackVerified) {
            Complete-AdminAction -result "error" -detail "$Reason -- rolled back to previous install ($versionBefore) and confirmed it is responding." -version $versionBefore
        } else {
            Complete-AdminAction -result "error" -detail "$Reason -- rolled back to previous install ($versionBefore) but could not confirm it is responding afterward. Manual check needed." -version $versionBefore
        }
    } catch {
        if ($renameStage -eq "move-broken-aside") {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed while moving the failed install aside: $_ -- $INSTALL_DIR still holds the BROKEN version that triggered this rollback, and no start was attempted (starting it would just run the broken build). $previousDir still holds the last known-good version, untouched. Manual recovery once whatever is locking $INSTALL_DIR clears: move or remove $INSTALL_DIR, rename $previousDir to $INSTALL_DIR, then start $AGENT_SERVICE." -version $null
        } elseif ($renameStage -eq "restore-previous") {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed while restoring the previous install: $_ -- $INSTALL_DIR does not currently exist (the broken build was already moved aside to $failedDir); $previousDir still holds the last known-good version under its own name. Manual recovery: rename $previousDir to $INSTALL_DIR and start $AGENT_SERVICE." -version $null
        } else {
            Complete-AdminAction -result "error" -detail "$Reason -- AND rollback also failed: $_ -- manual intervention needed." -version $null
        }
    }
}
function Fail($msg) {
    $line = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ERROR: $msg"
    Add-Content -Path $LOG_FILE -Value $line -ErrorAction SilentlyContinue
    Write-Host $line -ForegroundColor Red
    Complete-AdminAction -result "error" -detail $msg -version $null
    exit 1
}

Log "EBMS Live Updater starting"

# --- Mutual-exclusion: prevent a scheduled run and a portal-triggered run (or
# two scheduled runs somehow overlapping) from executing concurrently and
# colliding on the shared $zipPath download further down. Distinct from
# $LOCK_FILE above, which is the portal's own "one admin action in flight" UI
# signal, not a real mutex -- this script never checked it, and a concurrent
# run could still race on the same temp zip file. See 86e2t0g09/CR-14.
if (Test-Path $RUN_LOCK_FILE) {
    # 86e2rrypb re-fix: the previous [string](...) cast does NOT protect against a crash here.
    # Live-verified on PowerShell 5.1.26100: Get-Content -Raw on a genuine 0-byte file returns
    # $null, and [string]$null-via-a-variable stays $null (unlike the literal token [string]$null,
    # which PowerShell special-cases to "") -- so .Trim() on the cast result still throws
    # "You cannot call a method on a null-valued expression." An explicit null check, not a cast,
    # is what actually works.
    $rawLockContent = Get-Content $RUN_LOCK_FILE -Raw -ErrorAction SilentlyContinue
    if ($null -eq $rawLockContent) { $rawLockContent = "" }
    $existingPid = $rawLockContent.Trim()
    $stillRunning = $false
    # Only check the process if $existingPid is a valid positive integer (guards against
    # "0" being permanently truthy and non-numeric content causing ParameterBindingException)
    if ($existingPid -match '^\d+$' -and [int]$existingPid -gt 0) {
        $stillRunning = [bool](Get-Process -Id ([int]$existingPid) -ErrorAction SilentlyContinue)
    }
    if ($stillRunning) {
        # Another run owns this lock and is still in progress. This is
        # expected coordination, not a failure -- exit immediately WITHOUT
        # calling Fail() or Complete-AdminAction, and without touching either
        # lock file, both of which may belong to the still-running other run.
        Log "Another update run (PID $existingPid) is already in progress -- exiting."
        exit 0
    }
    # Message distinguishes empty/corrupt lock from stale PID
    if ($existingPid) {
        Warn "Found a stale $RUN_LOCK_FILE from PID $existingPid, which is no longer running -- a prior run likely crashed without cleaning up. Proceeding."
    } else {
        Warn "Found an empty or corrupt $RUN_LOCK_FILE -- a prior run likely crashed without cleaning up. Proceeding."
    }
}
Set-Content -Path $RUN_LOCK_FILE -Value $PID -NoNewline -ErrorAction SilentlyContinue

# 86e2zr28u: sweep leftover Rename-DirectoryWithRetry temp files from a
# crashed prior run. Normally these are removed by that function's own
# finally block, but a run that died before reaching finally (or whose
# retry-child was itself killed via the job-object protection above,
# mid-write) can leave one behind. One hour is generous relative to
# $RENAME_TIMEOUT_SECONDS (90s) -- anything older than that is definitely
# stale, not just a slow in-progress rename. Best-effort: never let this
# sweep block the update itself.
try {
    $staleCutoff = (Get-Date).AddHours(-1)
    Get-ChildItem -Path ([System.IO.Path]::GetTempPath()) -Filter "rename_retry_*" -File -ErrorAction SilentlyContinue |
        Where-Object { $_.LastWriteTime -lt $staleCutoff } |
        ForEach-Object {
            Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue
            Log "Swept stale leftover temp file from a crashed prior run: $($_.FullName)"
        }
} catch {
    Warn "Stale rename_retry_* temp-file sweep failed (non-fatal): $_"
}

# --- Crash recovery: detect an interrupted prior swap (86e2rrzj2) ---
# If a prior run died between the two renames in the swap step further
# down, $INSTALL_DIR won't exist but $INSTALL_DIR.previous (the last
# known-good version) will. Recover it before doing anything else --
# otherwise this run's own swap step would delete .previous (the only
# surviving copy) without ever checking whether it's actually needed.
$previousDirCheck = "$INSTALL_DIR.previous"
if (-not (Test-Path $INSTALL_DIR) -and (Test-Path $previousDirCheck)) {
    Warn "$INSTALL_DIR is missing but $previousDirCheck exists -- recovering from an interrupted prior update."
    try {
        Rename-DirectoryWithRetry -Path $previousDirCheck -NewName (Split-Path $INSTALL_DIR -Leaf)
        Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
        Fail "Recovered $INSTALL_DIR from $previousDirCheck after an interrupted prior update. Aborting this run -- the next scheduled cycle will retry the actual update."
    } catch {
        Fail "CRITICAL: $INSTALL_DIR is missing and could not be recovered from $previousDirCheck`: $_. Manual recovery needed immediately."
    }
} elseif (-not (Test-Path $INSTALL_DIR)) {
    Fail "CRITICAL: $INSTALL_DIR is missing and $previousDirCheck does not exist either -- there is no install to recover from on this box (86e2x7m06). Manual reinstall needed immediately."
}

# --- Register scheduled task if not already present ---
$task = Get-ScheduledTask -TaskName $TASK_NAME -ErrorAction SilentlyContinue
if (-not $task) {
    Log "Registering auto-update scheduled task (every 6 hours)..."
    try {
        $action    = New-ScheduledTaskAction -Execute "powershell.exe" `
                       -Argument "-NonInteractive -ExecutionPolicy Bypass -File `"$INSTALL_DIR\update.ps1`""
        $trigger   = New-ScheduledTaskTrigger -RepetitionInterval (New-TimeSpan -Hours 6) -Once -At "00:00"
        $principal = New-ScheduledTaskPrincipal -UserId "SYSTEM" -RunLevel Highest
        $settings  = New-ScheduledTaskSettingsSet -ExecutionTimeLimit (New-TimeSpan -Minutes 10) `
                       -StartWhenAvailable -MultipleInstances IgnoreNew
        Register-ScheduledTask -TaskName $TASK_NAME -Action $action -Trigger $trigger `
            -Principal $principal -Settings $settings -Force | Out-Null
        Log "Scheduled task registered."
    } catch {
        Fail "Failed to register scheduled task: $_"
    }
}

# --- Ensure both services have crash-recovery actions configured ---
# Backfill for machines whose services were registered before this was added
# to install.ps1/deploy.ps1 -- idempotent and cheap, so this runs every
# 6-hour cycle (deliberately placed before the version-check early return
# below, unlike the Cloudflared-name migration further down, which only gets
# one shot per version bump). See Known_Issues.md / 86e2nuxz5: EBMSLiveAgent
# had no recovery actions at all, and its uvicorn subprocess crashing left
# the service showing "Running" in Windows with nothing actually listening.
#
# EBMSLiveAgent also needs FAILURE_ACTIONS_ON_NONCRASH_FAILURES enabled for
# the restart actions above to actually fire -- live-verified 2026-08-07 on
# ErinTest that without it, its own crash handling (a clean SERVICE_STOPPED
# report with a nonzero exit code, not an unhandled process crash) is
# treated by Windows as a "non-crash failure," which sc.exe failure's
# restart actions ignore by default. With the flag set, the service
# actually restarted within ~7s of the child dying; without it, it stayed
# Stopped indefinitely. Scoped to EBMSLiveAgent only, not the tunnel service
# -- $CF_SERVICE_NAME runs cloudflared.exe directly with no wrapper reporting
# a clean stop, so it doesn't hit this same case, and this wasn't tested
# against it.
foreach ($svcName in @($AGENT_SERVICE, $CF_SERVICE_NAME)) {
    if (Get-Service $svcName -ErrorAction SilentlyContinue) {
        sc.exe failure $svcName reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    }
}
if (Get-Service $AGENT_SERVICE -ErrorAction SilentlyContinue) {
    sc.exe failureflag $AGENT_SERVICE 1 | Out-Null
}

# --- Ensure the IntraMind cloudflared tunnel service is actually running ---
# Deliberately placed here (before the version-check early return below), same
# reasoning as the crash-recovery backfill above: this must run every 6-hour
# cycle, not just on a cycle that happens to install a new version. It was
# previously placed later in this script, after the early return, so it only
# ever ran during an actual update -- meaning a tunnel stopped for any reason
# other than a crash (sc.exe failure only catches crashes, not e.g. a manual
# Stop-Service) stayed down until the next real version bump shipped, possibly
# weeks later. Found via a real incident on 2026-08-07. Ownership-verified via
# binPath first, same as the Cloudflared-name migration below -- never touch a
# service just because it has this name; see that block's own comment for the
# incident this protects against.
$svcInfo = Get-CimInstance Win32_Service -Filter "Name='$CF_SERVICE_NAME'" -ErrorAction SilentlyContinue
if ($svcInfo -and $svcInfo.PathName -like "*$CF_SYS_DIR*") {
    $cfSvc = Get-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue
    if ($cfSvc.Status -ne "Running") {
        Log "$CF_SERVICE_NAME was not running - starting it..."
        Start-Service $cfSvc.Name -ErrorAction SilentlyContinue
        Log "$CF_SERVICE_NAME started."
    }
} elseif ($svcInfo) {
    Warn "Service '$CF_SERVICE_NAME' exists but is not owned by IntraMind (binPath: $($svcInfo.PathName)). Not touching it."
} else {
    Warn "IntraMind's own cloudflared tunnel service not found - tunnel may be down."
}

# --- Read config from .env ---
$PORT = "8767"; $CHANNEL = "stable"
if (Test-Path "$DATA_DIR\.env") {
    foreach ($line in Get-Content "$DATA_DIR\.env") {
        if ($line -match "^EBMS_LIVE_PORT=(.+)$")    { $PORT    = $Matches[1].Trim() }
        if ($line -match "^EBMS_LIVE_CHANNEL=(.+)$") { $CHANNEL = $Matches[1].Trim().ToLower() }
    }
}
if (-not $MANIFEST_URLS.ContainsKey($CHANNEL)) {
    # Was silent before -- a box configured for a channel this copy of
    # update.ps1 doesn't know about (e.g. "main" on a box whose update.ps1
    # predates that channel existing) fell back to stable with zero trace
    # anywhere. Live-confirmed on ErinTest 2026-08-10 (86e2kj0kn): that
    # silent substitution combined with stable's real published version
    # being older than what was actually running made an unannounced
    # channel fallback look identical to a routine same-channel update,
    # and it took real debugging to even notice the channel had changed.
    Warn "Configured channel '$CHANNEL' is not recognized by this copy of update.ps1 (known: $($MANIFEST_URLS.Keys -join ', ')) -- falling back to stable. This usually means this box's update.ps1 is older than its configured channel; the fallback itself is intentional (a safe default), but if you didn't expect this channel to be unrecognized, update.ps1 on this box may be stale."
    $CHANNEL = "stable"
}
$MANIFEST_URL = $MANIFEST_URLS[$CHANNEL]
Log "Channel: $CHANNEL"

# --- Check current running version ---
$versionBefore = "unknown"
try {
    $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 5
    $versionBefore = ($resp.Content | ConvertFrom-Json).version
} catch {}

# --- Fetch manifest from latest release (no auth required) ---
$manifest = $null
try {
    $raw = Invoke-WebRequest -Uri $MANIFEST_URL -UseBasicParsing -TimeoutSec 15
    $manifest = $raw.Content | ConvertFrom-Json
} catch {
    Fail "Could not fetch update manifest from $MANIFEST_URL -- check network connection."
}

# Validate required fields before using them -- a manifest missing any of these
# (malformed publish, truncated response, etc.) must not reach an unguarded
# access below (e.g. $manifest.sha256.ToLower() on $null), which would throw
# an uncaught error and terminate the script before Fail()/Complete-AdminAction
# ever runs -- leaving $LOCK_FILE (the portal's in-flight indicator) wedged
# forever. See 86e2rrypb.
#
# Trust boundary note (86e2rrzga, documented not fixed -- Erin's 2026-08-20
# decision): this manifest is fetched over HTTPS (defends against network
# tampering) and the zip below is checksummed against this manifest's own
# sha256 (defends against a corrupted/incomplete download) -- but nothing here
# defends against a compromised GitHub account or repo pushing a malicious,
# internally-consistent manifest+zip pair together. Closing that gap would
# need manifest signing or full code-signing, both out of scope for now.
$missingFields = @()
foreach ($field in @("version", "zip_url", "sha256")) {
    if ([string]::IsNullOrEmpty($manifest.$field)) { $missingFields += $field }
}
if ($missingFields.Count -gt 0) {
    Fail "Manifest from $MANIFEST_URL is missing required field(s): $($missingFields -join ', ') -- aborting update."
}

$latestVersion = $manifest.version
$zipUrl        = $manifest.zip_url
$expectedSha   = $manifest.sha256
$whatsNew      = $manifest.whats_new

# The beta manifest tags versions as "x.y.z-beta", but /health reports the bare
# "x.y.z" from server.py. Strip any pre-release suffix from both sides before
# comparing so a beta box doesn't see itself as perpetually out of date and
# re-install (and restart the service) on every cycle.
#
# The main channel is different: its manifest version carries a commit-SHA
# build suffix ("x.y.z-main.<sha>") specifically so two pushes with an
# unchanged VERSION are still distinguishable -- but /health always reports
# the bare VERSION regardless of channel, so comparing against it the same
# way as beta/stable would make main-channel boxes install on literally every
# 6-hour cycle even when nothing changed (the manifest version never equals
# the bare /health version, since one always has a suffix and the other never
# does). So for a "-main." manifest version, compare the FULL string against
# the full manifest version this box last successfully installed (persisted
# to $INSTALLED_MANIFEST_VERSION_FILE below), not against /health's version.
if ($latestVersion -match '-main\.') {
    $installedManifestVersion = ""
    if (Test-Path $INSTALLED_MANIFEST_VERSION_FILE) {
        # 86e2rrypb re-fix (same bug as the RUN_LOCK_FILE read above -- see that comment) +
        # 86e2x8m3p (this read was also missing -ErrorAction SilentlyContinue, unlike its sibling).
        $rawInstalledVersion = Get-Content $INSTALLED_MANIFEST_VERSION_FILE -Raw -ErrorAction SilentlyContinue
        if ($null -eq $rawInstalledVersion) { $rawInstalledVersion = "" }
        $installedManifestVersion = $rawInstalledVersion.Trim()
    }
    if ($latestVersion -eq $installedManifestVersion) {
        Log "Already up to date (version $latestVersion) -- skipping."
        Complete-AdminAction -result "ok" -detail "Already up to date" -version $versionBefore
        exit 0
    }
} else {
    $latestCompare = ($latestVersion -split '-')[0]
    $beforeCompare = ($versionBefore -split '-')[0]

    if ($latestCompare -eq $beforeCompare) {
        Log "Already up to date (version $versionBefore) -- skipping."
        Complete-AdminAction -result "ok" -detail "Already up to date" -version $versionBefore
        exit 0
    }
}

Log "Updating: $versionBefore -> $latestVersion"

# --- Download release zip ---
$zipPath = "$env:TEMP\intramind-release.zip"
try {
    Invoke-WebRequest -Uri $zipUrl -OutFile $zipPath -UseBasicParsing -TimeoutSec 120
    Log "Downloaded release zip."
} catch {
    Fail "Failed to download release zip from $zipUrl"
}

# --- Verify SHA256 checksum ---
$actualSha = (Get-FileHash -Path $zipPath -Algorithm SHA256).Hash.ToLower()
if ($actualSha -ne $expectedSha.ToLower()) {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
    Fail "Checksum mismatch. Expected: $expectedSha  Got: $actualSha -- aborting update."
}
Log "Checksum verified."

# --- Extract to a staging directory, not $INSTALL_DIR directly (see
# 86e2rrzj2). An interruption here (crash, power loss) only ever leaves an
# incomplete staging directory -- the current install is untouched until the
# atomic swap below. ---
$stagingDir = "$INSTALL_DIR.new"
if (Test-Path $stagingDir) {
    Remove-Item $stagingDir -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $stagingDir) {
        Fail "Could not remove stale staging directory $stagingDir -- manual cleanup needed before update can proceed."
    }
}
$zip = $null
try {
    New-Item -ItemType Directory -Path $stagingDir -Force -ErrorAction Stop | Out-Null
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $zip = [System.IO.Compression.ZipFile]::OpenRead($zipPath)
    # Path-containment check (Zip Slip defense, see 86e2t0ft8/CR-3). Sibling
    # copies of this exact check live in install.ps1's extraction block and
    # onboarding/deploy.ps1's extraction block -- keep all three in sync if
    # this logic ever needs to change.
    $stagingDirFull = [System.IO.Path]::GetFullPath($stagingDir) + [System.IO.Path]::DirectorySeparatorChar
    foreach ($entry in $zip.Entries) {
        $destPath = Join-Path $stagingDir $entry.FullName
        $destPathFull = [System.IO.Path]::GetFullPath($destPath)
        if (-not $destPathFull.StartsWith($stagingDirFull, [System.StringComparison]::OrdinalIgnoreCase)) {
            Fail "Release zip entry '$($entry.FullName)' resolves outside the staging directory -- aborting extraction (possible Zip Slip)."
        }
        [System.IO.Compression.ZipFileExtensions]::ExtractToFile($entry, $destPath, $true)
        Log "  Extracted $($entry.FullName)"
    }
    $zip.Dispose()
    $zip = $null
    # 86e2xypqk: install.ps1/migrate.ps1/deploy.ps1 harden $INSTALL_DIR's ACL via
    # Protect-SecretsDir(), but Rename-Item (the atomic swap below) does not carry a
    # directory's DACL/inheritance-protected flag along with it -- $stagingDir starts
    # with the plain default ACL Windows gives a new directory, and swapping it into
    # $INSTALL_DIR's place would silently un-harden the live install after every
    # update cycle. Apply the identical restriction here too, AFTER extraction
    # completes (not before -- live-verified this session that hardening first
    # breaks the extraction itself for any account other than SYSTEM/Administrators,
    # since the process doing the writing loses its own just-granted access), so the
    # extracted tree carries the hardened ACL into the swap. A real box that predates
    # this fix (or has only ever been updated, never re-installed/migrated, since)
    # was confirmed this session to show exactly the un-hardened state this closes.
    #
    # Deliberately Warn(), not Fail(), on a non-zero icacls exit code -- this script
    # runs unattended every 6 hours; aborting a customer's update over an ACL call
    # would be worse than the gap being closed (see 86e2xypqk's own explicit note).
    icacls $stagingDir /inheritance:r /grant:r "*S-1-5-18:(OI)(CI)F" "*S-1-5-32-544:(OI)(CI)F" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Warn "Could not fully apply permissions on $stagingDir (icacls exit code $LASTEXITCODE) -- proceeding with the update anyway; the swapped-in install may have a weaker ACL than intended. An Administrator can re-apply it later with icacls `"$INSTALL_DIR`" /inheritance:r /grant:r `"*S-1-5-18:(OI)(CI)F`" `"*S-1-5-32-544:(OI)(CI)F`"."
    }
} catch {
    if ($zip) { $zip.Dispose() }
    Fail "Failed to extract release zip: $_"
} finally {
    Remove-Item $zipPath -Force -ErrorAction SilentlyContinue
}

# --- Write pending update notification for UI ---
$pending = @{ version = $latestVersion; whats_new = $whatsNew } | ConvertTo-Json -Compress
Set-Content "$DATA_DIR\pending_update.txt" $pending -NoNewline -ErrorAction SilentlyContinue
Log "Pending update notification written for version $latestVersion"

# --- Stop the agent service before swapping directories -- a directory
# rename while the service's process may still hold open file handles inside
# $INSTALL_DIR is the risk this avoids. Does not add net downtime versus the
# previous Restart-Service call, which already stopped-then-started the
# service; this just moves the stop earlier. See 86e2rrzj2. ---
Log "Stopping $AGENT_SERVICE for install swap..."
try {
    Stop-Service $AGENT_SERVICE -ErrorAction Stop
} catch {
    Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
    Fail "Failed to stop $AGENT_SERVICE before install swap: $_"
}

# --- Atomic swap: current install -> .previous (one-generation rollback
# backup, removed only when the NEXT successful swap needs the slot), staging
# -> current. If the swap partially fails, attempt to restore .previous so
# the machine is never left with neither a working $INSTALL_DIR nor a
# recoverable backup. See 86e2rrzj2. ---
try {
$previousDir = "$INSTALL_DIR.previous"
if (Test-Path $previousDir) {
    Remove-Item $previousDir -Recurse -Force -ErrorAction SilentlyContinue
    if (Test-Path $previousDir) {
        Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
        Fail "Could not remove stale $previousDir -- manual cleanup needed before update can proceed."
    }
}
try {
    Rename-DirectoryWithRetry -Path $INSTALL_DIR -NewName (Split-Path $previousDir -Leaf)
} catch {
    Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
    Fail "Failed to move current install to $previousDir before swap: $_"
}
try {
    Rename-DirectoryWithRetry -Path $stagingDir -NewName (Split-Path $INSTALL_DIR -Leaf)
} catch {
    Warn "Failed to swap staged install into place: $_ -- attempting to restore previous install."
    try {
        Rename-DirectoryWithRetry -Path $previousDir -NewName (Split-Path $INSTALL_DIR -Leaf)
        Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
        Fail "Swap failed; restored previous install. Update aborted."
    } catch {
        Fail "Swap failed AND could not restore previous install -- $INSTALL_DIR may be missing. Manual recovery needed. Restore-attempt error (the original swap error was logged above): $_"
    }
}
Log "Install directory swapped."

# --- Migrate legacy "Cloudflared" service name to "IntramindCloudServices" ---
# Renamed to avoid colliding with other Cloudflare Tunnel products (e.g. Koble)
# that use the default service name. install.ps1 does this migration on a fresh
# reinstall, but most customers only ever get auto-updated and never re-run the
# installer, so do it here too. NEVER touch a service just because it's named
# "Cloudflared": on a shared machine that name might belong to another product.
# Verify ownership by binPath first -- this runs unattended every 6 hours, so an
# unverified assumption here means silently deleting someone else's service on a
# schedule. See docs/cloudflared-tunnel-setup.md Troubleshooting for the
# 2026-07-16 mmp-ebms incident this check exists to prevent.
$legacyCfSvc = Get-CimInstance Win32_Service -Filter "Name='Cloudflared'" -ErrorAction SilentlyContinue
if ($legacyCfSvc -and $legacyCfSvc.PathName -like "*$CF_SYS_DIR*") {
    Log "Found legacy IntraMind 'Cloudflared' service - migrating to $CF_SERVICE_NAME..."
    $legacyBinPath = $legacyCfSvc.PathName
    $wasRunning = ($legacyCfSvc.State -eq "Running")
    Stop-Service "Cloudflared" -Force -ErrorAction SilentlyContinue
    sc.exe delete Cloudflared | Out-Null
    $cfDeleteExit = $LASTEXITCODE
    if ($cfDeleteExit -ne 0) {
        Warn "sc.exe delete Cloudflared exited with code $cfDeleteExit during service migration -- attempting to create $CF_SERVICE_NAME anyway."
    }
    sc.exe create $CF_SERVICE_NAME binPath= $legacyBinPath start= auto DisplayName= "IntraMind Cloud Services" | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Fail "CRITICAL: cloudflared tunnel service migration failed -- 'Cloudflared' was deleted (sc.exe delete exit $cfDeleteExit) but sc.exe create $CF_SERVICE_NAME failed (exit $LASTEXITCODE). The tunnel service no longer exists on this box. Manual recovery: sc.exe create $CF_SERVICE_NAME binPath= `"$legacyBinPath`" start= auto DisplayName= `"IntraMind Cloud Services`""
    }
    sc.exe failure $CF_SERVICE_NAME reset= 86400 actions= restart/5000/restart/10000/restart/30000 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        Warn "sc.exe failure $CF_SERVICE_NAME (configuring auto-restart) exited with code $LASTEXITCODE -- service created but crash auto-restart may not be configured."
    }
    if ($wasRunning) { Start-Service $CF_SERVICE_NAME -ErrorAction SilentlyContinue }
    Log "Migrated to $CF_SERVICE_NAME."
} elseif ($legacyCfSvc) {
    Warn "A 'Cloudflared' service exists but is not owned by IntraMind (binPath: $($legacyCfSvc.PathName)). Leaving it untouched."
}
} catch {
    # Catches only a genuinely unexpected, unhandled exception somewhere in
    # the swap/cloudflared-migration region above -- every existing Fail()
    # call site inside that region already exits directly (PowerShell's exit
    # bypasses catch blocks entirely) and is unaffected by this addition. See
    # 86e2rrzed: without this, an exception here (e.g. an unexpected
    # Get-CimInstance failure) would terminate the script with the agent left
    # stopped and no restart attempted, and Complete-AdminAction never called
    # (leaving the update lock wedged too).
    Start-Service $AGENT_SERVICE -ErrorAction SilentlyContinue
    Fail "Unexpected failure during install swap: $_"
}

# --- Start agent service (already stopped above for the swap) ---
Log "Starting $AGENT_SERVICE..."
try {
    Start-Service $AGENT_SERVICE -ErrorAction Stop
    Log "Service started."
} catch {
    Invoke-Rollback "Failed to start $AGENT_SERVICE after swap: $_"
    # Invoke-Rollback already reports via Complete-AdminAction; exit here so
    # execution doesn't fall through into the version-verification block
    # below for a service that never started in the first place.
    exit 1
}

# --- Verify new version ---
Start-Sleep -Seconds 5
$versionAfter = "unknown"
for ($i = 0; $i -lt 10; $i++) {
    try {
        $resp = Invoke-WebRequest -Uri "http://localhost:$PORT/health" -UseBasicParsing -TimeoutSec 3
        if ($resp.StatusCode -eq 200) {
            $versionAfter = ($resp.Content | ConvertFrom-Json).version
            break
        }
    } catch {}
    Start-Sleep -Seconds 2
}

if ($versionAfter -eq "unknown") {
    Invoke-Rollback "Update to $latestVersion failed verification"
} else {
    Log "Update complete. Version: $versionAfter"
    Set-Content -Path $INSTALLED_MANIFEST_VERSION_FILE -Value $latestVersion -NoNewline
    Complete-AdminAction -result "ok" -detail $null -version $versionAfter
}
