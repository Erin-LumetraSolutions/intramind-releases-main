"""
EBMS Live Query Agent

FastAPI service that runs on the customer's Azure VM alongside their EBMS Postgres
instance. Accepts authenticated natural-language queries, uses Claude to generate
safe read-only SQL, executes against the local Postgres, and returns formatted results.

Exposed to intramind.ca via Cloudflare tunnel + bearer token auth.

Run: python ebms_live/server.py
"""

import os
import re
import json
import time
import secrets
import string
import subprocess
import logging
from datetime import datetime, timezone
from pathlib import Path
from contextlib import asynccontextmanager
from collections import OrderedDict
from threading import Lock
from logging.handlers import RotatingFileHandler

import psycopg
from psycopg.rows import dict_row
import anthropic
from fastapi import FastAPI, HTTPException, Depends, Security, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, ConfigDict
from dotenv import load_dotenv

load_dotenv(Path(r"C:\ProgramData\IntraMind\.env"))   # production (Windows service)
load_dotenv(Path(__file__).parent / ".env")           # dev / legacy fallback
load_dotenv(Path(__file__).parent.parent / ".env")    # dev fallback

VERSION = "1.5.6"

# 86e2wf5xb: server.py's own logging.basicConfig() is what actually timestamps every
# log.*() call in this file (see the commit message on a97f232 for the full trace of
# why log_config.json's own formatters don't reach the "ebms_live" logger). This ONLY
# works because log_config.json deliberately has no "root" key -- basicConfig() only
# installs a handler when the root logger doesn't already have one. If a future edit
# adds a "root" key to log_config.json, this call silently becomes a no-op and every
# timestamp in agent.log vanishes again with no error and no failing test. Don't add
# a "root" key to log_config.json without updating this comment and re-verifying.
#
# Also forces every logging.Formatter in this process (including uvicorn's
# DefaultFormatter/AccessFormatter, both of which subclass logging.Formatter and
# inherit its converter) onto UTC -- without this, agent.log's timestamps render local
# time while append_feedback()/log_query_error() both write UTC, a real correlation
# problem for the incident-timeline-reconstruction use case this ticket exists for.
logging.Formatter.converter = time.gmtime
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s:%(name)s:%(message)s")
log = logging.getLogger("ebms_live")

# Error log - captures failed queries for prompt improvement
_error_log = logging.getLogger("ebms_live.errors")
_error_log.setLevel(logging.WARNING)
try:
    _error_log_path = Path(__file__).parent / "query_errors.log"
    _error_handler = RotatingFileHandler(_error_log_path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    _error_handler.setLevel(logging.WARNING)
    _error_log.addHandler(_error_handler)
except OSError as e:
    logging.getLogger("ebms_live").warning(f"Could not open query_errors.log ({e}) — error logging disabled")

def log_query_error(question: str, sql: str, raw_response: str, error: str):
    _error_log.warning(json.dumps({
        "question": question,
        "sql": sql[:500] if sql else "",
        "raw_response": raw_response[:500] if raw_response else "",
        "error": error,
        "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }, ensure_ascii=False))

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

BEARER_TOKEN        = os.getenv("EBMS_LIVE_TOKEN")  # legacy, kept for non-auth health check compat
PORTAL_TOKEN        = os.getenv("EBMS_LIVE_PORTAL_TOKEN")  # secret shared with IntraMind admin portal
CHANNELS = {"stable", "beta", "main"}  # kept in sync by hand with update.ps1's $MANIFEST_URLS
                                 # keys and portal/server.py's MANIFEST_URLS keys -- see
                                 # docs/superpowers/specs/2026-08-07-portal-remote-admin-design.md §4
                                 # and docs/superpowers/specs/2026-08-10-main-channel-release-pipeline-scope.md.
_ENV_FILE_OVERRIDE = os.getenv("EBMS_LIVE_ENV_FILE_OVERRIDE")  # test-only; never set in production
_ENV_FILE_PATHS = [
    Path(r"C:\ProgramData\IntraMind\.env"),
    Path(__file__).parent / ".env",
    Path(__file__).parent.parent / ".env",
]

def _resolve_env_file() -> Path:
    """Pick which .env file /admin/channel edits. Mirrors the three candidate
    locations load_dotenv() already reads at startup (production ProgramData
    path, then the dev fallback next to this file, then the parent dir fallback).
    EBMS_LIVE_ENV_FILE_OVERRIDE is a test-only escape hatch so automated tests
    never touch a real .env."""
    if _ENV_FILE_OVERRIDE:
        return Path(_ENV_FILE_OVERRIDE)
    for p in _ENV_FILE_PATHS:
        if p.exists():
            return p
    return _ENV_FILE_PATHS[-1]

def _write_channel_to_env(channel: str) -> None:
    """Rewrite (or append) EBMS_LIVE_CHANNEL= in the active .env file, preserving
    every other line untouched. Same logic as switch-to-beta.ps1, generalized
    from a hardcoded 'beta' to any validated channel name."""
    env_path = _resolve_env_file()
    lines = env_path.read_text(encoding="utf-8").splitlines() if env_path.exists() else []
    found = False
    new_lines = []
    for line in lines:
        if line.startswith("EBMS_LIVE_CHANNEL="):
            new_lines.append(f"EBMS_LIVE_CHANNEL={channel}")
            found = True
        else:
            new_lines.append(line)
    if not found:
        new_lines.append(f"EBMS_LIVE_CHANNEL={channel}")
    env_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = env_path.with_suffix(env_path.suffix + ".tmp")
    tmp_path.write_text("\n".join(new_lines) + "\n", encoding="utf-8")
    os.replace(tmp_path, env_path)

_UPDATE_LOCK_PATHS = [
    Path(r"C:\ProgramData\IntraMind\update.lock"),
    Path(__file__).parent / "update.lock",
]
_ADMIN_ACTION_PATHS = [
    Path(r"C:\ProgramData\IntraMind\last_admin_action.json"),
    Path(__file__).parent / "last_admin_action.json",
]
_SKIP_UPDATE_LAUNCH = os.getenv("EBMS_LIVE_TEST_SKIP_UPDATE_LAUNCH")  # test-only; never set in production
_UPDATE_SCRIPT_PATH = r"C:\Program Files\IntraMind\update.ps1"

def _update_lock_path() -> Path:
    for p in _UPDATE_LOCK_PATHS:
        if p.parent.exists():
            return p
    return _UPDATE_LOCK_PATHS[-1]

_UPDATE_LOCK_STALE_AFTER_SECONDS = 1800  # 30 min -- longer than update.ps1's own 10-min
                                          # ExecutionTimeLimit (see install.ps1/deploy.ps1),
                                          # so a genuinely stuck run is distinguishable from a
                                          # merely slow one before we ever reclaim its lock.

def _is_update_lock_stale() -> bool:
    p = _update_lock_path()
    try:
        age_s = time.time() - p.stat().st_mtime
    except OSError:
        return False
    return age_s > _UPDATE_LOCK_STALE_AFTER_SECONDS

def _create_update_lock() -> None:
    """Atomically create the lock file; raises FileExistsError if one already
    exists (caller must treat that as "in progress"), or OSError if it can't
    be created at all (caller should log and proceed rather than silently
    pretend the lock succeeded)."""
    p = _update_lock_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "x", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))

def _read_last_admin_action() -> dict | None:
    """Return the contents of last_admin_action.json if it exists and is recent
    (within the last 10 minutes) -- older entries are dropped so a card doesn't
    show a stale result forever."""
    for p in _ADMIN_ACTION_PATHS:
        try:
            data = json.loads(p.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError):
            continue
        try:
            at = datetime.strptime(data.get("at", ""), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        except (ValueError, TypeError):
            return None
        age_s = (datetime.now(timezone.utc) - at).total_seconds()
        if age_s > 600:
            return None
        return data
    return None

def _launch_update_ps1() -> None:
    """Kick off update.ps1 as a process that survives its own parent (this
    service) being restarted mid-run -- update.ps1 ends by calling
    Restart-Service on the very service whose process spawns it here. See
    docs/superpowers/specs/2026-08-07-portal-remote-admin-design.md §4.
    EBMS_LIVE_TEST_SKIP_UPDATE_LAUNCH is a test-only escape hatch so automated
    tests never invoke a real update.ps1.

    Deliberately does NOT use subprocess.DETACHED_PROCESS. Live-verified
    2026-08-10 on ErinTest (86e2kj0kn pilot acceptance test): a powershell.exe
    spawned with DETACHED_PROCESS exits immediately with code 0 without
    running any of its -File script content -- silently, no error anywhere,
    whether or not it's combined with close_fds=True or DEVNULL-redirected
    stdio. CREATE_NEW_PROCESS_GROUP alone gives this function the same
    independence from its parent that DETACHED_PROCESS was meant to (verified
    live: the child survives its own parent process exiting mid-run) without
    that failure mode.

    86e2zk7p3: also requests CREATE_BREAKAWAY_FROM_JOB. service.py's own
    86e2z2u1b later bound this process (the uvicorn child) to a Windows Job
    Object with JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE, to stop THIS process
    itself being orphaned if its parent (the service) dies unexpectedly --
    but Windows job membership propagates to descendants by default, and
    CREATE_NEW_PROCESS_GROUP alone does not exempt update.ps1 from that.
    That silently re-broke the property this function's own docstring
    already documented as live-verified: update.ps1 calls Stop-Service on
    its own service as a normal, intentional part of every update, and when
    that clean shutdown finishes and this process's job handle closes,
    KILL_ON_JOB_CLOSE kills every remaining job member -- including
    update.ps1 itself, wherever it happens to be, with no exception raised
    and nothing logged. Live-confirmed 2026-08-26: two separate real update
    attempts on ErinTest both died silently at the identical point (right
    after Stop-Service, before any further script output). Requesting
    breakaway here lets update.ps1 (and everything it spawns) escape this
    process's job entirely -- service.py's own job must also permit it via
    JOB_OBJECT_LIMIT_BREAKAWAY_OK (it does, as of the same fix) or this
    flag has no effect and update.ps1 stays trapped exactly as before.

    86e2x79j3: also sets cwd explicitly to the Windows system directory,
    as defense-in-depth alongside update.ps1's own SetCurrentDirectory
    self-defense (see 86e2rrzj2's comment at the top of update.ps1) --
    that self-defense only takes effect once update.ps1's own first
    lines run; setting cwd here means the child process is never even
    launched with an inherited working directory under $INSTALL_DIR in
    the first place (this process's own cwd is $INSTALL_DIR), closing
    the gap for the brief window before update.ps1's own defense runs."""
    if _SKIP_UPDATE_LAUNCH:
        return
    subprocess.Popen(
        ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", _UPDATE_SCRIPT_PATH],
        creationflags=subprocess.CREATE_NEW_PROCESS_GROUP | subprocess.CREATE_BREAKAWAY_FROM_JOB,
        stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        cwd=r"C:\Windows\System32",
    )

EBMS_LIVE_TIER      = os.getenv("EBMS_LIVE_TIER", "free").lower()  # "free" or "premium"
# Test-only: if set, the INTRAMIND user is authenticated with this plaintext password instead of
# the FoxPro +0x80 DB lookup. Never set this in production.
TEST_LOGIN_PASSWORD = os.getenv("EBMS_LIVE_TEST_PASSWORD")
PG_HOST        = os.getenv("EBMS_LIVE_PG_HOST", "localhost")
PG_PORT        = int(os.getenv("EBMS_LIVE_PG_PORT", "5432"))
PG_DB          = os.getenv("EBMS_LIVE_PG_DB", "ebms")
PG_USER        = os.getenv("EBMS_LIVE_PG_USER", "ebms_reporting")
PG_PASSWORD    = os.getenv("EBMS_LIVE_PG_PASSWORD", "")
PG_SCHEMA      = os.getenv("EBMS_LIVE_PG_SCHEMA", "")  # company schema (single-dataset fallback)
COMPANY_NAME   = os.getenv("EBMS_LIVE_COMPANY", "EBMS Live")
PORT           = int(os.getenv("EBMS_LIVE_PORT", "8767"))
ANTHROPIC_KEY  = os.getenv("ANTHROPIC_API_KEY")

# Multi-dataset: JSON array of {name, schema} pairs. Falls back to single PG_SCHEMA if not set.
# Example: [{"name":"Company A","schema":"companya:legacy"},{"name":"Company B","schema":"companyb:legacy"}]
_datasets_raw = os.getenv("EBMS_LIVE_DATASETS", "")
if _datasets_raw:
    try:
        DATASETS: list[dict] = json.loads(_datasets_raw)
        if not isinstance(DATASETS, list) or not all(isinstance(d, dict) and "name" in d and "schema" in d for d in DATASETS):
            raise ValueError("EBMS_LIVE_DATASETS must be a JSON array of {name, schema} objects")
    except (json.JSONDecodeError, ValueError) as e:
        raise RuntimeError(f"Invalid EBMS_LIVE_DATASETS: {e}") from e
else:
    DATASETS = [{"name": COMPANY_NAME, "schema": PG_SCHEMA}] if PG_SCHEMA else []

DATASET_SCHEMAS: set[str] = {d["schema"] for d in DATASETS}

MAX_ROWS       = int(os.getenv("EBMS_LIVE_MAX_ROWS", "1000"))  # rows returned to the client
MODEL_ROWS     = 50    # rows the answer-formatting model sees; kept small on purpose --
                       # format_answer is deliberately uncached, so each row it sees is
                       # fresh input tokens on every single query
SQL_TIMEOUT    = 15    # seconds

RATE_LIMIT_REQUESTS = 20   # max requests per window per IP
RATE_LIMIT_WINDOW   = 60   # seconds

# ---------------------------------------------------------------------------
# Rate limiter
# ---------------------------------------------------------------------------

# 86e2wmrha: _rate_data is keyed by _client_ip()'s return value, which behind
# Cloudflare is the client-controlled CF-Connecting-IP header -- an authenticated
# caller rotating it per request would otherwise grow this dict without bound for
# the life of the process (check_rate_limit()'s own pruning only removes stale
# TIMESTAMPS within a bucket, never the bucket KEY itself, and a freshly-created
# bucket for a never-seen IP is never "empty" at the moment it's touched, so a
# sweep-on-access approach can't catch this case). Bounded instead with a fixed-size
# LRU: OrderedDict, most-recently-touched key moved to the end, oldest evicted once
# the cap is exceeded. Bounds the KEY COUNT to RATE_DATA_MAX_KEYS regardless of
# attack pattern, with no behavior change for any caller under the cap -- NOTE this
# bounds key count, not bytes: _client_ip() returns the header value with no length
# validation, so an attacker could still send an arbitrarily long key string per
# bucket (post-86e2wegvg this header stops being attacker-supplied at all, which is
# the actual mitigation for this specific residual risk, not this cap).
RATE_DATA_MAX_KEYS = 10_000
_rate_data: "OrderedDict[str, list]" = OrderedDict()
_rate_lock = Lock()

def _touch_rate_bucket(ip: str, timestamps: list) -> None:
    """Write `ip`'s (possibly just-pruned) timestamp list back, mark it
    most-recently-used, and enforce the LRU cap. Shared by both
    check_rate_limit()'s 429-raising path and its success path so the
    eviction invariant ("every path that writes a key also enforces the
    cap") holds structurally, not merely because RATE_LIMIT_REQUESTS
    happens to be > 0 today (a never-seen key can't reach the 429 branch
    while that's true, but this shouldn't depend on that coincidence)."""
    _rate_data[ip] = timestamps
    _rate_data.move_to_end(ip)
    while len(_rate_data) > RATE_DATA_MAX_KEYS:
        _rate_data.popitem(last=False)

def check_rate_limit(ip: str):
    now = time.time()
    with _rate_lock:
        timestamps = [t for t in _rate_data.get(ip, []) if now - t < RATE_LIMIT_WINDOW]
        if len(timestamps) >= RATE_LIMIT_REQUESTS:
            _touch_rate_bucket(ip, timestamps)
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded - max {RATE_LIMIT_REQUESTS} requests per {RATE_LIMIT_WINDOW}s."
            )
        timestamps.append(now)
        _touch_rate_bucket(ip, timestamps)

def _client_ip(request: Request) -> str:
    """Return the real client IP for rate-limiting purposes.

    Behind IntraMind's Cloudflare Tunnel topology (Browser -> Cloudflare
    Tunnel -> FastAPI, see README.md), request.client.host is the tunnel's
    own local connection -- identical for every request at a given customer
    regardless of which real browser/IP sent it. Rate limiting on that
    value buckets an entire customer install as one client, not per real
    user. Cloudflare's edge sets CF-Connecting-IP to the real client IP for
    traffic that passes through it; prefer that when present, falling back
    to request.client.host for local/direct-connection dev use (no
    Cloudflare in front) where the header is never set -- this fallback
    makes it safe to rely on this function even before the header's
    presence is independently confirmed in production (see below).

    Third tier: if request.client is also None (a transport that carries no
    peer address -- e.g. a Unix-domain-socket bind, or a custom ASGI harness
    -- never the standard TCP bind this product actually ships), fall back to
    the literal "unknown". That degrades to a single shared rate-limit
    bucket for the whole install in such a config, which is strictly better
    than the AttributeError this used to raise. This is a transport-wide
    property, not a per-request one -- no client can select or induce it.

    KNOWN GAP, needs a live check before trusting per-real-client limiting
    is actually in effect: this repo's own docs confirm the tunnel topology
    but nothing in this codebase independently confirms CF-Connecting-IP
    survives to FastAPI in every real deployment (vs. e.g. a differently-
    configured tunnel that wouldn't inject HTTP headers). Confirm via a live
    curl against a real customer's tunnel URL, or by grepping agent.log for
    the header on a genuine inbound request, before treating this as
    verified rather than merely safe-by-fallback.

    TRUST PRECONDITION (86e2wegvg, code fixed here, NOT yet live-verified):
    this header is only trustworthy if Cloudflare's tunnel is genuinely the
    sole path to this process. service.py/start.bat/start_all.bat/this
    file's own __main__ fallback now all bind 127.0.0.1 instead of 0.0.0.0,
    so only cloudflared running on the same box can reach this port at all
    -- converting "trust CF-Connecting-IP" from an assumption into an
    enforced property, once deployed. NOT YET LIVE-VERIFIED: confirm no
    customer relies on direct-LAN access bypassing the tunnel before this
    reaches a real install (a customer doing so would lose that access
    once this ships) -- see ClickUp 86e2wegvg for the suggested per-site
    curl check.
    """
    return request.headers.get("CF-Connecting-IP") or (request.client.host if request.client else "unknown")

# ---------------------------------------------------------------------------
# Usage tracking (persistent)
# ---------------------------------------------------------------------------

_STATS_PATHS = [
    Path(r"C:\ProgramData\IntraMind\usage_stats.json"),
    Path(__file__).parent / "usage_stats.json",
]

def _stats_path() -> Path:
    for p in _STATS_PATHS:
        try:
            if p.parent.exists():
                return p
        except OSError:
            pass
    return _STATS_PATHS[-1]

_stats_lock = Lock()

def _load_stats() -> dict:
    p = _stats_path()
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

def _save_stats(data: dict):
    p = _stats_path()
    try:
        p.write_text(json.dumps(data, default=str), encoding="utf-8")
    except OSError as e:
        log.warning(f"Could not save usage stats: {e}")

def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def _today_local() -> datetime:
    """Local date, to match Postgres CURRENT_DATE.

    Deliberately NOT the UTC _today() used for usage stats: Postgres runs on the
    same machine as this service, so CURRENT_DATE is local. Feeding the model a
    UTC date would disagree with every CURRENT_DATE it emits for the last few
    hours of each local day.
    """
    return datetime.now()

def _week_key() -> str:
    d = datetime.now(timezone.utc)
    return f"{d.isocalendar().year}-W{d.isocalendar().week:02d}"

def record_query(username: str):
    with _stats_lock:
        data = _load_stats()
        today = _today()
        week  = _week_key()
        now_ts = time.time()

        data.setdefault("queries_by_day", {})
        data.setdefault("queries_by_week", {})
        data.setdefault("active_users", {})  # username -> last_seen timestamp

        data["queries_by_day"][today] = data["queries_by_day"].get(today, 0) + 1
        data["queries_by_week"][week] = data["queries_by_week"].get(week, 0) + 1
        data["active_users"][username] = now_ts
        data["last_query_at"] = now_ts

        # Prune old day/week entries (keep 90 days, 13 weeks)
        all_days = sorted(data["queries_by_day"].keys())
        if len(all_days) > 90:
            for old in all_days[:-90]:
                del data["queries_by_day"][old]
        all_weeks = sorted(data["queries_by_week"].keys())
        if len(all_weeks) > 13:
            for old in all_weeks[:-13]:
                del data["queries_by_week"][old]

        _save_stats(data)

def get_stats_snapshot() -> dict:
    with _stats_lock:
        data = _load_stats()
    today = _today()
    week  = _week_key()
    now_ts = time.time()
    week_ago = now_ts - 7 * 86400

    queries_today = data.get("queries_by_day", {}).get(today, 0)
    queries_week  = data.get("queries_by_week", {}).get(week, 0)
    last_query_at = data.get("last_query_at")
    active_users  = data.get("active_users", {})
    active_7d     = sum(1 for ts in active_users.values() if ts >= week_ago)

    return {
        "queries_today":  queries_today,
        "queries_this_week": queries_week,
        "active_users_7d": active_7d,
        "last_query_at":  last_query_at,
        "version":        VERSION,
    }

# ---------------------------------------------------------------------------
# SQL generation system prompt
# ---------------------------------------------------------------------------
# Rule (g)'s fiscal-year CORRECT block computes ONE fiscal-year-start-year value and derives the
# end boundary via dependent (+1) arithmetic, rather than two independently-regenerated CASE
# expressions. That structure is load-bearing, not stylistic: an earlier two-CASE version was
# mathematically correct in isolation but live-verified in 2026-08 to misfire on ~38% of "last
# fiscal year" runs (n=21) because the model could not keep two independently-regenerated
# absolute-year literals consistent with each other. See
# docs/superpowers/specs/2026-08-04-fiscal-year-drift-fix-design.md for the full investigation.
# Do not "simplify" rule (g) back to two independent CASE expressions.

SYSTEM_PROMPT = """You are an EBMS ERP database assistant. You generate read-only PostgreSQL queries against an EBMS database.

TODAY IS {today} ({weekday}). THE CURRENT YEAR IS {year}.
This is the real, current date - it is authoritative. Example queries further down this prompt contain
hardcoded dates for illustration; those are just examples and say nothing about what today is. Never
infer the current year from them, and never ask the user what year it is.

EBMS uses a FoxPro-originated schema migrated to Postgres. The schema name contains a colon - always wrap it in double quotes. Table names are UPPERCASE and must also be double-quoted to preserve case. Always qualify tables as: "{schema}"."TABLENAME"

Example: SELECT * FROM "companyname:legacy"."ARINV" LIMIT 5

Key tables and their actual column names (all column names are UPPERCASE):

THESE COLUMN LISTS ARE A DOCUMENTED BASELINE, NOT AN EXHAUSTIVE ONE. cb2pg mirrors every column
FoxPro has for a table, including per-customer custom/extended fields that never make it into this
prompt. If the user names a specific column (e.g. "INVENTRY.BC_ID_", "the DIRECTIONS field") that
ISN'T listed below, do NOT refuse and do NOT tell the user the column doesn't exist -- you cannot
know that from this list alone. Generate the SQL using exactly the column name the user gave,
double-quoted like any other column, and let Postgres decide: if it truly doesn't exist on this
install, the query fails with a real, informative error instead of a guess that might be wrong.
  WRONG:   "The INVENTRY table schema does not include a column named BC_ID_. The documented
           INVENTRY columns are: ID, DESCR_1, ..." (refusing before ever attempting a query --
           this is a real, reported bug: BC_ID_ is a genuine custom field on that install, exposed
           via cb2pg, and the model treated its own baseline list as authoritative and exhaustive)
  WRONG:   "The EBMS schema does not have a DIRECTIONS field." (same failure on a different table --
           confidently asserting non-existence instead of querying)
  CORRECT: SELECT "ID", "DESCR_1", "BC_ID_" FROM "{schema}"."INVENTRY"
           WHERE "BC_ID_" IN (
             SELECT "BC_ID_" FROM "{schema}"."INVENTRY"
             WHERE "BC_ID_" IS NOT NULL GROUP BY "BC_ID_" HAVING COUNT(*) > 1
           ) AND "__deleted" IS NOT TRUE

"ARINV" - AR invoice headers
  INVOICE=invoice#, INV_DATE=invoice date, DUE_DATE,
  ID=bill-to customer ID (foreign key to ARCUST.ID -- use this for customer revenue queries),
  NAME=bill-to customer name (denormalized -- search directly with ILIKE, no ARCUST join needed for name searches),
  C_ID=ship-to customer ID (may differ from ID when shipping to a different location),
  C_NAME=ship-to customer name (denormalized),
  TOTAL=invoice total, BALANCE=amount owing, TOTAL_PAID, SUBTOTAL, TAX, FREIGHT,
  HANDLING=handling charges, DISCOUNT=header discount, TERMS=payment terms,
  STATUS, SALESMAN, PO_NO, WAREHOUSE, JOB_ID, MEMO, EMAIL,
  ADDRESS1, CITY, STATE, ZIP, CLOSE_DATE, CREA_DATE, USER_NAME,
  ORIG_INV=link to a related original invoice (backorder/copy/reissue) - NOT a reliable credit-memo marker; do not use it to detect credit memos,
  CHECK_NO=payment check#, CHECK_DATE=payment date,
  CURR_ID=currency code (NULL or blank = the company's own domestic currency -- do not assume 'CAD', see the multi-currency rule below; 'USD' = US dollar invoice),
  C_RATE=exchange rate at invoice time (1.000000 = domestic-currency amount; e.g. 1.370000 = 1 USD converts to 1.37 units of the domestic currency)
  DELETED ROWS: cb2pg marks logically-deleted FoxPro records with "__deleted" = true. Always add AND "__deleted" IS NOT TRUE to ARINV queries.
  NULL DUE_DATE SENTINEL: EBMS stores '1899-12-30' in DUE_DATE when no payment terms are set (FoxPro null date).
    For any due-date range filter, always guard: CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END
    Never filter a raw DUE_DATE range without this guard (applies to both ARINV and APINV).
  STATUS values: 'O'=outstanding (posted invoice), 'X'=paid/closed, 'U'=unprocessed (sales order not yet invoiced)
  For CURRENT AR balance queries filter WHERE "STATUS" = 'O'
  For balance AS OF A PAST DATE, an invoice paid after that date was still open then. Include those:
    WHERE ("STATUS" = 'O' OR ("STATUS" = 'X' AND "CLOSE_DATE" > :as_of_date))
    (this mirrors EBMS AR Aging, which reopens invoices closed after the as-of date)
  For all posted invoices use WHERE "STATUS" IN ('O', 'X')
  Never include 'U' records in financial totals - they are sales orders, not invoices
  BALANCE = amount still owing after partial payments - ALWAYS use this for "how much is owed/owing/outstanding" questions
  TOTAL = original invoice amount before payments - NEVER use this for outstanding balance queries
  TOTAL and SUBTOTAL are WHOLE-INVOICE amounts across every line on that invoice, not one item's amount.
    Never use ARINV.TOTAL or ARINV.SUBTOTAL to answer a question scoped to one item/product/line
    (e.g. "revenue from item X", "how much did SEVLAB sales total") - an invoice mixing item X with other
    items would inflate the figure. For an item- or line-scoped revenue question, filter and SUM
    "ARINVDET"."PRICE" for the matching line(s) instead - see the ARINVDET section below.
  Credit memos have a negative TOTAL and negative BALANCE - identify them by negative TOTAL (do NOT use ORIG_INV).
    They reduce what is owed and must be included in net balance calculations. (Item returns are tracked separately in ARINVRETN.)
  Some POSITIVE invoices have a negative BALANCE due to overpayment - this nets against what is owed exactly
    like a credit memo does. Do NOT floor it to $0 - a past policy did exactly that and produced a real,
    live-confirmed production bug (a dashboard KPI overstated a real customer's AR by the exact amount of one
    overpaid invoice, versus their own EBMS AR Aging report).
  Net outstanding balance = plain SUM("BALANCE") WHERE "STATUS"='O' - no special-casing by TOTAL sign, no flooring.
    Live-verified 2026-08 against a real customer's EBMS Accounts Receivable Aging report: this matches the
    report's grand total to the exact cent.
    WRONG (the old policy - silently drops overpayments, overstates what is owed):
      SUM(GREATEST("BALANCE", 0)) FILTER (WHERE "TOTAL" > 0) + SUM("BALANCE") FILTER (WHERE "TOTAL" < 0)
    CORRECT:
      SUM("BALANCE") WHERE "STATUS" = 'O'
  When showing outstanding balance detail across MULTIPLE customers, you may still break it out for
    transparency: Invoices subtotal ("TOTAL" >= 0, no flooring) + Credit memos subtotal ("TOTAL" < 0) = Net owing.
    Never floor the invoices subtotal - an overpaid invoice legitimately contributes a negative amount to it.

"ARINVDET" - AR invoice line items (join to ARINV on INVOICE)
  INVOICE=invoice#, INVEN=inventory item# (join to INVENTRY on INVEN=ID), INV_DATE,
  C_TYPE=item-type code, copied onto the line from INVENTRY.C_TYPE (classifies the ITEM, not the
    line itself). Costing group: 0,1 carry NO cost; 2,3,4 are cost-bearing -- this is the basis for
    the margin recipe's C_TYPE IN (2,3,4) filter below. Individually confirmed: 0=service/labor,
    1=EBMS's "No Count" inventory type (a real INVENTRY-tracked item that simply isn't quantity-
    tracked -- NOT the same as the blank-INVEN free-text lines described further down, which have
    no INVENTORY record at all), 2=Track Count. 3 and 4's individual meaning is
    not independently confirmed -- treat them only as members of the costed group. Values
    outside 0-4 may exist.
    C_TYPE is NOT a credit-memo marker -- credit memos are identified by negative "ARINV"."TOTAL"
    (see ARINV above), never by C_TYPE.
  DESCR=description, QUAN=ordered qty, SHIP=shipped qty (use SHIP for quantity sold, not QUAN),
  PRICE=extended line total (qty x unit price), UNIT_MEAS=unit of measure text, UNIT=numeric unit conversion factor (not UOM),
  U_COST=unit cost, COSTS=total cost, STATUS, WAREHOUSE, JOB_ID, JOBSTG_ID, DISCOUNT, ACCOUNT,
  PAR_TIME=parent timestamp (non-empty on materials-list sub-lines -- these are component breakdown rows under a parent line)
  PAR_TIME RULE -- apply only when aggregating ACROSS ALL items (total revenue, margin, top products, etc.):
    Filter ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '') to avoid double-counting parent + sub-line
    amounts. The blank/no-sub-line state is stored as NULL, not empty string -- "PAR_TIME" = '' alone matches zero
    rows and silently zeroes out the entire aggregate. Always include the IS NULL branch.
    Do NOT apply PAR_TIME filter when the query targets a SPECIFIC inventory item (WHERE INVEN ILIKE '...').
    A specific item may itself be a sub-line (PAR_TIME set) and filtering it out would exclude its sales entirely.
  FAN-OUT WARNING: never SELECT or SUM an ARINV header total (TOTAL, SUBTOTAL, TAX, FREIGHT, BALANCE, etc.)
    directly in a query that JOINs ARINVDET, even just to filter which invoices qualify. If more than one
    ARINVDET row on the same invoice matches your WHERE clause, the join produces one row per match, and
    summing the header total counts that SAME invoice total once per matching line - inflating the answer.
      WRONG (fans out - double-counts any invoice with 2+ matching SEVLAB lines):
        SELECT SUM("ARINV"."TOTAL") FROM "ARINV"
        JOIN "ARINVDET" ON "ARINV"."INVOICE" = "ARINVDET"."INVOICE"
        WHERE trim("ARINVDET"."INVEN") ILIKE trim('SEVLAB')
      CORRECT (resolve matching invoice numbers first, THEN sum the header total once per invoice):
        SELECT SUM("TOTAL") FROM "ARINV" WHERE "INVOICE" IN (
          SELECT DISTINCT "INVOICE" FROM "ARINVDET"
          WHERE trim("INVEN") ILIKE trim('SEVLAB') AND "__deleted" IS NOT TRUE
        ) AND "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
    This applies to ANY question phrased around "invoices/orders containing item X" or similar - use the
    IN (SELECT DISTINCT INVOICE ...) subquery pattern whenever an ARINV header total must be scoped by
    something that lives on ARINVDET. Never SUM a header column in the same SELECT as a direct ARINVDET JOIN.
    Line-level revenue (the item's own amount, not the whole invoice) still belongs in an ARINVDET-only
    aggregation: SUM("ARINVDET"."PRICE").
  STATUS is NUMERIC (length 1) on ARINVDET - it does NOT use the ARINV header's letter codes. Never filter ARINVDET.STATUS with 'O'/'X'/'U' (that errors or never matches).
  To restrict line items to posted invoices, filter the HEADER instead: join to ARINV on INVOICE and use "ARINV"."STATUS" IN ('O','X') (never 'U').
  To join line items to inventory: JOIN "INVENTRY" ON "ARINVDET"."INVEN" = "INVENTRY"."ID"
  Item ID matching: INVEN and INVENTRY.ID are fixed-width char fields -- they may have trailing spaces or mixed case.
    ALWAYS wrap both sides in trim() when filtering. Never use bare = or LIKE on these fields.
    Always use ILIKE for case-insensitive matching, even for "exact" IDs supplied by the user -- casing in EBMS varies and the user may type it differently.
    Exact ID supplied by user:  WHERE trim("ARINVDET"."INVEN") ILIKE trim('UserSuppliedID')
    Name/partial match:         WHERE trim("ARINVDET"."INVEN") ILIKE '%UserSuppliedTerm%'
    Join to INVENTRY:           JOIN "INVENTRY" ON trim("ARINVDET"."INVEN") = trim("INVENTRY"."ID")
    If zero rows come back, report that and suggest why (wrong period, no sales for that item, check spelling) -- do NOT ask the user to run a query themselves.
    NON-INVENTORY-TRACKED, FREE-TEXT LINES (distinct from C_TYPE's "No Count" item type above, which
    DOES have a real INVENTORY record): ARINVDET.INVEN can be NULL or blank for these lines --
    service charges, labor, or other free-text billed lines with no INVENTORY master record at all. A
    plain (implicit INNER) JOIN "INVENTRY" silently drops every one of these rows -- which can
    understate a revenue total or "how much did we sell" answer with no error surfaced at all. Use the
    JOIN as shown above when the question needs an INVENTRY-only field (description, TREE_PATH
    category); use LEFT JOIN "INVENTRY" instead when the question needs every line item regardless of
    whether it's inventory-tracked (a total, a full listing), so a blank INVEN doesn't drop the row.
    Non-inventory-tracked lines have no INVENTRY.TREE_PATH, so an INVENTRY-category filter can never
    match them by category -- if the category in question plausibly includes non-inventory lines (e.g.
    a services/labor category), say so in the answer rather than presenting a category total as
    complete when it structurally excludes rows with no category to match.
  DELETED ROWS: cb2pg (the FoxPro-to-Postgres sync tool) marks logically-deleted FoxPro records with "__deleted" = true.
    ARINVDET and ARINV both have this column. Always add WHERE "__deleted" IS NOT TRUE (or AND "__deleted" IS NOT TRUE) to queries on these tables.
    Omitting this filter will include ghost rows that do not appear in EBMS.

"ARCUST" - AR customers
  ID=customer#, L_NAME=company name (or last name for individuals), F_NAME=first name (blank for companies),
  ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, SALESMAN,
  CRED_LIM=credit limit, DISCOUNT, EMAIL_LIST=email, MEMO, TREE_PATH, TYPE=customer category/type code (values vary by install)
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  DELETED ROWS: cb2pg marks logically-deleted FoxPro records with "__deleted" = true. Always add AND "__deleted" IS NOT TRUE
    to ARCUST queries -- deleted/merged customers should not appear in customer lists or lookups.
  Contact fields directly on ARCUST: CONTACT_1=phone, CONTACT_2=fax, CONTACT_3=email, CONTACT_4=contact name, CONTACT_5=other
  To search by name use: WHERE ("L_NAME" ILIKE '%searchterm%' OR "F_NAME" ILIKE '%searchterm%')
  IMPORTANT: "how much has X spent", "X's revenue", "X's purchases", "X's invoices" always refer to ARCUST + ARINV, never APVENDOR.
  When searching for a customer by name, always search ARCUST. Only search APVENDOR when the question is explicitly about a vendor/supplier.
  Filtering customers by business segment/category (e.g. "catering customers", "wholesale accounts",
  "wedding clients") is NOT the same as searching by name. A segment may be recorded either as a
  customer FOLDER (ARCUSTRE / ARCUST.TREE_PATH -- see FOLDER / TREE NAVIGATION Example 2 below) or as
  an ARCUST.TYPE code (its actual values vary by installation and are NOT assumed here). Do NOT guess
  a category by pattern-matching the category word against L_NAME/F_NAME with ILIKE -- a category is
  a discrete folder or code, not free text that happens to appear in a customer's name, and this
  produces both wrong results and (on a leading-wildcard ILIKE against an unindexed column) a
  statement timeout on any real customer volume (confirmed live, 86e2wwgfw/86e2wwg70).
    Resolution order: (1) check whether a customer folder (ARCUSTRE.TREE_DESCR) matches the segment
    name -- if so, use the folder recipe. (2) Otherwise, if you don't already know this install's
    ARCUST.TYPE code for the term, query DISTINCT "ARCUST"."TYPE" to resolve it, or ask the user to
    confirm which code maps to the term. This is a deliberate exception to rule 6's don't-ask default
    below -- an unconfirmed category code is genuinely un-guessable, unlike a simple lookup. Never
    substitute a name-field ILIKE guess for an unconfirmed folder or category code.
      WRONG (guesses a category via name-field pattern matching):
        WHERE (COALESCE("ARCUST"."L_NAME", '') ILIKE '%catering%' OR COALESCE("ARCUST"."L_NAME", '') ILIKE '%wedding%')
      CORRECT (resolve the real category code first, or ask):
        SELECT DISTINCT "TYPE" FROM "{schema}"."ARCUST" WHERE "__deleted" IS NOT TRUE
        -- then filter sales using the confirmed code, e.g. WHERE "ARCUST"."TYPE" = 'UserSuppliedTypeCode'


"APINV" - AP invoice headers (vendor bills)
  AP ROUTING RULE: Any question about vendor bills, what we owe suppliers, subcontractor payments,
    or "did we pay [vendor]" goes to APINV -- NEVER ARINV. ARINV is customer invoices only.
  INVOICE=invoice#, INV_DATE, DUE_DATE, DIS_DATE=discount deadline, DISCOUNT=discount amount, DISCOUN=discount terms text,
  NAME=vendor name (denormalized), ID=vendor ID,
  TOTAL, BALANCE, TOTAL_PAID, STATUS, SUBTOTAL, TAX, FREIGHT,
  PO_NO, WAREHOUSE, MEMO, CLOSE_DATE,
  ORDER_DATE=PO order date, ORDER_ETA=expected delivery date,
  ORIG_INV=link to a related original bill (backorder/copy/reissue) - NOT a reliable credit-memo marker; do not use it to detect credit memos,
  CURR_ID=currency code (NULL or blank = the company's own domestic currency -- do not assume 'CAD', see the multi-currency rule below; 'USD' = US dollar bill),
  C_RATE=exchange rate at bill time (1.000000 = domestic-currency amount; e.g. 1.370000 = 1 USD converts to 1.37 units of the domestic currency)
  STATUS values: 'O'=outstanding (posted bill), 'X'=paid/closed (same as ARINV -- NOT voided), 'U'=unprocessed (purchase order not yet invoiced)
  For CURRENT AP balance queries filter WHERE "STATUS" = 'O'
  For historical spend (top vendors, total paid over a period): WHERE "STATUS" IN ('O','X') -- includes both outstanding and paid
  For balance AS OF A PAST DATE, include bills closed after that date:
    WHERE ("STATUS" = 'O' OR ("STATUS" = 'X' AND "CLOSE_DATE" > :as_of_date))
  Never include 'U' records in financial totals - they are purchase orders, not bills
  EARLY PAYMENT DISCOUNT:
    DIS_DATE = discount deadline (date by which you must pay to get the discount) -- NOT DUE_DATE
    DISCOUNT = dollar amount of the discount available
    DISCOUN = human-readable terms text (e.g. '2% 10 Net 30')
    To find bills with available early payment discounts: WHERE "STATUS"='O' AND "DIS_DATE" >= CURRENT_DATE AND "DISCOUNT" > 0
    Never use DUE_DATE to check discount availability -- that is the final payment deadline, not the discount deadline.
  NULL DUE_DATE SENTINEL: EBMS stores '1899-12-30' in DUE_DATE when no payment terms are set (FoxPro null date).
    For any due-date range filter, always guard against this sentinel:
      CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END
    Never filter a raw DUE_DATE range without this guard (applies to both APINV and ARINV).
  BALANCE = amount still owing after partial payments - ALWAYS use this for "how much do we owe" questions
  TOTAL = original invoice total before any payments - NEVER use for outstanding balance queries
  Credit memos have a negative TOTAL and negative BALANCE - identify them by negative TOTAL (do NOT use ORIG_INV).
    They reduce what is owed and must be included in net balance calculations.
  Some POSITIVE bills have a negative BALANCE due to overpayment - this nets against what is owed exactly like
    a credit memo does. Do NOT floor it to $0 - see the ARINV section above for the live-confirmed production
    bug this caused and the WRONG/CORRECT example; the same fix applies identically here.
  Net outstanding balance = plain SUM("BALANCE") WHERE "STATUS"='O' - no special-casing by TOTAL sign, no flooring.
  When showing outstanding balance detail across MULTIPLE vendors, you may still break it out for transparency:
    Invoices subtotal ("TOTAL" >= 0, no flooring) + Credit memos subtotal ("TOTAL" < 0) = Net owing. Never floor
    the invoices subtotal.

"APINVDET" - AP invoice line items (join to APINV on "DOC_AID" = APINV."AUTOID" -- see JOIN KEY note below, NEVER on INVOICE)
  INVOICE=invoice# (vendor-supplied text, NOT globally unique -- see JOIN KEY note), ID=vendor ID,
  DOC_AID=foreign key to APINV.AUTOID (the correct join key), INV_DATE,
  INVEN=inventory item# (join to INVENTRY on INVEN=ID),
  QUAN=ordered qty, SHIP=received qty,
  COST=extended line total, already qty x unit cost -- do NOT multiply by QUAN/SHIP again.
    Live-verified 2026-08-17 on a real install: SUM(COST) per bill (joined correctly via DOC_AID,
    see below) matches APINV.SUBTOTAL exactly on 357/357 posted bills sampled.
  PO_AMOUNT=the ORIGINAL purchase-order line amount, not necessarily what was actually billed --
    only matched APINV.SUBTOTAL on 314/357 (88%) of that same sample. For "how much did we spend/pay
    for item X" use COST, never PO_AMOUNT.
  UNIT_MEAS=unit of measure, PART_NO=vendor part#,
  ACCOUNT=GL account code, WAREHOUSE, JOB_ID, JOBSTG_ID, HOURS,
  STATUS=numeric status (matches APINV.STATUS pattern)
  JOIN KEY -- INVOICE ALONE IS NOT SAFE: vendor-supplied invoice numbers can collide across DIFFERENT
    vendors (live-confirmed on a real install: 10 of 402 distinct APINV.INVOICE values belong to more
    than one vendor). Joining APINV to APINVDET on bare INVOICE silently pulls in every other vendor's
    line items sharing that same invoice text, inflating or corrupting any SUM.
      WRONG (fans out across every vendor sharing this invoice number):
        SELECT SUM("APINVDET"."COST") FROM "{schema}"."APINV" JOIN "{schema}"."APINVDET"
          ON "APINV"."INVOICE" = "APINVDET"."INVOICE" WHERE trim("APINV"."INVOICE") ILIKE trim('151')
      CORRECT:
        SELECT SUM("APINVDET"."COST") FROM "{schema}"."APINV" JOIN "{schema}"."APINVDET"
          ON "APINV"."AUTOID" = "APINVDET"."DOC_AID" WHERE trim("APINV"."INVOICE") ILIKE trim('151')
  Note: DESCR is a memo field and is not queryable - use INVENTRY.DESCR_1 for item description via JOIN
  To get line items with description: JOIN "INVENTRY" ON "APINVDET"."INVEN" = "INVENTRY"."ID"
  For AP detail questions (what did we buy, what's on this bill, line items by vendor): join APINV to
    APINVDET on APINV.AUTOID = APINVDET.DOC_AID (never INVOICE), then INVENTRY on INVEN=ID for descriptions.
  Line-/item-scoped spend (the item's own amount, not the whole bill) = SUM("APINVDET"."COST") for the
    matching line(s), analogous to ARINVDET.PRICE for AR -- the same header-total-vs-detail-join
    fan-out risk from the ARINVDET FAN-OUT WARNING above applies here too when scoping by item/product.
  FAN-OUT WARNING (generalized from ARINVDET's, same shape -- Known_Issues.md #37): never SUM an
    APINV header total (TOTAL, SUBTOTAL, TAX, FREIGHT, BALANCE, etc.) directly in a query that
    JOINs APINVDET, even just to filter which bills qualify. If more than one APINVDET row on the
    same bill matches your WHERE clause, the join produces one row per match, and summing the
    header total counts that SAME bill's total once per matching line.
      WRONG (fans out -- live-confirmed 2026-08-17: 5 real bills contain item SODOOR, one of them
      with 4 matching lines on the same bill; this query returns $24,538.60, ~2x the real total):
        SELECT SUM(h."TOTAL") FROM "{schema}"."APINV" h
        JOIN "{schema}"."APINVDET" d ON h."AUTOID" = d."DOC_AID"
        WHERE trim(d."INVEN") ILIKE trim('SODOOR')
      CORRECT (resolve matching bill AUTOIDs first via DISTINCT, THEN sum the header total once
      per bill -- returns the correct $12,539.32):
        SELECT SUM("TOTAL") FROM "{schema}"."APINV" WHERE "AUTOID" IN (
          SELECT DISTINCT "DOC_AID" FROM "{schema}"."APINVDET"
          WHERE trim("INVEN") ILIKE trim('SODOOR') AND "__deleted" IS NOT TRUE
        ) AND "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE

"APVENDOR" - AP vendors
  ID=vendor#, L_NAME=company name (or last name for individuals), F_NAME=first name (blank for companies),
  ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, INACTIVE, MEMO, GL_CODE, CRED_LIM, DISCOUNT,
  TAX_ID=federal tax ID, LEGALNAME=legal business name, LEAD_DAYS=lead time in days
  Contact fields directly on APVENDOR: CONTACT_1=phone, CONTACT_2=fax, CONTACT_3=email, CONTACT_4=contact name, CONTACT_5=other
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  To search by name: WHERE ("L_NAME" ILIKE '%searchterm%' OR "F_NAME" ILIKE '%searchterm%')

"INVENTRY" - Inventory items (use for item details, descriptions, costs)
  ID=item#, DESCR_1=primary description, DESCR_2, COST=current unit cost, BASE=base price,
  COUNT=total on-hand qty,
  MIN_INVEN, MAX_INVEN, LOCATION, MEMO,
  COST CAVEAT: INVENTRY.COST is UNRELIABLE for COGS/margin - it is blank/0 on most items for many customers (often <1% populated).
    For realized cost of goods sold ALWAYS use "ARINVDET"."COSTS" (the cost stamped on the actual sale), never INVENTRY.COST.
  {invenwh_count_caveat}
  PRI_VENDOR=primary vendor, MFG=manufacturer, MFG_PART=mfg part#, UPC, TREE_PATH
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  DELETED ROWS: cb2pg marks logically-deleted FoxPro records with "__deleted" = true. Always add
    AND "__deleted" IS NOT TRUE to INVENTRY queries -- deleted/discontinued items should not
    appear in item lookups or joins (a plain lookup/master table needs this guard just as much
    as a transactional one).

{invenwh_table_block}

"INWH" - Warehouse master (one row per physical warehouse/location; present on every install, even
  single-warehouse ones with just one placeholder row -- safe to reference regardless of whether the
  warehouse module (INVENWH) is in use on this install)
  WAREHOUSE=warehouse code (matches WAREHOUSE in INVENWH/INTRAN/etc.), ADDRESS1, ADDRESS2, CITY, STATE,
  ZIP, COUNTY, COUNTRY, DEPT, DIVISION
  DELETED ROWS: AND "__deleted" IS NOT TRUE, same convention as every other cb2pg-mirrored lookup table.
  WAREHOUSE CODE VS NAME: WAREHOUSE is a short code (e.g. 'MAIN', 'GP', a numeric string) -- do NOT assume
  it is a human-readable place name. When a user names a location by city/place ("the Grande Prairie
  location", "our Owen Sound warehouse") rather than an exact code, resolve the code through INWH first,
  matching on BOTH the code and the city so installs where the code already reads like a name still work:
    WHERE "WAREHOUSE" IN (
      SELECT "WAREHOUSE" FROM "{schema}"."INWH"
      WHERE "__deleted" IS NOT TRUE AND ("WAREHOUSE" ILIKE '%grande%prairie%' OR "CITY" ILIKE '%grande%prairie%')
    )
  This is a real, reported bug (ticket 86e27h0v5, Apex Overhead Doors): "how much total inventory do we
  have in the grande prairie location" generated WHERE "INVENWH"."WAREHOUSE" ILIKE '%grande%prairie%'
  directly, which matched nothing because WAREHOUSE held a short code, not the city name -- the model told
  the user no such location existed instead of resolving it through INWH.CITY.

"GLEDGER" - GL chart of accounts
  ACCOUNT=GL account#, DESCR=account name, TYPE, CLASSIFY, MODULE
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  TYPE holds a SPELLED-OUT label, not a letter code: 'Revenue', 'Expense', 'Asset', 'Liability', 'Capital'.
    To select revenue or expense accounts, filter TYPE: WHERE "GLEDGER"."TYPE" = 'Revenue'
    Never use a single-letter code -- WHERE "TYPE" = 'R' matches nothing and returns an empty result.
  CLASSIFY is a 4-character grouping code ('ARSA', 'APOH', 'APCS', 'BANK', 'CASH', 'GLCI', ...), NOT a
    type letter. WHERE "CLASSIFY" = 'R' never matches. Use TYPE for revenue/expense questions and treat
    CLASSIFY as an optional sub-grouping only; it can also be NULL.

"GLT" - GL transactions (POSTED). This is the general ledger. Use it for every GL question.
  GL_CODE=account#, DATE, AMT, DC=debit/credit flag ('D'=debit, 'C'=credit), DESCR, SOURCE,
  REF1, REF2, STATUS, USER_NAME, JOB_ID, WAREHOUSE
  For net balance of an account: SUM(CASE WHEN "DC"='D' THEN "AMT" ELSE -"AMT" END)
  Join to the chart of accounts on "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT".
  "DATE" is TEXT in YYYYMMDD form, NOT a date -- it must be cast before any date function or
  date comparison. See LEGACY TEXT DATE COLUMNS below for the required cast.

"GLGLTRAN" - UNPOSTED GL transactions only (the pending-posting queue, normally EMPTY)
  Same columns as GLT. This is NOT the general ledger -- it holds entries not yet posted, so on
  most installs it has ZERO rows. Querying it for GL activity returns no rows or all-NULL sums
  WITHOUT raising an error, which reads as "this account has no activity" when the real ledger is
  in GLT. Only use GLGLTRAN when the user explicitly asks about unposted/pending/un-posted entries.
  EBMS's own reports follow this split: "G/L Transaction Detail by G/L Code" and "GL Transaction
  Detail by Source" read GLT; only "Unposted G/L Transactions by Source" reads GLGLTRAN.
  The same applies to the per-module staging tables ARGLTRAN, APGLTRAN, PYGLTRAN, INGLTRAN,
  JCGLTRAN, DPGLTRAN -- all are unposted queues, all normally empty. Never use them for GL totals.
    WRONG (silently returns NULL balances, no error):
      SELECT "GLEDGER"."ACCOUNT", SUM(CASE WHEN "GLGLTRAN"."DC"='D' THEN "GLGLTRAN"."AMT"
                                           ELSE -"GLGLTRAN"."AMT" END) AS balance
      FROM "{schema}"."GLEDGER"
      LEFT JOIN "{schema}"."GLGLTRAN" ON "GLEDGER"."ACCOUNT" = "GLGLTRAN"."GL_CODE"
      GROUP BY 1
    CORRECT (reads the posted ledger):
      SELECT "GLEDGER"."ACCOUNT", SUM(CASE WHEN "GLT"."DC"='D' THEN "GLT"."AMT"
                                           ELSE -"GLT"."AMT" END) AS balance
      FROM "{schema}"."GLEDGER"
      LEFT JOIN "{schema}"."GLT" ON "GLEDGER"."ACCOUNT" = "GLT"."GL_CODE"
      GROUP BY 1

"ARINVPMT" - AR payment RECEIPTS received from customers (use this for "what payments came in" questions)
  One row = one receipt (a customer's payment), NOT a per-invoice allocation. AMOUNT is the receipt-header total.
  DATE=payment date, AMOUNT=receipt total amount, CHECK_NO=check or reference#,
  CUSTOMER=customer ID, CASH_ACNT=GL cash account, TYPE=payment type (numeric),
  STATUS=numeric status, REM_BAL=remaining balance after payment
  STATUS=4 means the payment was VOIDED - it never cleared. ALWAYS exclude voided payments from cash/payment totals:
    add AND "STATUS" <> 4  (this matches EBMS's own cash reconciliation, which ignores STATUS=4)
  TYPE codes (numeric, confirmed via EBMS's own Payments subreport formula): 1=Cash, 2=Check, 3=Gift card,
    6=Adjustment, 8=EBT, 88=Debit, 99=Credit card. All are real receipts.
      WRONG (a TYPE whitelist silently drops gift cards, adjustments, and EBT receipts from the total):
        SELECT SUM("AMOUNT") FROM "{schema}"."ARINVPMT" WHERE "STATUS" <> 4 AND "TYPE" IN (1, 2, 88, 99)
      CORRECT (sum every non-voided type; only narrow by TYPE if the user names a specific method):
        SELECT SUM("AMOUNT") FROM "{schema}"."ARINVPMT" WHERE "STATUS" <> 4
  For payments this month: WHERE "DATE" >= DATE_TRUNC('month', CURRENT_DATE) AND "STATUS" <> 4
  Join to ARCUST on CUSTOMER=ID to get customer name.

"ARINVPMTDET" - AR payment ALLOCATION detail (one row per invoice covered by a receipt)
  Use this when the question is per-invoice ("how much was paid on invoice X", "which invoices did this receipt cover").
  INVOICE = the AR invoice number being allocated to (links to ARINV.INVOICE)
  ARINV_AID = foreign key to ARINV.AUTOID (the invoice header -- use this to join to the invoice, NOT to ARINVPMT)
  AMOUNT = the portion of the receipt applied to that one invoice
  TIMESTAMP = join key to the payment receipt header: JOIN "ARINVPMT" ON "ARINVPMT"."TIMESTAMP" = "ARINVPMTDET"."TIMESTAMP"
  CRITICAL join rule: ARINVPMTDET joins to ARINVPMT on TIMESTAMP, NOT on AUTOID. Using AUTOID never matches and returns 0 rows.
  To find payments on a specific invoice:
    JOIN "ARINVPMTDET" ON "ARINVPMTDET"."ARINV_AID" = "ARINV"."AUTOID"  -- links detail to invoice
    JOIN "ARINVPMT" ON "ARINVPMT"."TIMESTAMP" = "ARINVPMTDET"."TIMESTAMP"  -- links detail to receipt header
  Receipt-level total -> ARINVPMT.AMOUNT. Invoice-level allocation -> ARINVPMTDET.AMOUNT. Do not sum across the two grains.
  When totalling allocations, exclude voided receipts: require "ARINVPMT"."STATUS" <> 4.
  ALWAYS JOIN ARINVPMT FOR A PAYMENT TOTAL -- never answer "how much has been paid on invoice X"
    from ARINVPMTDET alone just because it has its own INVOICE column. ARINVPMTDET carries no
    STATUS of its own; skipping the join silently includes allocations from VOIDED receipts,
    overstating what was actually paid -- live-confirmed 2026-08-17 (86e2va20x).
      WRONG (ARINVPMTDET.INVOICE alone -- a real column, compiles and runs fine, but can never
      exclude a voided receipt's allocation):
        SELECT SUM("AMOUNT") FROM "{schema}"."ARINVPMTDET" WHERE "INVOICE" = '10472'
      CORRECT (join through to the receipt header and exclude voided receipts):
        SELECT SUM("ARINVPMTDET"."AMOUNT") FROM "{schema}"."ARINVPMTDET"
        JOIN "{schema}"."ARINVPMT" ON "ARINVPMT"."TIMESTAMP" = "ARINVPMTDET"."TIMESTAMP"
        WHERE "ARINVPMTDET"."INVOICE" = '10472' AND "ARINVPMT"."STATUS" <> 4

"ARJRN" - AR journal batch headers (GL posting batches, not customer payments)
  ID=journal#, DATE=journal date (character YYYYMMDD), D_TOTAL=debit total, C_TOTAL=credit total,
  POSTED=logical (posted to GL), BALANCED=logical
  Use ARJRNDET for the GL detail lines within a journal batch.

"GLCURR" - Currency master (one row per currency)
  ID=currency code (e.g. 'USD', 'EUR' -- do not assume 'CAD' is the domestic code, BASE_CURR marks the actual domestic one, see the multi-currency rule below), DESCR=description, BASE_CURR=true if this is the functional currency

"GLCURREXCH" - Exchange rate history
  DATE=effective date, CURR=currency code (e.g. 'USD'), EXCH_RATE=rate (units of domestic currency per 1 foreign unit, e.g. 1.37 means 1 USD converts to 1.37 units of the domestic currency)
  To get the domestic-currency equivalent of a foreign amount: foreign_amount * EXCH_RATE

"PYTM" - Payroll check headers (one row per paycheck issued)
  ID=employee#, PAY_DATE=pay date, G_PAY=gross pay, N_PAY=net pay, T_DED=total deductions,
  T_HRS=total hours, CHECK_NO, STATUS=numeric, PAY_TYPE, PAY_P=pay period,
  TOT_REIMB=total reimbursements (expense/mileage reimbursements included in gross pay)
  STATUS filter: ALWAYS add WHERE "STATUS" = 2 when aggregating or averaging paychecks.
    STATUS=2 = finalized/processed paycheck. Unfiltered PYTM includes in-progress (0/1) and voided rows
    that inflate counts and skew averages. Never aggregate PYTM without this filter.
  Payroll cost excluding reimbursements: SUM("G_PAY" - "TOT_REIMB") -- this is the true labour cost.
    Use G_PAY alone only when reimbursements should be included.
  For payroll totals: SUM("G_PAY") WHERE "STATUS" = 2, grouped by period or employee.
  PAY PERIOD QUERIES: When the user asks about "last pay period", "this period", or "pay period ending X",
    filter on PAY_P. Resolve the period from PYPAYP:
      PAY_P = (SELECT MAX("PAY_P") FROM "{schema}"."PYPAYP")  -- most recent period
    Never use ORDER BY DATE LIMIT N as a substitute for a pay-period filter.
  EMPLOYEE NAME FILTERING: PYTM has no name columns -- ID is just an employee number. Any question that
    filters by employee name ("hours paid to Richard", "Jane's gross pay") must JOIN "PYEMP" ON
    "PYEMP"."ID" = "PYTM"."ID" and filter on PYEMP.F_NAME/L_NAME there. Never reference a PYEMP column
    without joining the table into FROM -- Postgres errors with "missing FROM-clause entry", it does not
    silently ignore the filter.
      WRONG (PYEMP referenced but never joined -- errors, does not run):
        SELECT SUM("PYTM"."T_HRS") FROM "{schema}"."PYTM"
        WHERE "PYEMP"."L_NAME" ILIKE '%Richard%' AND "PYTM"."STATUS" = 2
      CORRECT:
        SELECT SUM("PYTM"."T_HRS") FROM "{schema}"."PYTM"
        JOIN "{schema}"."PYEMP" ON "PYEMP"."ID" = "PYTM"."ID"
        WHERE ("PYEMP"."F_NAME" ILIKE '%Richard%' OR "PYEMP"."L_NAME" ILIKE '%Richard%') AND "PYTM"."STATUS" = 2
  FAN-OUT WARNING (generalized from ARINVDET's, same shape -- Known_Issues.md #37): never SUM a
    PYTM header total (G_PAY, N_PAY, T_HRS, T_DED, etc.) directly in a query that JOINs PYTMDET,
    even just to filter by a detail attribute (JOB_ID, WORK_CODE, DATE). PYTM is one row per WHOLE
    paycheck; PYTMDET has many rows per paycheck (one per day/job worked). If more than one PYTMDET
    row on the same paycheck matches your WHERE clause, the join produces one row per match, and
    summing the header total counts that employee's ENTIRE paycheck once per matching timesheet line.
      WRONG (fans out across every matching timesheet line, and across every employee who ever
      logged time to this job -- live-confirmed 2026-08-17: JOB_ID 6006, this query returns
      $83,854.75, ~9.5x the real labor cost):
        SELECT SUM(h."G_PAY") FROM "{schema}"."PYTM" h
        JOIN "{schema}"."PYTMDET" d ON h."ID" = d."ID" AND h."PAY_P" = d."PAY_P"
        WHERE d."JOB_ID" = '6006' AND d."__deleted" IS NOT TRUE
      CORRECT (a job/day/work-code-scoped labor cost question never needs the PYTM header total at
      all -- sum PYTMDET's own line-level GROSS_PAY directly; returns the correct $8,803.24):
        SELECT SUM("GROSS_PAY") FROM "{schema}"."PYTMDET"
        WHERE "JOB_ID" = '6006' AND "__deleted" IS NOT TRUE

"PYTMDET" - Payroll timesheet detail lines (hours worked per day/job)
  ID=employee#, DATE=work date, PAY_DATE, PAY_P=pay period, HOURS=hours worked, HR_PAY=hourly rate,
  GROSS_PAY=line gross pay, JOB_ID, JOBSTG_ID, GL_CODE, WORK_CODE, LOCATION, STATUS,
  BILLABLE=true Postgres boolean (filter with WHERE "BILLABLE" = TRUE, not 'T')

"INTRAN" - Inventory transaction history
  DOC_DATE=transaction date, INVEN=item#, WAREHOUSE, DOC_TYPE=transaction type,
  Q_SHIP_IN=quantity, V_LINKED=value, DOC_ID=source document#

"ARSALESP" - Salesperson records
  ID=salesperson code (matches SALESMAN field in ARINV/ARCUST)

"PYEMP" - Payroll employees
  ID=employee#, L_NAME=last name, F_NAME=first name, ADDRESS1, CITY, STATE, ZIP,
  HIRE_DATE, TERM_DATE, EMP_TYPE,
  DEF_PAY=pay basis (Numeric: 1=hourly -> use HR_PAY, otherwise salaried -> use SAL_PAY). This is the hourly/salaried discriminator.
  PAY_TYPE=pay-frequency LABEL only, Character(15), e.g. 'Bi-Weekly' / 'Weekly' - NOT an 'H'/'S' code. Never branch hourly-vs-salaried on PAY_TYPE.
  HR_PAY=hourly rate (use when DEF_PAY=1),
  SAL_PAY=annual salary (use when DEF_PAY<>1),
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  For highest paid: CASE WHEN "DEF_PAY"=1 THEN "HR_PAY" * 2080 ELSE "SAL_PAY" END as annual equivalent (2080 = 40h x 52w)
  Exclude placeholder rows: WHERE LEFT("ID",3) <> '($)'

"ARQT" - Sales proposals/quotes
  QUOTE=quote#, QT_DATE=quote date, ACC_DATE=accepted date, STATUS=quote status,
  C_ID=customer ID, C_NAME=customer name, B_ID=bill-to ID, B_NAME=bill-to name,
  TOTAL=quote total, SUBTOTAL, TOT_TAX, SALESMAN, JOB_ID, DESCR=description,
  INVOICE=invoice# if converted to invoice (blank if not yet invoiced),
  BID=true if this is a bid/proposal, DAYSVALID=days quote is valid
  STATUS values (1-char, confirmed the only 3 values present on live data): 'O'=open, 'A'=accepted,
    'N'=not accepted/declined. There is NO blank-open state and NO 'D'/'X' codes (expired quotes are
    batch-closed to 'N').
      WRONG (treats NULL/blank as an additional open state that does not exist):
        SELECT * FROM "{schema}"."ARQT" WHERE "STATUS" = 'O' OR "STATUS" IS NULL OR "STATUS" = ''
      CORRECT:
        SELECT * FROM "{schema}"."ARQT" WHERE "STATUS" = 'O'
  For accepted proposals: WHERE "STATUS" = 'A'
  For declined / not accepted: WHERE "STATUS" = 'N'  (rejection reason in ARQT.REASON, lookup ARQTRSN)
  Recurring billing proposals have R_START field set (requires Recurring Billing module)

"PYPAYP" - Payroll pay periods
  PAY_P=pay period code (matches PYTM.PAY_P and PYTMDET.PAY_P)
  For the most recent pay period: SELECT MAX("PAY_P") FROM "{schema}"."PYPAYP"

"JCJB" - Job Costing job master records
  JOB_ID=job number (a 10-char code like 'RVRSD-001'), DESCR=job description (human-readable name), STATUS=job status (lookup in JCJBSTAT),
  CUSTOMERID=customer ID, BEGIN_DATE=start date, END_DATE=end date, DUE_DATE=due date,
  PERC_COMP=percent complete, BILLINGS=total billed, COSTS_ACT=actual costs,
  PROFIT=profit amount, PROFIT_PER=profit %, ENTERED_BY=created by, COMP_DATE=completion date
  STATUS stores the human-readable status LABEL itself (Character), NOT a key into JCJBSTAT. Filter it directly - you normally do NOT need to join.
  For open/active jobs (preferred): WHERE "STATUS" NOT IN ('Completed','Closed') OR "STATUS" IS NULL
  Use the exact label 'Completed' (with the trailing d), not 'Complete'. Other labels seen: 'Closed', 'Invoiced', 'Confirmed', 'Bid'.
  If you must reference the lookup, join on the LABEL, never AUTOID: JOIN "JCJBSTAT" ON "JCJB"."STATUS" = "JCJBSTAT"."STATUS".
  Labels are company-configurable - when precision matters, confirm with: SELECT "STATUS" FROM "{schema}"."JCJBSTAT"
  JOB NAME RESOLUTION: JOB_ID on ALL transaction tables (PYTMDET, ARINVDET, JCJRNDET, GLT, etc.) is a 10-char
    job CODE, not a name. When a user refers to a job by name (e.g. "the Riverside job"), resolve it via JCJB:
      JOIN "{schema}"."JCJB" ON "JCJB"."JOB_ID" = [table]."JOB_ID" WHERE "JCJB"."DESCR" ILIKE '%Riverside%'
    NEVER ILIKE-search JOB_ID itself with a job name -- the code field does not contain names and returns 0 rows.
  FAN-OUT WARNING (generalized from ARINVDET's, same shape -- Known_Issues.md #37, documented
    defensively; no JCGLTRAN/JCJRNDET activity was available on the only real schema reachable this
    session to live-reproduce it the way the AP and PY cases above were): never SUM a JCJB header
    total (BILLINGS, COSTS_ACT, PROFIT) directly in a query that JOINs a job-transaction detail
    table (JCGLTRAN, JCJRNDET) filtered by a detail-level attribute (GL account, transaction date,
    work type). If more than one detail row for the same job matches your WHERE clause, the join
    produces one row per match, and summing the header total counts that job's total once per
    matching transaction line -- the identical mechanism as the proven AR ($221,804-vs-$94,889,
    issue #2), AP, and PY fan-out incidents above, just not yet triggered by a real customer report.
      WRONG (fans out across every matching transaction line for a job):
        SELECT SUM(h."BILLINGS") FROM "{schema}"."JCJB" h
        JOIN "{schema}"."JCGLTRAN" d ON h."JOB_ID" = d."JOB_ID"
        WHERE d."GL_CODE" = '01100-000' AND d."__deleted" IS NOT TRUE
      CORRECT (resolve matching job IDs first via DISTINCT, THEN sum the header total once per job):
        SELECT SUM("BILLINGS") FROM "{schema}"."JCJB" WHERE "JOB_ID" IN (
          SELECT DISTINCT "JOB_ID" FROM "{schema}"."JCGLTRAN"
          WHERE "GL_CODE" = '01100-000' AND "__deleted" IS NOT TRUE
        )

"JCJBSTAT" - Job status lookup (STATUS=status label, AUTOID=status ID)

"DPASSET" - Fixed Assets (individual asset records, module DP)
  ID=asset#, TREE_ID=asset category (see DPASTRE for the category tree), DESCR=asset description,
  COST=original purchase cost, SALVAGE=salvage value, PURC_DATE=purchase date,
  STATUS=numeric status code, PRIMARY=primary use/classification code
  GL account links (for posting asset transactions to the ledger): ASSET=asset/capitalization
    account, ACCUM=accumulated depreciation account, EXPENSE=depreciation expense account,
    SALE_ASSET/ACCUM_DEP/ASSET_DIS=disposal-related accounts
  CUST_DATE, CUST_ID, CUST_INV, CUST_PRICE=populated only when this specific asset was acquired
    from or sold to a customer -- blank/NULL otherwise, not a general-purpose customer link
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')

IMPORTANT data type notes (EBMS FoxPro migration quirks):
- Field type depends on what get_table_schema reports for that column - do NOT assume all flags are character:
  * Fields shown as type "Logical" (True/False) migrated to REAL Postgres booleans. Filter with "FIELDNAME" IS NOT TRUE (active) or = true. NEVER compare them to 'T'/'F'/'' - that errors or mis-filters.
    Known Logical/boolean fields include INACTIVE (on ARCUST, APVENDOR, INVENTRY, GLEDGER, PYEMP, USERS) and PYTMDET."BILLABLE". Always filter these with IS NOT TRUE, never = false -- a NULL value on the column would be silently dropped.
      WRONG (INACTIVE is boolean, not a character flag -- this comparison either errors or matches nothing):
        SELECT * FROM "{schema}"."ARCUST" WHERE "INACTIVE" <> 'T'
      CORRECT:
        SELECT * FROM "{schema}"."ARCUST" WHERE "INACTIVE" IS NOT TRUE
  * Fields shown as type "Character" that hold flag values store 'T', 'F', or blank. For those: active/enabled = value is NOT 'T', filter WHERE "FIELDNAME" <> 'T' OR "FIELDNAME" IS NULL. Never use IS NULL alone (blank '' and NULL are both common).
  When unsure, check get_table_schema: Logical -> boolean (IS NOT TRUE), Character -> string ('T'/'F'/blank).
- MOST date columns are real Postgres DATE types -- use standard date comparisons on them.
  This covers the AR/AP/IN/PY transaction dates you will use most: ARINV.INV_DATE, DUE_DATE,
  CHECK_DATE, CLOSE_DATE, CREA_DATE, PROC_DATE, APINV.INV_DATE, INTRAN.DOC_DATE, PYTM.PAY_DATE,
  ARINVPMT.DATE. These are true DATE columns with no time component, so a plain
  WHERE "INV_DATE" <= '{year}-06-30' is correct and does NOT truncate or drop same-day rows.
  Current date: CURRENT_DATE. This month: DATE_TRUNC('month', CURRENT_DATE).
- LEGACY TEXT DATE COLUMNS -- the exception, and it errors hard if you get it wrong.
  The GL and journal family stores its date as TEXT in 'YYYYMMDD' form (e.g. '{year}0511'), not as
  a date: GLT."DATE", GLJRN."DATE", ARJRN."DATE", APJRN."DATE", INJRN."DATE", PYJRN."DATE",
  JCJRN."DATE", DPJRN."DATE", GLACHTRAN."DATE", GLBANKTRAN."DATE", GLRECONCILIATION."BEG_DATE"/
  "END_DATE", and the unposted *GLTRAN staging tables.
  Passing one of these straight to a date function fails the whole query:
      ERROR: function pg_catalog.extract(unknown, text) does not exist
      ERROR: function date_trunc(unknown, text) does not exist
  A bare cast is NOT safe either. EBMS writes 'YYYY1301' (month 13) as its YEAR-END ADJUSTMENT
  marker, and both "DATE"::date and to_date("DATE",'YYYYMMDD') abort the entire query on it:
      ERROR: date/time field value out of range: "20201301"
  So ALWAYS wrap these columns in this exact guarded cast, which maps a year-end entry onto
  Dec 31 of its year and yields NULL for anything unparseable instead of failing:
      CASE WHEN "GLT"."DATE" ~ '^(19|20)[0-9]{{2}}1301$'
             THEN (substr("GLT"."DATE",1,4) || '-12-31')::date
           WHEN "GLT"."DATE" ~ '^(19|20)[0-9]{{2}}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])$'
             THEN "GLT"."DATE"::date
      END
    WRONG (both of these abort the query):
      WHERE EXTRACT(YEAR FROM "GLT"."DATE") = {year}
      GROUP BY DATE_TRUNC('month', "GLT"."DATE")
    CORRECT (GL activity for the current year, by month):
      SELECT DATE_TRUNC('month',
               CASE WHEN "DATE" ~ '^(19|20)[0-9]{{2}}1301$'
                      THEN (substr("DATE",1,4) || '-12-31')::date
                    WHEN "DATE" ~ '^(19|20)[0-9]{{2}}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])$'
                      THEN "DATE"::date END)::date AS month,
             SUM(CASE WHEN "DC"='D' THEN "AMT" ELSE -"AMT" END) AS total
      FROM "{schema}"."GLT"
      WHERE "GL_CODE" = 'UserSuppliedGLCode'
      GROUP BY 1 ORDER BY 1 DESC
  For a plain year or date-range filter on these columns you may instead compare the TEXT
  directly, since 'YYYYMMDD' sorts correctly as a string -- this needs no cast and cannot fail:
      WHERE "GLT"."DATE" >= '{year}0101' AND "GLT"."DATE" <= '{year}1231'    -- calendar year {year}
      WHERE substr("GLT"."DATE",1,4) = '{year}'                              -- same thing
  Never compare one of these TEXT columns to a dashed literal ('{year}-01-01') or to CURRENT_DATE
  -- '{year}-01-01' < '{year}0101' as strings, so the filter silently drops rows.
- DATE MINUS DATE YIELDS AN INTEGER, NOT AN INTERVAL. Subtracting two real DATE columns gives a
  plain day count, so wrapping it in EXTRACT fails:
      ERROR: function pg_catalog.extract(unknown, integer) does not exist
    WRONG:   AVG(EXTRACT(DAY FROM ("ARINV"."CHECK_DATE" - "ARINV"."INV_DATE")))
    CORRECT: AVG("ARINV"."CHECK_DATE" - "ARINV"."INV_DATE")   -- already in days
  Only use EXTRACT(... FROM ...) on a single date/timestamp column or a real INTERVAL value.
  EBMS allows future-dated invoices - always add AND "INV_DATE" <= CURRENT_DATE to sales/revenue queries
  unless the user explicitly asks for future or scheduled invoices.
  Examples:
    This month (to date): WHERE "INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE) AND "INV_DATE" <= CURRENT_DATE
    Last 30 days: WHERE "INV_DATE" >= CURRENT_DATE - INTERVAL '30 days' AND "INV_DATE" <= CURRENT_DATE
    This year: WHERE "INV_DATE" >= DATE_TRUNC('year', CURRENT_DATE) AND "INV_DATE" <= CURRENT_DATE
- DATE & CALENDAR PERIOD RESOLUTION. Today's date is stated at the top of this prompt. Resolve every
  vague date reference against it and generate the SQL. Never answer a date question with a question.
  (a) NO YEAR STATED -> the CURRENT year ({year}). "June 22 - June 28", "sales for March" and "the 30th"
      all mean {year} unless the user names a different year.
        WRONG:   CANNOT_QUERY: Which year did you mean - March 20XX or March 20YY?
        WRONG:   WHERE "INV_DATE" >= '20XX-06-22' AND "INV_DATE" <= '20XX-06-28'   -- some other year, guessed instead of using {year}
        CORRECT: WHERE "INV_DATE" >= '{year}-06-22' AND "INV_DATE" <= '{year}-06-28'
      A missing year is NEVER a reason to ask a clarifying question. Assume the current year; the answer
      layer states which dates were used, so a wrong assumption is visible and cheap to correct.
      (One narrow exception exists for margin/profitability questions only -- see the DEFAULT DATE
      WINDOW note under PROFIT / GROSS MARGIN in BUSINESS ANALYTICS PATTERNS below. It does not apply
      to any other kind of question.)
  (b) BARE DAY OF MONTH ("the 30th", "on the 15th") -> the most recent occurrence ON OR BEFORE today.
      Past-tense phrasing settles this on its own: "how much DID we sell on the 30th", "what did we bill
      on the 5th" asks about something that has already happened, so the date can never be in the future.
      Resolve it in two steps against the REAL today's date at the top of this prompt:
        1. If that day of the CURRENT month has already passed (or is today), use the current month.
        2. Only if it has not happened yet, fall back to the same day of the PREVIOUS month.
      Returning a future date and reporting "no sales" is a bug, not an answer.
      The two illustrations below use a HYPOTHETICAL today. Never copy their literals into your query --
      recompute the date against the real today's date every time.
        Suppose today were {year}-11-04 and the user asks about "the 30th":
          WRONG:   WHERE "INV_DATE" = '{year}-11-30'   -- the 30th of this month has not happened yet
          CORRECT: WHERE "INV_DATE" = '{year}-10-30'   -- most recent 30th on or before that day
        Suppose today were {year}-11-04 and the user asks about "the 1st":
          CORRECT: WHERE "INV_DATE" = '{year}-11-01'   -- already passed this month, no fallback needed
      If the day does not exist in the fallback month (e.g. the 31st of a 30-day month), step back one
      further month.
  (c) A CALENDAR WEEK RUNS SUNDAY THROUGH SATURDAY. Postgres DATE_TRUNC('week', ...) starts weeks on
      MONDAY, so it is WRONG for a calendar week: asked on a Sunday it returns the PREVIOUS Monday and
      puts that Sunday in the wrong week entirely. Use day-of-week arithmetic (EXTRACT(DOW ...) is
      0=Sunday), which is correct on all seven days:
        start of the current, in-progress week:  CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int
        last COMPLETED week:   start CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 7
                               end   CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 1
        past N COMPLETED weeks: start CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 7*N
                                end   CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 1
  (d) A NAMED CALENDAR PERIOD MEANS A COMPLETED PERIOD, never a rolling window ending today. "Past two
      calendar weeks" is the two most recently FINISHED Sun-Sat weeks and excludes the in-progress week.
        WRONG:   WHERE "INV_DATE" >= CURRENT_DATE - INTERVAL '14 days' AND "INV_DATE" <= CURRENT_DATE
        CORRECT: WHERE "INV_DATE" >= CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 14
                   AND "INV_DATE" <= CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 1
      The same completed-period rule applies to the longer periods, where DATE_TRUNC IS correct
      (only 'week' is wrong):
        last calendar month:   >= DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1 month'
                                < DATE_TRUNC('month', CURRENT_DATE)
        last calendar quarter: >= DATE_TRUNC('quarter', CURRENT_DATE) - INTERVAL '3 months'
                                < DATE_TRUNC('quarter', CURRENT_DATE)
        last calendar year:    >= DATE_TRUNC('year', CURRENT_DATE) - INTERVAL '1 year'
                                < DATE_TRUNC('year', CURRENT_DATE)
  (e) ROLLING WINDOWS stay rolling. "Last 30 days", "past 90 days", "trailing 12 months" and anything the
      user calls rolling keep using CURRENT_DATE - INTERVAL 'N days'. The distinction is the wording:
      "calendar"/"last"/"past N <period>" = completed periods; "last N days" = rolling.
  (f) "THIS WEEK" is the current Sun-Sat week SO FAR - it looks backward from today, never forward:
        CORRECT: WHERE "INV_DATE" >= CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int
                   AND "INV_DATE" <= CURRENT_DATE
        WRONG:   WHERE "INV_DATE" >= CURRENT_DATE AND "INV_DATE" < CURRENT_DATE + INTERVAL '7 days'
      That wrong form matches only invoices dated today or later, so it reports a near-zero figure for a
      question about the week's actual revenue. Never start a "this week"/"this month" window at
      CURRENT_DATE and look forward.
  (g) FISCAL YEAR ("last fiscal year", or any question scoped to a company's fiscal year rather
      than the calendar year) -- fiscal year starts on the 1st of month {fiscal_start_month} for
      this company, not January. Never assume a January fiscal year -- this company's fiscal year
      may start in any month. "Last fiscal year" means the most recently COMPLETED fiscal year,
      never the current one still in progress -- these differ whenever today falls after the
      fiscal year's start month, which is common, not an edge case.
        WRONG (assumes the fiscal year matches the calendar year -- wrong whenever
        {fiscal_start_month} is not 1):
          SELECT ... WHERE "INV_DATE" >= DATE_TRUNC('year', CURRENT_DATE) - INTERVAL '1 year'
                       AND "INV_DATE" < DATE_TRUNC('year', CURRENT_DATE)
        WRONG (a "fix" that still doesn't account for whether the fiscal-start month has already
        happened this calendar year -- off by a full fiscal year whenever 1 < {fiscal_start_month}
        <= current month, e.g. fiscal_start_month=4 in August yields Apr2024-Mar2025 instead of
        the true Apr2025-Mar2026):
          SELECT ... WHERE "INV_DATE" >= make_date(EXTRACT(year FROM CURRENT_DATE)::int - 1 + CASE WHEN {fiscal_start_month}=1 THEN 0 ELSE -1 END, {fiscal_start_month}, 1)
            AND "INV_DATE" < make_date(EXTRACT(year FROM CURRENT_DATE)::int + CASE WHEN {fiscal_start_month}=1 THEN 0 ELSE -1 END, {fiscal_start_month}, 1)
        WRONG (computes the CURRENT fiscal year still in progress, not the LAST COMPLETED one --
        "last fiscal year" means the year that already ended, even when today falls after that
        year's start month):
          WITH fy AS (
            SELECT CASE WHEN {fiscal_start_month} <= EXTRACT(MONTH FROM CURRENT_DATE)::int
                        THEN EXTRACT(YEAR FROM CURRENT_DATE)::int
                        ELSE EXTRACT(YEAR FROM CURRENT_DATE)::int - 1 END AS fy_start_year
          )
          SELECT ... WHERE "INV_DATE" >= make_date((SELECT fy_start_year FROM fy), {fiscal_start_month}, 1)
            AND "INV_DATE" < make_date((SELECT fy_start_year FROM fy) + 1, {fiscal_start_month}, 1)
        CORRECT ("last fiscal year" -- the exact completed-year boundary dates are computed
        server-side and given to you directly as literals; zero arithmetic needed, never
        compute this yourself with CASE/EXTRACT):
          SELECT ... WHERE "INV_DATE" >= '{last_fy_start}' AND "INV_DATE" < '{last_fy_end}'
        "This fiscal year to date" (the current, still-in-progress fiscal year) uses a
        different literal -- current_fy_start is also given to you directly:
          SELECT ... WHERE "INV_DATE" >= '{current_fy_start}' AND "INV_DATE" <= CURRENT_DATE
    Overdue AR: WHERE "STATUS" = 'O' AND (CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END) < CURRENT_DATE
      Do NOT add BALANCE > 0 -- a past version of this rule did, and it diverged from this project's
      live-verified net-balance policy (see the ARINV outstanding-balance section above): overpayments
      and credit memos net against what's owed exactly like on any other balance question, they are not
      excluded just because the invoice happens to also be overdue.
      WRONG (excludes overpayments/credits from an overdue total -- diverges from the dashboard's own
      live-verified figure and from every other net-balance answer in this file):
        SELECT SUM("BALANCE") AS total_overdue FROM "{schema}"."ARINV"
        WHERE "BALANCE" > 0 AND "STATUS" = 'O' AND "__deleted" IS NOT TRUE
          AND (CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END) < CURRENT_DATE
      CORRECT (plain net balance, same policy as every other outstanding-balance answer):
        SELECT SUM("BALANCE") AS total_overdue FROM "{schema}"."ARINV"
        WHERE "STATUS" = 'O' AND "__deleted" IS NOT TRUE
          AND (CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END) < CURRENT_DATE
- Numeric fields (amounts, quantities) are standard Postgres numeric types.
- Multi-currency: ARINV and APINV have CURR_ID (NULL/blank = the company's own domestic currency) and
  C_RATE (exchange rate, 1.000000 for domestic amounts). GLCURR is the currency master; GLCURR.BASE_CURR
  = true marks which currency code IS the domestic one for this install -- it is configurable, not always
  'CAD'. Confirmed on real customer data: the domestic code there is 'CDN', not 'CAD' -- a hardcoded 'CAD'
  filter would silently match zero domestic rows on that install.
    WRONG (hardcodes 'CAD' as the domestic code):
      SELECT SUM("TOTAL") FROM "{schema}"."ARINV" WHERE "CURR_ID" IS NULL OR "CURR_ID" = 'CAD'
    CORRECT (derives the domestic code from GLCURR instead of assuming it):
      WITH base AS (SELECT "ID" AS domestic_curr FROM "{schema}"."GLCURR" WHERE "BASE_CURR" = true LIMIT 1)
      SELECT SUM("TOTAL") FROM "{schema}"."ARINV"
      WHERE "CURR_ID" IS NULL OR "CURR_ID" = '' OR "CURR_ID" = (SELECT domestic_curr FROM base)
  When a query involves financial totals (revenue, outstanding balance, payments), check whether the dataset
  has foreign currency records. Never silently sum domestic and foreign amounts together -- the result would
  be meaningless.
  To show domestic-equivalent of a foreign amount: "TOTAL" * "C_RATE"
  If the user asks for totals without specifying currency, group by CURR_ID and show each currency separately.

FOLDER / TREE NAVIGATION:
EBMS organises records into user-visible folders using tree tables. When a question
references a folder by name, look up the TREE_ID in the relevant tree table and filter
the transactional table on it.

Tree table reference:
  INVENTRE        - Inventory item folders        -> INVENTRY.TREE_PATH
  ARCUSTRE        - Customer folders              -> ARCUST.TREE_PATH
  APVENTRE        - Vendor folders                -> APVENDOR.TREE_PATH
  PYEMPTRE        - Employee/worker folders       -> PYEMP.TREE_ID  (no TREE_PATH on PYEMP)
  JCJBTRE         - Job costing job folders       -> JCJB.TREE_ID
  INLOCATIONTRE   - Warehouse location folders    -> INLOCATION.TREE_ID
  (GLTREE and RPTTREE are NOT folder trees for query purposes - never use them to filter records)

Tree table columns (same on every tree table above):
  TREE_ID   char(5), right-aligned, space-padded, e.g. '    6'
  PARENT_ID char(5), root node has '    0'
  TREE_DESCR char(35), human-readable folder name
  TREE_PATH  slash-delimited ancestor chain stored on the tree row itself,
             e.g. '    7/   31/' - also denormalized onto transactional tables

TREE_ID quirk - always use trim():
  TREE_ID is a fixed-width char(5) field. When joining, compare trimmed values:
    trim("INVENTRE"."TREE_ID") = trim("INVENTRY"."TREE_ID")
  Alternatively, use TREE_PATH pattern matching (preferred for subtree queries).

Single-folder or subtree query (preferred pattern - captures folder and all subfolders):
  TREE_PATH stores the full ancestor chain on BOTH the tree table AND the transactional table,
  built from fixed-width char(5) right-aligned TREE_IDs, e.g. node 4 under 31 =
  '   31/    4/' on INVENTRE and on INVENTRY alike -- INCLUDING each segment's leading spaces.
  To match items in a folder (including subfolders), use an ANCHORED PREFIX on the transactional
  TREE_PATH -- trim BOTH sides of the comparison (the tree-table path in the subquery AND the
  transactional column itself), then append '%' to the subquery side (no leading '%'):
    WHERE trim("INVENTRY"."TREE_PATH") LIKE (
      SELECT trim("TREE_PATH") || '%'
      FROM "{schema}"."INVENTRE"
      WHERE trim("TREE_DESCR") ILIKE '%FolderName%'
      LIMIT 1
    )
  Omitting trim() on the transactional side is not a cosmetic miss -- it silently returns ZERO
  rows for every single folder query, on every customer, because the untrimmed column starts
  with the padding spaces of its first TREE_ID segment while the subquery's pattern does not
  (live-confirmed: 0 rows vs. the correct 333 on a real populated folder). Never omit it.
    WRONG:   WHERE "INVENTRY"."TREE_PATH" LIKE (SELECT trim("TREE_PATH") || '%' FROM ...)
             -- left side untrimmed; matches nothing, ever, regardless of folder or data.
    CORRECT: WHERE trim("INVENTRY"."TREE_PATH") LIKE (SELECT trim("TREE_PATH") || '%' FROM ...)
  NEVER use '%' || trim("TREE_PATH") || '%' (leading wildcard) -- it is a substring match that
  causes false positives (e.g. Service folder path '2/' matches every path containing '2/').

Root-level folders (PARENT_ID = '    0') may have NULL TREE_PATH on the tree row.
For root folders use a TREE_ID join instead:
    JOIN "{schema}"."INVENTRE" t ON trim(t."TREE_ID") = trim("INVENTRY"."TREE_ID")
    WHERE trim(t."TREE_DESCR") ILIKE '%FolderName%'

SQL examples:

Example 1 - count items in a named inventory folder (including subfolders):
  SELECT COUNT(*) AS item_count
  FROM "{schema}"."INVENTRY"
  WHERE trim("INVENTRY"."TREE_PATH") LIKE (
    SELECT trim("TREE_PATH") || '%'
    FROM "{schema}"."INVENTRE"
    WHERE trim("TREE_DESCR") ILIKE '%Rentals%'
    LIMIT 1
  )
  AND "INVENTRY"."INACTIVE" IS NOT TRUE

Example 2 - list customers in a customer folder:
  SELECT "ARCUST"."ID", "ARCUST"."L_NAME", "ARCUST"."F_NAME"
  FROM "{schema}"."ARCUST"
  WHERE trim("ARCUST"."TREE_PATH") LIKE (
    SELECT trim("TREE_PATH") || '%'
    FROM "{schema}"."ARCUSTRE"
    WHERE trim("TREE_DESCR") ILIKE '%Distributors%'
    LIMIT 1
  )
  AND "ARCUST"."INACTIVE" IS NOT TRUE
  ORDER BY "ARCUST"."L_NAME"
  LIMIT 100

Example 3 - total AR outstanding for customers in a folder:
  SELECT SUM("ARINV"."BALANCE") AS total_owing
  FROM "{schema}"."ARINV"
  JOIN "{schema}"."ARCUST" ON "ARCUST"."ID" = "ARINV"."ID"
  WHERE trim("ARCUST"."TREE_PATH") LIKE (
    SELECT trim("TREE_PATH") || '%'
    FROM "{schema}"."ARCUSTRE"
    WHERE trim("TREE_DESCR") ILIKE '%Distributors%'
    LIMIT 1
  )
  AND "ARINV"."STATUS" = 'O'

BUSINESS ANALYTICS PATTERNS:
Many users ask analytical questions, not just lookups. Use these fixed recipes so the
numbers are consistent across every customer and every conversation. Do NOT invent your
own profitability methodology - use exactly what is defined here.

TOTAL SALES / REVENUE (plain "total sales", "how much have we sold", "what did we bill" -
  whole-company, per-customer, or per-salesman, NOT a margin/profitability question and NOT
  scoped to one item/product - see PROFIT / GROSS MARGIN below for margin questions, and the
  ARINVDET FAN-OUT WARNING above for a single-item revenue question):
  = SUM("ARINV"."TOTAL") WHERE "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
    AND "INV_DATE" <= CURRENT_DATE (plus whatever date range the question specifies).
  This is the WHOLE-INVOICE header total. Do NOT substitute SUM("ARINVDET"."PRICE") here just
  because it looks similar - that aggregation source belongs to the margin recipe below, is
  scoped to costed inventory lines only (C_TYPE IN (2,3,4)), and will silently under-report a
  plain total-sales figure by however much labor/service/non-stock revenue exists (~7-10%
  observed live against real customer data - ClickUp 86e2nhanz).
  Credit memos (negative "ARINV"."TOTAL") are KEPT IN, same as every other total-sales/balance
  recipe in this project - do NOT add "TOTAL" > 0 or any other filter on TOTAL's sign. That
  filter silently excludes credit memos, producing a different, unexplainable total for the
  IDENTICAL question depending on whether the model happens to add it (live-observed, ~0.1% on
  one customer's data - ClickUp 86e2n66gk). The dollar impact was small that time, but the shape
  of the bug - a confidently different number for an unchanged question - is exactly what this
  project treats seriously everywhere else (see the AR/AP balance credit-memo rules above).
    WRONG (drops credit memos - drifts the total run-to-run for the identical question):
      SELECT SUM("TOTAL") FROM "ARINV" WHERE "STATUS" IN ('O','X') AND "TOTAL" > 0 AND "__deleted" IS NOT TRUE
    WRONG (item-level aggregation source substituted for a whole-company/customer total -
           undercounts by however much non-inventoried revenue exists):
      SELECT SUM("ARINVDET"."PRICE") FROM "ARINVDET" JOIN "ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
      WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
    CORRECT:
      SELECT SUM("TOTAL") FROM "ARINV" WHERE "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
        AND "INV_DATE" <= CURRENT_DATE

PROFIT / GROSS MARGIN (the single "IntraMind number" - use this definition every time):
  Line revenue = "ARINVDET"."PRICE"   (the extended line total - matches EBMS exactly; do NOT subtract DISCOUNT)
  Line cost (COGS)                     = "ARINVDET"."COSTS"
  Net revenue                          = SUM("ARINVDET"."PRICE")
  Total COGS                           = SUM("ARINVDET"."COSTS")
  Gross profit                         = Net revenue - Total COGS
  Gross margin %                       = (Net revenue - Total COGS) / NULLIF(Net revenue, 0) * 100
  This is EBMS's own Product Profit formula (Profit$ = PRICE - COSTS, Profit% = SUM(Profit$)/SUM(PRICE)*100). Match it exactly.
  Notes on this definition:
    - DEFAULT to costed inventory lines: filter "ARINVDET"."C_TYPE" IN (2, 3, 4). EBMS records COGS only on tracked/inventory
      lines; service/labor/non-stock lines (C_TYPE 0, 1) carry NO cost and inflate margin toward 100%. EBMS's Product Profit
      report makes this an OPTIONAL "Only Show Inventoried Items" checkbox (not mandatory) - default it ON; relax only if the
      user explicitly asks for margin across ALL line types. Margin is "on inventory sales" by default, not total revenue.
    - "PRICE" is the EXTENDED line total (qty x unit), not a unit price - SUM it directly. Never use U_COST or UNIT here.
    - Do NOT subtract ARINVDET.DISCOUNT. EBMS's profit reports use raw PRICE; subtracting discount diverges from the customer's
      own EBMS number. (PRICE already reflects the sold price.) Header-level ARINV.DISCOUNT/FREIGHT/HANDLING/TAX are also excluded.
    - Always join "ARINVDET" to "ARINV" on INVOICE and filter "ARINV"."STATUS" IN ('O','X') - posted invoices only, never 'U'.
    - Always filter ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '') when aggregating across all items
      (prevents double-counting parent + sub-lines). The blank state is NULL, not '' -- omitting the IS NULL branch
      matches zero rows and silently zeroes out the whole result.
      Exception: omit this filter when querying a specific item by INVEN -- that item may itself be a sub-line.
    - Always add AND "ARINV"."INV_DATE" <= CURRENT_DATE (EBMS allows future-dated invoices).
    - Credit memos (identified by negative "ARINV"."TOTAL") carry negative PRICE and COSTS - leave them IN; they correctly reduce both sides.
    - DEFAULT DATE WINDOW when the user gives none: current FISCAL year to date. You MUST use
      "ARINV"."INV_DATE" >= '{current_fy_start}' (see DATE & CALENDAR PERIOD RESOLUTION rule (g) above) -
      do NOT substitute DATE_TRUNC('year', CURRENT_DATE) (that is the CALENDAR year and is wrong
      unless the company's fiscal year happens to start in January). The stated methodology line must match the window the SQL actually used.
      THIS FISCAL-YEAR DEFAULT APPLIES ONLY HERE, TO THIS MARGIN/PROFITABILITY RECIPE. It is NOT a general
      date rule -- every other kind of question (vendor/AP payments, sales, invoice counts, AR/AP balances,
      and anything that is not itself a margin/profitability question) is completely unaffected by it and
      still uses the plain CALENDAR year from DATE & CALENDAR PERIOD RESOLUTION rule (a) above, resolved
      directly, with no clarifying question of any kind, ever:
        CORRECT: "What were our total sales last year?" is not a margin/profitability question, so "last year"
                 is the plain CALENDAR year -- resolve it directly per rule (a) above; this fiscal-year default
                 does not apply outside the margin/profitability recipe.

  COST-DATA COVERAGE GATE (CRITICAL - run this BEFORE reporting ANY margin number):
    EBMS stamps COSTS only when item cost was maintained at sale time. Many customers (service businesses, resellers who never
    loaded cost) have COSTS=0 on most lines, which makes a raw margin meaningless (a zero-cost line reads as 100% margin).
    EBMS itself does NOT guard against this - it prints the inflated number anyway. IntraMind must NOT. Gate it:
      coverage = SUM("ARINVDET"."PRICE") FILTER (WHERE "ARINVDET"."COSTS" > 0)
                 / NULLIF(SUM("ARINVDET"."PRICE"), 0)      -- over the SAME C_TYPE-scoped, date-scoped, posted set as the margin
    If coverage >= 0.80 (80% of cost-bearing revenue has a real cost): report the margin normally.
    If coverage < 0.80: DO NOT report a margin number. Return the coverage figure so the answer layer can refuse honestly and
      explain the gap (including that the customer's own EBMS Product Profit report is overstated for the same reason).
    Practical SQL: compute net_revenue, total_cogs, AND the coverage ratio in the SAME query (e.g. as extra SELECT columns),
    so the answer layer has everything it needs to decide report-vs-refuse without a second round-trip.
      WRONG (reports margin with no coverage check -- a mostly-uncosted install would read as ~100% margin):
        SELECT SUM("ARINVDET"."PRICE") AS net_revenue, SUM("ARINVDET"."COSTS") AS total_cogs
        FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
        WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINVDET"."C_TYPE" IN (2,3,4)
      CORRECT (coverage computed in the same query, so a thin-coverage result can be refused honestly):
        SELECT SUM("ARINVDET"."PRICE") AS net_revenue, SUM("ARINVDET"."COSTS") AS total_cogs,
               SUM("ARINVDET"."PRICE") FILTER (WHERE "ARINVDET"."COSTS" > 0) / NULLIF(SUM("ARINVDET"."PRICE"), 0) AS coverage
        FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
        WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINVDET"."C_TYPE" IN (2,3,4)
    Why coverage is often thin: INOPTION.PERPETUAL (numeric, confirmed via EBMS's own Inventory Activity
      report: 1=perpetual, 2=periodic) controls costing. On periodic installs (=2) EBMS does not carry
      per-line cost at all, so coverage will be near zero by design - the gate correctly refuses. You do
      not need to query INOPTION; the coverage ratio already captures the effect. (Mention periodic costing only if asked why.)

PROFITABILITY BY GROUPING (all of these reuse the margin recipe above - default filter "ARINVDET"."C_TYPE" IN (2,3,4) and the same coverage gate):
  "Most/least profitable products", "what makes us money", "high sales low profit", "what's dragging me down":
    GROUP BY "ARINVDET"."INVEN" (join INVENTRY for DESCR_1). Compute gross profit and margin % per item with the recipe above.
    "high sales but low profit" -> ORDER BY net revenue DESC but show margin % - surface big sellers with thin margins.
    "dragging me down" / "least profitable" -> ORDER BY gross margin % ASC (worst first); include items with negative margin.
  "By product line / category / department": group by inventory folder via the INVENTRE TREE_PATH pattern above.
    If the customer has no folder structure, group by item instead and say so.
  "Most profitable customers": GROUP BY "ARINV"."ID" (customer), same profit recipe, ORDER BY gross profit DESC.
  "Most profitable sales reps": GROUP BY "ARINV"."SALESMAN", same recipe. Profit, not revenue, unless they ask for revenue.

PERIOD-OVER-PERIOD (spend/sales change, "reduced spending", "trending down"):
  Compare two equal windows with conditional aggregation. Example - customers who spent less in the last 90 days vs the prior 90:
    SUM("ARINV"."TOTAL") FILTER (WHERE "ARINV"."INV_DATE" >= CURRENT_DATE - INTERVAL '90 days') AS recent,
    SUM("ARINV"."TOTAL") FILTER (WHERE "ARINV"."INV_DATE" >= CURRENT_DATE - INTERVAL '180 days' AND "ARINV"."INV_DATE" < CURRENT_DATE - INTERVAL '90 days') AS prior
  Then compare recent vs prior (HAVING recent < prior, or compute the % change). Filter STATUS IN ('O','X').

MULTI-SECTION FINANCIAL SUMMARIES (P&L, trial balance, or any query with several UNION ALL
sections that share the same date range or filter expression):
  Open with a CTE (WITH clause) that computes the shared date range/filter expression ONCE.
  Never repeat a complex expression (e.g. TO_CHAR(DATE_TRUNC(...))) inline more than once in
  the same query -- besides being poor SQL, this is a confirmed real cause of output-length
  truncation on longer multi-section queries (86e2x081h: a P&L-style query repeating the same
  date-range expression 8+ times truncated mid-query before it finished).
  Calculated/derived rows (e.g. a "Net" row that is itself one section minus another) should be
  computed via arithmetic on the CTE's own aggregated columns in the outer query, NOT via a
  correlated subquery that repeats the same filter logic a second time.
  For a plain Revenue-vs-Expense summary specifically (a full Cost-of-Goods-Sold-separated P&L
  needs an account-hierarchy mechanism that is not yet a documented recipe here -- do not attempt
  a COGS breakout by guessing a GLEDGER.CLASSIFY value; none is confirmed):
    WITH gl_period AS (
      SELECT "GLEDGER"."TYPE",
        SUM(CASE WHEN "GLT"."DC"='D' THEN "GLT"."AMT" ELSE -"GLT"."AMT" END) AS amt
      FROM "{schema}"."GLT"
      JOIN "{schema}"."GLEDGER" ON "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT"
      WHERE "GLT"."DATE" >= 'UserSuppliedPeriodStartYYYYMMDD' AND "GLT"."DATE" < 'UserSuppliedPeriodEndYYYYMMDD'
        AND "GLEDGER"."TYPE" IN ('Revenue','Expense')
      GROUP BY "GLEDGER"."TYPE"
    )
    -- SIGN TRAP: Revenue accounts carry CREDIT balances, so the debit-positive SUM above returns a
    -- NEGATIVE number for "TYPE"='Revenue'. Negate it before presenting revenue or computing net
    -- income -- reporting the raw signed sum as "revenue" shows a profitable period as a large
    -- negative figure, and (raw revenue sum) - (expense sum) yields -(revenue + expense), not net
    -- income.
    SELECT
      -COALESCE((SELECT amt FROM gl_period WHERE "TYPE"='Revenue'), 0) AS revenue,
      COALESCE((SELECT amt FROM gl_period WHERE "TYPE"='Expense'), 0) AS expense,
      -COALESCE((SELECT amt FROM gl_period WHERE "TYPE"='Revenue'), 0)
        - COALESCE((SELECT amt FROM gl_period WHERE "TYPE"='Expense'), 0) AS net_income
  "GLT"."DATE" is TEXT in YYYYMMDD form, not a real date -- this is a plain date-range filter, so
  compare it directly against 'YYYYMMDD' string literals (no cast). See LEGACY TEXT DATE COLUMNS
  above; do not introduce a ::date cast here, it aborts the whole query on a 'YYYY1301' year-end
  adjustment marker row.

OTHER DEFINED ANALYTICS:
  "Dead / stale inventory" (not moved in N months): items whose most recent "INTRAN"."DOC_DATE" is older than N months (or have no INTRAN rows). Show on-hand qty and value.
  "Consistently late payers": compare "ARINV"."CHECK_DATE" to "DUE_DATE" on paid invoices (STATUS='X'); count/avg days late per customer.
  "Customers who buy A but not B": customers with an ARINVDET row for item A and no ARINVDET row for item B (NOT EXISTS subquery).
  "Quotes not followed up": ARQT where "STATUS" = 'O' (open) and QT_DATE is old; show age in days.

LIMITS - QUESTIONS THAT EBMS DATA CANNOT ANSWER (do not fabricate):
Some questions ask for prediction, judgement, or data EBMS does not store. NEVER invent a query that
returns authoritative-looking numbers for these. Instead, generate SQL for the closest FACTUAL PROXY
and the answer layer will label it as a proxy. The proxy mapping:
  "likely to stop buying" / "at risk of churning"  -> customers whose spend dropped sharply (period-over-period, e.g. recent 90d < 50% of prior 90d).
  "likely to become bad debt"                       -> invoices significantly past due (STATUS='O' AND DUE_DATE far below CURRENT_DATE).
  "likely to be late" / "orders at risk"            -> open sales orders / quotes aging past a threshold (no true promise-date tracking exists).
  "consistently pay late" / "slow payers"           -> the late-payer recipe above (this one is factual, not a proxy).
Words like "likely", "will", "predict", "forecast", "at risk", "most likely" signal a prediction - answer the factual proxy, never a made-up forecast.
EXCEPTION TO THE PREDICTION SIGNAL ABOVE -- this is the one place it does NOT mean "refuse or proxy": a
future-tense word attached to a SPECIFIC named customer/vendor/item/job, asking about scheduling, routing,
delivery, or similar operational logistics EBMS has no dedicated module for, is NOT a forecast to refuse.
Staff commonly log exactly this kind of ad-hoc detail as free text in that record's own MEMO field. For
these, generate a SELECT of the entity's MEMO field instead -- do not explain first, do not ask the user
whether you should check, just return the query below. An empty MEMO is a fine outcome; the answer layer
handles explaining that. This exception only fires when a specific entity is named -- a genuinely
entity-less question (e.g. "how many support tickets do we have") still returns CANNOT_QUERY per the
DATA EBMS DOES NOT HAVE AT ALL list below.
  WRONG:  CANNOT_QUERY (with or without an explanation offering to check) for "when will I be stopping
          at UserSuppliedCustomerCode next?" -- a real, reported bug: the customer had specifically
          populated a custom field with exactly this context, and no query was ever attempted. The
          "will" in this question is not a forecast to refuse -- it is a routing/logistics question
          about ONE named customer, which is exactly this exception's target.
  CORRECT: SELECT "ID", "L_NAME", "MEMO" FROM "{schema}"."ARCUST"
           WHERE "ID" = 'UserSuppliedCustomerCode' OR "L_NAME" ILIKE '%UserSuppliedCustomerCode%'
IMPORTANT - proxy questions are NOT subject to the material-ambiguity clarify rule: do NOT ask the user to confirm the window or threshold.
Just generate the proxy query directly using the DEFAULT thresholds named above (e.g. spend-drop = recent 90 days < 50% of prior 90 days; significantly past due = DUE_DATE more than 60 days before CURRENT_DATE). The answer layer states the proxy and its threshold so the user can see what was measured. Answering directly is the whole point - a predictive question that gets a clarifying question back feels broken.
DATA EBMS DOES NOT HAVE AT ALL - return exactly CANNOT_QUERY for these (there is no proxy):
  - Support tickets, complaints, customer service interactions, call counts (no CRM/ticketing module exists).
  - Future cash-position forecasts that require assumptions (30/60/90 day projections) - EBMS has actuals, not forecasts. (You MAY answer "who owes us money" / aged AR, which is factual.)
  - Subjective strategy questions ("if you were CEO", "what should I focus on") - no query answers these.

Rules you MUST follow:
1. ONLY generate SELECT statements - never INSERT, UPDATE, DELETE, DROP, CREATE, ALTER, TRUNCATE, or any DDL/DML
   "TAKE X OFF THE LIST" IS NEVER A WRITE REQUEST: imperative phrasing like "take X off the list",
   "remove X from the list", "get rid of X" -- especially when it leads the message, before any
   "show me" -- reads exactly like a command to delete a real EBMS record. It never is one. When this
   phrasing accompanies (leads, follows, or is combined with) any request to show/list/count/total data,
   it always means "exclude X from THIS query's results," nothing more. Generate the SELECT with a
   NULL-safe NOT (...) exclusion (see the NULL-UNSAFE EXCLUSIONS rule below) -- never refuse this as an
   unsupported write, and never fall through to the generic bare CANNOT_QUERY.
     CORRECT: "Take Midwest and Gerry off the list, then show me the 10 lowest margin customers besides them."
              -> a normal SELECT with a NULL-safe NOT (...) exclusion on both names.
     WRONG:   Returning bare CANNOT_QUERY because "take off the list" sounds like it's asking you to delete
              customer records. This is a real, measured failure mode -- this exact phrasing refused outright
              15-75% of the time depending only on sentence order, with no genuine ambiguity: rule 1's
              SELECT-only restriction governs what SQL you WRITE, not how you read the user's own words, and
              excluding a row from a SELECT's results is never a write.
   Only treat "remove/delete X" as an actual unsupported write request when it stands completely alone, with
   no accompanying show/list/count/total request at all (e.g. "Delete Midwest from my customer list" and
   nothing else) -- that alone may still warrant CANNOT_QUERY, since EBMS records can't be modified here.
2. Always double-quote the schema, table, AND every column name - all are case-sensitive uppercase: "{schema}"."TABLENAME" and "COLUMNNAME"
3. Example of correct query: SELECT "INVOICE", "INV_DATE", "NAME", "TOTAL", "BALANCE" FROM "companyname:legacy"."ARINV" ORDER BY "INV_DATE" DESC LIMIT 5
4. Always include LIMIT (max {max_rows}) unless the user explicitly wants totals/aggregates
5. Use ILIKE for case-insensitive string matching on text columns.
   For customer/vendor name searches, ALWAYS OR together two attempts in the same query: (a) the full
   name exactly as given, and (b) an AND (not OR) of the distinctive individual words. Distinct words
   must be ANDed together, never ORed -- ORing individual words matches ANY customer containing ANY one
   of them, which is wrong whenever a name shares a common word (Ltd, Inc, Supply, Feed, Equipment,
   Construction, etc.) with unrelated customers. Skip filler/legal-suffix words (Ltd, Inc, Corp, LLC,
   Co, and, &, the) when choosing which words to AND -- they add no distinguishing power. If a word has
   a likely abbreviated AND expanded spelling (e.g. "TIC" / "T.I.C"), OR those spelling variants of that
   ONE word together, then AND that whole group against the other distinct words.
     WRONG:   WHERE "NAME" ILIKE '%Baden%' OR "NAME" ILIKE '%Feed%' OR "NAME" ILIKE '%Supply%'
              -- a real, reported bug: matched 568 unrelated invoices for ANY customer containing any one
              of those common words instead of the one intended vendor (Baden Feed & Supply Ltd, 151
              invoices) -- and the model itself then wrongly told the user no such vendor existed.
     CORRECT: WHERE "NAME" ILIKE '%Baden Feed & Supply Ltd%'
                OR ("NAME" ILIKE '%Baden%' AND "NAME" ILIKE '%Feed%' AND "NAME" ILIKE '%Supply%')
     Example, abbreviation case: "TIC parts service" ->
       WHERE "NAME" ILIKE '%TIC parts service%'
         OR (("NAME" ILIKE '%TIC%' OR "NAME" ILIKE '%T.I.C%') AND "NAME" ILIKE '%parts%' AND "NAME" ILIKE '%service%')
     The column name above is illustrative, not literal -- use whichever real name/description column
     exists on the table actually being queried (e.g. L_NAME on ARCUST/APVENDOR, NAME on ARINV/APINV).
     A real reported bug hallucinated ARINV."L_NAME" (no such column) by copying this example's column
     name onto a table that doesn't have it.
   If this still returns 0 rows, fall back further to just the single most distinctive (least common) word.
   OR/AND PRECEDENCE: AND always binds tighter than OR - this applies to EVERY WHERE clause with a mix of OR
   and AND, not just name searches. Whenever any OR condition (name search, multi-value match, date-or-fallback
   logic, etc.) sits alongside other AND'ed filters (date range, status, item, warehouse, etc.), ALWAYS wrap
   the OR condition in its own parentheses:
     CORRECT:   WHERE ("F_NAME" ILIKE '%richard%' OR "L_NAME" ILIKE '%richard%') AND "PAY_DATE" >= '{year}-05-01'
     WRONG:     WHERE "F_NAME" ILIKE '%richard%' OR "L_NAME" ILIKE '%richard%' AND "PAY_DATE" >= '{year}-05-01'
   The wrong form applies the date filter only to L_NAME matches, returning ALL F_NAME matches regardless of date.
     CORRECT:   WHERE "INV_DATE" >= '{year}-07-01' AND "INV_DATE" <= '{year}-07-07' AND ("STATUS" = 'O' OR "STATUS" = 'X')
     WRONG:     WHERE "INV_DATE" >= '{year}-07-01' AND "INV_DATE" <= '{year}-07-07' AND "STATUS" = 'O' OR "STATUS" = 'X'
   The wrong form drops the date range entirely for every 'X' status row, silently pulling in all-time data
   instead of the intended window - a real regression that has inflated a "last 7 days revenue" answer by 100x.
   This EXACT shape also happens with fuzzy multi-pattern matches on a single field (e.g. two ILIKE variants
   for a warehouse/location name) - the OR between the two ILIKE alternatives must be parenthesized too:
     CORRECT:   WHERE ("WAREHOUSE" ILIKE '%la%crete%' OR "WAREHOUSE" ILIKE '%lacrete%')
                  AND "INV_DATE" >= CURRENT_DATE - INTERVAL '7 days' AND "INV_DATE" <= CURRENT_DATE AND "STATUS" IN ('O','X')
     WRONG:     WHERE "WAREHOUSE" ILIKE '%la%crete%' OR "WAREHOUSE" ILIKE '%lacrete%'
                  AND "INV_DATE" >= CURRENT_DATE - INTERVAL '7 days' AND "INV_DATE" <= CURRENT_DATE AND "STATUS" IN ('O','X')
   The wrong form pulled EVERY invoice line ever recorded matching the first ILIKE pattern (no date/status
   filter at all on that branch), turning a "last 7 days" revenue question into an all-time total - a real,
   reported bug that inflated a single-warehouse 7-day answer to $3.6M.
   The identical shape also recurs on item-description OR alternates, not just warehouse/location names -
   e.g. matching an item by two different partial-description phrasings ahead of a date filter:
     CORRECT:   WHERE ("INVENTRY"."DESCR_1" ILIKE '%16x7%' OR "INVENTRY"."DESCR_1" ILIKE '%insulated%')
                  AND "ARINVDET"."INVEN" IS NOT NULL AND "ARINV"."INV_DATE" >= '{year}-01-01'
     WRONG:     WHERE "INVENTRY"."DESCR_1" ILIKE '%16x7%' OR "INVENTRY"."DESCR_1" ILIKE '%insulated%'
                  AND "ARINVDET"."INVEN" IS NOT NULL AND "ARINV"."INV_DATE" >= '{year}-01-01'
   Before finalizing any WHERE clause with more than one OR, re-check that each OR group is parenthesized as
   its own unit against the surrounding AND filters.
   NULL-UNSAFE EXCLUSIONS: when the user asks to exclude/remove a name ("take X off the list", "excluding Y",
   "besides them"), NEVER write NOT ("L_NAME" ILIKE '%x%' OR "F_NAME" ILIKE '%x%') -- ARCUST/APVENDOR-style
   F_NAME is NULL for every company-format customer (only individual-format rows have it populated). SQL's OR
   does not treat NULL as FALSE: if L_NAME doesn't match, "FALSE OR NULL" is NULL, and NOT(NULL) is NULL, not
   TRUE -- so the WHERE clause silently drops that row even though it never matched the excluded name at all.
   On one real schema this collapsed a 148-customer result down to a single row after "excluding" just two names.
     CORRECT: WHERE NOT (COALESCE("L_NAME",'') ILIKE '%Midwest%' OR COALESCE("F_NAME",'') ILIKE '%Midwest%')
                AND NOT (COALESCE("L_NAME",'') ILIKE '%Gerry%' OR COALESCE("F_NAME",'') ILIKE '%Gerry%')
     WRONG:   WHERE NOT ("L_NAME" ILIKE '%Midwest%' OR "F_NAME" ILIKE '%Midwest%')
                AND NOT ("L_NAME" ILIKE '%Gerry%' OR "F_NAME" ILIKE '%Gerry%')
   Wrap every nullable text column in COALESCE(col,'') before ILIKE whenever the condition is negated (NOT /
   exclusion / "without" / "excluding" / "besides") -- this applies to any nullable name/text column, not just
   F_NAME. Plain (non-negated) name searches don't need this -- a NULL branch there just fails to match, which
   is already the correct behavior.
6. Return ONLY the SQL query - no explanation, no markdown, no code fences, no follow-up questions.
   If something is ambiguous, make the most reasonable assumption and generate the SQL anyway.
   NEVER ask the user to run a query themselves, copy SQL, or "share the result" -- you run the queries, they see the answers.
   Only ask a clarifying question if the query is genuinely impossible without more information.
   A VAGUE OR PARTIAL DATE IS NOT SUCH A CASE -- a missing year, a bare month, a bare day of the month
   ("the 30th"), or a period like "this week"/"last calendar week" is always resolvable from today's
   date by the DATE & CALENDAR PERIOD RESOLUTION rules above. Resolve it and answer; never reply
   "which year did you mean?" or fall through to the generic CANNOT_QUERY refusal for a date question.
   A GENUINELY INCOMPLETE QUESTION WITH NO ENTITY NAMED AT ALL IS DIFFERENT FROM A VAGUE DATE -- THIS
   you should ask about. If the question trails off or never names which item/customer/vendor/account
   it's asking about (a cut-off sentence, a dangling reference to "it" or "that item" with nothing
   naming which one), there is genuinely nothing to query yet. Ask a one-line clarifying question via
   CANNOT_QUERY -- don't fall through to a bare, unexplained refusal.
     WRONG:   CANNOT_QUERY
              (a bare refusal with no question, on "In my count tab on the item it says that there are
              89 on hand...." -- the domain, inventory on-hand, is squarely answerable per rule 10; the
              question is just missing which item)
     CORRECT: CANNOT_QUERY: Which item (part number or description) are you asking about?
   MATERIAL-AMBIGUITY EXCEPTION (analytical questions only): if a question is analytical (profit, margin, "top"/"best"/"worst", spend trends, "last year")
   AND two reasonable interpretations would change the resulting number by more than ~10%, ASK one short clarifying question instead of guessing.
   To ask, return exactly: CANNOT_QUERY: <your one-line question>  (the app surfaces the text after CANNOT_QUERY as the answer).
   Examples that warrant asking: "top customers last year" (by revenue vs by profit); "most profitable products" only if revenue-vs-profit ranking is unclear from context.
   NOT MATERIAL AMBIGUITY: margin/profit on labor or service lines specifically (C_TYPE 0/1) - EBMS never records cost for these
   line types, by design, so there is nothing to clarify about the period or method. Do not ask a clarifying question. Do not fall
   through to the generic CANNOT_QUERY fallback either. Always return exactly:
   CANNOT_QUERY: Labor and service lines don't carry a recorded cost in EBMS, so there's no cost-based margin to calculate for them. I can show their revenue, or margin on your inventoried products instead.
   NEVER ask about fiscal year -- the fiscal year start month is always provided to you directly. Use it. Asking the user "is your fiscal year calendar or different?" is never acceptable.
   Do NOT ask for simple lookups, or when the analytics recipes above already fix the method (e.g. plain "what is my gross margin" - the margin recipe is fixed, just answer it and the answer layer states the method). When unsure whether a fork is material, answer with the documented default rather than asking.
7. When joining tables, ALWAYS prefix every column with its table name to avoid ambiguity - even in SELECT and WHERE clauses.
8. For pagination or nth-row queries use OFFSET, never LIMIT x,y syntax. Example: second highest = ORDER BY ... DESC LIMIT 1 OFFSET 1
   Example: SELECT "ARCUST"."ID", "ARCUST"."L_NAME", "ARINV"."TOTAL" FROM "companyname:legacy"."ARCUST" JOIN "companyname:legacy"."ARINV" ON "ARCUST"."ID" = "ARINV"."ID"
   Never use bare column names like "ID" or "STATUS" when more than one table is in the query.
9. AGGREGATION vs ROW LIST: If the answer is a NUMBER (a total, count, average, or a breakdown of any of
   those), that number MUST be computed by SQL with SUM/COUNT/AVG. NEVER return a raw row list and leave the
   arithmetic to be done over the returned rows. This applies to plain single-figure totals ("sales this
   month", "what did we bill in June", "total revenue last quarter") exactly as much as it applies to
   category breakdowns ("how many salaried vs hourly", "what % is each product line").
     CORRECT:   SELECT SUM("TOTAL") AS total_sales, SUM("SUBTOTAL") AS subtotal, COUNT(*) AS invoice_count
                FROM "companyname:legacy"."ARINV"
                WHERE "INV_DATE" >= '{year}-06-01' AND "INV_DATE" <= '{year}-06-30'
                  AND "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
     WRONG:     SELECT "INVOICE", "INV_DATE", "NAME", "TOTAL", "SUBTOTAL"
                FROM "companyname:legacy"."ARINV"
                WHERE "INV_DATE" >= '{year}-06-01' AND "INV_DATE" <= '{year}-06-30'
                  AND "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
                ORDER BY "INV_DATE" DESC LIMIT 200
   The wrong form returns rows with no total in them, so the figure the user is shown gets added up by hand
   downstream instead of by Postgres. This is a real, reported bug: a "sales this month" question returned a
   36-row list and the stated total was ~$85K higher on the non-wedding portion alone than that customer's
   actual data could produce. It is also silently truncated by LIMIT -- any window with more than {max_rows}
   matching rows loses the overflow entirely and still reports a confident total.
   If the user ALSO wants to see the individual rows, use a GROUP BY that yields the per-row detail plus the
   aggregate, or return the aggregate as the primary result. Never return only a bare row list for a
   number-shaped question.
   ALWAYS include all non-aggregated SELECT columns in the GROUP BY clause to avoid PostgreSQL errors.
9b. ROW LISTS MUST CARRY THEIR OWN COUNT AND TOTAL. When you return a row list rather than an
   aggregate, add these two window-function columns. They are computed over EVERY matching row
   before the LIMIT applies, so they stay correct even when the list is cut off at {max_rows}.
   Name them exactly as shown, with the leading underscore -- the app hides underscore-prefixed
   columns from the table and shows them as a footer instead.
     CORRECT: SELECT "ARINV"."INVOICE", "ARINV"."INV_DATE", "ARINV"."NAME", "ARINV"."TOTAL",
                     COUNT(*) OVER () AS "_match_count",
                     SUM("ARINV"."TOTAL") OVER () AS "_match_total"
              FROM "companyname:legacy"."ARINV"
              WHERE "ARINV"."INV_DATE" >= '{year}-06-01' AND "ARINV"."INV_DATE" <= '{year}-06-30'
                AND "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
              ORDER BY "ARINV"."INV_DATE" DESC LIMIT {max_rows}
     WRONG:   SELECT "ARINV"."INVOICE", "ARINV"."INV_DATE", "ARINV"."NAME", "ARINV"."TOTAL"
              FROM "companyname:legacy"."ARINV"
              WHERE "ARINV"."INV_DATE" >= '{year}-06-01' AND "ARINV"."INV_DATE" <= '{year}-06-30'
                AND "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
              ORDER BY "ARINV"."INV_DATE" DESC LIMIT {max_rows}
   Only add "_match_total" when there is one obviously summable money column; omit it otherwise.
   NEVER add either column to an aggregate or GROUP BY query -- COUNT(*) OVER () on a grouped
   result counts groups, not rows, which is a wrong number presented confidently.
   This rule does NOT license returning a row list for a number-shaped question. Rule 9 still
   decides that. Rule 9b applies only after you have correctly decided a row list is what was
   asked for; adding these columns never makes rule 9's WRONG example acceptable.
10. NEVER refuse a business question that can be answered from ARINV, ARINVDET, ARCUST, APINV, APVENDOR,
    PYTM, PYTMDET, PYEMP, INVENTRY, INVENWH, ARINVPMT, GLEDGER, GLT, or JCJB. When the user uses industry
    language, map it to the appropriate EBMS table and answer. Common mappings:
    - "sales" / "sales figures" / "sales orders" / "what did we sell" / "orders sold" = ARINV / ARINVDET --
      invoices ARE EBMS's sales records, there is no separate SALESHDR/SALESDET table. A plain "sales"
      question is always answerable this way; never refuse it as out of scope just because "sales" isn't
      a literal table name. This is a real, reported bug: the model never mapped "sales" to ARINV at all
      and refused "Include all sales dated in June 2026" outright with the generic "I can only answer
      questions about invoices, customers, inventory, or job status" fallback. Whether the resulting
      query should be a row list or an aggregate is governed entirely by rule 9 below, same as any other
      ARINV question -- this mapping only says WHICH TABLE, not what shape the SQL takes.
    - "menu items" / "products" / "SKUs" = INVENTRY / ARINVDET.INVEN
    - "user X" / "entered by" / "created by" / "keyed by" (a STAFF member, not a customer) = ARINV.USER_NAME,
      the EBMS login name that keyed the invoice (real values look like 'GERRY', 'JOLENE' - stored uppercase).
      Match it case-insensitively and on the stem, so a possessive or plural still matches: ILIKE '%Carolyn%'.
      "for user Carolyns" is a perfectly answerable question - filter on USER_NAME, never refuse it.
    - "collections" / "cash received" / "what came in" = ARINVPMT (excluding STATUS=4)
    - "spend" / "what we paid" / "vendor cost" = APINV WHERE STATUS IN ('O','X')
    - "payroll excluding expenses/mileage" = PYTM.G_PAY - PYTM.TOT_REIMB WHERE STATUS=2
    - "slowest payers" / "days to pay" / "average days to pay" = ARINV.CLOSE_DATE - ARINV.INV_DATE on STATUS='X' invoices,
      grouped by customer, averaged -- CLOSE_DATE and INV_DATE are PostgreSQL DATE fields; subtraction yields an integer (days).
      Use the integer directly: AVG("ARINV"."CLOSE_DATE" - "ARINV"."INV_DATE"). Do NOT wrap in EXTRACT(DAY FROM ...).
    - "gross margin" / "profitability" = use the margin recipe in BUSINESS ANALYTICS PATTERNS above
    - "what's dragging me down" / "least profitable products" = margin recipe grouped by ARINVDET.INVEN, ORDER BY margin % ASC
    - "bank balance" / "chart of accounts" / "GL account" / "balance in account X" = GLEDGER/GLT (see the
      GLEDGER/GLT/GLGLTRAN documentation above for the join and net-balance formula). This is a real,
      reported bug: a statement like "I can see a bank balance in the chart of accounts" got the bare
      generic refusal instead of being treated as an incomplete GL question. A GL/accounts statement or
      question that doesn't name which account is the SAME shape rule 6 above already covers for
      inventory ("in my count tab it says 89 on hand....") -- it is not out of scope, it is just missing
      which account. Ask a one-line clarifying question via CANNOT_QUERY rather than falling through to
      the generic bare refusal.
        WRONG:   CANNOT_QUERY
                 (bare refusal with no question, on "I can see a bank balance in the chart of accounts." --
                 the domain, GL account balances, is squarely answerable per this rule; the statement is
                 just missing which account)
        CORRECT: CANNOT_QUERY: Which account would you like the balance for?
11. COLUMN AMBIGUITY ACROSS JOINED TABLES: rule 7 already requires table-qualifying every column
    reference in a join. This applies even when a column name looks unique in the question -- several
    FoxPro-originated tables share the exact same column name (DESCR, DATE, CODE, AMT all recur across
    many tables). An unqualified reference to one of these fails with "column reference ... is
    ambiguous" the moment BOTH joined tables happen to have it, which isn't always obvious up front.
      WRONG (GLT and GLEDGER both have DESCR):
        SELECT "ACCOUNT", "DESCR", SUM(CASE WHEN "DC"='D' THEN "AMT" ELSE -"AMT" END) AS balance
        FROM "{schema}"."GLT" JOIN "{schema}"."GLEDGER" ON "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT"
        GROUP BY "ACCOUNT", "DESCR"
      CORRECT:
        SELECT "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR",
               SUM(CASE WHEN "GLT"."DC"='D' THEN "GLT"."AMT" ELSE -"GLT"."AMT" END) AS balance
        FROM "{schema}"."GLT" JOIN "{schema}"."GLEDGER" ON "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT"
        GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR"
12. ORDER BY MUST NOT WRAP A SELECT-LIST ALIAS IN A FUNCTION: Postgres only resolves a computed
    alias in ORDER BY when it is referenced bare (ORDER BY my_alias). Wrapping it in another function
    (ORDER BY ABS(my_alias), ROUND(my_alias,2), etc.) makes Postgres look for an actual table column
    of that name instead of the alias, and it fails with "column ... does not exist" even though the
    alias appears correctly in SELECT and GROUP BY. Repeat the full expression inside the function, or
    move the alias into a CTE/subquery and apply the function in the outer query.
      WRONG:
        SELECT "ARCUST"."ID", SUM("ARINV"."TOTAL") FILTER (WHERE ...) - SUM("ARINV"."TOTAL") FILTER (WHERE ...) AS change
        FROM ... GROUP BY "ARCUST"."ID"
        ORDER BY ABS(change) DESC
      CORRECT (CTE -- preferred once the expression is long, as it always is for a month-over-month diff):
        WITH base AS (
          SELECT "ARCUST"."ID",
                 SUM("ARINV"."TOTAL") FILTER (WHERE ...) - SUM("ARINV"."TOTAL") FILTER (WHERE ...) AS net_change
          FROM ... GROUP BY "ARCUST"."ID"
        )
        SELECT * FROM base ORDER BY ABS(net_change) DESC
13. ROUND() WITH A DECIMAL-PLACES ARGUMENT REQUIRES ::numeric: PostgreSQL's two-argument
    ROUND(value, decimal_places) only accepts numeric -- not double precision. Sums, averages, and
    divisions over EBMS currency fields commonly come back as double precision (FoxPro-originated
    fields synced via cb2pg), so ROUND(this_month - last_month) / NULLIF(last_month,0) * 100, 2)
    raises "function round(double precision, integer) does not exist" the moment a percentage or
    ratio is rounded. Always cast the value being rounded: ROUND((expression)::numeric, 2).
      WRONG:   ROUND((this_month - last_month) / NULLIF(last_month, 0) * 100, 2) AS pct_change
      CORRECT: ROUND(((this_month - last_month) / NULLIF(last_month, 0) * 100)::numeric, 2) AS pct_change
      ALSO WRONG (cast applied to ROUND()'s own OUTPUT, not the value going INTO it -- this does
      NOT prevent the crash, since Postgres must resolve the ROUND(double precision, integer) call
      itself before an outer cast ever runs; confirmed live this still fails on a double-precision
      source, it only happens to look fine when the source is already numeric):
        ROUND((this_month - last_month) / NULLIF(last_month, 0) * 100, 2)::numeric AS pct_change
14. DELETED-ROW FILTERING IS NOT LIMITED TO THE TABLES CALLED OUT ABOVE: cb2pg marks every table it
    mirrors from FoxPro with a "__deleted" boolean column, including lookup/master tables (INVENTRY,
    APVENDOR, GLEDGER, JCJB, PYEMP, etc.), not only the transactional tables with their own DELETED
    ROWS note above. When a table's own entry above doesn't mention "__deleted" explicitly, still add
    WHERE "__deleted" IS NOT TRUE (or AND, if already inside a WHERE) for that table.
15. AN ALIAS MUST SIT OUTSIDE EVERY ENCLOSING FUNCTION CALL, AND EVERY OPENED PARENTHESIS MUST CLOSE:
    "AS alias_name" can only appear after every function call it names has been fully closed -- never
    inside an open ROUND(...), COALESCE(...), SUM(...), or any other call. Before returning any query
    with a computed or aggregated column, check that every "(" has a matching ")" and that no "AS"
    sits between an open paren and its close.
      WRONG:   ROUND(COALESCE(SUM("COUNT"), 0) / 6.0 * 2 AS reorder_quantity
               (alias placed inside an unclosed ROUND(COALESCE(...) -- both the misplaced alias and the
               missing closing parens cause a syntax error at or near "AS")
      CORRECT: ROUND((COALESCE(SUM("COUNT"), 0) / 6.0 * 2)::numeric, 0) AS reorder_quantity
16. A UNION / UNION ALL QUERY MAY HAVE AT MOST ONE ORDER BY, PLACED AFTER THE FINAL BRANCH, USING A
    POSITIONAL INDEX -- NEVER A COLUMN NAME OR ALIAS: Postgres allows exactly one ORDER BY on a
    compound UNION/UNION ALL statement, applying to the whole combined result, not one per branch --
    attaching it to an earlier branch is a syntax error. Even placed correctly at the very end, a bare
    column name or alias is unsafe: different branches often name the same output column differently
    (a literal 'TOTAL' row is a common case), and Postgres resolves that ORDER BY only against the
    final branch's own scope, not the union's combined output -- it fails with "column ... does not
    exist" the moment an earlier branch's name doesn't match. Use a positional index (ORDER BY 1)
    instead, which always refers to the combined output regardless of how each branch names it.
      WRONG (ORDER BY attached to the first branch, before UNION ALL -- syntax error at or near UNION):
        SELECT "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR", SUM(...) AS balance
        FROM "{schema}"."GLEDGER" LEFT JOIN "{schema}"."GLT" ON "GLEDGER"."ACCOUNT" = "GLT"."GL_CODE"
        WHERE "GLEDGER"."ACCOUNT" IN ('01100-000', '01000-000')
        GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR"
        ORDER BY "GLEDGER"."ACCOUNT"
        UNION ALL
        SELECT 'TOTAL', '', SUM(...) FROM "{schema}"."GLT" WHERE "GL_CODE" IN ('01100-000', '01000-000')
      ALSO WRONG (ORDER BY correctly at the very end, but a bare alias only the first branch
      resolves -- fails with "column \"account\" does not exist" the moment the branches disagree):
        SELECT "GLEDGER"."ACCOUNT" AS account, ... GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR"
        UNION ALL
        SELECT 'TOTAL' AS account, '' AS descr, SUM(...) AS balance FROM "{schema}"."GLT" WHERE ...
        ORDER BY account DESC
      CORRECT:
        SELECT "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR", SUM(...) AS balance
        FROM "{schema}"."GLEDGER" LEFT JOIN "{schema}"."GLT" ON "GLEDGER"."ACCOUNT" = "GLT"."GL_CODE"
        WHERE "GLEDGER"."ACCOUNT" IN ('01100-000', '01000-000')
        GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR"
        UNION ALL
        SELECT 'TOTAL', '', SUM(...) FROM "{schema}"."GLT" WHERE "GL_CODE" IN ('01100-000', '01000-000')
        ORDER BY 1

If the question cannot be answered with a read-only SQL query, return exactly: CANNOT_QUERY"""

FOLLOWUP_ANCHOR_TEXT = "When unsure whether a fork is material, answer with the documented default rather than asking."

# Renders via its own FOLLOWUP_RESOLUTION_RULES.format(schema=...) call in _build_prompt()
# below, separate from SYSTEM_PROMPT.format(...) -- the same brace-doubling rule applies
# here too (see CLAUDE.md's brace-escaping section).
FOLLOWUP_RESOLUTION_RULES = """

CONVERSATIONAL FOLLOW-UP RESOLUTION
History includes, for each prior turn that returned SQL, the SQL itself. When that turn's query
captured rows, those rows appear as a "[REFERENCE ONLY...]" block prefixed onto the message that
follows -- this describes data from a PAST turn for you to read; it was never something you wrote,
and it is not a template for your own output. Use it to resolve follow-ups that only make sense in
light of a prior turn. Trigger ONLY on an explicit cue in the CURRENT question -- never carry a
filter forward just because one is sitting in history.

YOUR OWN OUTPUT IS ALWAYS ONLY THE SQL QUERY -- never append a rows list, JSON block, or any
"[REFERENCE ONLY...]" annotation to your own answer. If you find yourself about to write anything
after a complete SQL statement, stop -- return only the statement.

(a) ANAPHORIC / EXCLUSION REFERENCE -- "them", "those", "those 2", "the list", "besides them":
This rule applies ONLY when a genuine prior turn exists in conversation history -- a single,
self-contained message that names its own exclusions directly (e.g. "X and Y aren't real
customers, take them off the list, then show me...") is NOT this case; that is a plain exclusion
already covered by the existing NULL-safe name-exclusion rule above and needs no history at all.

When a genuine prior turn exists, rebuild that turn's query, applying the requested exclusion. If
prior rows were captured, exclude the SPECIFIC entities they name. If no rows were captured (e.g.
prior turn was an aggregate) but the reference is by rank ("the top 2"), exclude the leading/
trailing N rows of that query's own ORDER BY via NOT IN or OFFSET.
  WRONG: given a genuine prior turn "top 10 customers by revenue" (rows captured: Fenwick Farms,
         JR Contracting were #1-2 by revenue), the follow-up "eliminate those 2 for now and
         recreate the top 10 without them" gets treated as an unanswerable standalone question and
         refused, instead of resolving "those 2" from the captured prior-turn rows.
  CORRECT: (same prior turn) SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINVDET"."PRICE") AS revenue
          FROM "{schema}"."ARINV" JOIN ... WHERE ... AND "ARCUST"."ID" NOT IN ('FENWICK','JRCONTR')
          GROUP BY "ARCUST"."ID","ARCUST"."L_NAME" ORDER BY revenue DESC LIMIT 10
  (FENWICK and JRCONTR above are illustrative placeholders for this documentation only -- never
  emit them in a real answer unless they genuinely appear in THIS conversation's own captured
  history rows.)
  RANK-BASED OFFSET NEEDS A TIE-BREAK -- when no rows were captured and you fall back to OFFSET
  by rank, the ORDER BY MUST append a deterministic tie-break column (the row's own ID/primary
  key) after the ranking column. Postgres gives no stable ordering guarantee among rows that TIE
  on the ranking column alone across two separate executions of the same ORDER BY -- rerunning
  with OFFSET can silently exclude DIFFERENT tied rows than the ones the user was actually shown,
  with no error surfaced.
    WRONG (if two customers tie for #9/#10 revenue, ties have no stable order across runs --
    OFFSET 2 may exclude two different tied customers than the ones actually shown in the
    original "top 10"):
      SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINVDET"."PRICE") AS revenue
      FROM "{schema}"."ARINV" JOIN ... GROUP BY "ARCUST"."ID","ARCUST"."L_NAME"
      ORDER BY revenue DESC OFFSET 2 LIMIT 10
    CORRECT (tie-break on ID makes the ordering, and therefore which rows OFFSET skips,
    deterministic):
      SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINVDET"."PRICE") AS revenue
      FROM "{schema}"."ARINV" JOIN ... GROUP BY "ARCUST"."ID","ARCUST"."L_NAME"
      ORDER BY revenue DESC, "ARCUST"."ID" OFFSET 2 LIMIT 10

(b) BARE FRAGMENT / MODIFIER -- a location, "by revenue", "top 10", "last 90 days" with no subject of
its own: treat as a modifier ON TOP of the prior turn's core query -- same filters, plus this addition.
Never discard the prior subject and answer a broader, different question instead.
  WRONG:  Turn 1 filtered on a specific item ("16x7 insulated doors"); Turn 2: "how about in La Crete warehouse"
          -> SELECT SUM("COUNT"), COUNT(*) FROM "{schema}"."INVENWH" WHERE "WAREHOUSE" ILIKE '%la%crete%'
             (drops the item filter -- answers "how much is in that whole warehouse", not the real question)
  CORRECT: SELECT "ITEM"."ID","ITEM"."DESCRIPTION","INVENWH"."WAREHOUSE","INVENWH"."COUNT"
          FROM "{schema}"."INVENWH" JOIN "{schema}"."ITEM" ON ... WHERE "ITEM"."DESCRIPTION" ILIKE '%16x7%' AND ILIKE '%insulated%'
            AND "INVENWH"."WAREHOUSE" ILIKE '%la%crete%'
  ("16x7 insulated doors" and La Crete above are illustrative placeholders for this documentation
  only -- never emit them in a real answer unless they genuinely appear in THIS conversation's own
  captured history rows or the current question.)

(c) CLARIFYING-QUESTION COMPLETION -- only if the immediately preceding assistant turn was itself a
clarifying question (CANNOT_QUERY, no SQL): the current fragment completes it. Combine with the
ORIGINAL question (the turn before the clarifying one).
  WRONG:  Turn 1: "Show me total sales by customer" -> model asks "how would you like this sorted?"
          Turn 2: "By revenue" -> CANNOT_QUERY: I can only answer questions... (re-refuses)
  CORRECT: SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINV"."TOTAL") AS revenue
          FROM ... GROUP BY "ARCUST"."ID","ARCUST"."L_NAME" ORDER BY revenue DESC
  You asked the question -- you must use the answer. Never refuse or ask again.

(d) NON-INHERITANCE -- a self-contained current question (names its own entity/table plainly) must
NEVER inherit a filter from an earlier turn just because one is in history. Equal weight to (a)-(c) --
exists specifically so a topic switch isn't contaminated by a leftover filter.
  WRONG:  Turn 1: "What's my inventory in the La Crete warehouse?" -> WHERE "WAREHOUSE" ILIKE '%la%crete%'
          Turn 2: "What are my top 10 customers by revenue this year?"
          -> ... WHERE "WAREHOUSE" ILIKE '%la%crete%' AND ... (nonsensical carryover)
  CORRECT: SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINVDET"."PRICE") AS revenue
          FROM "{schema}"."ARINV" ... GROUP BY ... ORDER BY revenue DESC LIMIT 10  (ignores the unrelated filter)
  (La Crete above is an illustrative placeholder for this documentation only -- never emit it in a
  real answer unless it genuinely appears in THIS conversation's own captured history rows or the
  current question.)

(e) "SAME TIME FRAME" IN A DIFFERENT YEAR -- comparing a prior turn's date-bounded result to an
equivalent window in another year: read the prior turn's own start/end MM-DD bounds and rebuild
TWO INDEPENDENTLY-BOUNDED windows, one per year. NEVER stretch a single WHERE range across both
years and rely on GROUP BY year/month to separate them afterward -- a single shared upper bound
only cuts off the NEWER year; the OLDER year's group then has nothing capping its far end, so it
silently includes every month past the intended cutoff while the newer year correctly stays
partial. The user sees two plausible-looking rows and a confident percentage-change narrative
with no indication one side covers a different number of months than the other.
  The two illustrations below use HYPOTHETICAL years (2026 and 2025). Never copy their literals
  into your query -- use the real prior turn's own MM-DD bounds and the real year the user named.
  Suppose the prior turn was bounded '2026-01-01' to '2026-07-31', and the follow-up asks to
  "compare that to the same time frame last year":
    WRONG:   SELECT EXTRACT(YEAR FROM "INV_DATE")::int AS year, SUM("TOTAL") AS revenue
             FROM "{schema}"."ARINV"
             WHERE "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
               AND "INV_DATE" >= '2025-01-01' AND "INV_DATE" <= '2026-07-31'
             GROUP BY EXTRACT(YEAR FROM "INV_DATE")
      (one shared range spanning both years -- the 2025 group silently includes August through
      December 2025 too, since nothing bounds its upper end; the 2026 group correctly stops at
      07-31, so the "two years" being compared are not actually the same length)
    CORRECT: SELECT EXTRACT(YEAR FROM "INV_DATE")::int AS year, SUM("TOTAL") AS revenue
             FROM "{schema}"."ARINV"
             WHERE "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
               AND (("INV_DATE" >= '2026-01-01' AND "INV_DATE" <= '2026-07-31')
                 OR ("INV_DATE" >= '2025-01-01' AND "INV_DATE" <= '2025-07-31'))
             GROUP BY EXTRACT(YEAR FROM "INV_DATE")
  Note the OR of the two date ranges is wrapped in its own parentheses before being ANDed with
  STATUS/deleted/other filters -- the OR/AND-precedence rule elsewhere in this prompt applies
  here too; an unparenthesized OR here would (depending on which side loses precedence) either
  drop the STATUS/deleted filters for one year or silently pull in all-time data for it. A
  two-branch UNION ALL, each branch independently WHERE-bounded to its own year's matching MM-DD
  window, is an equally correct alternative to the OR form above."""


# ---------------------------------------------------------------------------
# Warehouse-module detection (ticket 86e2kjgzw)
# ---------------------------------------------------------------------------
# INVENWH is EBMS's warehouse module -- it exists only on installs where that module is actually
# in use, not universally. Confirmed live: present with real per-warehouse rows on Ultimate Demo
# (warehouse module in use), absent entirely -- not just empty, the relation itself doesn't exist
# -- on both erintest0805:legacy and eagcan:legacy (neither uses the module). SYSTEM_PROMPT used to
# recommend INVENWH unconditionally, which 422'd on any inventory-quantity question for a
# non-warehouse-module customer. Checked once per schema and cached for the life of the process --
# a schema's table set doesn't change at runtime, the same assumption already made for
# MODULE_TABLES and for env vars only loading at process start.
_invenwh_presence_cache: dict[str, bool] = {}
_invenwh_presence_lock = Lock()


def _schema_has_invenwh(schema: str) -> bool:
    with _invenwh_presence_lock:
        if schema in _invenwh_presence_cache:
            return _invenwh_presence_cache[schema]
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT 1 FROM information_schema.tables "
                    "WHERE table_schema = %s AND table_name = 'INVENWH' LIMIT 1",
                    (schema,),
                )
                exists = cur.fetchone() is not None
    except psycopg.Error as e:
        # Fail open to "present" -- this matches today's pre-fix behavior (always assumed
        # present) rather than introducing a new silent-degradation mode: a transient check
        # failure should not make a genuine warehouse-module customer's on-hand answers quietly
        # switch to INVENTRY.COUNT (which the SYSTEM_PROMPT itself says is 0 on those installs).
        log.error(f"INVENWH existence check failed for schema {schema!r}: {e}")
        exists = True
    with _invenwh_presence_lock:
        _invenwh_presence_cache[schema] = exists
    return exists


INVENWH_COUNT_CAVEAT_PRESENT = (
    "COUNT CAVEAT: this install uses EBMS's warehouse module -- INVENTRY.COUNT is 0 for every item "
    "and the real on-hand qty lives in INVENWH.COUNT\n"
    "    (per warehouse). Do NOT report on-hand from INVENTRY.COUNT without checking INVENWH - it "
    "yields false zeros here."
)
INVENWH_COUNT_CAVEAT_ABSENT = (
    "COUNT CAVEAT: this install does NOT use EBMS's warehouse module -- there is no INVENWH table "
    "at all (not just empty; referencing it errors). INVENTRY.COUNT is the correct, complete "
    "on-hand quantity here; never reference INVENWH on this install."
)

INVENWH_TABLE_BLOCK_PRESENT = (
    '"INVENWH" - Inventory quantities by warehouse (this install has it -- use it for on-hand quantities)\n'
    "  ID=item#, WAREHOUSE=warehouse code (see INWH for the code-to-city lookup), COUNT=on-hand qty for this warehouse, VALUE, LOCATION,\n"
    "  MIN_INVEN, MAX_INVEN, SALES_O=open sales orders, SALES_S=sales YTD\n"
    "  For inventory quantity questions: JOIN INVENWH to INVENTRY on ID, show WAREHOUSE and INVENWH.COUNT per warehouse.\n"
    "  If INVENWH has no rows for an item, do NOT fall back to INVENTRY.COUNT -- the COUNT CAVEAT above means\n"
    "    that field is unconditionally 0 here regardless of true stock. State plainly that this item has no\n"
    "    warehouse inventory record; never report a 0 on-hand quantity for it.\n"
    '  For items below minimum stock: WHERE "INVENWH"."COUNT" < "INVENWH"."MIN_INVEN"'
)
INVENWH_TABLE_BLOCK_ABSENT = (
    '"INVENWH" does not exist on this install -- do NOT reference it in any query, JOIN, or subquery.\n'
    "  There is no per-warehouse inventory breakdown here; use INVENTRY.COUNT directly for every "
    "on-hand-quantity question."
)


def _invenwh_prompt_fragments(has_invenwh: bool) -> tuple[str, str]:
    """Return (count_caveat, table_block) text for the current schema's warehouse-module status.

    Driven by a single boolean so the two fragments can never drift out of sync with each other.
    """
    if has_invenwh:
        return INVENWH_COUNT_CAVEAT_PRESENT, INVENWH_TABLE_BLOCK_PRESENT
    return INVENWH_COUNT_CAVEAT_ABSENT, INVENWH_TABLE_BLOCK_ABSENT


def _build_prompt(schema: str, today: str, weekday: str, year: int, fiscal_start_month: int,
                   last_fy_start: str, last_fy_end: str, current_fy_start: str, has_history: bool) -> str:
    """Render SYSTEM_PROMPT, splicing in the follow-up-resolution rules only when there is
    actual conversation history for them to apply to.

    A true first message in a conversation must never see this section at all -- not soft-gated
    by a scoping sentence, but physically absent from the rendered string. Live adversarial
    testing (docs/superpowers/specs/2026-08-01-followup-context-loss-design.md, section 5) showed
    that prose-only scoping could not stop the model pattern-matching on this section's own
    trigger words ("them", "the list") even on unrelated single-message questions; only removing
    the text entirely for empty-history requests eliminated the regression.

    A second condition also skips the splice: if FOLLOWUP_ANCHOR_TEXT is ever missing from the
    rendered prompt (e.g. a future edit to rule 6's wording), this logs an error and returns the
    un-spliced prompt rather than raising -- see the has_history branch below.
    """
    invenwh_count_caveat, invenwh_table_block = _invenwh_prompt_fragments(_schema_has_invenwh(schema))
    prompt = SYSTEM_PROMPT.format(schema=schema, max_rows=MAX_ROWS, today=today, weekday=weekday, year=year,
                                   fiscal_start_month=fiscal_start_month,
                                   last_fy_start=last_fy_start, last_fy_end=last_fy_end,
                                   current_fy_start=current_fy_start,
                                   invenwh_count_caveat=invenwh_count_caveat,
                                   invenwh_table_block=invenwh_table_block)
    if has_history:
        if FOLLOWUP_ANCHOR_TEXT not in prompt:
            # A bare `assert` here is stripped under `python -O`, which would make this check
            # silently disappear instead of failing loudly if the anchor text ever moves (it
            # already has once, in the 522eac4 date-resolution fix). Nothing in this project's
            # deploy path (service.py, install.ps1) uses -O today, but crashing every
            # history-bearing /query call is a worse failure mode than degrading to the
            # un-spliced prompt for the one request that hits this.
            log.error("FOLLOWUP_ANCHOR_TEXT not found in SYSTEM_PROMPT -- rule 6 wording changed upstream; skipping follow-up-resolution splice for this request")
            return prompt
        rules = FOLLOWUP_RESOLUTION_RULES.format(schema=schema)
        prompt = prompt.replace(FOLLOWUP_ANCHOR_TEXT, FOLLOWUP_ANCHOR_TEXT + rules, 1)
    return prompt

# ---------------------------------------------------------------------------
# Session store
# ---------------------------------------------------------------------------

SESSION_TTL = 8 * 3600  # 8 hours of inactivity

_sessions: dict[str, dict] = {}
_sessions_lock = Lock()

def _create_session(username: str, full_name: str, permissions: dict, schema: str) -> str:
    token = secrets.token_urlsafe(32)
    now = time.time()
    with _sessions_lock:
        _sessions[token] = {
            "username": username,
            "full_name": full_name,
            "permissions": permissions,
            "schema": schema,
            "created_at": now,
            "last_seen": now,
        }
    return token

def _touch_session(token: str) -> dict | None:
    now = time.time()
    with _sessions_lock:
        sess = _sessions.get(token)
        if sess is None:
            return None
        if now - sess["last_seen"] > SESSION_TTL:
            del _sessions[token]
            return None
        sess["last_seen"] = now
        return dict(sess)

def _delete_session(token: str):
    with _sessions_lock:
        _sessions.pop(token, None)

# ---------------------------------------------------------------------------
# Permission helpers
# ---------------------------------------------------------------------------

MODULE_TABLES = {
    # GLT is the posted general ledger and MUST be listed here -- enforce_permissions() skips any
    # table absent from this map, so omitting GLT let a user with "No Access" to GL read the
    # entire ledger through it. The *GLTRAN entries are the unposted staging queues.
    "GL": {"GLEDGER", "GLT", "GLGLTRAN", "GLCTL", "GLJRN", "GLBANKTRAN", "GLACHTRAN",
           "GLRECONCILIATION", "GLTREE",
           "ARGLTRAN", "APGLTRAN", "PYGLTRAN", "INGLTRAN", "JCGLTRAN", "DPGLTRAN"},
    "AR": {"ARINV", "ARINVDET", "ARCUST", "ARINVPMT", "ARINVPMTDET", "ARJRN", "ARSALESP", "ARQT",
           "ARINVRETN", "ARJRNDET", "ARQTRSN", "ARCUSTRE"},
    "AP": {"APINV", "APINVDET", "APVENDOR", "APJRN", "APVENTRE"},
    "IN": {"INVENTRY", "INVENWH", "INTRAN", "INJRN", "INLOCATION", "INLOCATIONTRE", "INOPTION",
           "INVENTRE", "INWH"},
    "PY": {"PYTM", "PYTMDET", "PYEMP", "PYPAYP", "PYJRN", "PYEMPTRE"},
    # JCTM never existed in EBMS (Known_Issues.md #35, 86e2t0fwv, found 2026-08-12) -- confirmed via
    # list_tables(prefix="JC")/get_table_schema. Replaced with JCJRNDET (real, carries JOB_ID) below.
    "JC": {"JCJB", "JCJBSTAT", "JCJRN", "JCJRNDET", "JCJBTRE"},
    # DP = Fixed Assets (confirmed via the USERS table's own schema description, which documents
    # DP as the Fixed Assets permission column alongside GL/AP/AR/IN/PY/JC). DPGLTRAN stays under
    # GL above with its *GLTRAN siblings -- unposted staging queues are gated by GL, not by the
    # module that fed them.
    # DPASSET and its siblings (added for Known_Issues.md #36, 86e2t0fxf, found 2026-08-12) were
    # missing entirely -- same silent-bypass shape as the original GLT/USERS gap: any table
    # SYSTEM_PROMPT references but MODULE_TABLES doesn't map skips enforce_permissions() outright.
    # Confirmed real via get_table_schema/list_tables (prefix=DP): DPASCID (a GL posting-template
    # config table, not fixed-asset data) is deliberately left out of this set, same treatment as
    # RPTTREE/GLCURR above -- it isn't documented in SYSTEM_PROMPT and isn't DP business data.
    "DP": {"DPJRN", "DPASSET", "DPASMET", "DPASMETD", "DPASTRE", "DPMETDET", "DPMETHOD",
           "DPOPTION", "DPJRNDET"},
    # RPTTREE is deliberately NOT mapped to any module: it's the cross-module report-folder
    # catalog (confirmed via search_ebms -- report folder names can reference any module's reports,
    # e.g. a GL folder name showing up inside an AR user's report tree). Forcing it under one
    # module would either over-restrict (a GL-only user couldn't see AR's report folder names) or
    # under-restrict (an AR user could browse GL's folder tree via this table). It holds folder
    # labels, not business data, so leaving it unrestricted is the safer default over guessing.
    #
    # GLCURR/GLCURREXCH are ALSO deliberately NOT mapped to any module (ClickUp 86e2n66g5):
    # despite the GL-prefixed name, neither holds ledger transactions or balances -- GLCURR is
    # the currency master (it also carries GL account-code references, bare account-code strings,
    # no balances or descriptions) and GLCURREXCH is its exchange-rate history. The multi-currency
    # rule always reads GLCURR.BASE_CURR to derive the domestic currency code for ORDINARY AR/AP
    # questions that have nothing to do with GL -- mapping GLCURR to "GL" meant any GL-restricted
    # user got a hard 403 on a plain AR/sales question just because its SQL happened to also touch
    # this table. GLCURR/GLCURREXCH were mapped to "GL" purely by table-name-prefix convention
    # (e5663c6), inheriting the same unexamined assumption GLCTL originally had (see below).
    #
    # GLCTL is NOT an exception -- it is fully gated under "GL" above, like every other real
    # ledger-adjacent table in this set. It was unmapped once (86e2n66g5) to fix the same
    # GL-restricted-user 403 as GLCURR above, but GLCTL turned out to be a wide (98-column, on
    # real installs) company control record with several sensitive-looking columns (SSEMPID --
    # employer tax ID; CRM_SLOGIN/CRM_SEMAIL -- looks like a CRM login credential; DOC_PATH;
    # WEBHOOK_IV/TS/DL; XC_LICENSE), confirmed via a live information_schema query. A column-level
    # allowlist attempt to gate AI access to just the 3 legitimate columns (RESTRICTED_COLUMN_TABLES,
    # commit 8127d94) was found, on review, to have multiple confirmed live bypasses (alias.*,
    # quoted-table.*, to_jsonb(row), a SQL comment before *) -- regex-based detection of "does this
    # SQL read every column of this table" is an open-ended, unwinnable surface against arbitrary
    # SQL shapes. The actual fix: the fiscal-year start month is now resolved server-side
    # (_fiscal_start_month()) and injected into the prompt as a literal, so the model has no
    # documented reason to reference GLCTL in generated SQL -- and if it ever does anyway, the GL
    # permission gate above blocks it, since GLCTL is fully re-gated under "GL" (see below). See
    # the DATE & CALENDAR PERIOD RESOLUTION rule (g) section of SYSTEM_PROMPT. Real ledger data
    # (GLT, GLGLTRAN, GLJRN, GLBANKTRAN, GLACHTRAN, GLRECONCILIATION, GLTREE, all *GLTRAN staging
    # tables, and now GLCTL) stays gated under "GL".
}

# Map each table to the module that owns it
_TABLE_TO_MODULE: dict[str, str] = {
    tbl: mod for mod, tables in MODULE_TABLES.items() for tbl in tables
}

# Tables that must never be readable via the AI query engine, regardless of any module
# permission. USERS holds login credentials (PASSWORD) and is not conceptually owned by any
# single GL/AR/AP/IN/PY/JC/DP permission the way business tables are -- a MODULE_TABLES entry
# would let a user with access to that module read password data. Block it unconditionally
# instead of gating it on a permission that was never meant to guard credentials.
HARD_BLOCKED_TABLES = {"USERS"}


def get_user_permissions(username: str, schema: str | None = None) -> dict | None:
    """
    Query USERS table for the given username (already uppercased by caller).
    Returns a dict of module -> permission string, or None if user not found/
    inactive/deleted (a successful query with no matching row).

    Raises psycopg.Error on a genuine DB failure -- callers must NOT treat
    that the same as "not found" (86e2t0g50/CR-20: a transient DB blip
    during verify_session()'s per-request re-check must not force-log-out
    every active user). verify_session() catches this explicitly and
    returns a retryable 503 without deleting the session. login()'s two
    call sites deliberately do NOT catch it -- it propagates to the
    global exception handler (86e2rryv8) as a generic 500, which is
    correct: a DB error during login must never look like a successful
    login (the TEST_LOGIN_PASSWORD branch's admin-fallback) or a wrong
    password.
    """
    schema = schema or _default_schema()
    sql = f"""
        SELECT "FULL_NAME", "PASSWORD", "GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES"
        FROM "{schema}"."USERS"
        WHERE "NAME" = %s
          AND "INACTIVE" IS NOT TRUE
          AND "__deleted" IS NOT TRUE
        LIMIT 1
    """
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, (username,))
            row = cur.fetchone()
    if row is None:
        return None
    return dict(row)

_TRAILING_LIMIT_RE = re.compile(r"\bLIMIT\s+(\d+)\s*;?\s*$", re.IGNORECASE)


def _bump_trailing_limit(sql: str, cap: int) -> str:
    """Raise a trailing LIMIT by one so a truncation probe row can be fetched.

    Only rewrites when the limit is at or above `cap`. A smaller limit is user
    intent -- "my top 5 customers" produces LIMIT 5, and bumping that would hand
    back a sixth row nobody asked for. A LIMIT inside a subquery or CTE is not in
    trailing position and is never touched; rewriting it would change the result.
    When nothing matches, the fetchmany(cap + 1) backstop in /query still detects
    truncation, so returning `sql` unchanged is always safe.
    """
    m = _TRAILING_LIMIT_RE.search(sql)
    if not m:
        return sql
    n = int(m.group(1))
    if n < cap:
        return sql
    return sql[: m.start(1)] + str(n + 1) + sql[m.end(1) :]


# Columns that are part of the standard EBMS schema (documented in SYSTEM_PROMPT above) but
# confirmed, on at least one real customer install, to be absent from that install's cb2pg
# mirror -- module/feature-dependent on the FoxPro side, not a model hallucination. A "column
# does not exist" error on one of these, with no Postgres HINT pointing at an alternative, is
# handled by stripping every reference to it and retrying once, rather than 422ing outright.
# CURR_ID was the original, one-off version of this handling; VALUE (INVENWH -- ticket
# 86e27h0eh, Apex Overhead Doors) is a second confirmed instance of the exact same shape, which
# is why this was generalized instead of adding a second hardcoded special case.
KNOWN_OPTIONAL_COLUMNS = {"CURR_ID", "VALUE"}

_UNDEFINED_COLUMN_SQLSTATE = "42703"
_MISSING_COLUMN_RE = re.compile(r'column\s+"?([A-Za-z0-9_.]+)"?\s+does not exist', re.IGNORECASE)
_HINT_COLUMN_RE = re.compile(r'Perhaps you meant to reference the column "([A-Za-z0-9_.]+)"\.')


def _missing_column_name(err_message: str) -> str | None:
    """Extract the bare (unqualified) column name from a 'column ... does not exist' error.

    Postgres's own message_primary takes two different shapes depending on whether the SQL
    qualified the column: 'column "L_NAM" does not exist' (bare) or 'column ARCUST.L_NAM does
    not exist' (table-qualified, unquoted) -- confirmed live against real Postgres 17, both
    forms handled by the same pattern.
    """
    m = _MISSING_COLUMN_RE.search(err_message)
    if not m:
        return None
    return m.group(1).split(".")[-1]


def _hint_column_name(hint: str | None) -> str | None:
    """Extract the column name Postgres's own HINT suggests instead, if any.

    Only present when Postgres finds a close-match column name via its own trigram similarity
    search (e.g. NXT_STP_ -> NXT_STOP_, ticket 86e1x3e04) -- confirmed live there is no hint at
    all when no plausible match exists, which is exactly when KNOWN_OPTIONAL_COLUMNS applies
    instead.
    """
    if not hint:
        return None
    m = _HINT_COLUMN_RE.search(hint)
    if not m:
        return None
    return m.group(1).split(".")[-1]


def _strip_column(sql: str, column_name: str) -> str:
    """Remove all references to column_name from SQL, for installs where it doesn't exist.

    Handles both a bare reference ("COLUMN") and a table-qualified one ("TABLE"."COLUMN") --
    rule 7 requires the model to table-qualify every column in a join, so a qualified reference
    is the common case, not the exception. Stripping only the bare "COLUMN" part and leaving a
    dangling "TABLE". prefix behind produces invalid SQL (confirmed live: found and fixed this
    exact bug while verifying the retry mechanism against real Postgres this session).
    """
    col = re.escape(column_name)
    qualified = rf'(?:"[A-Za-z0-9_]+"\.)?"{col}"'
    # Remove AND/OR conditions referencing the column (handles IS NULL, =, <>, LIKE patterns)
    sql = re.sub(rf'\s+AND\s*\([^)]*{qualified}[^)]*\)', '', sql, flags=re.IGNORECASE)
    sql = re.sub(rf'\s+OR\s*\([^)]*{qualified}[^)]*\)', '', sql, flags=re.IGNORECASE)
    sql = re.sub(rf'\s+AND\s+{qualified}\s*[^\n,)]+', '', sql, flags=re.IGNORECASE)
    sql = re.sub(rf',?\s*{qualified}', '', sql, flags=re.IGNORECASE)
    return sql.strip()

#  Confirmed real, via search_ebms's own "Security Levels" Crystal Report formula (which
# itself falls back to a numeric "7" tier -- below even "No Access" -- for anything that
# doesn't match one of these). Used only to decide whether an unrecognized value is worth a
# log.warning(), not to gate access -- see enforce_permissions()'s own comment for why an
# unrecognized value still ALLOWS rather than denies.
_KNOWN_PERMISSION_LEVELS = {"Administrator", "Manager", "Advanced Entry", "Basic Entry", "Viewer", "No Access"}


def enforce_permissions(permissions: dict, sql: str):
    """Raise 403 if the SQL touches a table the user has No Access to (or a missing/NULL/
    empty permission value -- see below)."""
    # Extract quoted uppercase table names from the SQL
    tables_in_query = set(re.findall(r'"([A-Z][A-Z0-9_]+)"', sql))
    for table in tables_in_query:
        if table in HARD_BLOCKED_TABLES:
            raise HTTPException(
                status_code=403,
                detail=f"Access to {table} is not permitted."
            )
        mod = _TABLE_TO_MODULE.get(table)
        if mod is None:
            continue
        perm = permissions.get(mod)
        # Fail CLOSED, not open (86e2rryxe): the old check was `perm == "No Access"`, an
        # exact-match denylist -- a missing key, a real Postgres NULL for that module column,
        # or an empty string (the same NULL-vs-'' hazard that's already bitten ARCUST.F_NAME,
        # ARINVDET.PAR_TIME, ARINV.SALESMAN on other tables) all fell through to "allowed".
        if not perm or perm == "No Access":
            raise HTTPException(
                status_code=403,
                detail=f"You do not have access to the {mod} module."
            )
        if perm not in _KNOWN_PERMISSION_LEVELS:
            # Genuinely unrecognized (non-empty, not "No Access") -- allow rather than lock
            # out a real customer over a security-level label this codebase has never seen
            # (EBMS installs can plausibly customize these), but make it visible instead of
            # silent, matching this project's own "loud Warn() over a silent fallback" lesson.
            log.warning(
                f"Unrecognized permission value {perm!r} for module {mod!r} -- allowing "
                f"(does not match any known EBMS security level)."
            )

def _password_matches(input_password: str, stored_password: str) -> bool:
    """
    Compare a submitted password against a USERS.PASSWORD value read from Postgres.

    Older EBMS builds store this value FoxPro-style, each ASCII byte offset by +128
    (migrated to Postgres as Latin-1). Newer EBMS builds write plain ASCII instead.
    Check both encodings since a customer's EBMS version determines which applies --
    both comparisons always run (no short-circuit) to avoid a timing side-channel.
    """
    if not stored_password:
        return False
    stored_encoded = stored_password.encode("latin-1")
    plain_encoded = input_password.encode("latin-1", errors="ignore")
    plain_match = secrets.compare_digest(plain_encoded, stored_encoded)
    try:
        shifted_encoded = bytes(ord(c) + 0x80 for c in input_password)
    except ValueError:
        # ord(c) + 0x80 > 255 for some input characters (e.g. accented letters, emoji) --
        # such a password can never match a shifted value, reject rather than crash.
        shifted_match = False
    else:
        shifted_match = secrets.compare_digest(shifted_encoded, stored_encoded)
    return plain_match | shifted_match


def is_password_weak(password: str) -> bool:
    if len(password) < 8:
        return True
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(c in string.punctuation for c in password)
    return not (has_upper and has_lower and has_digit and has_special)

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

security = HTTPBearer()

def verify_session(credentials: HTTPAuthorizationCredentials = Security(security)) -> dict:
    sess = _touch_session(credentials.credentials)
    if sess is None:
        raise HTTPException(status_code=401, detail="Session expired or invalid. Please sign in again.")
    # Re-fetch permissions from DB on every request, using the schema bound to this session
    username = sess["username"]
    try:
        row = get_user_permissions(username, sess.get("schema"))
    except psycopg.Error as e:
        # A transient DB error is not the same as a deleted/inactive account --
        # leave the session intact so the client can retry (86e2t0g50/CR-20).
        log.exception(f"Permission re-check failed for {username}: {e}")
        raise HTTPException(status_code=503, detail="Temporary server error. Please try again.")
    if row is None:
        _delete_session(credentials.credentials)
        raise HTTPException(status_code=401, detail="User account no longer active.")
    sess["permissions"] = {k: row[k] for k in ("GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES") if k in row}
    return sess


# ---------------------------------------------------------------------------
# Postgres connection
# ---------------------------------------------------------------------------

def get_conn():
    return psycopg.connect(
        host=PG_HOST,
        port=PG_PORT,
        dbname=PG_DB,
        user=PG_USER,
        password=PG_PASSWORD,
        connect_timeout=10,
        options=f"-c statement_timeout={SQL_TIMEOUT * 1000}",
        row_factory=dict_row,
    )

def _default_schema() -> str:
    """Return the first configured dataset's schema, or PG_SCHEMA as fallback."""
    return DATASETS[0]["schema"] if DATASETS else PG_SCHEMA

# ---------------------------------------------------------------------------
# Claude SQL generation
# ---------------------------------------------------------------------------

_claude = None

def get_claude():
    global _claude
    if _claude is None:
        _claude = anthropic.Anthropic(api_key=ANTHROPIC_KEY)
    return _claude

def fix_schema_quoting(sql: str) -> str:
    """Fix model occasionally quoting schema.TABLE as a single identifier instead of "schema"."TABLE"."""
    return re.sub(r'"([^"]+\.[A-Z_]+)"', lambda m: f'"{m.group(1).split(".", 1)[0]}"."{m.group(1).split(".", 1)[1]}"', sql)

def _foreign_schema_qualifiers(sql: str, expected_schema: str) -> set[str]:
    """Return the schema names, excluding `expected_schema`, of every table-position
    schema qualifier in `sql` (the "schema"."TABLE" shape fix_schema_quoting() can
    produce, or a shape the model can emit directly).

    Deliberately excludes a captured span that itself looks like a bare table name
    (all-uppercase, no colon/lowercase) -- that shape is "TABLE"."COLUMN" (a
    table-qualified column reference, mandated by SYSTEM_PROMPT rule 7 and used in
    its own rule 8/9b examples), not a schema qualifier. This codebase's real schema
    names are always cb2pg-style ("company:legacy" -- lowercase with a colon), so a
    bare-uppercase capture can never be a legitimate schema in practice.

    Known limitations, accepted (see this ticket's spec's Known Limitation section):
    like enforce_permissions()'s own table-extraction regex, this cannot distinguish
    a real identifier from the same text inside a string literal; an UNQUOTED schema
    qualifier bypasses this check entirely; and a schema-qualified table name in
    lowercase also bypasses it (enforce_permissions() shares this last one too).
    """
    found = {
        s for s in re.findall(r'"([^"]+)"\s*\.\s*"[A-Z][A-Z0-9_]*"', sql)
        if not re.fullmatch(r'[A-Z][A-Z0-9_]*', s)
    }
    return found - {expected_schema}

def _strip_sql_string_literals(sql: str) -> str:
    """Replace every single-quoted string literal's contents with an empty
    placeholder, so a downstream character/keyword scan over the remaining
    text doesn't false-positive on legitimate literal data (e.g. a customer
    name containing a semicolon, or a business name containing a word that
    looks like a SQL keyword). Handles '' as an escaped quote inside a
    literal (the standard SQL escaping convention).

    Shared infrastructure: 86e2t0g4a (write-keyword filter false-flags
    string literals) needs this identical logic -- reuse this helper there,
    don't re-derive the regex a second time.

    Known limitation, accepted: like enforce_permissions()'s own
    table-extraction regex, this is regex-based text stripping, not a real
    SQL parser -- it cannot handle every edge case a full parser would
    (e.g. dollar-quoted strings, which this codebase's generated SQL never
    uses), but single-quoted literals are the only string syntax the model
    is ever prompted to emit.
    """
    return re.sub(r"'(?:[^']|'')*'", "''", sql)


def _has_multiple_statements(sql: str) -> bool:
    """True if `sql` contains more than one non-empty statement -- i.e. a
    ';' anywhere other than as a single optional trailing terminator.
    Catches statement smuggling that the SELECT-only anchor and write-keyword
    checks miss: a smuggled second statement using no blocked keyword (a
    second SELECT, pg_sleep() for DoS, a session-level SET/COPY/VACUUM,
    etc.) still executes, since psycopg's simple-query protocol runs every
    ';'-separated statement in one call.

    Strips string literals and comments first (see
    _strip_sql_literals_and_comments()) so a legitimate semicolon inside
    free-text data isn't mistaken for a statement separator.
    """
    stripped = _strip_sql_literals_and_comments(sql).rstrip()
    if stripped.endswith(";"):
        stripped = stripped[:-1].rstrip()
    return ";" in stripped

def _strip_sql_comments(sql: str) -> str:
    """Replace every SQL comment ('-- line comment' or '/* block comment */')
    with a single space, so a downstream keyword/character scan doesn't
    false-positive on comment text.

    Must run on text that has ALREADY had string literals stripped (see
    _strip_sql_string_literals()) -- otherwise a '--' or '/*' sequence
    inside a legitimate string literal would be misread as starting a real
    comment. Callers apply both in that order, not this function alone.

    This function remains correct and is tested standalone. Callers that
    need literal-and-comment-aware stripping together should use
    _strip_sql_literals_and_comments() instead of composing this function
    with _strip_sql_string_literals() themselves -- that specific
    composition had a real false-negative (86e2wdz6p, fixed by the new
    single-pass scanner): an apostrophe inside a comment or a
    double-quoted identifier could get paired by
    _strip_sql_string_literals() with the NEXT real single-quote later in
    the SQL string -- potentially across a newline -- blanking everything
    between them, including a genuine write keyword.
    """
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.DOTALL)
    sql = re.sub(r"--[^\n]*", " ", sql)
    return sql

def _strip_sql_literals_and_comments(sql: str) -> str:
    """Single left-to-right scan that strips every single-quoted string
    literal, '--' line comment, and nesting-aware '/* */' block comment
    from `sql` in one pass -- and passes double-quoted identifiers through
    completely unscanned -- so a downstream keyword/character scan doesn't
    false-positive on legitimate literal data or comment text, and doesn't
    false-negative on a write keyword hidden by a misread span boundary.

    Replaces the previous two-sequential-regex composition
    (_strip_sql_comments(_strip_sql_string_literals(sql))), which had a
    real false-negative (86e2wdz6p): an apostrophe inside a comment or a
    double-quoted identifier could get paired by the literal-stripping
    regex with the NEXT real single-quote later in the string --
    potentially across a newline -- blanking everything between them,
    including a genuine write keyword or (in _has_multiple_statements())
    a genuine statement-separating semicolon.

    This eliminates that specific bug class for the string/comment syntax
    it recognizes -- single-quoted literals (with '' escaping), '--' line
    comments, nesting-aware '/* */' block comments, and "..." identifiers
    (with "" escaping) -- by recognizing each span as a whole before ever
    looking at what's inside it, so an apostrophe or '--'/'/*' sequence
    already inside a comment or identifier can never be misread as
    starting a different span.

    _strip_sql_string_literals()/_strip_sql_comments() are NOT replaced by
    this function everywhere -- they remain individually correct and
    directly unit-tested. This function replaces only the vulnerable
    composition at its two call sites (the write-keyword check in
    query(), and _has_multiple_statements()).

    FAIL-CLOSED ON UNRECOGNIZED STRING SYNTAX (86e2wdz6p final-review
    fix): this scanner does not recognize dollar-quoted ($tag$...$tag$)
    string syntax, which the model is never prompted to emit. A raw,
    unescaped quote character inside one of these can make a real literal
    or block comment look unterminated to this scanner. Rather than
    silently consuming the rest of the string in that case (which would
    hide anything after it, including a write keyword -- a real,
    confirmed regression an earlier version of this function had, caught
    in this cluster's own final review), an unterminated literal or block
    comment makes this function return the ORIGINAL `sql` completely
    unchanged, so the caller's regex scans the raw text instead of
    trusting output from a scan that ran off the end. query() also
    rejects generated SQL containing dollar-quote syntax outright (see
    the dollar-quote guard beside the write-keyword check) as a second,
    independent layer, since that syntax is never legitimately needed
    here.

    ACTIVE DETECTION OF E'...'/U&'...' PREFIXES (86e2yq8d0): this scanner
    also does not implement PostgreSQL's E'...' (C-style backslash-escape
    string) or U&'...' (Unicode-escape string) grammars -- both support
    `\'` as an additional way to escape an embedded quote, on top of the
    `''`-doubling this scanner understands, with distinct escaping rules
    from each other. Rather than let this scanner's ''-doubling-only
    logic misread a `\'` inside one of these, 86e2wdz6p's final review
    found that TWO separate E'...'/U&'...' spans, each containing one
    stray escaped quote immediately followed by its own real terminating
    quote, could have their stray-quote-plus-terminator pairs each get
    misread as a single '' doubled escape -- keeping the scanner's notion
    of "still inside a literal" open across the ENTIRE stretch between
    the two spans, silently swallowing whatever real SQL sits there
    (including a write keyword or a statement-separating semicolon)
    without either span ever looking unterminated, so the existing
    unterminated-span fail-closed path never triggered. This is now
    closed by detecting an E'/U&' prefix directly, at the exact point a
    new top-level literal would begin (immediately before the character
    identified as `'` is treated as an ordinary literal's opening quote):
    checking whether the character(s) immediately preceding that quote
    form a bare `E`/`e`, or a bare `U`/`u` immediately followed by `&`,
    themselves not preceded by an identifier character. This can never
    mis-fire on a quote character that is itself inside an
    already-recognized literal/identifier/comment span (like `'E'`'s own
    closing quote) -- those spans are consumed whole by their own
    branches above before control returns to the top of this loop, so
    their interior characters are never re-examined by this check. On a
    match, this function returns the ORIGINAL `sql` unchanged -- the same
    fail-closed sentinel used for the unterminated-literal/
    unterminated-block-comment cases above, not new fail-open/fail-closed
    logic.
    """
    out = []
    i = 0
    n = len(sql)
    while i < n:
        ch = sql[i]
        if sql.startswith("--", i):
            j = sql.find("\n", i)
            end = j if j != -1 else n
            out.append(" ")
            i = end
            continue
        if sql.startswith("/*", i):
            depth = 1
            j = i + 2
            while j < n and depth > 0:
                if sql.startswith("/*", j):
                    depth += 1
                    j += 2
                elif sql.startswith("*/", j):
                    depth -= 1
                    j += 2
                else:
                    j += 1
            if depth > 0:
                # Unterminated block comment -- fail closed. See docstring.
                return sql
            out.append(" ")
            i = j
            continue
        if ch == '"':
            j = i + 1
            while j < n:
                if sql[j] == '"':
                    if j + 1 < n and sql[j + 1] == '"':
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            else:
                j = n
            out.append(sql[i:j])
            i = j
            continue
        if ch == "'":
            # 86e2yq8d0: an E'...' or U&'...' prefix uses backslash (\')
            # as an additional way to escape an embedded quote, which this
            # scanner's ''-doubling-only logic doesn't understand -- and
            # two such spans can have their misread quote-pairings chain
            # into EACH OTHER, hiding real SQL between them without ever
            # looking unterminated (see docstring). Detect the prefix
            # HERE, at the exact point a new top-level literal would
            # begin, before any content is consumed -- this can never
            # mis-fire on a quote already inside an open literal/
            # identifier/comment span, since those are consumed whole by
            # their own branches above before control returns to the top
            # of this loop.
            # An unquoted PostgreSQL identifier may contain '$' after its
            # first character, not just alnum/'_' -- an identifier like
            # abc$E directly abutting a quote (abc$E'x') is real PG
            # identifier-then-plain-literal syntax, not an E'...' prefix.
            # Excluding '$' here too avoids fail-closing on that (a purely
            # theoretical case for this project's own generated SQL, but
            # matching the real grammar is cheap and removes the
            # ambiguity entirely rather than leaving it as a known gap).
            is_e_prefix = i >= 1 and sql[i - 1] in ("E", "e") and (
                i < 2 or not (sql[i - 2].isalnum() or sql[i - 2] in ("_", "$"))
            )
            is_u_amp_prefix = (
                i >= 2
                and sql[i - 1] == "&"
                and sql[i - 2] in ("U", "u")
                and (i < 3 or not (sql[i - 3].isalnum() or sql[i - 3] in ("_", "$")))
            )
            if is_e_prefix or is_u_amp_prefix:
                # Unsupported string syntax -- fail closed. See docstring.
                return sql
            j = i + 1
            terminated = False
            while j < n:
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":
                        j += 2
                        continue
                    j += 1
                    terminated = True
                    break
                j += 1
            if not terminated:
                # Unterminated string literal -- fail closed. See docstring.
                return sql
            out.append("''")
            i = j
            continue
        out.append(ch)
        i += 1
    return "".join(out)

def _log_cache_usage(label: str, msg) -> None:
    """Record prompt-cache effectiveness so a silent cache miss is visible in the log.

    A broken cache does not raise -- it just bills full price forever. The one
    reliable signal is cache_read_input_tokens staying at 0 across repeat calls,
    so log the three counts and let agent.log answer "is caching actually working"
    without needing a test harness.
    """
    try:
        u = msg.usage
        read = getattr(u, "cache_read_input_tokens", 0) or 0
        write = getattr(u, "cache_creation_input_tokens", 0) or 0
        fresh = getattr(u, "input_tokens", 0) or 0
        total = read + write + fresh
        hit = "READ" if read else ("WRITE" if write else "MISS")
        log.info(
            f"cache[{label}] {hit} read={read} write={write} uncached={fresh} "
            f"total_input={total}"
        )
    except Exception as e:  # never let telemetry break a query
        log.debug(f"cache usage logging failed: {e}")

def _history_message_content(h: "HistoryMessage") -> str:
    """Build the content sent to Claude for one history turn's OWN text.

    Assistant turns send SQL (unambiguous for date/filter references) rather than the
    natural-language answer. Deliberately NEVER appends row data here, even when the turn
    captured rows -- see _build_messages() for where and why captured rows are surfaced
    instead. An earlier version appended a "[REFERENCE ONLY...]" + JSON rows block directly
    onto the assistant turn's own content. Live verification
    (.superpowers/sdd/2026-08-01-followup-context-loss/task-6-report.md, "Concern found
    during verification") showed the model would sometimes imitate that shape in its OWN
    new output -- appending a fabricated trailing JSON block after an otherwise-correct SQL
    statement and breaking the query with a Postgres syntax error. Softening the wording of
    that same annotation (still embedded in an assistant turn) only changed which literal
    text got echoed (25% -> 20%, live-verified, not a meaningful drop) -- the model was
    imitating the SHAPE of its own past turns, not any particular wording in them. Moving
    the rows out of assistant turns entirely (see _build_messages) is what actually fixed it.
    """
    if h.role == "assistant" and h.sql:
        return h.sql
    return h.content

def _rows_reference_note(rows: list) -> str:
    """Build the '[REFERENCE ONLY...]' block for rows a prior query returned. Callers must
    attach this to a USER-role message, never inside an assistant turn's own content --
    see _build_messages() for why."""
    return (
        "[REFERENCE ONLY -- rows a previous query returned, shown so you can resolve a "
        'follow-up reference (e.g. "those 2"). This describes data from a PAST turn; it is '
        "not something you produced and not a template for your own output.]\n"
        + json.dumps(rows, default=str)
    )

def _build_messages(history: list, question: str) -> list[dict]:
    """Build the Claude messages list for one generate_sql() call.

    Assistant turns are sent as ONLY their own SQL (via _history_message_content) -- never
    with row data attached -- so the model is never shown an assistant turn shaped like
    "SQL followed by a rows/JSON block," which live verification found the model would
    sometimes imitate in its own new output (see _history_message_content's docstring).
    Any rows captured from an assistant turn are instead prefixed onto the NEXT ROLE="USER"
    message -- the following history turn if there is one, otherwise the new question being
    asked right now. A block that only ever appears on a "user" turn in this transcript has
    no assistant-authored precedent for the model to pattern-match against.

    Only the MOST RECENT rows-bearing assistant turn's rows are ever surfaced -- every earlier
    rows-bearing turn's rows are dropped entirely (their SQL is still shown, per the above,
    just not their row data). Anaphoric follow-ups ("those 2", "the list") in every ticket this
    was built for only ever reference the immediately preceding relevant turn; attaching every
    historical turn's rows would mean up to MAX_ROWS captured rows x up to 10 turns of history,
    all sent as UNCACHED per-request content (only the system prompt is cache-breakpointed),
    for no behavioral benefit over surfacing just the latest one.
    """
    last_rows_idx = None
    for i, h in enumerate(history):
        if h.role == "assistant" and h.rows:
            last_rows_idx = i

    messages = []
    pending_rows_note = None
    for i, h in enumerate(history):
        content = _history_message_content(h)
        if h.role == "user" and pending_rows_note:
            content = pending_rows_note + "\n\n" + content
            pending_rows_note = None
        messages.append({"role": h.role, "content": content})
        if h.role == "assistant" and h.rows and i == last_rows_idx:
            pending_rows_note = _rows_reference_note(h.rows)
    q_content = question
    if pending_rows_note:
        q_content = pending_rows_note + "\n\n" + q_content
    messages.append({"role": "user", "content": q_content})
    return messages

# Defense-in-depth guard against the hallucination fixed by _build_messages() above (see its
# docstring): the model occasionally still emits its own SQL followed by a trailing
# "[REFERENCE ONLY..." marker or a JSON-array-looking block. This does not replace the
# prompt-level fix -- it converts "very unlikely to reach the customer" into "structurally
# impossible," for near-zero cost. A line starting with "[{" or '["' (or the literal marker)
# has not been observed as valid standalone SQL in this codebase's generated queries (a
# constructed counter-example like `ANY(ARRAY\n["COL1","COL2"])` could in principle still get
# clipped, though this model has never produced that shape in practice).
#
# Matches either at the very start of the text (\A) or after a newline, both followed by
# optional whitespace then the marker/JSON opener. The \A branch matters for `clarification`
# (see generate_sql()): when the fenced-SQL case's trailing block IS the entire clarification
# text, .strip() has already removed any leading newline before this check ever runs, so a
# newline-only anchor would miss it.
_TRAILING_REFERENCE_BLOCK_RE = re.compile(
    r'(?:\A|\n)\s*\[\s*(?:REFERENCE ONLY\b|[{"]).*', re.IGNORECASE | re.DOTALL
)

def _strip_trailing_reference_block(text: str) -> tuple[str, str]:
    """If `text` contains a '[REFERENCE ONLY...' marker or JSON-array-looking block -- as a
    trailing tail, or as the ENTIRE text -- cut it off. Returns (clean_text, stripped_text) --
    `stripped_text` is empty when nothing was cut, otherwise it is the offending portion, for
    logging only. Callers must NOT surface `stripped_text` to the user; see generate_sql(),
    which applies this to both the extracted `sql` and `clarification`."""
    m = _TRAILING_REFERENCE_BLOCK_RE.search(text)
    if not m:
        return text, ""
    return text[:m.start()].rstrip(), text[m.start():].strip()

def _looks_like_sql_paragraph(paragraph: str) -> bool:
    """True if a blank-line-separated chunk of a would-be SQL response itself looks like
    it begins a SQL statement, clause, or comment, rather than an English sentence.
    Deliberately broad (covers common clause-continuation keywords, not just SELECT/WITH)
    so a legitimately blank-line-formatted multi-clause query is never mistaken for prose --
    false NEGATIVES here (missing a real prose leak) are the accepted cost, not false
    positives against real SQL."""
    return bool(re.match(
        r'^\s*(?:'
        r'SELECT\b|WITH\b|FROM\b|WHERE\b|AND\b|OR\b|GROUP\s+BY\b|ORDER\s+BY\b|HAVING\b|LIMIT\b|UNION\b|'
        r'JOIN\b|INNER\s+JOIN\b|LEFT\s+JOIN\b|RIGHT\s+JOIN\b|ON\b|CASE\b|WHEN\b|--|\(|\)|'
        r'[A-Za-z_][A-Za-z0-9_]*\s+AS\s*\('  # a bare CTE name declaration, e.g. `fy_dates AS (`
        r')',
        paragraph, re.IGNORECASE
    ))

def _detect_self_correction_leak(sql: str) -> tuple[str, str]:
    """Detect the model second-guessing its own SQL mid-response instead of using the
    CANNOT_QUERY path: a complete-looking SQL statement, then (after a blank line) a plain
    English sentence -- sometimes itself followed by a second SQL attempt.

    Found live 2026-08-03 investigating a residual failure on ambiguous "last year"
    questions once the prompt started discussing calendar-vs-fiscal-year resolution: e.g.
        SELECT "FIRST_M"::int AS fiscal_start_month FROM "..."."GLCTL" LIMIT 1

        Once I know your fiscal year structure, I'll query the top 5 vendors...
    -- a syntactically valid probing query, followed by prose that was clearly meant to be
    a CANNOT_QUERY clarification but wasn't formatted as one. The trigger topic (fiscal vs.
    calendar year) is specific to this investigation, but the SHAPE (SQL, blank line, prose,
    optionally more SQL) is general and not itself about fiscal year -- this guard does not
    look for that wording at all, only the structural shape.

    Deliberately conservative: if ANY non-empty paragraph after the first fails to look like
    SQL, the WHOLE response is treated as unresolved and collapsed to CANNOT_QUERY, rather
    than trying to guess which of several candidate SQL paragraphs is the model's real,
    on-topic answer. A later paragraph is sometimes a fully correct second attempt (see the
    example above) and sometimes just a caveat after an already-correct first statement --
    but it can also be a probing query answering a different question entirely (like the
    GLCTL example above), and there is no reliable way to tell those apart without executing
    the SQL. Per this project's own repeated rule (never silently return a wrong-topic
    answer), a clean refusal is the safe default when this shape appears at all; a false
    positive here just costs one refusal on an otherwise-fine answer, which is far cheaper
    than guessing wrong.

    Returns (sql, leaked_text). leaked_text is empty when nothing was detected; otherwise
    sql is forced to "CANNOT_QUERY" and leaked_text is the original text, for logging only
    -- never surfaced to the user, same convention as _strip_trailing_reference_block.

    Never touches a response that already starts with CANNOT_QUERY -- that is a legitimate,
    intentional multi-paragraph shape (e.g. "CANNOT_QUERY: Which warehouse did you mean?\\n\\n
    I found La Crete, Fort Vermilion and Main."), not a self-correction leak. Code-review
    finding: without this guard, the second paragraph's plain English fails the SQL-paragraph
    check the same way a genuine leak would, so the WHOLE clarifying question was being
    collapsed to the generic "I can only answer..." boilerplate -- losing the model's actual,
    answerable question, and (via the caller clearing `clarification` in response) also
    corrupting the follow-up rule (c) history mechanism that lets a user complete the model's
    own prior clarifying question in their next turn.
    """
    if sql.lstrip().upper().startswith("CANNOT_QUERY"):
        return sql, ""
    paragraphs = re.split(r'\n\s*\n', sql)
    if len(paragraphs) < 2:
        return sql, ""
    for p in paragraphs[1:]:
        if p.strip() and not _looks_like_sql_paragraph(p):
            return "CANNOT_QUERY", sql
    return sql, ""

def generate_sql(question: str, schema: str, history: list = None) -> tuple[str, str]:
    """Returns (sql, clarification) where clarification is any follow-up text the model appended."""
    now = _today_local()
    fiscal_start_month = _fiscal_start_month(schema)
    fy_boundaries = _fiscal_year_boundaries(fiscal_start_month, now)
    prompt = _build_prompt(schema, now.strftime("%Y-%m-%d"), now.strftime("%A"), now.year, fiscal_start_month,
                            fy_boundaries["last_fy_start"], fy_boundaries["last_fy_end"],
                            fy_boundaries["current_fy_start"], has_history=bool(history))
    messages = _build_messages(history or [], question)
    msg = get_claude().messages.create(
        model="claude-haiku-4-5-20251001",
        # Known_Issues.md #42 (ClickUp 86e2uccxg): a broad "CFO health-check" question invites
        # a multi-CTE analytical query (revenue trend + AR health + overdue aging in one
        # statement) long enough to hit a 1024 ceiling mid-string, producing SQL that fails
        # with a confusing Postgres syntax error instead of a clean, diagnosable signal.
        # Raised to 4096 as the primary fix; the stop_reason check below is the backstop for
        # whatever still doesn't fit even at that size.
        max_tokens=4096,
        # Cache the system prompt. It is ~64KB and was previously re-sent as fresh
        # input on every single query -- the dominant cost of this endpoint by far.
        # Cache reads bill at ~0.1x of input, so this is close to a 90% cut on the
        # prompt portion. The breakpoint goes on the whole block: {schema} is fixed
        # per install and the injected date only changes at local midnight. Since
        # _build_prompt() conditionally splices in FOLLOWUP_RESOLUTION_RULES based on
        # has_history, each customer actually holds TWO cache entries per day (with
        # history / without), not one -- a small, already-accepted cost increase.
        system=[{
            "type": "text",
            "text": prompt,
            "cache_control": {"type": "ephemeral"},
        }],
        messages=messages,
    )
    _log_cache_usage("generate_sql", msg)
    if msg.stop_reason == "max_tokens":
        # The model was still writing when it hit the ceiling -- whatever text came back is a
        # cut-off fragment, not valid SQL. Returning it would fail downstream with a cryptic
        # Postgres syntax error (Known_Issues.md #42's original symptom); return a clean,
        # diagnosable refusal instead.
        log.warning(
            "generate_sql: hit the max_tokens ceiling before finishing SQL generation "
            f"(question={question!r}) -- returning CANNOT_QUERY instead of truncated SQL"
        )
        return (
            "CANNOT_QUERY: That question needs a broader query than I can generate in one "
            "pass. Try breaking it into smaller, more specific questions (e.g. one metric or "
            "time period at a time).",
            "",
        )
    full_response = msg.content[0].text.strip()
    clarification = ""

    # If the model wrapped SQL in a code fence, extract SQL and capture anything after the fence
    fence_match = re.search(r"```(?:sql)?\s*\n(.*?)```(.*)", full_response, re.IGNORECASE | re.DOTALL)
    if fence_match:
        sql = fence_match.group(1).strip()
        clarification = fence_match.group(2).strip()
    else:
        sql = full_response
        # No fences - if model prefixed with explanation, extract from SELECT/WITH onward
        if not re.match(r"^\s*(SELECT|WITH|CANNOT_QUERY)\b", sql, re.IGNORECASE):
            sql_match = re.search(r"^\s*(SELECT|WITH)\b", sql, re.IGNORECASE | re.MULTILINE)
            if sql_match:
                clarification = sql[:sql_match.start()].strip()
                sql = sql[sql_match.start():].strip()
            else:
                # No SQL found at all - treat entire response as a clarification
                clarification = full_response
                sql = "CANNOT_QUERY"

    sql, stripped_reference_block = _strip_trailing_reference_block(sql)
    if stripped_reference_block:
        # Deliberately NOT appended to `clarification` -- that gets shown to the user (see
        # /query's answer-building), and showing the stripped block would just relocate the
        # exact leak this guard exists to prevent. Log only, for visibility into how often
        # the prompt-level fix is still letting this shape through.
        log.warning(
            "generate_sql: stripped a trailing reference/JSON block from the model's own "
            f"SQL output (question={question!r}): {stripped_reference_block[:300]!r}"
        )

    sql, self_correction_leak = _detect_self_correction_leak(sql)
    if self_correction_leak:
        # Same "log only, never surface" convention as the reference-block guard above.
        # This collapses to CANNOT_QUERY rather than trying to salvage a "best" SQL
        # paragraph -- see _detect_self_correction_leak's docstring for why guessing among
        # candidates is unsafe here.
        clarification = ""
        log.warning(
            "generate_sql: detected the model second-guessing its own SQL mid-response "
            f"(question={question!r}); collapsed to CANNOT_QUERY: {self_correction_leak[:300]!r}"
        )

    # Same guard, applied to `clarification` too. The fenced-SQL case above captures
    # everything after the closing fence as `clarification` -- if the model appended the
    # "[REFERENCE ONLY..." / JSON block AFTER the fence rather than inside it, that text
    # never goes near `sql` or the guard above, and `clarification` gets appended verbatim to
    # the user-visible answer (see /query's answer-building). Without this, the fenced-SQL
    # variant of the same hallucination would still reach the customer even though the
    # unfenced variant is now blocked.
    clarification, stripped_from_clarification = _strip_trailing_reference_block(clarification)
    if stripped_from_clarification:
        log.warning(
            "generate_sql: stripped a reference/JSON block from the model's own clarification "
            f"text (question={question!r}): {stripped_from_clarification[:300]!r}"
        )

    return sql.strip(), clarification

# ---------------------------------------------------------------------------
# Answer formatting
# ---------------------------------------------------------------------------

# Rendered via FORMAT_PROMPT.format(year=...) in format_answer() below -- any literal brace in
# this template must be doubled ({{ / }}) or .format() raises (see CLAUDE.md's brace-escaping
# rule; {coverage} and the JSON row example below are deliberately doubled for this reason).
FORMAT_PROMPT = """You are a concise business assistant. The user asked a question about their EBMS ERP data.
You have the raw query results. Format a clear, helpful answer in plain English.
Use dollar formatting for amounts. Be direct - no preamble. Do not build markdown tables of the
result rows; the app renders those itself (see DO NOT TYPE OUT ROW TABLES below).
If results are empty and the question involved a customer, vendor, or item name, suggest the user may have used a different spelling or abbreviation (e.g. "T.I.C. Parts & Service" vs "TIC parts", or "Catering" vs "CATERING") and offer to search again with a different spelling.
If results are empty for any other reason, say so plainly and suggest why (e.g. no open invoices, date range issue).
NEVER ask the user to run a query themselves, copy SQL, or "share the result" -- you run the queries, not the user.

NEVER FABRICATE QUERY RESULTS. If a query executes and returns rows, report those rows
accurately. Do not state that no results were found, or summarize a result as empty/
partial/inconclusive, unless the result set is genuinely empty (zero rows). If you are
uncertain what a query actually returned, say so explicitly rather than asserting a
result you haven't verified. (86e1x3g0m: a customer was told "none found" for a query
that had actually returned 15 rows, and only got the correct answer after pushing back
twice.)

NEVER COMPUTE A TOTAL YOURSELF. Every number you state must already be present in the query results.
Do NOT add up a column across returned rows, do NOT subtotal a subset of the rows, and do NOT derive a
percentage or split from row-by-row arithmetic. If the results are a row list with no aggregate column and
the user asked for a total, report what the rows show and say the total was not part of the result set --
do not supply the figure from your own arithmetic. Hand-summed figures have been wrong by tens of thousands
of dollars in real customer answers, and the customer has no way to tell a computed number from a queried one.
Restating a single value that appears in one returned cell is fine; that is reading, not computing.

DO NOT TYPE OUT ROW TABLES. The app renders the result rows as a real scrollable table directly
below your answer, so a markdown table in your text duplicates it, and yours is capped by your own
token budget while the app's is not. Write the summary and the figures; the table is not your job.
  WRONG:   Here are your June invoices:
           | Invoice | Date | Customer | Total |
           | 29185 | {year}-06-19 | Molette Wedding | $10,576.03 |
           | 29186 | {year}-06-20 | Conestogo Agri | $18,791.90 |
           ...and 48 more rows typed out one by one
  CORRECT: Your June {year} invoices are in the table below. If you want the total, ask for it
           directly and it will be computed in SQL rather than added up by eye.
EXCEPTION: when the result is a SINGLE row, state its figures in your text as normal. The app
suppresses the table for single-row results, so there is nothing to duplicate.
If the results carry "_match_count" or "_match_total" columns, those are the true count and total
across EVERY matching row, computed by Postgres before any row limit was applied. Read them off the
first row and state them. They remain correct even when fewer rows came back than actually matched,
so prefer them over anything the visible rows suggest. Reading them is reading a returned cell, not
computing.
IF THE RESULTS SAY TRUNCATED, the row count you were given is a CEILING, not the real number --
UNLESS "_match_count" or "_match_total" are present (see above), in which case those ARE the real
figures and this "at least N" fallback does not apply.
  WRONG (ignoring _match_count/_match_total when they are right there in the data):
    Results (TRUNCATED -- 5 rows returned, but MORE than 5 actually matched):
    [{{"INVOICE": "29185", "TOTAL": "1200.00", "_match_count": 176, "_match_total": "421264.01"}}, ...]
    -> "I can show at least 5 invoices, but the full total was not part of the result."
  CORRECT (reading the true figures off the columns that are actually there):
    -> "There are 176 matching invoices totaling $421,264.01. Showing the first 5 below."
When "_match_count"/"_match_total" are ABSENT from a truncated result, the ceiling caveat still
applies as before: never state the visible row count as the number of matching records. Say
"at least N" or "the first N shown", and state plainly that the full total was not part of the
result. Do not estimate or extrapolate the real figure from the rows you can see. If the user
needs the true total, say that asking for the total directly will compute it in SQL.

EBMS STATUS codes - never mischaracterize these:
  'O' = outstanding (posted, unpaid invoice - money still owed)
  'X' = paid / closed (invoice has been paid - NOT cancelled, NOT voided)
  'U' = unprocessed (sales order not yet invoiced - never a real invoice)
When the SQL includes STATUS IN ('O','X') it means all posted invoices: both outstanding and paid.
When the SQL filters STATUS = 'O' only, it means unpaid/open invoices.

When showing balance totals (this MUST match how the SQL computed them - do not re-net the numbers yourself):
- A credit memo has a negative TOTAL. KEEP it in the total as a negative - it legitimately reduces what is owed. Do NOT drop it.
- A POSITIVE invoice with a negative BALANCE is an overpayment. It nets against what is owed exactly like a
  credit memo does - KEEP it as a negative contribution too. Do NOT floor it to $0.
- A grand total across multiple customers/vendors is: invoices subtotal (TOTAL >= 0, no flooring) PLUS credit
  memos subtotal (TOTAL < 0, kept negative) = net owing. If breaking this out for the user, present three lines:
  Invoices $X / Credit memos -$Y / Net owing $Z.
- For a single customer or vendor, a plain net balance is fine - their own credits net against their own invoices.
- Never silently discard negative rows (credit memos OR overpayments) - dropping either overstates what is owed.

ANALYTICAL ANSWERS (profit, margin, "most profitable", "dragging me down", spend trends, dead stock, late payers):
- These return a calculated number the user cannot eyeball-verify, so always make your method visible and correctable.
- End the answer with ONE plain-English methodology line stating what was measured and over what window, e.g.:
    "Gross margin = (net sales after line discounts - cost of goods) / net sales, on posted invoices this fiscal year. Excludes freight, handling, tax and header-level discounts."
    "Spend compared: last 90 days vs the prior 90 days, on posted invoices."
- Keep it to one line. The point is that the user can spot if your definition differs from their accountant's, not to write an essay.

PROXY ANSWERS (the user asked something predictive or judgemental - "likely to churn", "at risk", "will be late", "bad debt"):
- The data cannot predict; the SQL answered the closest FACTUAL signal instead. Be honest about this up front.
- LEAD with a one-line disclaimer naming the limit and what you measured instead, then give the real data. Example:
    "I can't predict which customers will stop buying, but here are customers whose spend dropped more than 50% in the last 90 days vs the prior 90 - a common early warning sign:"
- Never present a proxy as a prediction. No invented probabilities, scores, or "X% likely" figures - only what the data actually shows.

SANITY CHECK ON CALCULATED PERCENTAGES (flag impossible results - do NOT hide plausible ones):
- A gross margin % ABOVE 100, or any result computed from a NEGATIVE net-revenue figure, is mathematically impossible for a real margin and almost always signals a data issue (a bad join, or cost/credit-memo sign problem), NOT a real business result.
- There is NO lower bound on a real margin: a deep loss can be -150%, -300%, etc. (selling far below cost). Do NOT flag a large negative margin as impossible - it is a valid, if alarming, result. Only >100% and negative-net-revenue are truly impossible.
- When you see an impossible value, DO NOT report it as fact. Instead: state the figure, say plainly it isn't a possible real margin and likely reflects a data issue in how costs/credits are recorded, SHOW the raw underlying numbers (net sales and COGS), and advise verifying before relying on it.
    Example: "That comes out to 312%, which isn't possible for a real gross margin - it likely reflects a data issue in how costs are recorded on these invoices. Raw figures: net sales $X, cost of goods $Y. Worth checking the cost data before relying on this."
- This applies ONLY to mathematically-impossible values. Normal-but-surprising results (a thin 3% margin, a real -12% loss, even a real -200% loss on items dumped below cost) are valid answers - report them normally. NEVER suppress or cast doubt on a plausible number just because it is bad news.

COST-DATA COVERAGE REFUSAL (when the margin query returns a coverage ratio below 0.80):
- The margin recipe gates on cost-data coverage. If the query reports coverage < 80% (most revenue has no recorded cost), DO NOT state a margin %.
- Instead, refuse honestly and explain the gap, then offer what you CAN show. Be specific about the coverage figure if available.
    Example: "I can't give you a reliable gross margin - cost is recorded on only about {{coverage}}% of your sales, so any margin figure would be badly overstated (uncosted lines look like 100% profit). Your EBMS Product Profit report has the same blind spot for the same reason. To get a real margin, item costs need to be maintained at the time of sale. In the meantime I can show revenue, top products by sales, top customers, or AR - just ask."
- Frame this as IntraMind catching a data-quality issue, not as a limitation of IntraMind. It is a trust signal, not a failure.
- COMPOUND LABOR+PRODUCT margin query (e.g. "margin on labor and parts together") that legitimately executes SQL spanning
  C_TYPE 0-4 and lands here on low coverage: explain that labor/service lines never carry a recorded cost in EBMS by design
  (not just "this period"), so blending them with inventoried lines drags coverage down structurally. Offer margin scoped to
  just the inventoried lines as the fix, not merely "try again later" - this is a different situation than "no cost data yet".
- EMPTY RESULT on a margin query (all aggregates NULL / zero rows): this usually means the C_TYPE IN (2,3,4) inventoried-line
  filter matched NOTHING - i.e. the customer made NO inventoried-product sales in this period (common for service businesses).
  Do NOT explain an empty margin result as "no posted invoices this period" - the customer may have many invoices, just none of
  the inventoried type. Say instead: "I don't see any inventoried-product sales (tracked items) in this period, so there's no
  cost-based margin to calculate. If you sell services or labor, those carry no recorded cost. I can show your margin across ALL
  line types (it will note how much is actually cost-backed), or revenue, top customers, or AR - just ask." Only attribute an
  empty result to missing invoices if you have separate evidence there are genuinely no posted invoices at all.

SANITY CHECK ON NEGATIVE ON-HAND INVENTORY QUANTITIES (flag as unusual - do NOT build a confident narrative on top):
- A negative on-hand quantity (INVENTRY.COUNT, INVENWH.COUNT, or a sum of either) is physically atypical for a real inventory
  item - you cannot have fewer than zero physical units on a shelf. Unlike an impossible margin (which is a hard mathematical
  contradiction), a negative on-hand figure CAN be a genuine, correctly-recorded EBMS state (an unposted return, a warehouse
  transfer in transit, an over-issued adjustment, a legitimate backorder-tracking convention) - so state the number plainly,
  do not suppress or "correct" it, and do not treat it as necessarily wrong the way an impossible margin is.
- What you must NOT do: invent operational commentary or advice on top of the number that the data does not
  support - "you're short," "you owe inventory," "receive stock immediately," "you need to reorder now." A
  negative figure alone tells you the number is unusual, not why, and not what the business should do about it.
    WRONG:   "You have -5.00 units of 1A1316480 on hand. You're 5 units short and should receive stock immediately to
              cover the shortfall and get back to a positive position."
    CORRECT: "On-hand for 1A1316480 comes out to -5.00 units. A negative on-hand count is unusual for a physical item -
              it can reflect a pending transfer, an unposted return, or an inventory adjustment. Worth checking the item's
              transaction history in EBMS before treating this as a real shortage."
- If the figure is a sum across multiple warehouses and any single warehouse's contribution is itself deeply negative while
  others are positive, you may mention that breakdown (it is often the most useful diagnostic detail), but still without
  asserting which warehouse is "wrong" or why - simply state the per-warehouse figures alongside the total. Do not label a
  warehouse a "backorder" or "virtual" bucket unless something in the data itself says so (a warehouse type/flag) - EBMS does
  not universally reserve any particular warehouse code for that purpose, and treating one that way without evidence has
  produced a wrong diagnosis before."""

def _jsonable_rows(rows: list[dict]) -> list[dict]:
    """Coerce psycopg row values into types Pydantic can serialize.

    Postgres hands back Decimal, date and datetime, none of which Pydantic will
    encode. This is the same json.dumps(..., default=str) coercion format_answer
    has always used, applied once so the browser payload and the model's copy can
    never diverge. Numbers and dates come out as strings; the client already
    handles that (appendKPIDetail parseFloats its balance column).
    """
    return json.loads(json.dumps(rows, default=str, allow_nan=False))


def _model_rows(rows: list[dict]) -> list[dict]:
    """The slice of rows the answer-formatting model sees.

    Logs when the slice is smaller than the result, because that gap was invisible
    at every layer before now -- it is why an answer could narrate 200 rows while
    having seen 50, and it survived unnoticed since the initial commit.
    """
    if len(rows) > MODEL_ROWS:
        log.info(f"format_answer sees {MODEL_ROWS} of {len(rows)} rows")
    return rows[:MODEL_ROWS]


def format_answer(question: str, rows: list[dict], sql: str, history: list = None,
                  truncated: bool = False, row_cap: int = 0) -> str:
    if not rows:
        data_str = "Query returned 0 rows."
    else:
        data_str = json.dumps(_model_rows(rows), default=str, indent=2)

    if truncated:
        has_true_figures = bool(rows) and ("_match_count" in rows[0] or "_match_total" in rows[0])
        if has_true_figures:
            count_note = (f"Results (TRUNCATED -- {len(rows)} rows returned, but MORE than {row_cap} "
                          f"actually matched; the TRUE count and total ARE present, in the "
                          f"_match_count/_match_total columns on the first row -- read and state those)")
        else:
            count_note = (f"Results (TRUNCATED -- {len(rows)} rows returned, but MORE than {row_cap} "
                          f"actually matched; the true count and total were NOT returned)")
    else:
        count_note = f"Results ({len(rows)} rows)"

    messages = []
    for h in (history or []):
        messages.append({"role": h.role, "content": h.content})
    messages.append({
        "role": "user",
        "content": f"Question: {question}\n\nSQL used: {sql}\n\n{count_note}:\n{data_str}"
    })
    year = _today_local().year
    # Deliberately NOT cached: FORMAT_PROMPT is ~8KB, roughly 2-3K tokens, and Haiku
    # 4.5 will not cache a prefix under 4,096 tokens. A cache_control here would be a
    # silent no-op (no error, cache_creation_input_tokens just stays 0) while implying
    # in the code that this call is cached. Revisit only if this prompt grows past 4K
    # tokens. The rows appended below are per-query anyway and could never cache.
    msg = get_claude().messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=2048,
        system=FORMAT_PROMPT.format(year=year),
        messages=messages,
    )
    _log_cache_usage("format_answer", msg)
    return msg.content[0].text.strip()

# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

class LoginRequest(BaseModel):
    username: str
    password: str
    dataset: str = ""  # schema string of the chosen dataset; empty = use first/default

class HistoryMessage(BaseModel):
    role: str     # "user" or "assistant"
    content: str  # English answer (used by format_answer for context)
    sql: str = "" # SQL query (used by generate_sql for context -- unambiguous for date/filter references)
    rows: list[dict] | None = None  # up to 20 rows this turn's SQL returned, used by generate_sql
                                     # to resolve anaphoric references ("those 2") to actual entity
                                     # identities -- format_answer no longer enumerates rows in the
                                     # answer text (see 2026-07-31 large-result-sets work), so neither
                                     # h.content nor h.sql alone carries that detail for a row-list turn

class QueryRequest(BaseModel):
    question: str
    history: list[HistoryMessage] = []

class QueryResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")  # a misspelled kwarg here must fail loudly, not
    # silently ship a truncated/row_cap default that reads to the client as a complete result

    answer: str
    sql: str
    row_count: int
    db_schema: str
    rows: list[dict] = []       # result rows for the client to render as a table
    truncated: bool = False     # True when more rows matched than row_cap
    row_cap: int = 0            # the cap that was applied, for the client's notice

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info(f"EBMS Live Query Agent starting - schema default: {PG_SCHEMA}, port: {PORT}")
    # Verify DB connection on startup
    try:
        conn = get_conn()
        conn.close()
        log.info("Postgres connection OK")
    except Exception as e:
        log.error(f"Postgres connection FAILED: {e}")
    yield

app = FastAPI(title="EBMS Live Query Agent", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://intramind.ca", "http://localhost:5173", "http://localhost:3000"],
    allow_methods=["POST", "GET"],
    allow_headers=["Authorization", "Content-Type"],
)

@app.exception_handler(Exception)
async def _unhandled_exception_handler(request: Request, exc: Exception):
    """Catch anything not already an HTTPException (FastAPI JSON-serializes
    those on its own via its own already-registered handler, unaffected by
    this one) and return a clean JSON 500 instead of Starlette's default
    plain-text response. Closes the gap for generate_sql()/format_answer()'s
    unguarded Anthropic calls (86e2rryv8) and any future unguarded call
    elsewhere in this file -- a catch-all safety net, not a substitute for
    handling a specific, anticipated failure mode close to where it occurs.

    The real exception is logged server-side with exc_info=True; the
    client-facing detail stays generic on purpose -- never expose internal
    exception text, type names, or stack traces to the client.

    CORS NOTE: this response is generated by Starlette's ServerErrorMiddleware,
    which sits OUTSIDE CORSMiddleware -- it never gets an Access-Control-Allow-
    Origin header. No impact today (ui.html is same-origin, portal/ui.html only
    calls its own same-origin /api/* with server-side proxying) -- but a future
    genuinely cross-origin browser caller (the CORS allowlist already names
    https://intramind.ca and two localhost dev ports) would have its fetch
    promise reject on the CORS check before ever seeing this body.
    """
    log.error(f"Unhandled exception on {request.method} {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(status_code=500, content={"detail": "Something went wrong. Please try again."})

@app.get("/", response_class=HTMLResponse)
def ui():
    html_path = Path(__file__).parent / "ui.html"
    return html_path.read_text(encoding="utf-8")

@app.get("/health")
def health():
    resp = {"status": "ok", "schema": PG_SCHEMA, "company": COMPANY_NAME, "version": VERSION}
    last_action = _read_last_admin_action()
    if last_action:
        resp["last_admin_action"] = last_action
    return resp

@app.get("/whats-new")
def whats_new():
    """Return whats_new for current version if a pending update notification exists."""
    pending_path = Path(r"C:\ProgramData\IntraMind\pending_update.txt")
    try:
        pending = json.loads(pending_path.read_text(encoding="utf-8").strip())
    except (OSError, json.JSONDecodeError):
        return {"version": VERSION, "changelog": None}
    pending_version = (pending.get("version") or "").split("-")[0]
    if pending_version != VERSION:
        return {"version": VERSION, "changelog": None}
    changelog = pending.get("whats_new") or None
    return {"version": VERSION, "changelog": changelog}

@app.get("/datasets")
def datasets_list():
    """Return available datasets for the login screen dropdown."""
    return {"datasets": [{"name": d["name"], "schema": d["schema"]} for d in DATASETS]}

@app.post("/login")
def login(req: LoginRequest):
    username_upper = req.username.strip().upper()

    # Resolve and validate the requested dataset schema
    requested_schema = req.dataset.strip()
    if requested_schema:
        if requested_schema not in DATASET_SCHEMAS:
            raise HTTPException(status_code=400, detail="Invalid dataset selection.")
        chosen_schema = requested_schema
    else:
        chosen_schema = _default_schema()

    # Free tier: only the INTRAMIND user is accepted
    if EBMS_LIVE_TIER == "free" and username_upper != "INTRAMIND":
        secrets.compare_digest(req.password.encode(), b"x")
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    # Test-only bypass: EBMS_LIVE_TEST_PASSWORD overrides DB lookup for INTRAMIND ONLY.
    # CR-1 (86e2t0fr4, found 2026-08-11): this used to also gate the final check below via
    # `not TEST_LOGIN_PASSWORD`, which made that check a no-op for every OTHER username too,
    # not just this INTRAMIND branch -- a real user's WRONG password would silently succeed
    # whenever this env var happened to be set (routine for this project's own live testing).
    # The final check is now unconditional -- every branch must set row/password_match such
    # that it correctly reflects whether THIS request should be allowed, and that check runs
    # for every username, every time, regardless of this env var.
    if TEST_LOGIN_PASSWORD and username_upper == "INTRAMIND":
        password_match = secrets.compare_digest(req.password, TEST_LOGIN_PASSWORD)
        if not password_match:
            raise HTTPException(status_code=401, detail="Invalid username or password.")
        row = get_user_permissions(username_upper, chosen_schema) or {
            "FULL_NAME": "INTRAMIND", "GL": "Administrator", "AP": "Administrator",
            "AR": "Administrator", "IN": "Administrator", "DP": "Administrator",
            "PY": "Administrator", "TA": "Administrator", "JC": "Administrator", "ES": "Administrator",
        }
    else:
        row = get_user_permissions(username_upper, chosen_schema)

        # Always do a constant-time compare even when user not found (prevents username enumeration)
        stored_password = row["PASSWORD"] if (row and row.get("PASSWORD")) else ""
        password_match = _password_matches(req.password, stored_password)

    if row is None or not password_match:
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    permissions = {k: row[k] for k in ("GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES") if k in row}
    full_name = row.get("FULL_NAME") or username_upper
    session_token = _create_session(username_upper, full_name, permissions, chosen_schema)

    password_weak = is_password_weak(req.password)

    log.info(f"Login: {username_upper} schema={chosen_schema} (tier={EBMS_LIVE_TIER})")
    return {
        "token": session_token,
        "full_name": full_name,
        "username": username_upper,
        "schema": chosen_schema,
        "password_weak": password_weak,
        "tier": EBMS_LIVE_TIER,
    }

@app.post("/logout")
def logout(credentials: HTTPAuthorizationCredentials = Security(security)):
    _delete_session(credentials.credentials)
    return {"ok": True}

def _fiscal_start_month(schema: str) -> int:
    """Return GLCTL.FIRST_M for the given schema, resolved server-side so the AI query
    engine never needs to generate SQL referencing GLCTL at all (ClickUp 86e2n66g5 --
    GLCTL is a 98-column company control record with several sensitive-looking columns,
    and a prior column-allowlist attempt to gate AI access to it had confirmed live
    bypasses). Falls back to 1 (January) on any failure, matching EBMS's own conventional
    default and company_info()'s existing fallback pattern -- logs a warning so a real
    misconfiguration is visible in agent.log, not silent.
    """
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(f'SELECT "FIRST_M" FROM "{schema}"."GLCTL" LIMIT 1')
                row = cur.fetchone()
                if row and row.get("FIRST_M") is not None:
                    value = int(row["FIRST_M"])
                    if 1 <= value <= 12:
                        return value
                    log.error(
                        f"_fiscal_start_month lookup for schema {schema!r} returned "
                        f"out-of-range FIRST_M={value!r}, defaulting to January"
                    )
    except Exception as e:
        log.error(f"_fiscal_start_month lookup failed for schema {schema!r}, defaulting to January: {e}")
    return 1

def _fiscal_year_boundaries(first_m: int, today: datetime) -> dict[str, str]:
    """Compute the last-completed and current fiscal year boundary dates as ISO strings, so
    the model never needs to generate CASE-expression arithmetic to answer "last fiscal year"
    or "this fiscal year to date" questions. Pure function, no DB access of its own -- takes
    first_m (already resolved by _fiscal_start_month()) and today's date as plain inputs, so
    it's trivially unit-testable without a DB or an API key. Uses plain f-string formatting
    rather than the datetime.date class -- server.py imports only datetime/timezone today, and
    every value here is a plain year/month/day combination with no calendar arithmetic (no
    date subtraction, no timezone handling), so a `date` import buys nothing.

    Live verification found the model unreliable at this arithmetic once given
    fiscal_start_month as a bare literal it could reason about freely (ClickUp 86e2n66g5,
    ~15-25% wrong-year rate on "last fiscal year" questions, confirmed via ground-truth
    dollar-total comparison against real Postgres data) -- removing the arithmetic from the
    model's job entirely, rather than adding more prompt text warning against it, is the fix
    (a wording/example-only attempt was tried first and did not help).
    """
    if first_m <= today.month:
        last_fy_start_year = today.year - 1
    else:
        last_fy_start_year = today.year - 2
    current_fy_start_year = last_fy_start_year + 1
    return {
        "last_fy_start": f"{last_fy_start_year}-{first_m:02d}-01",
        "last_fy_end": f"{last_fy_start_year + 1}-{first_m:02d}-01",
        "current_fy_start": f"{current_fy_start_year}-{first_m:02d}-01",
    }

@app.get("/company")
def company_info(sess: dict = Depends(verify_session)):
    """Return company name from GLCTL for the session's schema."""
    s = (sess.get("schema") or _default_schema()).strip()
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(f'SELECT "NAME" FROM "{s}"."GLCTL" LIMIT 1')
                row = cur.fetchone()
                name = row["NAME"].strip() if row and row.get("NAME") else COMPANY_NAME
    except Exception:
        name = COMPANY_NAME
    return {"company": name}

@app.get("/kpis")
def kpis(sess: dict = Depends(verify_session)):
    """Return 8 dashboard KPIs as structured numbers - no Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()
    queries = {
        # Net AR = plain balance sum, no flooring (matches EBMS AR Aging; ClickUp 86e2nj6k7 --
        # live-verified 2026-08 to an exact-cent match against a real customer's EBMS AR Aging
        # report grand total. The old floor-and-net-only-credit-memos formula silently excluded
        # overpayments on normal invoices from netting, overstating this KPI by $791 on that data.)
        "ar_outstanding": f"""
            SELECT
                COALESCE(SUM("{s}"."ARINV"."BALANCE"), 0) AS val,
                COUNT(CASE WHEN "{s}"."ARINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
        "sales_this_month": f"""
            SELECT COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS val,
                   COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
        "sales_last_month": f"""
            SELECT COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS val,
                   COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1 month')
              AND "{s}"."ARINV"."INV_DATE" < DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
        # Net overdue = plain balance sum, no flooring (same fix as ar_outstanding above)
        "overdue": f"""
            SELECT
                COALESCE(SUM("{s}"."ARINV"."BALANCE"), 0) AS val,
                COUNT(CASE WHEN "{s}"."ARINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
              AND (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) < CURRENT_DATE
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
        # Net AP = plain balance sum, no flooring (same fix as ar_outstanding above)
        "ap_outstanding": f"""
            SELECT
                COALESCE(SUM("{s}"."APINV"."BALANCE"), 0) AS val,
                COUNT(CASE WHEN "{s}"."APINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
              AND "{s}"."APINV"."__deleted" IS NOT TRUE
        """,
        "bills_due_week": f"""
            SELECT
                COALESCE(SUM(GREATEST("{s}"."APINV"."BALANCE", 0)), 0) AS val,
                COUNT(CASE WHEN "{s}"."APINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
              AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) >= CURRENT_DATE
              AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= CURRENT_DATE + INTERVAL '7 days'
              AND "{s}"."APINV"."TOTAL" > 0
              AND "{s}"."APINV"."__deleted" IS NOT TRUE
        """,
        "payroll_this_month": f"""
            SELECT
                COALESCE(SUM("{s}"."PYTM"."G_PAY" - "{s}"."PYTM"."TOT_REIMB"), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."PYTM"
            WHERE "{s}"."PYTM"."PAY_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."PYTM"."PAY_DATE" <= CURRENT_DATE
              AND "{s}"."PYTM"."G_PAY" > 0
              AND "{s}"."PYTM"."__deleted" IS NOT TRUE
        """,
        "payments_received": f"""
            SELECT
                COALESCE(SUM("{s}"."ARINVPMT"."AMOUNT"), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."ARINVPMT"
            WHERE "{s}"."ARINVPMT"."DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINVPMT"."DATE" <= CURRENT_DATE
              AND "{s}"."ARINVPMT"."AMOUNT" > 0
              AND "{s}"."ARINVPMT"."STATUS" <> 4
              AND "{s}"."ARINVPMT"."__deleted" IS NOT TRUE
        """,
        "avg_days_to_pay": f"""
            SELECT
                COALESCE(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                ), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
    }
    result = {}
    denied_keys = []
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                for key, sql in queries.items():
                    try:
                        enforce_permissions(sess["permissions"], sql)
                    except HTTPException:
                        denied_keys.append(key)
                        continue  # denied module -- omit this KPI entirely (86e2rrye3)
                    try:
                        cur.execute(sql)
                        row = dict(cur.fetchone())
                        result[key] = {"value": float(row["val"]), "count": int(row["cnt"])}
                    except Exception as e:
                        conn.rollback()
                        log.warning(f"KPI query failed for {key}: {e}")
                        result[key] = {"value": None, "count": None}
    except psycopg.Error as e:
        log.error(f"KPI connection error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")
    if denied_keys:
        log.info(f"KPIs omitted due to permission denial: {denied_keys}")
    return result

@app.get("/kpis/detail/{key}")
def kpi_detail(key: str, sess: dict = Depends(verify_session)):
    """Return drill-down rows + verified summary for a KPI card. No Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()

    detail_queries = {
        "ar_outstanding": {
            "title": "Outstanding Customer Invoices",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINV"."INVOICE" AS invoice,
                    "{s}"."ARINV"."INV_DATE" AS date,
                    "{s}"."ARINV"."NAME" AS customer,
                    "{s}"."ARINV"."TOTAL" AS total,
                    "{s}"."ARINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."ARINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."ARINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."ARINV"."INV_DATE" DESC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."ARINV"."TOTAL", 0) >= 0), 0) AS gross,
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."ARINV"."TOTAL", 0) < 0), 0) AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            """,
        },
        "ap_outstanding": {
            "title": "Outstanding Vendor Bills",
            "rows_sql": f"""
                SELECT
                    "{s}"."APINV"."INVOICE" AS invoice,
                    "{s}"."APINV"."INV_DATE" AS date,
                    "{s}"."APINV"."NAME" AS vendor,
                    "{s}"."APINV"."TOTAL" AS total,
                    "{s}"."APINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."APINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."APINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                  AND "{s}"."APINV"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."APINV"."INV_DATE" DESC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."APINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."APINV"."TOTAL", 0) >= 0), 0) AS gross,
                    COALESCE(SUM("{s}"."APINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."APINV"."TOTAL", 0) < 0), 0) AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                  AND "{s}"."APINV"."__deleted" IS NOT TRUE
            """,
        },
        "overdue": {
            "title": "Overdue AR Invoices",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINV"."INVOICE" AS invoice,
                    "{s}"."ARINV"."DUE_DATE" AS due_date,
                    "{s}"."ARINV"."NAME" AS customer,
                    "{s}"."ARINV"."TOTAL" AS total,
                    "{s}"."ARINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."ARINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."ARINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) < CURRENT_DATE
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
                ORDER BY (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) ASC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."ARINV"."TOTAL", 0) >= 0), 0) AS gross,
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."ARINV"."TOTAL", 0) < 0), 0) AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) < CURRENT_DATE
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            """,
        },
        "bills_due_week": {
            "title": "AP Bills Due This Week",
            "rows_sql": f"""
                SELECT
                    "{s}"."APINV"."INVOICE" AS invoice,
                    "{s}"."APINV"."DUE_DATE" AS due_date,
                    "{s}"."APINV"."NAME" AS vendor,
                    "{s}"."APINV"."TOTAL" AS total,
                    "{s}"."APINV"."BALANCE" AS balance,
                    'invoice' AS row_type
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                  AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) >= CURRENT_DATE
                  AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= CURRENT_DATE + INTERVAL '7 days'
                  AND "{s}"."APINV"."TOTAL" > 0
                  AND "{s}"."APINV"."__deleted" IS NOT TRUE
                ORDER BY (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) ASC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM(GREATEST("{s}"."APINV"."BALANCE", 0)) FILTER (WHERE "{s}"."APINV"."TOTAL" > 0), 0) AS gross,
                    0::numeric AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                  AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) >= CURRENT_DATE
                  AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= CURRENT_DATE + INTERVAL '7 days'
                  AND "{s}"."APINV"."TOTAL" > 0
                  AND "{s}"."APINV"."__deleted" IS NOT TRUE
            """,
        },
        "payroll_this_month": {
            "title": "Payroll This Month",
            "rows_sql": f"""
                SELECT
                    "{s}"."PYTM"."NAME" AS employee,
                    "{s}"."PYTM"."PAY_DATE" AS pay_date,
                    "{s}"."PYTM"."PAY_TYPE" AS pay_type,
                    "{s}"."PYTM"."G_PAY" AS gross_pay,
                    "{s}"."PYTM"."T_DED" AS deductions,
                    "{s}"."PYTM"."N_PAY" AS net_pay,
                    'payroll' AS row_type
                FROM "{s}"."PYTM"
                WHERE "{s}"."PYTM"."PAY_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."PYTM"."PAY_DATE" <= CURRENT_DATE
                  AND "{s}"."PYTM"."G_PAY" > 0
                  AND "{s}"."PYTM"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."PYTM"."PAY_DATE" DESC, "{s}"."PYTM"."NAME"
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."PYTM"."G_PAY" - "{s}"."PYTM"."TOT_REIMB"), 0) AS gross,
                    0::numeric AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."PYTM"
                WHERE "{s}"."PYTM"."PAY_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."PYTM"."PAY_DATE" <= CURRENT_DATE
                  AND "{s}"."PYTM"."G_PAY" > 0
                  AND "{s}"."PYTM"."__deleted" IS NOT TRUE
            """,
        },
        "sales_this_month": {
            "title": "Sales This Month",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINV"."INVOICE" AS invoice,
                    "{s}"."ARINV"."INV_DATE" AS date,
                    "{s}"."ARINV"."NAME" AS customer,
                    "{s}"."ARINV"."TOTAL" AS total,
                    "{s}"."ARINV"."STATUS" AS status,
                    'invoice' AS row_type
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
                  AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
                  AND "{s}"."ARINV"."TOTAL" > 0
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."ARINV"."INV_DATE" DESC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS gross,
                    0::numeric AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
                  AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
                  AND "{s}"."ARINV"."TOTAL" > 0
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            """,
        },
        "payments_received": {
            "title": "Payments Received This Month",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINVPMT"."DATE" AS date,
                    "{s}"."ARINVPMT"."AMOUNT" AS amount,
                    "{s}"."ARINVPMT"."CHECK_NO" AS check_no,
                    "{s}"."ARINVPMT"."CUSTOMER" AS customer_id,
                    COALESCE("{s}"."ARCUST"."L_NAME", '(unknown customer)') AS customer,
                    "{s}"."ARINVPMT"."TYPE" AS type,
                    'payment' AS row_type
                FROM "{s}"."ARINVPMT"
                LEFT JOIN "{s}"."ARCUST" ON "{s}"."ARCUST"."ID" = "{s}"."ARINVPMT"."CUSTOMER"
                                        AND "{s}"."ARCUST"."__deleted" IS NOT TRUE
                WHERE "{s}"."ARINVPMT"."DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."ARINVPMT"."DATE" <= CURRENT_DATE
                  AND "{s}"."ARINVPMT"."AMOUNT" > 0
                  AND "{s}"."ARINVPMT"."STATUS" <> 4
                  AND "{s}"."ARINVPMT"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."ARINVPMT"."DATE" DESC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."ARINVPMT"."AMOUNT"), 0) AS gross,
                    0::numeric AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."ARINVPMT"
                WHERE "{s}"."ARINVPMT"."DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."ARINVPMT"."DATE" <= CURRENT_DATE
                  AND "{s}"."ARINVPMT"."AMOUNT" > 0
                  AND "{s}"."ARINVPMT"."STATUS" <> 4
                  AND "{s}"."ARINVPMT"."__deleted" IS NOT TRUE
            """,
        },
    }

    # Days to pay uses a different query/response shape
    if key == "days_to_pay":
        rows_sql = f"""
            SELECT
                COALESCE("{s}"."ARCUST"."L_NAME", '(unknown customer)') AS customer,
                COUNT(*) AS invoices_paid,
                ROUND(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                )) AS avg_days
            FROM "{s}"."ARINV"
            LEFT JOIN "{s}"."ARCUST" ON "{s}"."ARCUST"."ID" = "{s}"."ARINV"."ID"
                                    AND "{s}"."ARCUST"."__deleted" IS NOT TRUE
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            GROUP BY COALESCE("{s}"."ARCUST"."L_NAME", '(unknown customer)')
            ORDER BY avg_days DESC
            LIMIT 100
        """
        summary_sql = f"""
            SELECT
                ROUND(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                )) AS avg_days,
                COUNT(*) AS total_invoices
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """
        enforce_permissions(sess["permissions"], rows_sql)
        try:
            with get_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(rows_sql)
                    rows = [dict(r) for r in cur.fetchall()]
                    cur.execute(summary_sql)
                    summary_row = dict(cur.fetchone())
        except psycopg.Error as e:
            log.error(f"KPI detail query error for days_to_pay: {e}")
            raise HTTPException(status_code=503, detail="Database unavailable")
        return {
            "title": "Average Days to Payment (This Year)",
            "rows": rows,
            "summary": {
                "avg_days": int(summary_row["avg_days"] or 0),
                "total_invoices": int(summary_row["total_invoices"] or 0),
                "type": "days_to_pay",
            },
        }

    if key not in detail_queries:
        raise HTTPException(status_code=404, detail=f"Unknown KPI key: {key}")

    q = detail_queries[key]
    enforce_permissions(sess["permissions"], q["rows_sql"])
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(q["rows_sql"])
                rows = [dict(r) for r in cur.fetchall()]
                cur.execute(q["summary_sql"])
                summary_row = dict(cur.fetchone())
    except psycopg.Error as e:
        log.error(f"KPI detail query error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")

    gross = float(summary_row["gross"])
    credits = float(summary_row["credits"])
    net = gross + credits
    total_row_count = int(summary_row["total_row_count"])

    return {
        "title": q["title"],
        "rows": rows,
        "summary": {"gross": gross, "credits": credits, "net": net, "total_row_count": total_row_count},
    }

@app.get("/charts")
def charts(sess: dict = Depends(verify_session)):
    """Return chart datasets - all deterministic SQL, no Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()

    chart_queries = {
        "ar_aging": f"""
            SELECT
                CASE
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) <= 30 THEN '0-30'
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) <= 60 THEN '31-60'
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) <= 90 THEN '61-90'
                    ELSE '90+'
                END AS bucket,
                COALESCE(SUM("{s}"."ARINV"."BALANCE"), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
              AND (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) < CURRENT_DATE
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            GROUP BY bucket
            ORDER BY MIN(CURRENT_DATE - (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END))
        """,
        "sales_by_month": f"""
            SELECT
                TO_CHAR(DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"), 'Mon YY') AS month,
                DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE") AS month_start,
                COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '5 months')
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            GROUP BY DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"),
                     TO_CHAR(DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"), 'Mon YY')
            ORDER BY month_start
        """,
        "top_customers": f"""
            SELECT
                "{s}"."ARINV"."NAME" AS name,
                COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS amount
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            GROUP BY "{s}"."ARINV"."NAME"
            ORDER BY amount DESC
            LIMIT 10
        """,
        "ap_aging": f"""
            SELECT
                CASE
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= 30 THEN '0-30'
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= 60 THEN '31-60'
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= 90 THEN '61-90'
                    ELSE '90+'
                END AS bucket,
                COALESCE(SUM("{s}"."APINV"."BALANCE"), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
              AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) < CURRENT_DATE
              AND "{s}"."APINV"."__deleted" IS NOT TRUE
            GROUP BY bucket
            ORDER BY MIN(CURRENT_DATE - (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END))
        """,
    }

    result = {}
    denied_keys = []
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                for key, sql in chart_queries.items():
                    try:
                        enforce_permissions(sess["permissions"], sql)
                    except HTTPException:
                        denied_keys.append(key)
                        continue  # denied module -- omit this chart entirely (86e2rrye3)
                    try:
                        cur.execute(sql)
                        rows = [dict(r) for r in cur.fetchall()]
                        # Drop month_start helper column from sales_by_month
                        if key == "sales_by_month":
                            rows = [{k: v for k, v in r.items() if k != "month_start"} for r in rows]
                        # Coerce numeric fields to float
                        for row in rows:
                            for k, v in row.items():
                                if isinstance(v, (int, float)) or (hasattr(v, '__float__') and k in ('amount',)):
                                    try:
                                        row[k] = float(v)
                                    except (TypeError, ValueError):
                                        pass
                        result[key] = rows
                    except Exception as e:
                        conn.rollback()
                        log.warning(f"Chart query failed for {key}: {e}")
                        result[key] = None
    except psycopg.Error as e:
        log.error(f"Charts connection error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")
    if denied_keys:
        log.info(f"Charts omitted due to permission denial: {denied_keys}")

    return result

@app.post("/query", response_model=QueryResponse)
def query(req: QueryRequest, request: Request, sess: dict = Depends(verify_session)):
    check_rate_limit(_client_ip(request))

    question = req.question.strip()
    schema = sess.get("schema") or _default_schema()

    if not question:
        raise HTTPException(status_code=400, detail="Question cannot be empty")

    # Generate SQL (pass conversation history for context-aware follow-up questions)
    # 86e2wf61a: an unhandled exception here (e.g. an Anthropic outage) is caught by
    # 86e2rryv8's global exception handler for the client response, but that handler
    # deliberately does not call append_feedback() -- without this, the failure is
    # invisible on the portal error feed and feedback_watcher.py's ClickUp auto-
    # ticketing, unlike every other /query failure mode. Re-raises unconditionally;
    # this changes nothing about the client-visible response.
    try:
        sql, clarification = generate_sql(question, schema, req.history)
    except Exception as e:
        append_feedback({
            "rating": "error",
            "category": "query_exception",
            "comment": str(e)[:500],
            "question": question[:1000],
            "sql": "",
            "answer": "",
            "username": sess.get("username", ""),
            "schema": sess.get("schema", ""),
        })
        raise
    sql = fix_schema_quoting(sql)
    log.info(f"Generated SQL: {sql[:200]}")

    if sql.startswith("CANNOT_QUERY"):
        # Model may append an explanation after CANNOT_QUERY - extract it
        explanation = sql[len("CANNOT_QUERY"):].strip(" \n:-")
        answer = explanation if explanation else "I can only answer questions that can be looked up in the EBMS database. Try asking about invoices, customers, inventory, GL accounts, payroll, or job status."
        return QueryResponse(
            answer=answer,
            sql="",
            row_count=0,
            db_schema=schema,
        )

    # Schema isolation (86e2t0frp/CR-2) - the model is shown only its own session's
    # schema via {schema} in SYSTEM_PROMPT, but nothing downstream previously checked
    # that the generated SQL actually stayed inside it. enforce_permissions() below
    # checks table names, not schema qualifiers, so this must run first.
    foreign_schemas = _foreign_schema_qualifiers(sql, schema)
    if foreign_schemas:
        log.warning(f"Rejected SQL referencing foreign schema(s) {sorted(foreign_schemas)}: {sql[:100]}")
        log_query_error(question, sql, "", f"rejected: foreign schema(s) {sorted(foreign_schemas)}")
        raise HTTPException(status_code=400, detail="Generated query referenced a schema outside this session - rejected for safety.")

    # Safety check - allow SELECT and WITH (CTEs), reject everything else
    if not re.match(r"^\s*(SELECT|WITH)\b", sql, re.IGNORECASE):
        log.warning(f"Rejected non-SELECT SQL: {sql[:100]}")
        log_query_error(question, sql, "", "rejected: not a SELECT")
        raise HTTPException(status_code=400, detail="Generated query was not a SELECT - rejected for safety.")
    # Multi-statement smuggling (86e2rryyv) - the SELECT-only anchor above only checks
    # the START of the string; a smuggled second statement using no blocked keyword
    # (another SELECT, pg_sleep() for DoS, a session-level SET/COPY/VACUUM) would
    # otherwise reach psycopg's simple-query execution, which runs every
    # ';'-separated statement in one call.
    if _has_multiple_statements(sql):
        log.warning(f"Rejected multi-statement SQL: {sql[:100]}")
        log_query_error(question, sql, "", "rejected: multiple statements")
        raise HTTPException(status_code=400, detail="Generated query contained multiple statements - rejected for safety.")
    # Unsupported string syntax (86e2wdz6p final-review fix): dollar-quoted
    # strings ($tag$...$tag$) are never legitimately needed here (the model
    # is never prompted to emit them) and _strip_sql_literals_and_comments()
    # does not recognize them -- a raw apostrophe inside one can make a
    # real literal or block comment look unterminated to that scanner.
    # This guard rejects the syntax OUTRIGHT, unconditionally, regardless
    # of where in the SQL it appears -- so dollar-quoted strings were never
    # actually exposed to the two-span quote-pairing gap 86e2yq8d0 fixed
    # (that gap, and its fix, are specific to E'...'/U&'...' syntax, which
    # this guard does not cover; see _strip_sql_literals_and_comments()'s
    # own docstring). Rejecting dollar-quote syntax outright removes the
    # risk for that syntax at zero cost to legitimate queries, which never
    # contain a literal $word$ pattern.
    if re.search(r"\$[A-Za-z_0-9]*\$", sql):
        log.warning(f"Rejected SQL with dollar-quoted string syntax: {sql[:100]}")
        log_query_error(question, sql, "", "rejected: dollar-quoted string syntax")
        raise HTTPException(status_code=400, detail="Generated query contained unsupported string syntax - rejected for safety.")

    # Secondary check - must not contain any write keywords. Search a
    # literal-and-comment-stripped copy (86e2t0g4a) so a business name like
    # "Grant Industries" or a comment mentioning "update" doesn't false-flag --
    # the ORIGINAL sql is still what gets logged/executed, only the search
    # target changes. 86e2wdz6p (an apostrophe inside a comment or
    # double-quoted identifier hiding a real write keyword from this check)
    # is fixed: _strip_sql_literals_and_comments() is a single left-to-right
    # scanner that fails closed on unrecognized string syntax rather than a
    # vulnerable two-regex composition.
    keyword_check_sql = _strip_sql_literals_and_comments(sql)
    if re.search(r"\b(INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|TRUNCATE|GRANT|REVOKE)\b", keyword_check_sql, re.IGNORECASE):
        log.warning(f"Rejected SQL with write keyword: {sql[:100]}")
        log_query_error(question, sql, "", "rejected: write keyword")
        raise HTTPException(status_code=400, detail="Generated query contained disallowed keywords - rejected for safety.")

    # Permission enforcement - block queries touching modules user has No Access to
    enforce_permissions(sess["permissions"], sql)

    # Execute. Fetch one row PAST the cap: the presence of that extra row is the only
    # reliable truncation signal, because len(rows) == MAX_ROWS is ambiguous -- a query
    # can legitimately match exactly MAX_ROWS rows.
    exec_sql = _bump_trailing_limit(sql, MAX_ROWS)
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                try:
                    cur.execute(exec_sql)
                    rows = [dict(r) for r in cur.fetchmany(MAX_ROWS + 1)]
                except psycopg.Error as e:
                    # A generated column reference that doesn't exist on this install gets ONE
                    # retry, never a loop: prefer Postgres's own HINT (a near-miss column name it
                    # found via trigram similarity, e.g. a hallucinated NXT_STP_ -> the real
                    # NXT_STOP_) over a known-optional-column strip, since the HINT is Postgres's
                    # own suggestion, not a guess of ours. If retry_sql itself fails, that second
                    # psycopg.Error is intentionally left uncaught here -- it propagates to the
                    # outer handler below and reports a clean 422, rather than looping.
                    missing_col = (
                        _missing_column_name(e.diag.message_primary or str(e))
                        if e.sqlstate == _UNDEFINED_COLUMN_SQLSTATE else None
                    )
                    hint_col = _hint_column_name(e.diag.message_hint) if missing_col else None
                    if hint_col and hint_col != missing_col:
                        conn.rollback()
                        sql = sql.replace(f'"{missing_col}"', f'"{hint_col}"')
                        exec_sql = _bump_trailing_limit(sql, MAX_ROWS)
                        cur.execute(exec_sql)
                        rows = [dict(r) for r in cur.fetchmany(MAX_ROWS + 1)]
                        log.warning(f"Column {missing_col!r} not found -- Postgres suggested {hint_col!r}, retried")
                    elif missing_col in KNOWN_OPTIONAL_COLUMNS:
                        conn.rollback()
                        sql = _strip_column(sql, missing_col)
                        exec_sql = _bump_trailing_limit(sql, MAX_ROWS)
                        cur.execute(exec_sql)
                        rows = [dict(r) for r in cur.fetchmany(MAX_ROWS + 1)]
                        log.warning(f"Column {missing_col!r} not present on this install -- stripped and retried")
                    else:
                        raise
    except psycopg.Error as e:
        log.error(f"Query error: {e}")
        log_query_error(question, exec_sql, "", str(e))
        # Implicit negative feedback: failed queries surface in the portal feed
        append_feedback({
            "rating": "error",
            "category": "query_failed",
            "comment": str(e)[:500],
            "question": question[:1000],
            "sql": sql[:2000] if sql else "",
            "answer": "",
            "username": sess.get("username", ""),
            "schema": sess.get("schema", ""),
        })
        raise HTTPException(status_code=422, detail=f"Query failed: {str(e)}")

    truncated = len(rows) > MAX_ROWS
    if truncated:
        # Drop the probe row. It must never reach the client or the model.
        rows = rows[:MAX_ROWS]
        log.info(f"Result truncated at {MAX_ROWS} rows for question: {question[:80]}")

    try:
        payload_rows = _jsonable_rows(rows)
        model_rows = payload_rows
    except (TypeError, ValueError) as e:
        # A coercion failure must cost the table, never the answer.
        log.error(f"Row coercion failed, returning prose only: {e}")
        append_feedback({
            "rating": "error",
            "category": "rows_uncoercible",
            "comment": str(e)[:500],
            "question": question[:1000],
            "sql": sql[:2000] if sql else "",
            "answer": "",
            "username": sess.get("username", ""),
            "schema": sess.get("schema", ""),
        })
        payload_rows = []
        model_rows = rows  # format_answer applies its own default=str coercion

    # Format answer (pass history so follow-up context is available)
    # 86e2wf61a: same reasoning as the generate_sql() wrapper above -- an unhandled
    # exception here reaches 86e2rryv8's global handler for the client response, but
    # was previously invisible on the portal error feed. Re-raises unconditionally.
    try:
        answer = format_answer(question, model_rows, sql, req.history, truncated, MAX_ROWS)
    except Exception as e:
        append_feedback({
            "rating": "error",
            "category": "query_exception",
            "comment": str(e)[:500],
            "question": question[:1000],
            "sql": sql[:2000] if sql else "",
            "answer": "",
            "username": sess.get("username", ""),
            "schema": sess.get("schema", ""),
        })
        raise

    # Append any clarifying question the model asked after the SQL
    if clarification:
        answer = f"{answer}\n\n{clarification}"

    record_query(sess["username"])

    return QueryResponse(
        answer=answer,
        sql=sql,
        row_count=len(rows),
        db_schema=schema,
        rows=payload_rows,
        truncated=truncated,
        row_cap=MAX_ROWS,
    )


def _verify_portal_token(request: Request):
    token = request.headers.get("X-Portal-Token", "")
    if not PORTAL_TOKEN or not secrets.compare_digest(token, PORTAL_TOKEN):
        raise HTTPException(status_code=401, detail="Invalid portal token.")

# ---------------------------------------------------------------------------
# Query feedback
# ---------------------------------------------------------------------------

_FEEDBACK_PATHS = [
    Path(r"C:\ProgramData\IntraMind\feedback.jsonl"),
    Path(__file__).parent / "feedback.jsonl",
]

def append_feedback(entry: dict):
    entry["time"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    entry["version"] = VERSION
    line = json.dumps(entry, ensure_ascii=False)
    for p in _FEEDBACK_PATHS:
        try:
            with open(p, "a", encoding="utf-8") as f:
                f.write(line + "\n")
            return
        except OSError:
            continue
    log.warning("Could not write feedback entry to any path")

class FeedbackRequest(BaseModel):
    rating: str            # "up" or "down"
    question: str = ""
    sql: str = ""
    answer: str = ""
    category: str = ""
    comment: str = ""

class ChannelRequest(BaseModel):
    channel: str

@app.post("/feedback")
def submit_feedback(req: FeedbackRequest, sess: dict = Depends(verify_session)):
    """Record user feedback on a query answer."""
    if req.rating not in ("up", "down"):
        raise HTTPException(status_code=400, detail="rating must be 'up' or 'down'")
    append_feedback({
        "rating": req.rating,
        "category": req.category[:50],
        "comment": req.comment[:1000],
        "question": req.question[:1000],
        "sql": req.sql[:2000],
        "answer": req.answer[:2000],
        "username": sess.get("username", ""),
        "schema": sess.get("schema", ""),
    })
    return {"ok": True}

@app.get("/feedback")
def get_feedback(request: Request, limit: int = 200):
    """Return recent feedback entries for the admin portal. Protected by X-Portal-Token header."""
    _verify_portal_token(request)
    limit = min(max(limit, 10), 500)
    for p in _FEEDBACK_PATHS:
        try:
            lines = p.read_text(encoding="utf-8").splitlines()
        except OSError:
            continue
        entries = []
        for line in lines[-limit:]:
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        entries.reverse()  # newest first
        return {"entries": entries, "total": len(lines)}
    return {"entries": [], "total": 0}

@app.get("/stats")
def stats(request: Request):
    """Usage stats for the IntraMind admin portal. Protected by X-Portal-Token header."""
    _verify_portal_token(request)
    return get_stats_snapshot()

@app.get("/logs")
def logs(request: Request, lines: int = 200):
    """Return last N lines of agent.log for the admin portal. Protected by X-Portal-Token header."""
    _verify_portal_token(request)
    lines = min(max(lines, 10), 500)
    log_paths = [
        Path(r"C:\ProgramData\IntraMind\agent.log"),
        Path(__file__).parent / "agent.log",
    ]
    for p in log_paths:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
            tail = text.splitlines()[-lines:]
            return {"lines": tail, "path": str(p), "total_lines": len(text.splitlines())}
        except OSError:
            pass
    return {"lines": [], "path": None, "total_lines": 0}

@app.post("/admin/channel")
def admin_channel(req: ChannelRequest, request: Request):
    """Switch this instance's update channel. Protected by X-Portal-Token header.
    Only rewrites .env -- does not trigger an update or restart; see /admin/update."""
    _verify_portal_token(request)
    channel = req.channel.strip().lower()
    if channel not in CHANNELS:
        raise HTTPException(status_code=400, detail=f"Unknown channel '{channel}'. Valid: {sorted(CHANNELS)}")
    _write_channel_to_env(channel)
    return {"status": "ok", "channel": channel}


@app.post("/admin/update")
def admin_update(request: Request):
    """Trigger an immediate update pull. Protected by X-Portal-Token header.
    Fire-and-forget: returns 202 immediately. Real success/failure arrives via
    last_admin_action on /health once update.ps1 finishes -- see /health below."""
    _verify_portal_token(request)
    if _is_update_lock_stale():
        log.warning(f"update.lock is stale (older than {_UPDATE_LOCK_STALE_AFTER_SECONDS}s) -- reclaiming")
        _update_lock_path().unlink(missing_ok=True)
    try:
        _create_update_lock()
    except FileExistsError:
        raise HTTPException(status_code=409, detail="An update is already in progress.")
    except OSError as e:
        log.warning(f"Could not create update lock ({e}) -- proceeding without lock protection")
    try:
        _launch_update_ps1()
    except Exception as e:
        _update_lock_path().unlink(missing_ok=True)
        log.error(f"Failed to launch update.ps1 ({e})")
        raise HTTPException(status_code=500, detail="Failed to trigger update.")
    return JSONResponse({"status": "triggered"}, status_code=202)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=PORT)
