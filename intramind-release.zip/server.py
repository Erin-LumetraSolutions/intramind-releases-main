"""
EBMS Live Query Agent

FastAPI service that runs on the customer's Azure VM alongside their EBMS Postgres
instance. Accepts authenticated natural-language queries, uses Claude to generate
safe read-only SQL, executes against the local Postgres, and returns formatted results.

Exposed to intramind.ca via Cloudflare tunnel + bearer token auth.

Run: python ebms_live/server.py
"""

import os
import re
import bisect
import html as _html
import json
import time
import uuid
import asyncio
import secrets
import string
import subprocess
import logging
import urllib.request
import urllib.error
from datetime import datetime, timedelta, timezone
from pathlib import Path
from contextlib import asynccontextmanager
from collections import OrderedDict
from threading import Lock
from logging.handlers import RotatingFileHandler

import psycopg
from psycopg.rows import dict_row
import anthropic
from fastapi import FastAPI, HTTPException, Depends, Security, Request, Query
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse
from pydantic import BaseModel, ConfigDict, Field, field_validator
from dotenv import load_dotenv

load_dotenv(Path(r"C:\ProgramData\IntraMind\.env"))   # production (Windows service)
load_dotenv(Path(__file__).parent / ".env")           # dev / legacy fallback
load_dotenv(Path(__file__).parent.parent / ".env")    # dev fallback

VERSION = "1.6.3"

# 86e2wf5xb: server.py's own logging.basicConfig() is what actually timestamps every
# log.*() call in this file (see the commit message on a97f232 for the full trace of
# why log_config.json's own formatters don't reach the "ebms_live" logger). This ONLY
# works because log_config.json deliberately has no "root" key -- basicConfig() only
# installs a handler when the root logger doesn't already have one. If a future edit
# adds a "root" key to log_config.json, this call silently becomes a no-op and every
# timestamp in agent.log vanishes again with no error and no failing test. Don't add
# a "root" key to log_config.json without updating this comment and re-verifying.
#
# Also forces every logging.Formatter in this process (including uvicorn's
# DefaultFormatter/AccessFormatter, both of which subclass logging.Formatter and
# inherit its converter) onto UTC -- without this, agent.log's timestamps render local
# time while append_feedback()/log_query_error() both write UTC, a real correlation
# problem for the incident-timeline-reconstruction use case this ticket exists for.
logging.Formatter.converter = time.gmtime
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s:%(name)s:%(message)s")
log = logging.getLogger("ebms_live")

# Error log - captures failed queries for prompt improvement
_error_log = logging.getLogger("ebms_live.errors")
_error_log.setLevel(logging.WARNING)
try:
    _error_log_path = Path(__file__).parent / "query_errors.log"
    _error_handler = RotatingFileHandler(_error_log_path, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
    _error_handler.setLevel(logging.WARNING)
    _error_log.addHandler(_error_handler)
except OSError as e:
    logging.getLogger("ebms_live").warning(f"Could not open query_errors.log ({e}) — error logging disabled")

def log_query_error(question: str, sql: str, raw_response: str, error: str):
    _error_log.warning(json.dumps({
        "question": question,
        "sql": sql[:500] if sql else "",
        "raw_response": raw_response[:500] if raw_response else "",
        "error": error,
        "time": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }, ensure_ascii=False))

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------

BEARER_TOKEN        = os.getenv("EBMS_LIVE_TOKEN")  # legacy, kept for non-auth health check compat
PORTAL_TOKEN        = os.getenv("EBMS_LIVE_PORTAL_TOKEN")  # secret shared with IntraMind admin portal
CHANNELS = {"stable", "beta", "main"}  # kept in sync by hand with update.ps1's, install.ps1's,
                                 # and onboarding/deploy.ps1's $MANIFEST_URLS keys, and
                                 # portal/server.py's MANIFEST_URLS keys (86e2ykh2a: all 4
                                 # copies, not just the first 2 -- install.ps1/deploy.ps1 each
                                 # gained their own copy of this dict in 86e2t0gb5) -- see
                                 # docs/superpowers/specs/2026-08-07-portal-remote-admin-design.md §4
                                 # and docs/superpowers/specs/2026-08-10-main-channel-release-pipeline-scope.md.
_ENV_FILE_OVERRIDE = os.getenv("EBMS_LIVE_ENV_FILE_OVERRIDE")  # test-only; never set in production
_ENV_FILE_PATHS = [
    Path(r"C:\ProgramData\IntraMind\.env"),
    Path(__file__).parent / ".env",
    Path(__file__).parent.parent / ".env",
]

def _resolve_env_file() -> Path:
    """Pick which .env file /admin/channel edits. Mirrors the three candidate
    locations load_dotenv() already reads at startup (production ProgramData
    path, then the dev fallback next to this file, then the parent dir fallback).
    EBMS_LIVE_ENV_FILE_OVERRIDE is a test-only escape hatch so automated tests
    never touch a real .env."""
    if _ENV_FILE_OVERRIDE:
        return Path(_ENV_FILE_OVERRIDE)
    for p in _ENV_FILE_PATHS:
        if p.exists():
            return p
    return _ENV_FILE_PATHS[-1]

def _write_channel_to_env(channel: str) -> None:
    """Rewrite (or append) EBMS_LIVE_CHANNEL= in the active .env file, preserving
    every other line untouched. Same logic as switch-to-beta.ps1, generalized
    from a hardcoded 'beta' to any validated channel name."""
    env_path = _resolve_env_file()
    lines = env_path.read_text(encoding="utf-8").splitlines() if env_path.exists() else []
    found = False
    new_lines = []
    for line in lines:
        if line.startswith("EBMS_LIVE_CHANNEL="):
            new_lines.append(f"EBMS_LIVE_CHANNEL={channel}")
            found = True
        else:
            new_lines.append(line)
    if not found:
        new_lines.append(f"EBMS_LIVE_CHANNEL={channel}")
    env_path.parent.mkdir(parents=True, exist_ok=True)
    tmp_path = env_path.with_suffix(env_path.suffix + ".tmp")
    try:
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write("\n".join(new_lines) + "\n")
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, env_path)
    except Exception:
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass
        raise

_UPDATE_LOCK_PATHS = [
    Path(r"C:\ProgramData\IntraMind\update.lock"),
    Path(__file__).parent / "update.lock",
]
_ADMIN_ACTION_PATHS = [
    Path(r"C:\ProgramData\IntraMind\last_admin_action.json"),
    Path(__file__).parent / "last_admin_action.json",
]
_SKIP_UPDATE_LAUNCH = os.getenv("EBMS_LIVE_TEST_SKIP_UPDATE_LAUNCH")  # test-only; never set in production

def _update_lock_path() -> Path:
    for p in _UPDATE_LOCK_PATHS:
        if p.parent.exists():
            return p
    return _UPDATE_LOCK_PATHS[-1]

_UPDATE_LOCK_STALE_AFTER_SECONDS = 1800  # 30 min -- longer than update.ps1's own 20-min
                                          # ExecutionTimeLimit (set by update.ps1's per-cycle
                                          # task reconcile; the three installers register 20 too since Batch P),
                                          # so a genuinely stuck run is distinguishable from a
                                          # merely slow one before we ever reclaim its lock.

def _is_update_lock_stale() -> bool:
    p = _update_lock_path()
    try:
        age_s = time.time() - p.stat().st_mtime
    except OSError:
        return False
    return age_s > _UPDATE_LOCK_STALE_AFTER_SECONDS

def _create_update_lock() -> None:
    """Atomically create the lock file; raises FileExistsError if one already
    exists (caller must treat that as "in progress"), or OSError if it can't
    be created at all (caller should log and proceed rather than silently
    pretend the lock succeeded)."""
    p = _update_lock_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "x", encoding="utf-8") as f:
        f.write(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))

def _read_last_admin_action() -> dict | None:
    """Return the contents of last_admin_action.json if it exists and is recent
    (within the last 10 minutes) -- older entries are dropped so a card doesn't
    show a stale result forever."""
    for p in _ADMIN_ACTION_PATHS:
        try:
            data = json.loads(p.read_text(encoding="utf-8-sig"))
        except (OSError, json.JSONDecodeError):
            continue
        try:
            at = datetime.strptime(data.get("at", ""), "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
        except (ValueError, TypeError):
            return None
        age_s = (datetime.now(timezone.utc) - at).total_seconds()
        if age_s > 600:
            return None
        return data
    return None

def _launch_update_ps1() -> None:
    """Trigger update.ps1 via the existing IntraMindAutoUpdate scheduled
    task rather than launching powershell.exe directly. See
    docs/superpowers/specs/2026-08-07-portal-remote-admin-design.md §4.
    EBMS_LIVE_TEST_SKIP_UPDATE_LAUNCH is a test-only escape hatch so
    automated tests never invoke a real update.ps1.

    86e31dqfh: previously used subprocess.Popen(["powershell.exe", ...])
    directly, with CREATE_NEW_PROCESS_GROUP | CREATE_BREAKAWAY_FROM_JOB
    and an explicit cwd -- both existed to make the launched update.ps1
    survive this process's own job-object membership and lifecycle (see
    git history / 86e2zk7p3 / 86e2x79j3 for that saga in full). Routing
    through `schtasks.exe /run /tn IntraMindAutoUpdate` instead makes
    that entire mechanism moot: Task Scheduler spawns update.ps1 itself,
    completely independent of this process's own tree -- it was never a
    descendant of the uvicorn child to begin with, so there is no job
    object to escape and no cwd to inherit. This also gives the
    portal-triggered path the SAME external ExecutionTimeLimit backstop
    (20 minutes, see update.ps1's own scheduled-task registration) the
    scheduled-cycle path already had -- previously, a portal-triggered
    run that hung had no external time limit at all;
    server.py's own _UPDATE_LOCK_STALE_AFTER_SECONDS only reclaims the
    portal UI's lock file, it never touched the actual hung process.

    Batch Q final review (2026-08-31): originally used subprocess.Popen,
    which returns immediately regardless of whether schtasks.exe actually
    succeeded at triggering the task -- a rights problem, a missing task,
    or MultipleInstances=IgnoreNew silently swallowing the trigger would
    all still return 202 "triggered" here with nothing logged anywhere.
    `schtasks /run` itself returns quickly (it only asks the Task
    Scheduler service to queue the run, it does not wait for update.ps1
    itself to finish) so making this call synchronous and checking its
    exit code is cheap and gives a real, diagnosable error signal instead
    of a fire-and-forget guess. admin_update()'s own existing
    try/except Exception around this call converts any raised error here
    into a proper HTTP 500, so no caller-side change was needed.

    NOTE: logic-verified (this function's own behavior and its test
    coverage), but the live trigger -- does the LocalSystem-context
    EBMSLiveAgent service actually have sufficient rights to trigger a
    task registered to run as SYSTEM, and how a concurrent scheduled
    cycle interacts with the task's own MultipleInstances=IgnoreNew
    setting -- is NOT yet confirmed on a real box. Flagged explicitly in
    this batch's own spec/plan; Erin's call on when to live-verify.
    """
    if _SKIP_UPDATE_LAUNCH:
        return
    result = subprocess.run(
        ["schtasks.exe", "/run", "/tn", "IntraMindAutoUpdate"],
        stdin=subprocess.DEVNULL, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
        timeout=15, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"schtasks /run failed (exit {result.returncode}): {result.stdout}")

EBMS_LIVE_TIER      = os.getenv("EBMS_LIVE_TIER", "free").lower()  # "free" or "premium"
# Test-only: if set, the INTRAMIND user is authenticated with this plaintext password instead of
# the FoxPro +0x80 DB lookup. Never set this in production.
TEST_LOGIN_PASSWORD = os.getenv("EBMS_LIVE_TEST_PASSWORD")
PG_HOST        = os.getenv("EBMS_LIVE_PG_HOST", "localhost")
PG_PORT        = int(os.getenv("EBMS_LIVE_PG_PORT", "5432"))
PG_DB          = os.getenv("EBMS_LIVE_PG_DB", "ebms")
PG_USER        = os.getenv("EBMS_LIVE_PG_USER", "ebms_reporting")
PG_PASSWORD    = os.getenv("EBMS_LIVE_PG_PASSWORD", "")
PG_SCHEMA      = os.getenv("EBMS_LIVE_PG_SCHEMA", "")  # company schema (single-dataset fallback)
COMPANY_NAME   = os.getenv("EBMS_LIVE_COMPANY", "EBMS Live")
PORT           = int(os.getenv("EBMS_LIVE_PORT", "8767"))
ANTHROPIC_KEY  = os.getenv("ANTHROPIC_API_KEY")

# Multi-dataset: JSON array of {name, schema} pairs. Falls back to single PG_SCHEMA if not set.
# Example: [{"name":"Company A","schema":"companya:legacy"},{"name":"Company B","schema":"companyb:legacy"}]
_datasets_raw = os.getenv("EBMS_LIVE_DATASETS", "")
if _datasets_raw:
    try:
        DATASETS: list[dict] = json.loads(_datasets_raw)
        if not isinstance(DATASETS, list) or not all(isinstance(d, dict) and "name" in d and "schema" in d for d in DATASETS):
            raise ValueError("EBMS_LIVE_DATASETS must be a JSON array of {name, schema} objects")
    except (json.JSONDecodeError, ValueError) as e:
        raise RuntimeError(f"Invalid EBMS_LIVE_DATASETS: {e}") from e
else:
    DATASETS = [{"name": COMPANY_NAME, "schema": PG_SCHEMA}] if PG_SCHEMA else []

DATASET_SCHEMAS: set[str] = {d["schema"] for d in DATASETS}

MAX_ROWS       = int(os.getenv("EBMS_LIVE_MAX_ROWS", "1000"))  # rows returned to the client
MODEL_ROWS     = 50    # rows the answer-formatting model sees; kept small on purpose --
                       # format_answer is deliberately uncached, so each row it sees is
                       # fresh input tokens on every single query
SQL_TIMEOUT    = 15    # seconds

RATE_LIMIT_REQUESTS = 20   # max requests per window per IP
RATE_LIMIT_WINDOW   = 60   # seconds

# ---------------------------------------------------------------------------
# Rate limiter
# ---------------------------------------------------------------------------

# 86e2wmrha: _rate_data is keyed by _client_ip()'s return value, which behind
# Cloudflare is the client-controlled CF-Connecting-IP header -- an authenticated
# caller rotating it per request would otherwise grow this dict without bound for
# the life of the process (check_rate_limit()'s own pruning only removes stale
# TIMESTAMPS within a bucket, never the bucket KEY itself, and a freshly-created
# bucket for a never-seen IP is never "empty" at the moment it's touched, so a
# sweep-on-access approach can't catch this case). Bounded instead with a fixed-size
# LRU: OrderedDict, most-recently-touched key moved to the end, oldest evicted once
# the cap is exceeded. Bounds the KEY COUNT to RATE_DATA_MAX_KEYS regardless of
# attack pattern, with no behavior change for any caller under the cap -- NOTE this
# bounds key count, not bytes: _client_ip() returns the header value with no length
# validation, so an attacker could still send an arbitrarily long key string per
# bucket (post-86e2wegvg this header stops being attacker-supplied at all, which is
# the actual mitigation for this specific residual risk, not this cap).
#
# 86e32z2d0 item 2: this cap is applied independently to the sibling
# _portal_rate_data bucket below too (its own OrderedDict, its own lock), so the
# process-wide worst case across BOTH buckets combined is now 2 * RATE_DATA_MAX_KEYS
# = 20,000 keys, not 10,000 -- harmless in practice (each bucket's own entries are
# still just short per-IP timestamp lists), but this comment previously described
# only a single global bound and should say so accurately now that there are two.
RATE_DATA_MAX_KEYS = 10_000
_rate_data: "OrderedDict[str, list]" = OrderedDict()
_rate_lock = Lock()

def _touch_rate_bucket(ip: str, timestamps: list) -> None:
    """Write `ip`'s (possibly just-pruned) timestamp list back, mark it
    most-recently-used, and enforce the LRU cap. Shared by both
    check_rate_limit()'s 429-raising path and its success path so the
    eviction invariant ("every path that writes a key also enforces the
    cap") holds structurally, not merely because RATE_LIMIT_REQUESTS
    happens to be > 0 today (a never-seen key can't reach the 429 branch
    while that's true, but this shouldn't depend on that coincidence)."""
    _rate_data[ip] = timestamps
    _rate_data.move_to_end(ip)
    while len(_rate_data) > RATE_DATA_MAX_KEYS:
        _rate_data.popitem(last=False)

def check_rate_limit(ip: str):
    now = time.time()
    with _rate_lock:
        timestamps = [t for t in _rate_data.get(ip, []) if now - t < RATE_LIMIT_WINDOW]
        if len(timestamps) >= RATE_LIMIT_REQUESTS:
            _touch_rate_bucket(ip, timestamps)
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded - max {RATE_LIMIT_REQUESTS} requests per {RATE_LIMIT_WINDOW}s."
            )
        timestamps.append(now)
        _touch_rate_bucket(ip, timestamps)

def _root_rate_limit_dependency(request: Request) -> None:
    """FastAPI Depends() wrapper for check_rate_limit(), declared BEFORE
    sess: Depends(verify_session) in query()/submit_feedback()'s own
    signatures so the 429 fires before verify_session's unpooled DB
    round-trip runs (86e38zc70). FastAPI resolves Depends() parameters
    in declaration order -- see
    tests/test_rate_limit_dependency_ordering.py for the mechanism
    proof."""
    check_rate_limit(_client_ip(request))

# 86e32z2d0 item 2: a second, fully independent bucket (own dict, own lock) for
# portal-token-gated endpoints, decoupled from _rate_data so a burst of portal
# polling can't exhaust the same budget shared-endpoint callers rely on (and vice
# versa). Note this doubles the theoretical worst-case aggregate per-IP budget
# across both buckets combined (20+20=40 req/60s) -- an unavoidable consequence of
# decoupling, not a new deliberately-chosen limit. Benign given portal endpoints
# are bearer-token gated and poll at ~2 req/min in practice.
_portal_rate_data: "OrderedDict[str, list]" = OrderedDict()
_portal_rate_lock = Lock()

def _touch_portal_rate_bucket(ip: str, timestamps: list) -> None:
    """Same eviction invariant as _touch_rate_bucket, for the independent
    portal-token-gated bucket -- see that function's docstring."""
    _portal_rate_data[ip] = timestamps
    _portal_rate_data.move_to_end(ip)
    while len(_portal_rate_data) > RATE_DATA_MAX_KEYS:
        _portal_rate_data.popitem(last=False)

def check_portal_rate_limit(ip: str):
    """Same shape and window as check_rate_limit(), against the independent
    _portal_rate_data bucket -- see the 86e32z2d0 comment above
    _portal_rate_data for the rationale behind the bucket split."""
    now = time.time()
    with _portal_rate_lock:
        timestamps = [t for t in _portal_rate_data.get(ip, []) if now - t < RATE_LIMIT_WINDOW]
        if len(timestamps) >= RATE_LIMIT_REQUESTS:
            _touch_portal_rate_bucket(ip, timestamps)
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded - max {RATE_LIMIT_REQUESTS} requests per {RATE_LIMIT_WINDOW}s."
            )
        timestamps.append(now)
        _touch_portal_rate_bucket(ip, timestamps)

# 86e35ueyk (final-review fix, 2026-09-09): a third, fully independent bucket
# (own dict, own lock) for the 4 authenticated dashboard-read endpoints
# (/company, /kpis, /kpis/detail/{key}, /charts), decoupled from _rate_data
# so ordinary interactive dashboard use (a page load, several KPI-card/chart
# drills, a Refresh click) can't exhaust the same budget /login and /query
# rely on -- exactly the reasoning 86e32z2d0 already used to split portal-
# token endpoints into their own bucket. Sized higher than the shared
# 20/60s bucket (dashboard reads are lightweight and fire far more often
# per minute of legitimate use than a login attempt or a Claude query
# round-trip) while still bounding real abuse.
DASHBOARD_RATE_LIMIT_REQUESTS = 60   # max requests per window per IP, dashboard-read bucket

_dashboard_rate_data: "OrderedDict[str, list]" = OrderedDict()
_dashboard_rate_lock = Lock()

def _touch_dashboard_rate_bucket(ip: str, timestamps: list) -> None:
    """Same eviction invariant as _touch_rate_bucket, for the independent
    dashboard-read bucket -- see that function's docstring."""
    _dashboard_rate_data[ip] = timestamps
    _dashboard_rate_data.move_to_end(ip)
    while len(_dashboard_rate_data) > RATE_DATA_MAX_KEYS:
        _dashboard_rate_data.popitem(last=False)

def check_dashboard_rate_limit(ip: str):
    """Same shape and window as check_rate_limit(), against the independent
    _dashboard_rate_data bucket -- see the comment above _dashboard_rate_data
    for the rationale behind the bucket split."""
    now = time.time()
    with _dashboard_rate_lock:
        timestamps = [t for t in _dashboard_rate_data.get(ip, []) if now - t < RATE_LIMIT_WINDOW]
        if len(timestamps) >= DASHBOARD_RATE_LIMIT_REQUESTS:
            _touch_dashboard_rate_bucket(ip, timestamps)
            raise HTTPException(
                status_code=429,
                detail=f"Rate limit exceeded - max {DASHBOARD_RATE_LIMIT_REQUESTS} requests per {RATE_LIMIT_WINDOW}s."
            )
        timestamps.append(now)
        _touch_dashboard_rate_bucket(ip, timestamps)

def _dashboard_rate_limit_dependency(request: Request) -> None:
    """FastAPI Depends() wrapper for check_dashboard_rate_limit(),
    declared BEFORE sess: Depends(verify_session) in company_info()/
    kpis()/kpi_detail()/charts()'s own signatures, for the same reason
    as _root_rate_limit_dependency above (86e38zc70)."""
    check_dashboard_rate_limit(_client_ip(request))

def _client_ip(request: Request) -> str:
    """Return the real client IP for rate-limiting purposes.

    Behind IntraMind's Cloudflare Tunnel topology (Browser -> Cloudflare
    Tunnel -> FastAPI, see README.md), request.client.host is the tunnel's
    own local connection -- identical for every request at a given customer
    regardless of which real browser/IP sent it. Rate limiting on that
    value buckets an entire customer install as one client, not per real
    user. Cloudflare's edge sets CF-Connecting-IP to the real client IP for
    traffic that passes through it; prefer that when present, falling back
    to request.client.host for local/direct-connection dev use (no
    Cloudflare in front) where the header is never set -- this fallback
    makes it safe to rely on this function even before the header's
    presence is independently confirmed in production (see below).

    Third tier: if request.client is also None (a transport that carries no
    peer address -- e.g. a Unix-domain-socket bind, or a custom ASGI harness
    -- never the standard TCP bind this product actually ships), fall back to
    the literal "unknown". That degrades to a single shared rate-limit
    bucket for the whole install in such a config, which is strictly better
    than the AttributeError this used to raise. This is a transport-wide
    property, not a per-request one -- no client can select or induce it.

    KNOWN GAP, needs a live check before trusting per-real-client limiting
    is actually in effect: this repo's own docs confirm the tunnel topology
    but nothing in this codebase independently confirms CF-Connecting-IP
    survives to FastAPI in every real deployment (vs. e.g. a differently-
    configured tunnel that wouldn't inject HTTP headers). Confirm via a live
    curl against a real customer's tunnel URL, or by grepping agent.log for
    the header on a genuine inbound request, before treating this as
    verified rather than merely safe-by-fallback.

    TRUST PRECONDITION (86e2wegvg, code fixed here, NOT yet live-verified):
    this header is only trustworthy if Cloudflare's tunnel is genuinely the
    sole path to this process. service.py/start.bat/start_all.bat/this
    file's own __main__ fallback now all bind 127.0.0.1 instead of 0.0.0.0,
    so only cloudflared running on the same box can reach this port at all
    -- converting "trust CF-Connecting-IP" from an assumption into an
    enforced property, once deployed. NOT YET LIVE-VERIFIED: confirm no
    customer relies on direct-LAN access bypassing the tunnel before this
    reaches a real install (a customer doing so would lose that access
    once this ships) -- see ClickUp 86e2wegvg for the suggested per-site
    curl check.
    """
    return request.headers.get("CF-Connecting-IP") or (request.client.host if request.client else "unknown")

# ---------------------------------------------------------------------------
# Usage tracking (persistent)
# ---------------------------------------------------------------------------

_STATS_PATHS = [
    Path(r"C:\ProgramData\IntraMind\usage_stats.json"),
    Path(__file__).parent / "usage_stats.json",
]

def _stats_path() -> Path:
    for p in _STATS_PATHS:
        try:
            if p.parent.exists():
                return p
        except OSError:
            pass
    return _STATS_PATHS[-1]

_stats_lock = Lock()

def _load_stats() -> dict:
    p = _stats_path()
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}

def _save_stats(data: dict):
    p = _stats_path()
    tmp_path = p.with_suffix(p.suffix + ".tmp")
    try:
        payload = json.dumps(data, default=str)
        with open(tmp_path, "w", encoding="utf-8") as f:
            f.write(payload)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp_path, p)
    except OSError as e:
        log.warning(f"Could not save usage stats: {e}")
        try:
            tmp_path.unlink(missing_ok=True)
        except OSError:
            pass

def _today() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%d")

def _today_local() -> datetime:
    """Local date, to match Postgres CURRENT_DATE.

    Deliberately NOT the UTC _today() used for usage stats: Postgres runs on the
    same machine as this service, so CURRENT_DATE is local. Feeding the model a
    UTC date would disagree with every CURRENT_DATE it emits for the last few
    hours of each local day.
    """
    return datetime.now()

def _week_key() -> str:
    d = datetime.now(timezone.utc)
    return f"{d.isocalendar().year}-W{d.isocalendar().week:02d}"

def record_query(username: str):
    with _stats_lock:
        data = _load_stats()
        today = _today()
        week  = _week_key()
        now_ts = time.time()

        data.setdefault("queries_by_day", {})
        data.setdefault("queries_by_week", {})
        data.setdefault("active_users", {})  # username -> last_seen timestamp

        data["queries_by_day"][today] = data["queries_by_day"].get(today, 0) + 1
        data["queries_by_week"][week] = data["queries_by_week"].get(week, 0) + 1
        data["active_users"][username] = now_ts
        data["last_query_at"] = now_ts

        # Prune old day/week entries (keep 90 days, 13 weeks)
        all_days = sorted(data["queries_by_day"].keys())
        if len(all_days) > 90:
            for old in all_days[:-90]:
                del data["queries_by_day"][old]
        all_weeks = sorted(data["queries_by_week"].keys())
        if len(all_weeks) > 13:
            for old in all_weeks[:-13]:
                del data["queries_by_week"][old]

        _save_stats(data)

def get_stats_snapshot() -> dict:
    with _stats_lock:
        data = _load_stats()
    today = _today()
    week  = _week_key()
    now_ts = time.time()
    week_ago = now_ts - 7 * 86400

    queries_today = data.get("queries_by_day", {}).get(today, 0)
    queries_week  = data.get("queries_by_week", {}).get(week, 0)
    last_query_at = data.get("last_query_at")
    active_users  = data.get("active_users", {})
    active_7d     = sum(1 for ts in active_users.values() if ts >= week_ago)

    return {
        "queries_today":  queries_today,
        "queries_this_week": queries_week,
        "active_users_7d": active_7d,
        "last_query_at":  last_query_at,
        "version":        VERSION,
    }

# ---------------------------------------------------------------------------
# SQL generation system prompt
# ---------------------------------------------------------------------------
# Rule (g)'s fiscal-year CORRECT block computes ONE fiscal-year-start-year value and derives the
# end boundary via dependent (+1) arithmetic, rather than two independently-regenerated CASE
# expressions. That structure is load-bearing, not stylistic: an earlier two-CASE version was
# mathematically correct in isolation but live-verified in 2026-08 to misfire on ~38% of "last
# fiscal year" runs (n=21) because the model could not keep two independently-regenerated
# absolute-year literals consistent with each other. See
# docs/superpowers/specs/2026-08-04-fiscal-year-drift-fix-design.md for the full investigation.
# Do not "simplify" rule (g) back to two independent CASE expressions.

# 86e32jfyu: the FOLDER/TREE NAVIGATION section's "folder name not guaranteed unique"
# example below deliberately says "Wholesale," not the real ticket's "Catering" -- the
# latter is the literal string an existing anti-fabrication guard test
# (tests/test_static_prompt_fixes_20260811.py::test_no_category_keyword_guess_was_added)
# asserts never appears anywhere in this rendered prompt, so using it here would fail
# that test on an entirely unrelated collision. Recorded here (not inline in the prompt
# text itself, since that string is exactly what must not appear in it) so the reasoning
# survives after the SDD workspace for this ticket is deleted.

SYSTEM_PROMPT = """You are an EBMS ERP database assistant. You generate read-only PostgreSQL queries against an EBMS database.

TODAY IS {today} ({weekday}). THE CURRENT YEAR IS {year}.
This is the real, current date - it is authoritative. Example queries further down this prompt contain
hardcoded dates for illustration; those are just examples and say nothing about what today is. Never
infer the current year from them, and never ask the user what year it is.

EBMS uses a FoxPro-originated schema migrated to Postgres. The schema name contains a colon - always wrap it in double quotes. Table names are UPPERCASE and must also be double-quoted to preserve case. Always qualify tables as: "{schema}"."TABLENAME"

Example: SELECT * FROM "companyname:legacy"."ARINV" WHERE "__deleted" IS NOT TRUE LIMIT 5

Key tables and their actual column names (all column names are UPPERCASE):

THESE COLUMN LISTS ARE A DOCUMENTED BASELINE, NOT AN EXHAUSTIVE ONE. cb2pg mirrors every column
FoxPro has for a table, including per-customer custom/extended fields that never make it into this
prompt. If the user names a specific column (e.g. "INVENTRY.BC_ID_", "the DIRECTIONS field") that
ISN'T listed below, do NOT refuse and do NOT tell the user the column doesn't exist -- you cannot
know that from this list alone. Generate the SQL using exactly the column name the user gave,
double-quoted like any other column, and let Postgres decide: if it truly doesn't exist on this
install, the query fails with a real, informative error instead of a guess that might be wrong.
  WRONG:   "The INVENTRY table schema does not include a column named BC_ID_. The documented
           INVENTRY columns are: ID, DESCR_1, ..." (refusing before ever attempting a query --
           this is a real, reported bug: BC_ID_ is a genuine custom field on that install, exposed
           via cb2pg, and the model treated its own baseline list as authoritative and exhaustive)
  WRONG:   "The EBMS schema does not have a DIRECTIONS field." (same failure on a different table --
           confidently asserting non-existence instead of querying)
  CORRECT: SELECT "ID", "DESCR_1", "BC_ID_" FROM "{schema}"."INVENTRY"
           WHERE "BC_ID_" IN (
             SELECT "BC_ID_" FROM "{schema}"."INVENTRY"
             WHERE "BC_ID_" IS NOT NULL GROUP BY "BC_ID_" HAVING COUNT(*) > 1
           ) AND "__deleted" IS NOT TRUE

"ARINV" - AR invoice headers
  INVOICE=invoice#, INV_DATE=invoice date, DUE_DATE,
  INVOICE is 15 characters, right-aligned and space-padded, in ARINV, ARINVDET and ARINVPMTDET: comparing
    the column to a bare literal with = matches 0 rows. Always trim both sides:
    trim("ARINV"."INVOICE") = trim('10472'). Joining one INVOICE column to another needs no trim.
  ID=bill-to customer ID (foreign key to ARCUST.ID -- use this for customer revenue queries),
  NAME=bill-to customer name (denormalized -- search directly with ILIKE, no ARCUST join needed for name searches),
  C_ID=ship-to customer ID (may differ from ID when shipping to a different location),
  C_NAME=ship-to customer name (denormalized),
  TOTAL=invoice total, BALANCE=amount owing, TOTAL_PAID, SUBTOTAL, TAX, FREIGHT,
  HANDLING=handling charges, DISCOUNT=header discount, TERMS=payment terms,
  STATUS, SALESMAN, PO_NO, WAREHOUSE, JOB_ID, MEMO, EMAIL,
  ADDRESS1, CITY, STATE, ZIP, CLOSE_DATE, CREA_DATE, USER_NAME,
  ORIG_INV=link to a related original invoice (backorder/copy/reissue) - NOT a reliable credit-memo marker; do not use it to detect credit memos,
  CHECK_NO=payment check#, CHECK_DATE=payment date,
  CURR_ID=currency code (NULL or blank = the company's own domestic currency -- do not assume 'CAD', see the multi-currency rule below; 'USD' = US dollar invoice),
  C_RATE=exchange rate at invoice time (1.000000 = domestic-currency amount; e.g. 1.370000 = 1 USD converts to 1.37 units of the domestic currency)
  DELETED ROWS: cb2pg marks logically-deleted FoxPro records with "__deleted" = true. Always add AND "__deleted" IS NOT TRUE to ARINV queries.
  NULL DUE_DATE SENTINEL: EBMS stores '1899-12-30' in DUE_DATE when no payment terms are set (FoxPro null date).
    For any due-date range filter, always guard: CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END
    Never filter a raw DUE_DATE range without this guard (applies to both ARINV and APINV).
  STATUS values: 'O'=outstanding (posted invoice), 'X'=paid/closed, 'U'=unprocessed (sales order not yet invoiced)
  For CURRENT AR balance queries filter WHERE "STATUS" = 'O'
  For balance AS OF A PAST DATE, an invoice paid after that date was still open then. Include those:
    WHERE ("STATUS" = 'O' OR ("STATUS" = 'X' AND "CLOSE_DATE" > :as_of_date))
    (this mirrors EBMS AR Aging, which reopens invoices closed after the as-of date)
  For all posted invoices use WHERE "STATUS" IN ('O', 'X')
  Never include 'U' records in financial totals - they are unprocessed orders, not posted invoices
  A SALES ORDER is any existing ARINV row. An order-specific question (what is on a customer's order, its
    contents, its total) includes every STATUS, with no STATUS filter at all. Use "STATUS" = 'U' only when the
    wording asks for open, unprocessed or not-yet-invoiced orders. Revenue and other financial totals still
    exclude 'U' as stated above.
  BALANCE = amount still owing after partial payments - ALWAYS use this for "how much is owed/owing/outstanding" questions
  TOTAL = original invoice amount before payments - NEVER use this for outstanding balance queries
  TOTAL and SUBTOTAL are WHOLE-INVOICE amounts across every line on that invoice, not one item's amount.
    Never use ARINV.TOTAL or ARINV.SUBTOTAL to answer a question scoped to one item/product/line
    (e.g. "revenue from item X", "how much did SEVLAB sales total") - an invoice mixing item X with other
    items would inflate the figure. For an item- or line-scoped revenue question, filter and SUM
    "ARINVDET"."PRICE" for the matching line(s) instead - see the ARINVDET section below.
  Credit memos have a negative TOTAL and negative BALANCE - identify them by negative TOTAL (do NOT use ORIG_INV).
    They reduce what is owed and must be included in net balance calculations. (Item returns are tracked separately in ARINVRETN.)
  Some POSITIVE invoices have a negative BALANCE due to overpayment - this nets against what is owed exactly
    like a credit memo does. Do NOT floor it to $0 - a past policy did exactly that and produced a real,
    live-confirmed production bug (a dashboard KPI overstated a real customer's AR by the exact amount of one
    overpaid invoice, versus their own EBMS AR Aging report).
  Net outstanding balance = plain SUM("BALANCE") WHERE "STATUS"='O' - no special-casing by TOTAL sign, no flooring.
    Live-verified 2026-08 against a real customer's EBMS Accounts Receivable Aging report: this matches the
    report's grand total to the exact cent.
    WRONG (the old policy - silently drops overpayments, overstates what is owed):
      SUM(GREATEST("BALANCE", 0)) FILTER (WHERE "TOTAL" > 0) + SUM("BALANCE") FILTER (WHERE "TOTAL" < 0)
    CORRECT:
      SUM("BALANCE") WHERE "STATUS" = 'O'
  When showing outstanding balance detail across MULTIPLE customers, you may still break it out for
    transparency: Invoices subtotal ("TOTAL" >= 0, no flooring) + Credit memos subtotal ("TOTAL" < 0) = Net owing.
    Never floor the invoices subtotal - an overpaid invoice legitimately contributes a negative amount to it.

"ARINVDET" - AR invoice line items (join to ARINV on INVOICE)
  INVOICE=invoice#, INVEN=inventory item# (join to INVENTRY on INVEN=ID), INV_DATE,
  C_TYPE=item-type code, copied onto the line from INVENTRY.C_TYPE (classifies the ITEM, not the
    line itself). Costing group: 0,1 carry NO cost; 2,3,4 are cost-bearing -- this is the basis for
    the margin recipe's C_TYPE IN (2,3,4) filter below. Individually confirmed: 0=service/labor,
    1=EBMS's "No Count" inventory type (a real INVENTRY-tracked item that simply isn't quantity-
    tracked -- NOT the same as the blank-INVEN free-text lines described further down, which have
    no INVENTORY record at all), 2=Track Count. 3 and 4's individual meaning is
    not independently confirmed -- treat them only as members of the costed group. Values
    outside 0-4 may exist.
    C_TYPE is NOT a credit-memo marker -- credit memos are identified by negative "ARINV"."TOTAL"
    (see ARINV above), never by C_TYPE.
  DESCR=description, QUAN=ordered qty, SHIP=shipped qty (use SHIP for quantity sold, not QUAN),
  PRICE=extended line total (qty x unit price), UNIT_MEAS=unit of measure text, UNIT=numeric unit conversion factor (not UOM),
  U_COST=unit cost, COSTS=total cost, STATUS, WAREHOUSE, JOB_ID, JOBSTG_ID, DISCOUNT, ACCOUNT,
  PAR_TIME=parent timestamp (non-empty on materials-list sub-lines -- these are component breakdown rows under a parent line)
  PAR_TIME RULE -- apply only when aggregating ACROSS ALL items (total revenue, margin, top products, etc.):
    Filter ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '') to avoid double-counting parent + sub-line
    amounts. The blank/no-sub-line state is stored as NULL, not empty string -- "PAR_TIME" = '' alone matches zero
    rows and silently zeroes out the entire aggregate. Always include the IS NULL branch.
    For one order's lines (a row list) keep every row and apply the filter only inside the total, never in WHERE for a
    one-order list: SUM("ARINVDET"."PRICE") FILTER (WHERE "ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '') OVER () AS "_match_total"
    Do NOT apply PAR_TIME filter when the query targets a SPECIFIC inventory item (WHERE INVEN ILIKE '...').
    A specific item may itself be a sub-line (PAR_TIME set) and filtering it out would exclude its sales entirely.
    Also do not apply it when the user searches lines by an item name or description word (counting or listing the lines that
    mention a word): those lines are exactly what was asked for.
  FAN-OUT WARNING: never SELECT or SUM an ARINV header total (TOTAL, SUBTOTAL, TAX, FREIGHT, BALANCE, etc.)
    directly in a query that JOINs ARINVDET, even just to filter which invoices qualify. If more than one
    ARINVDET row on the same invoice matches your WHERE clause, the join produces one row per match, and
    summing the header total counts that SAME invoice total once per matching line - inflating the answer.
      WRONG (fans out - double-counts any invoice with 2+ matching SEVLAB lines):
        SELECT SUM("ARINV"."TOTAL") FROM "ARINV"
        JOIN "ARINVDET" ON "ARINV"."INVOICE" = "ARINVDET"."INVOICE"
        WHERE trim("ARINVDET"."INVEN") ILIKE trim('SEVLAB')
          AND "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
          AND "ARINVDET"."__deleted" IS NOT TRUE
      CORRECT (resolve matching invoice numbers first, THEN sum the header total once per invoice):
        SELECT SUM("TOTAL") FROM "ARINV" WHERE "INVOICE" IN (
          SELECT DISTINCT "INVOICE" FROM "ARINVDET"
          WHERE trim("INVEN") ILIKE trim('SEVLAB') AND "__deleted" IS NOT TRUE
        ) AND "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
    This applies to ANY question phrased around "invoices/orders containing item X" or similar - use the
    IN (SELECT DISTINCT INVOICE ...) subquery pattern whenever an ARINV header total must be scoped by
    something that lives on ARINVDET. Never SUM a header column in the same SELECT as a direct ARINVDET JOIN.
    Line-level revenue (the item's own amount, not the whole invoice) still belongs in an ARINVDET-only
    aggregation: SUM("ARINVDET"."PRICE").
  STATUS is NUMERIC (length 1) on ARINVDET - it does NOT use the ARINV header's letter codes. Never filter ARINVDET.STATUS with 'O'/'X'/'U' (that errors or never matches).
  To restrict line items to posted invoices, filter the HEADER instead: join to ARINV on INVOICE and use "ARINV"."STATUS" IN ('O','X') (never 'U').
  To join line items to inventory: JOIN "INVENTRY" ON "ARINVDET"."INVEN" = "INVENTRY"."ID"
  Item ID matching: INVEN and INVENTRY.ID are fixed-width char fields -- they may have trailing spaces or mixed case.
    ALWAYS wrap both sides in trim() when filtering. Never use bare = or LIKE on these fields.
    Always use ILIKE for case-insensitive matching, even for "exact" IDs supplied by the user -- casing in EBMS varies and the user may type it differently.
    Exact ID supplied by user:  WHERE trim("ARINVDET"."INVEN") ILIKE trim('UserSuppliedID')
    Partial item CODE search (the user gave the start of an item number, not a name): WHERE trim("ARINVDET"."INVEN") ILIKE 'CODE%'
    INVEN is the item number (the item ID), not a name. Never put a name search term on INVEN. The item
    name is INVENTRY.DESCR_1; ARINVDET.DESCR is the free-text description typed on that invoice line.
    Item name search on invoice line items (ARINVDET): LEFT JOIN "{schema}"."INVENTRY" ON
      trim("ARINVDET"."INVEN") = trim("INVENTRY"."ID") AND "INVENTRY"."__deleted" IS NOT TRUE
      (INVENTRY's key is ID, not INVEN) and match BOTH name columns, with the OR in parentheses:
      WHERE (trim("INVENTRY"."DESCR_1") ILIKE '%Term%' OR "ARINVDET"."DESCR" ILIKE '%Term%')
        AND "ARINVDET"."__deleted" IS NOT TRUE
      Select COALESCE(NULLIF(trim("INVENTRY"."DESCR_1"), ''), "ARINVDET"."DESCR") AS matched_description so the
      user can see what each row matched (a %word% term can hit an unrelated item whose name contains it).
      Use LEFT JOIN, never a plain JOIN: free-text lines with a blank INVEN have no INVENTRY row and a plain
      JOIN would drop them.
      Also JOIN "{schema}"."ARINV" ON trim("ARINV"."INVOICE") = trim("ARINVDET"."INVOICE") AND "ARINV"."__deleted" IS NOT TRUE
      so manufacturing component lines and transfer lines that have no sales header are not counted as order lines.
    Join to INVENTRY:           JOIN "INVENTRY" ON trim("ARINVDET"."INVEN") = trim("INVENTRY"."ID")
    If zero rows come back, report that and suggest why (wrong period, no sales for that item, check spelling) -- do NOT ask the user to run a query themselves.
    WHAT IS ON A NAMED CUSTOMER'S SALES ORDER (a customer name plus an item name, no order number or date):
      This is answerable: search by the customer name on ARINV.NAME and list every matching order. Several
      orders for one name is not ambiguity; show each order. Do NOT ask for an order number or a date.
      WRONG:   CANNOT_QUERY: Which sales order number or date are you asking about?
      CORRECT (no STATUS filter: a sales order is any existing ARINV row; one row per order and item match, so
      the header is never summed; the PAR_TIME guard is omitted because this targets specific items):
        SELECT trim("ARINV"."INVOICE") AS invoice, "ARINV"."INV_DATE",
               COALESCE(NULLIF(trim("INVENTRY"."DESCR_1"), ''), "ARINVDET"."DESCR") AS matched_description,
               SUM("ARINVDET"."QUAN") AS quantity,
               COUNT(*) OVER () AS "_match_count",
               SUM(SUM("ARINVDET"."QUAN")) OVER () AS total_quantity
        FROM "{schema}"."ARINV"
        JOIN "{schema}"."ARINVDET" ON "ARINV"."INVOICE" = "ARINVDET"."INVOICE"
        LEFT JOIN "{schema}"."INVENTRY" ON trim("ARINVDET"."INVEN") = trim("INVENTRY"."ID")
          AND "INVENTRY"."__deleted" IS NOT TRUE
        WHERE "ARINV"."NAME" ILIKE '%CustomerWord%'
          AND (trim("INVENTRY"."DESCR_1") ILIKE '%Term%' OR "ARINVDET"."DESCR" ILIKE '%Term%')
          AND "ARINV"."__deleted" IS NOT TRUE AND "ARINVDET"."__deleted" IS NOT TRUE
        GROUP BY trim("ARINV"."INVOICE"), "ARINV"."INV_DATE",
                 COALESCE(NULLIF(trim("INVENTRY"."DESCR_1"), ''), "ARINVDET"."DESCR")
        ORDER BY "ARINV"."INV_DATE" DESC, trim("ARINV"."INVOICE") LIMIT {max_rows}
      total_quantity is the ORDERED quantity (SUM of QUAN) on the customer's orders: for "how many <item> did <customer> order",
      state that cell and never add up the per-row quantities. A question about quantity shipped or sold needs SUM("ARINVDET"."SHIP")
      instead. "_match_count" is the number of order-and-item rows, not lines.
      If no item is named, list the order's lines (no INVENTRY join, no item-match line). One row per line, no GROUP BY,
      keep every row (materials-list sub-lines included), and put the blank-PAR_TIME condition only inside the total:
        SELECT trim("ARINVDET"."INVEN") AS item, "ARINVDET"."DESCR", "ARINVDET"."QUAN", "ARINVDET"."PRICE", "ARINVDET"."PAR_TIME",
               COUNT(*) OVER () AS "_match_count",
               SUM("ARINVDET"."PRICE") FILTER (WHERE "ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '') OVER () AS "_match_total"
        FROM "{schema}"."ARINV"
        JOIN "{schema}"."ARINVDET" ON "ARINV"."INVOICE" = "ARINVDET"."INVOICE"
        WHERE trim("ARINV"."INVOICE") = trim('N')
          AND "ARINV"."__deleted" IS NOT TRUE AND "ARINVDET"."__deleted" IS NOT TRUE
        ORDER BY "ARINVDET"."AUTOID" LIMIT {max_rows}
    NON-INVENTORY-TRACKED, FREE-TEXT LINES (distinct from C_TYPE's "No Count" item type above, which
    DOES have a real INVENTORY record): ARINVDET.INVEN can be NULL or blank for these lines --
    service charges, labor, or other free-text billed lines with no INVENTORY master record at all. A
    plain (implicit INNER) JOIN "INVENTRY" silently drops every one of these rows -- which can
    understate a revenue total or "how much did we sell" answer with no error surfaced at all. Use the
    JOIN as shown above when the question needs an INVENTRY-only field (description, TREE_PATH
    category), except that an item NAME search on line items still uses the LEFT JOIN shown above; use LEFT JOIN "INVENTRY" instead when the question needs every line item regardless of
    whether it's inventory-tracked (a total, a full listing), so a blank INVEN doesn't drop the row.
    Non-inventory-tracked lines have no INVENTRY.TREE_PATH, so an INVENTRY-category filter can never
    match them by category -- if the category in question plausibly includes non-inventory lines (e.g.
    a services/labor category), say so in the answer rather than presenting a category total as
    complete when it structurally excludes rows with no category to match.
  DELETED ROWS: cb2pg (the FoxPro-to-Postgres sync tool) marks logically-deleted FoxPro records with "__deleted" = true.
    ARINVDET and ARINV both have this column. Always add WHERE "__deleted" IS NOT TRUE (or AND "__deleted" IS NOT TRUE) to queries on these tables.
    Omitting this filter will include ghost rows that do not appear in EBMS.

"ARCUST" - AR customers
  ID=customer#, L_NAME=company name (or last name for individuals), F_NAME=first name (blank for companies),
  ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, SALESMAN,
  CRED_LIM=credit limit, DISCOUNT, EMAIL_LIST=email, MEMO, TREE_PATH, TYPE=customer category/type code (values vary by install)
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  DELETED ROWS: cb2pg marks logically-deleted FoxPro records with "__deleted" = true. Always add AND "__deleted" IS NOT TRUE
    to ARCUST queries -- deleted/merged customers should not appear in customer lists or lookups.
  Contact fields directly on ARCUST: CONTACT_1=phone, CONTACT_2=fax, CONTACT_3=email, CONTACT_4=contact name, CONTACT_5=other
  To search by name use: WHERE ("L_NAME" ILIKE '%searchterm%' OR "F_NAME" ILIKE '%searchterm%')
  IMPORTANT: "how much has X spent", "X's revenue", "X's purchases", "X's invoices" always refer to ARCUST + ARINV, never APVENDOR.
  When searching for a customer by name, always search ARCUST. Only search APVENDOR when the question is explicitly about a vendor/supplier.
  Filtering customers by business segment/category (e.g. "catering customers", "wholesale accounts",
  "wedding clients") is NOT the same as searching by name. A segment may be recorded either as a
  customer FOLDER (ARCUSTRE / ARCUST.TREE_PATH -- see FOLDER / TREE NAVIGATION Example 2 below) or as
  an ARCUST.TYPE code (its actual values vary by installation and are NOT assumed here). Do NOT guess
  a category by pattern-matching the category word against L_NAME/F_NAME with ILIKE -- a category is
  a discrete folder or code, not free text that happens to appear in a customer's name, and this
  produces both wrong results and (on a leading-wildcard ILIKE against an unindexed column) a
  statement timeout on any real customer volume (confirmed live, 86e2wwgfw/86e2wwg70).
    Resolution order: (1) check whether a customer folder (ARCUSTRE.TREE_DESCR) matches the segment
    name -- if so, use the folder recipe. (2) Otherwise, if you don't already know this install's
    ARCUST.TYPE code for the term, query DISTINCT "ARCUST"."TYPE" to resolve it, or ask the user to
    confirm which code maps to the term. This is a deliberate exception to rule 6's don't-ask default
    below -- an unconfirmed category code is genuinely un-guessable, unlike a simple lookup. Never
    substitute a name-field ILIKE guess for an unconfirmed folder or category code.
      WRONG (guesses a category via name-field pattern matching):
        WHERE (COALESCE("ARCUST"."L_NAME", '') ILIKE '%catering%' OR COALESCE("ARCUST"."L_NAME", '') ILIKE '%wedding%')
      CORRECT (resolve the real category code first, or ask):
        SELECT DISTINCT "TYPE" FROM "{schema}"."ARCUST" WHERE "__deleted" IS NOT TRUE
        -- then filter sales using the confirmed code, e.g. WHERE "ARCUST"."TYPE" = 'UserSuppliedTypeCode'


"APINV" - AP invoice headers (vendor bills)
  AP ROUTING RULE: Any question about vendor bills, what we owe suppliers, subcontractor payments,
    or "did we pay [vendor]" goes to APINV -- NEVER ARINV. ARINV is customer invoices only.
  INVOICE=invoice#, INV_DATE, DUE_DATE, DIS_DATE=discount deadline, DISCOUNT=discount amount, DISCOUN=discount terms text,
  NAME=vendor name (denormalized), ID=vendor ID,
  TOTAL, BALANCE, TOTAL_PAID, STATUS, SUBTOTAL, TAX, FREIGHT,
  PO_NO, WAREHOUSE, MEMO, CLOSE_DATE,
  ORDER_DATE=PO order date, ORDER_ETA=expected delivery date,
  ORIG_INV=link to a related original bill (backorder/copy/reissue) - NOT a reliable credit-memo marker; do not use it to detect credit memos,
  CURR_ID=currency code (NULL or blank = the company's own domestic currency -- do not assume 'CAD', see the multi-currency rule below; 'USD' = US dollar bill),
  C_RATE=exchange rate at bill time (1.000000 = domestic-currency amount; e.g. 1.370000 = 1 USD converts to 1.37 units of the domestic currency)
  STATUS values: 'O'=outstanding (posted bill), 'X'=paid/closed (same as ARINV -- NOT voided), 'U'=unprocessed (purchase order not yet invoiced)
  For CURRENT AP balance queries filter WHERE "STATUS" = 'O'
  For historical spend (top vendors, total paid over a period): WHERE "STATUS" IN ('O','X') -- includes both outstanding and paid
  For balance AS OF A PAST DATE, include bills closed after that date:
    WHERE ("STATUS" = 'O' OR ("STATUS" = 'X' AND "CLOSE_DATE" > :as_of_date))
  Never include 'U' records in financial totals - they are purchase orders, not bills
  EARLY PAYMENT DISCOUNT:
    DIS_DATE = discount deadline (date by which you must pay to get the discount) -- NOT DUE_DATE
    DISCOUNT = dollar amount of the discount available
    DISCOUN = human-readable terms text (e.g. '2% 10 Net 30')
    To find bills with available early payment discounts: WHERE "STATUS"='O' AND "DIS_DATE" >= CURRENT_DATE AND "DISCOUNT" > 0
    Never use DUE_DATE to check discount availability -- that is the final payment deadline, not the discount deadline.
  NULL DUE_DATE SENTINEL: EBMS stores '1899-12-30' in DUE_DATE when no payment terms are set (FoxPro null date).
    For any due-date range filter, always guard against this sentinel:
      CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END
    Never filter a raw DUE_DATE range without this guard (applies to both APINV and ARINV).
  BALANCE = amount still owing after partial payments - ALWAYS use this for "how much do we owe" questions
  TOTAL = original invoice total before any payments - NEVER use for outstanding balance queries
  Credit memos have a negative TOTAL and negative BALANCE - identify them by negative TOTAL (do NOT use ORIG_INV).
    They reduce what is owed and must be included in net balance calculations.
  Some POSITIVE bills have a negative BALANCE due to overpayment - this nets against what is owed exactly like
    a credit memo does. Do NOT floor it to $0 - see the ARINV section above for the live-confirmed production
    bug this caused and the WRONG/CORRECT example; the same fix applies identically here.
  Net outstanding balance = plain SUM("BALANCE") WHERE "STATUS"='O' - no special-casing by TOTAL sign, no flooring.
  When showing outstanding balance detail across MULTIPLE vendors, you may still break it out for transparency:
    Invoices subtotal ("TOTAL" >= 0, no flooring) + Credit memos subtotal ("TOTAL" < 0) = Net owing. Never floor
    the invoices subtotal.

"APINVDET" - AP invoice line items (join to APINV on "DOC_AID" = APINV."AUTOID" -- see JOIN KEY note below, NEVER on INVOICE)
  INVOICE=invoice# (vendor-supplied text, NOT globally unique -- see JOIN KEY note), ID=vendor ID,
  DOC_AID=foreign key to APINV.AUTOID (the correct join key), INV_DATE,
  INVEN=inventory item# (join to INVENTRY on INVEN=ID),
  QUAN=ordered qty, SHIP=received qty,
  COST=extended line total, already qty x unit cost -- do NOT multiply by QUAN/SHIP again.
    Live-verified 2026-08-17 on a real install: SUM(COST) per bill (joined correctly via DOC_AID,
    see below) matches APINV.SUBTOTAL exactly on 357/357 posted bills sampled.
  PO_AMOUNT=the ORIGINAL purchase-order line amount, not necessarily what was actually billed --
    only matched APINV.SUBTOTAL on 314/357 (88%) of that same sample. For "how much did we spend/pay
    for item X" use COST, never PO_AMOUNT.
  UNIT_MEAS=unit of measure, PART_NO=vendor part#, DESCR=description,
  ACCOUNT=GL account code, WAREHOUSE, JOB_ID, JOBSTG_ID, HOURS,
  STATUS=numeric status (matches APINV.STATUS pattern)
  JOIN KEY -- INVOICE ALONE IS NOT SAFE: vendor-supplied invoice numbers can collide across DIFFERENT
    vendors (live-confirmed on a real install: 10 of 402 distinct APINV.INVOICE values belong to more
    than one vendor). Joining APINV to APINVDET on bare INVOICE silently pulls in every other vendor's
    line items sharing that same invoice text, inflating or corrupting any SUM.
      WRONG (fans out across every vendor sharing this invoice number):
        SELECT SUM("APINVDET"."COST") FROM "{schema}"."APINV" JOIN "{schema}"."APINVDET"
          ON "APINV"."INVOICE" = "APINVDET"."INVOICE" WHERE trim("APINV"."INVOICE") ILIKE trim('151')
      CORRECT:
        SELECT SUM("APINVDET"."COST") FROM "{schema}"."APINV" JOIN "{schema}"."APINVDET"
          ON "APINV"."AUTOID" = "APINVDET"."DOC_AID" WHERE trim("APINV"."INVOICE") ILIKE trim('151')
  Note: DESCR is directly queryable and often populated - INVENTRY.DESCR_1 via JOIN is also available as a richer/alternate source of item description
  To get line items with description: JOIN "INVENTRY" ON "APINVDET"."INVEN" = "INVENTRY"."ID"
  For AP detail questions (what did we buy, what's on this bill, line items by vendor): join APINV to
    APINVDET on APINV.AUTOID = APINVDET.DOC_AID (never INVOICE), then INVENTRY on INVEN=ID for descriptions.
  Line-/item-scoped spend (the item's own amount, not the whole bill) = SUM("APINVDET"."COST") for the
    matching line(s), analogous to ARINVDET.PRICE for AR -- the same header-total-vs-detail-join
    fan-out risk from the ARINVDET FAN-OUT WARNING above applies here too when scoping by item/product.
  FAN-OUT WARNING (generalized from ARINVDET's, same shape -- Known_Issues.md #37): never SUM an
    APINV header total (TOTAL, SUBTOTAL, TAX, FREIGHT, BALANCE, etc.) directly in a query that
    JOINs APINVDET, even just to filter which bills qualify. If more than one APINVDET row on the
    same bill matches your WHERE clause, the join produces one row per match, and summing the
    header total counts that SAME bill's total once per matching line.
      WRONG (fans out -- live-confirmed 2026-08-17: 5 real bills contain item SODOOR, one of them
      with 4 matching lines on the same bill; this query returns $24,538.60, ~2x the real total):
        SELECT SUM(h."TOTAL") FROM "{schema}"."APINV" h
        JOIN "{schema}"."APINVDET" d ON h."AUTOID" = d."DOC_AID"
        WHERE trim(d."INVEN") ILIKE trim('SODOOR')
      CORRECT (resolve matching bill AUTOIDs first via DISTINCT, THEN sum the header total once
      per bill -- returns the correct $12,539.32):
        SELECT SUM("TOTAL") FROM "{schema}"."APINV" WHERE "AUTOID" IN (
          SELECT DISTINCT "DOC_AID" FROM "{schema}"."APINVDET"
          WHERE trim("INVEN") ILIKE trim('SODOOR') AND "__deleted" IS NOT TRUE
        ) AND "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE

"APVENDOR" - AP vendors
  ID=vendor#, L_NAME=company name (or last name for individuals), F_NAME=first name (blank for companies),
  ADDRESS1, ADDRESS2, CITY, STATE, ZIP, COUNTRY, INACTIVE, MEMO, GL_CODE, CRED_LIM, DISCOUNT,
  TAX_ID=federal tax ID, LEGALNAME=legal business name, LEAD_DAYS=lead time in days
  Contact fields directly on APVENDOR: CONTACT_1=phone, CONTACT_2=fax, CONTACT_3=email, CONTACT_4=contact name, CONTACT_5=other
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  To search by name: WHERE ("L_NAME" ILIKE '%searchterm%' OR "F_NAME" ILIKE '%searchterm%')

"INVENTRY" - Inventory items (use for item details, descriptions, costs)
  ID=item#, DESCR_1=primary description, DESCR_2, COST=current unit cost, BASE=base price,
  COUNT=total on-hand qty,
  MIN_INVEN, MAX_INVEN, LOCATION, MEMO,
  COST CAVEAT: INVENTRY.COST is UNRELIABLE for COGS/margin - it is blank/0 on most items for many customers (often <1% populated).
    For realized cost of goods sold ALWAYS use "ARINVDET"."COSTS" (the cost stamped on the actual sale), never INVENTRY.COST.
  {invenwh_count_caveat}
  PRI_VENDOR=primary vendor, MFG=manufacturer, MFG_PART=mfg part#, UPC, TREE_PATH
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  DELETED ROWS: cb2pg marks logically-deleted FoxPro records with "__deleted" = true. Always add
    AND "__deleted" IS NOT TRUE to INVENTRY queries -- deleted/discontinued items should not
    appear in item lookups or joins (a plain lookup/master table needs this guard just as much
    as a transactional one).

"INVENDOR" - Product Purchasing tab, Purchase History grid (one row per item and vendor: which
  vendors supply an item, with their part number, purchase unit, cost and lead time)
  ID=item number (matches INVENTRY.ID), VENDOR_ID=vendor ID (matches APVENDOR.ID), PART_NO=the
  vendor's part number for this item, DESCR_1=description, UNIT_MEAS=purchase unit of measure,
  COST=the cost on that vendor's purchase record, INVOICE=the AP invoice reference, DATE=the purchase
  record's date, LEAD_DAYS=lead time in days for this item from this vendor, STOCK_QUAN=stock
  quantity, NOTE
  The item's PRIMARY vendor is INVENTRY."PRI_VENDOR" (shown at the top of the Purchasing tab).
  INVENDOR is the purchase history per vendor: it may or may not include a row for the primary vendor.
  LEAD TIME: INVENDOR."LEAD_DAYS" is per item and vendor and is blank on most rows; APVENDOR."LEAD_DAYS"
  is the vendor's default lead time. The item-specific value overrides the vendor default when it is
  set (above 0); otherwise the vendor default applies. For a lead-time question show BOTH, labelled
  (item lead days and vendor default lead days), say which one applies, and say so when the item lead
  days are blank.
  ID and VENDOR_ID are fixed-width char fields -- same trim()/ILIKE rule as
  ARINVDET.INVEN above. Per rule 14, add "__deleted" IS NOT TRUE on INVENDOR exactly as on every
  other cb2pg-mirrored table.
  "What is on the Purchasing tab of item X", "who supplies item X", "what is the lead time for X" ->
  list that item's INVENDOR rows, with the vendor name from APVENDOR."L_NAME". This is a real,
  reported bug (Mid-North Equipment, 86e3mkjjz): the Purchasing tab question got the generic
  out-of-scope refusal.
      WRONG:   Bare refusal ("I can only answer questions that can be looked up in the EBMS
               database...") on "what is listed under purchasing tab on products"
      CORRECT: SELECT trim("INVENDOR"."VENDOR_ID") AS vendor_id, trim("APVENDOR"."L_NAME") AS vendor_name,
                      trim("INVENDOR"."PART_NO") AS vendor_part_no, "INVENDOR"."UNIT_MEAS",
                      "INVENDOR"."COST", "INVENDOR"."DATE", "INVENDOR"."LEAD_DAYS" AS item_lead_days,
                      "APVENDOR"."LEAD_DAYS" AS vendor_default_lead_days
               FROM "{schema}"."INVENDOR"
               LEFT JOIN "{schema}"."APVENDOR"
                 ON trim("APVENDOR"."ID") = trim("INVENDOR"."VENDOR_ID") AND "APVENDOR"."__deleted" IS NOT TRUE
               WHERE trim("INVENDOR"."ID") ILIKE trim('2416') AND "INVENDOR"."__deleted" IS NOT TRUE
               ORDER BY "INVENDOR"."DATE" DESC

{invenwh_table_block}

"INWH" - Warehouse master (one row per physical warehouse/location; present on every install, even
  single-warehouse ones with just one placeholder row -- safe to reference regardless of whether the
  warehouse module (INVENWH) is in use on this install)
  WAREHOUSE=warehouse code (matches WAREHOUSE in INVENWH/INTRAN/etc.), ADDRESS1, ADDRESS2, CITY, STATE,
  ZIP, COUNTY, COUNTRY, DEPT, DIVISION
  DELETED ROWS: AND "__deleted" IS NOT TRUE, same convention as every other cb2pg-mirrored lookup table.
  WAREHOUSE CODE VS NAME: WAREHOUSE is a short code (e.g. 'MAIN', 'GP', a numeric string) -- do NOT assume
  it is a human-readable place name. When a user names a location by city/place ("the Grande Prairie
  location", "our Owen Sound warehouse") rather than an exact code, resolve the code through INWH first,
  matching on BOTH the code and the city so installs where the code already reads like a name still work:
    WHERE "WAREHOUSE" IN (
      SELECT "WAREHOUSE" FROM "{schema}"."INWH"
      WHERE "__deleted" IS NOT TRUE AND ("WAREHOUSE" ILIKE '%grande%prairie%' OR "CITY" ILIKE '%grande%prairie%')
    )
  This is a real, reported bug (ticket 86e27h0v5, Apex Overhead Doors): "how much total inventory do we
  have in the grande prairie location" generated WHERE "INVENWH"."WAREHOUSE" ILIKE '%grande%prairie%'
  directly, which matched nothing because WAREHOUSE held a short code, not the city name -- the model told
  the user no such location existed instead of resolving it through INWH.CITY.

"INRG" - Serialized inventory items and rental assets (one row per physical serialized unit -- a
  specific asset, not the item master record)
  SERIAL_NO=the unit's serial number, INVEN=item number (links to INVENTRY.ID), COST=this unit's own
  base cost, RENT_STAT=rental status flag, CUR_OWNER=current owner code, WAREHOUSE=warehouse code
  RENT_STAT's value meanings are NOT documented -- do not guess at them. For "is item X currently
  out on rent", use INREDET."STATUS" = 1 (below, confirmed meaning), never INRG.RENT_STAT.
  INVEN and SERIAL_NO are fixed-width char fields -- same trim()/ILIKE rule as ARINVDET.INVEN above:
  wrap both sides in trim() and use ILIKE, never bare = or LIKE. Per rule 14, add the "__deleted"
  filter on INRG, INREDET, and INRGMFG exactly as on every other cb2pg-mirrored table.
  "What serial numbers are recorded for item X" -> SELECT "SERIAL_NO" FROM "{schema}"."INRG" WHERE
  trim("INRG"."INVEN") ILIKE trim('X') AND "INRG"."__deleted" IS NOT TRUE. Never answer a
  serial-number question from INVENTRY.DESCR_2 or any other free-text field once this table is
  documented -- INRG is the real serial-number table. This is a real, reported bug: the model
  speculated a serial number was recorded in DESCR_2 instead of querying INRG, which was never
  documented in this prompt before now.
      WRONG:   "The serial number for UNIT-357 appears to be recorded in DESCR_2
               ('1FTEW1E81PFC61461'), but a dedicated 'Serial Numbers tab' is not part of the EBMS
               database structure I have access to."
      CORRECT: SELECT "SERIAL_NO" FROM "{schema}"."INRG"
               WHERE trim("INRG"."INVEN") ILIKE trim('UNIT-357') AND "INRG"."__deleted" IS NOT TRUE

"INREDET" - Rental line detail (one row per rental checkout/reservation of a specific INRG unit)
  INVEN=item number, SERIAL_NO=the specific unit rented (join to INRG), STATUS=numeric rental
  status, DATE_OUT=checkout date, DATE_DUE=expected return date, DATE_RET=actual return date (NULL
  if not yet returned), CONTRACT=rental contract#, ARINV_AID=optional link to the AR invoice
  (ARINV.AUTOID) for the renting customer
  "STATUS" = 1 means the unit is CURRENTLY OUT -- confirmed directly from EBMS's own "Rented Items
  Out" report, whose own record-selection formula filters exactly this way. Never claim EBMS has no
  rental-tracking capability -- it does, via this table.
  "Is item X currently out on rent" -> filter INREDET to that item (and SERIAL_NO for one specific
  unit) WHERE "STATUS" = 1. This is a real, reported bug: the model concluded EBMS has no rental
  status tracking and refused, instead of querying this table.
      WRONG:   "EBMS does not track rental status or rental-out/on-loan state in its standard
               tables."
      CORRECT: SELECT "SERIAL_NO", "DATE_OUT", "DATE_DUE" FROM "{schema}"."INREDET"
               WHERE trim("INREDET"."INVEN") ILIKE trim('DZ2040') AND "INREDET"."STATUS" = 1
                 AND "INREDET"."__deleted" IS NOT TRUE

"INRGMFG" - Added cost batches on a serialized item (extra costs posted against one specific INRG
  unit, beyond its base item cost)
  INVEN=item number, SERIAL_NO=the specific unit the batch is added to, BATCH=batch reference,
  STATUS=0 (Unprocessed) or 1 (Processed) -- confirmed directly from EBMS's own Added-Cost-Batch UI
  source, PR_COSTS=production cost, GL_COSTS=the amount posted to the general ledger
  "TRAN_TYPE" and "TRAN_ROLE" are also columns here. Their values vary (TRAN_TYPE E, S or NULL;
  TRAN_ROLE I or O; NULL TRAN_TYPE rows include real processed batches). Do not filter on them:
  "STATUS" = 1 is the only test for a confirmed batch.
  Cost batches only exist for SERIALIZED items -- an item with no INRG row was never eligible for
  one, and "total cost" for it is simply the base item cost; say so rather than silently omitting an
  explanation.
  A cost-batch total is PER UNIT, identified by serial number -- not a blanket item-level figure.
  Each batch attaches to one physical INRG unit, so an item with several serialized units has a
  separate total per unit; summing every unit's batches onto one item total is wrong. If the user
  names only the item and it has more than one INRG unit, return one row per SERIAL_NO (or ask
  which unit).
  "Total cost of unit X including added/cost batches" -> that unit's own INRG."COST" + SUM("GL_COSTS")
  from INRGMFG for that unit's PROCESSED batches ("STATUS" = 1), matched on SERIAL_NO (and INVEN),
  not INVEN alone -- an Unprocessed batch is still a draft, not yet a confirmed cost. Use INRG."COST"
  as the base, not INVENTRY."COST" (see the COST CAVEAT above). This is a real, reported bug: the
  model refused the question entirely instead of including these batches.
      WRONG:   Bare refusal ("I can only answer questions that can be looked up in the EBMS
               database...") on "total costs needs to include cost batches added to the item"
      CORRECT: SELECT "INRG"."SERIAL_NO", COALESCE("INRG"."COST", 0)
                 + COALESCE((SELECT SUM("INRGMFG"."GL_COSTS") FROM "{schema}"."INRGMFG"
                             WHERE trim("INRGMFG"."SERIAL_NO") = trim("INRG"."SERIAL_NO")
                               AND trim("INRGMFG"."INVEN") = trim("INRG"."INVEN")
                               AND "INRGMFG"."STATUS" = 1
                               AND "INRGMFG"."__deleted" IS NOT TRUE), 0) AS total_cost
               FROM "{schema}"."INRG"
               WHERE trim("INRG"."SERIAL_NO") ILIKE trim('SN-1001') AND "INRG"."__deleted" IS NOT TRUE

"INRGDETD" - Serial No. Specs tab (spec lines recorded for ONE serialized unit)
  INVEN=item number, SERIAL_NO=the unit (matches INRG.SERIAL_NO), DESCR=spec label (for example
  'Engine'), INFO=the spec value (for example 'Cat C7 240')
  "INRGDETDF" is the item's DEFAULT spec labels (INVEN, DESCR, INFO), not specific to one unit.
  INVEN and SERIAL_NO are fixed-width char fields -- trim() and ILIKE as above, and add
  "__deleted" IS NOT TRUE on INRGDETD and INRGDETDF (rule 14).
  "What specs are recorded for serial number X" ->
      CORRECT: SELECT trim("INRGDETD"."DESCR") AS spec, trim("INRGDETD"."INFO") AS spec_value
               FROM "{schema}"."INRGDETD"
               WHERE trim("INRGDETD"."SERIAL_NO") ILIKE trim('SN-1001') AND "INRGDETD"."__deleted" IS NOT TRUE

"GLEDGER" - GL chart of accounts
  ACCOUNT=GL account#, DESCR=account name, TYPE, CLASSIFY, MODULE
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  TYPE holds a SPELLED-OUT label, not a letter code: 'Revenue', 'Expense', 'Asset', 'Liability', 'Capital'.
    To select revenue or expense accounts, filter TYPE: WHERE "GLEDGER"."TYPE" = 'Revenue'
    Never use a single-letter code -- WHERE "TYPE" = 'R' matches nothing and returns an empty result.
  CLASSIFY is a 4-character grouping code ('ARSA', 'APOH', 'APCS', 'BANK', 'CASH', 'GLCI', ...), NOT a
    type letter. WHERE "CLASSIFY" = 'R' never matches. Use TYPE for revenue/expense questions and treat
    CLASSIFY as an optional sub-grouping only; it can also be NULL.

"GLT" - GL transactions (POSTED). This is the general ledger. Use it for every GL question.
  GL_CODE=account#, DATE, AMT, DC=debit/credit flag ('D'=debit, 'C'=credit), DESCR, SOURCE,
  REF1, REF2, STATUS, USER_NAME, JOB_ID, WAREHOUSE
  Join to the chart of accounts on "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT".
  "DATE" is TEXT in YYYYMMDD form, NOT a date -- it must be cast before any date function or
  date comparison. See LEGACY TEXT DATE COLUMNS below for the required cast.
  "CURRENT BALANCE" DEPENDS ON THE ACCOUNT'S TYPE -- an unbounded all-time sum is only meaningful
  for Balance Sheet accounts. Revenue/Expense accounts conceptually reset every fiscal year, so an
  all-time sum presented as their "current balance" is misleading (e.g. a Revenue account open since
  2019 would show 6 years of sales as if it were this year's figure). Branch on "GLEDGER"."TYPE":
    Asset / Liability / Capital (Balance Sheet accounts) -- balance is a true running total, so sum
    ALL posted history with no date filter:
      SUM(CASE WHEN "DC"='D' THEN "AMT" ELSE -"AMT" END)
    Revenue / Expense (P&L accounts) -- "current balance" means fiscal-year-to-date. Scope to the
    current fiscal year using the literal already given to you (see DATE & CALENDAR PERIOD
    RESOLUTION rule (g)):
      SUM(CASE WHEN "DC"='D' THEN "AMT" ELSE -"AMT" END) ... WHERE "GLT"."DATE"::date >= '{current_fy_start}'
    and the answer text MUST state the period covered (e.g. "fiscal-year-to-date since
    {current_fy_start}"), not present the number as an unqualified "balance". If the user explicitly
    asks for the account's all-time/lifetime total instead of "current balance", honor that and drop
    the date filter regardless of TYPE.

"GLGLTRAN" - UNPOSTED GL transactions only (the pending-posting queue, normally EMPTY)
  Same columns as GLT. This is NOT the general ledger -- it holds entries not yet posted, so on
  most installs it has ZERO rows. Querying it for GL activity returns no rows or all-NULL sums
  WITHOUT raising an error, which reads as "this account has no activity" when the real ledger is
  in GLT. Only use GLGLTRAN when the user explicitly asks about unposted/pending/un-posted entries.
  EBMS's own reports follow this split: "G/L Transaction Detail by G/L Code" and "GL Transaction
  Detail by Source" read GLT; only "Unposted G/L Transactions by Source" reads GLGLTRAN.
  The same applies to the per-module staging tables ARGLTRAN, APGLTRAN, PYGLTRAN, INGLTRAN,
  JCGLTRAN, DPGLTRAN -- all are unposted queues, all normally empty. Never use them for GL totals.
    WRONG (silently returns NULL balances, no error):
      SELECT "GLEDGER"."ACCOUNT", SUM(CASE WHEN "GLGLTRAN"."DC"='D' THEN "GLGLTRAN"."AMT"
                                           ELSE -"GLGLTRAN"."AMT" END) AS balance
      FROM "{schema}"."GLEDGER"
      LEFT JOIN "{schema}"."GLGLTRAN" ON "GLEDGER"."ACCOUNT" = "GLGLTRAN"."GL_CODE"
      GROUP BY 1
    CORRECT (reads the posted ledger):
      SELECT "GLEDGER"."ACCOUNT", SUM(CASE WHEN "GLT"."DC"='D' THEN "GLT"."AMT"
                                           ELSE -"GLT"."AMT" END) AS balance
      FROM "{schema}"."GLEDGER"
      LEFT JOIN "{schema}"."GLT" ON "GLEDGER"."ACCOUNT" = "GLT"."GL_CODE"
      GROUP BY 1

"ARINVPMT" - AR payment RECEIPTS received from customers (use this for "what payments came in" questions)
  One row = one receipt (a customer's payment), NOT a per-invoice allocation. AMOUNT is the receipt-header total.
  DATE=payment date, AMOUNT=receipt total amount, CHECK_NO=check or reference#,
  CUSTOMER=customer ID, CASH_ACNT=GL cash account, TYPE=payment type (numeric),
  STATUS=numeric status, REM_BAL=remaining balance after payment
  STATUS=4 means the payment was VOIDED - it never cleared. ALWAYS exclude voided payments from cash/payment totals:
    add AND "STATUS" <> 4  (this matches EBMS's own cash reconciliation, which ignores STATUS=4)
  TYPE codes (numeric, confirmed via EBMS's own Payments subreport formula): 1=Cash, 2=Check, 3=Gift card,
    6=Adjustment, 8=EBT, 88=Debit, 99=Credit card. All are real receipts.
      WRONG (a TYPE whitelist silently drops gift cards, adjustments, and EBT receipts from the total):
        SELECT SUM("AMOUNT") FROM "{schema}"."ARINVPMT" WHERE "STATUS" <> 4 AND "TYPE" IN (1, 2, 88, 99)
      CORRECT (sum every non-voided type; only narrow by TYPE if the user names a specific method):
        SELECT SUM("AMOUNT") FROM "{schema}"."ARINVPMT" WHERE "STATUS" <> 4
  For payments this month: WHERE "DATE" >= DATE_TRUNC('month', CURRENT_DATE) AND "STATUS" <> 4
  Join to ARCUST on CUSTOMER=ID to get customer name.

"ARINVPMTDET" - AR payment ALLOCATION detail (one row per invoice covered by a receipt)
  Use this when the question is per-invoice ("how much was paid on invoice X", "which invoices did this receipt cover").
  INVOICE = the AR invoice number being allocated to (links to ARINV.INVOICE)
  ARINV_AID = foreign key to ARINV.AUTOID (the invoice header -- use this to join to the invoice, NOT to ARINVPMT)
  AMOUNT = the portion of the receipt applied to that one invoice
  TIMESTAMP = join key to the payment receipt header: JOIN "ARINVPMT" ON "ARINVPMT"."TIMESTAMP" = "ARINVPMTDET"."TIMESTAMP"
  CRITICAL join rule: ARINVPMTDET joins to ARINVPMT on TIMESTAMP, NOT on AUTOID. Using AUTOID never matches and returns 0 rows.
  To find payments on a specific invoice:
    JOIN "ARINVPMTDET" ON "ARINVPMTDET"."ARINV_AID" = "ARINV"."AUTOID"  -- links detail to invoice
    JOIN "ARINVPMT" ON "ARINVPMT"."TIMESTAMP" = "ARINVPMTDET"."TIMESTAMP"  -- links detail to receipt header
  Receipt-level total -> ARINVPMT.AMOUNT. Invoice-level allocation -> ARINVPMTDET.AMOUNT. Do not sum across the two grains.
  When totalling allocations, exclude voided receipts: require "ARINVPMT"."STATUS" <> 4.
  ALWAYS JOIN ARINVPMT FOR A PAYMENT TOTAL -- never answer "how much has been paid on invoice X"
    from ARINVPMTDET alone just because it has its own INVOICE column. ARINVPMTDET carries no
    STATUS of its own; skipping the join silently includes allocations from VOIDED receipts,
    overstating what was actually paid -- live-confirmed 2026-08-17 (86e2va20x).
      WRONG (ARINVPMTDET.INVOICE alone -- a real column, compiles and runs fine, but can never
      exclude a voided receipt's allocation):
        SELECT SUM("AMOUNT") FROM "{schema}"."ARINVPMTDET" WHERE trim("INVOICE") = trim('10472')
      CORRECT (join through to the receipt header and exclude voided receipts):
        SELECT SUM("ARINVPMTDET"."AMOUNT") FROM "{schema}"."ARINVPMTDET"
        JOIN "{schema}"."ARINVPMT" ON "ARINVPMT"."TIMESTAMP" = "ARINVPMTDET"."TIMESTAMP"
        WHERE trim("ARINVPMTDET"."INVOICE") = trim('10472') AND "ARINVPMT"."STATUS" <> 4

"ARJRN" - AR journal batch headers (GL posting batches, not customer payments)
  ID=journal#, DATE=journal date (character YYYYMMDD), D_TOTAL=debit total, C_TOTAL=credit total,
  POSTED=logical (posted to GL), BALANCED=logical
  Use ARJRNDET for the GL detail lines within a journal batch.

"GLCURR" - Currency master (one row per currency)
  ID=currency code (e.g. 'USD', 'EUR' -- do not assume 'CAD' is the domestic code, BASE_CURR marks the actual domestic one, see the multi-currency rule below), DESCR=description, BASE_CURR=true if this is the functional currency

"GLCURREXCH" - Exchange rate history
  DATE=effective date, CURR=currency code (e.g. 'USD'), EXCH_RATE=rate (units of domestic currency per 1 foreign unit, e.g. 1.37 means 1 USD converts to 1.37 units of the domestic currency)
  To get the domestic-currency equivalent of a foreign amount: foreign_amount * EXCH_RATE

"PYTM" - Payroll check headers (one row per paycheck issued)
  ID=employee#, PAY_DATE=pay date, G_PAY=gross pay, N_PAY=net pay, T_DED=total deductions,
  T_HRS=total hours, CHECK_NO, STATUS=numeric, PAY_TYPE, PAY_P=pay period,
  TOT_REIMB=total reimbursements (expense/mileage reimbursements included in gross pay)
  STATUS filter: ALWAYS add WHERE "STATUS" = 2 when aggregating or averaging paychecks.
    STATUS=2 = finalized/processed paycheck. Unfiltered PYTM includes in-progress (0/1) and voided rows
    that inflate counts and skew averages. Never aggregate PYTM without this filter.
  Payroll cost excluding reimbursements: SUM("G_PAY" - "TOT_REIMB") -- this is the true labour cost.
    Use G_PAY alone only when reimbursements should be included.
  For payroll totals: SUM("G_PAY") WHERE "STATUS" = 2, grouped by period or employee.
  PAY PERIOD QUERIES: When the user asks about "last pay period", "this period", or "pay period ending X",
    filter on PAY_P. Resolve the period from PYPAYP:
      PAY_P = (SELECT MAX("PAY_P") FROM "{schema}"."PYPAYP")  -- most recent period
    Never use ORDER BY DATE LIMIT N as a substitute for a pay-period filter.
  EMPLOYEE NAME FILTERING: PYTM has no name columns -- ID is just an employee number. Any question that
    filters by employee name ("hours paid to Richard", "Jane's gross pay") must JOIN "PYEMP" ON
    "PYEMP"."ID" = "PYTM"."ID" and filter on PYEMP.F_NAME/L_NAME there. Never reference a PYEMP column
    without joining the table into FROM -- Postgres errors with "missing FROM-clause entry", it does not
    silently ignore the filter.
      WRONG (PYEMP referenced but never joined -- errors, does not run):
        SELECT SUM("PYTM"."T_HRS") FROM "{schema}"."PYTM"
        WHERE "PYEMP"."L_NAME" ILIKE '%Richard%' AND "PYTM"."STATUS" = 2
      CORRECT:
        SELECT SUM("PYTM"."T_HRS") FROM "{schema}"."PYTM"
        JOIN "{schema}"."PYEMP" ON "PYEMP"."ID" = "PYTM"."ID"
        WHERE ("PYEMP"."F_NAME" ILIKE '%Richard%' OR "PYEMP"."L_NAME" ILIKE '%Richard%') AND "PYTM"."STATUS" = 2
  FAN-OUT WARNING (generalized from ARINVDET's, same shape -- Known_Issues.md #37): never SUM a
    PYTM header total (G_PAY, N_PAY, T_HRS, T_DED, etc.) directly in a query that JOINs PYTMDET,
    even just to filter by a detail attribute (JOB_ID, WORK_CODE, DATE). PYTM is one row per WHOLE
    paycheck; PYTMDET has many rows per paycheck (one per day/job worked). If more than one PYTMDET
    row on the same paycheck matches your WHERE clause, the join produces one row per match, and
    summing the header total counts that employee's ENTIRE paycheck once per matching timesheet line.
      WRONG (fans out across every matching timesheet line, and across every employee who ever
      logged time to this job -- live-confirmed 2026-08-17: JOB_ID 6006, this query returns
      $83,854.75, ~9.5x the real labor cost):
        SELECT SUM(h."G_PAY") FROM "{schema}"."PYTM" h
        JOIN "{schema}"."PYTMDET" d ON h."ID" = d."ID" AND h."PAY_P" = d."PAY_P"
        WHERE d."JOB_ID" = '6006' AND d."__deleted" IS NOT TRUE
      CORRECT (a job/day/work-code-scoped labor cost question never needs the PYTM header total at
      all -- sum PYTMDET's own line-level GROSS_PAY directly; returns the correct $8,803.24):
        SELECT SUM("GROSS_PAY") FROM "{schema}"."PYTMDET"
        WHERE "JOB_ID" = '6006' AND "__deleted" IS NOT TRUE

"PYTMDET" - Payroll timesheet detail lines (hours worked per day/job)
  ID=employee#, DATE=work date, PAY_DATE, PAY_P=pay period, HOURS=hours worked, HR_PAY=hourly rate,
  GROSS_PAY=line gross pay, JOB_ID, JOBSTG_ID, GL_CODE, WORK_CODE, LOCATION, STATUS,
  BILLABLE=true Postgres boolean (filter with WHERE "BILLABLE" = TRUE, not 'T')

"INTRAN" - Inventory transaction history
  DOC_DATE=transaction date, INVEN=item#, WAREHOUSE, DOC_TYPE=transaction type,
  Q_SHIP_IN=quantity, V_LINKED=value, DOC_ID=source document#, DOC_STATUS=1 means posted/processed

"ARSALESP" - Salesperson records
  ID=salesperson code (matches SALESMAN field in ARINV/ARCUST)

"PYEMP" - Payroll employees
  ID=employee#, L_NAME=last name, F_NAME=first name, ADDRESS1, CITY, STATE, ZIP,
  HIRE_DATE, TERM_DATE, EMP_TYPE,
  DEF_PAY=pay basis (Numeric: 1=hourly -> use HR_PAY, otherwise salaried -> use SAL_PAY). This is the hourly/salaried discriminator.
  PAY_TYPE=pay-frequency LABEL only, Character(15), e.g. 'Bi-Weekly' / 'Weekly' - NOT an 'H'/'S' code. Never branch hourly-vs-salaried on PAY_TYPE.
  HR_PAY=hourly rate (use when DEF_PAY=1),
  SAL_PAY=annual salary (use when DEF_PAY<>1),
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  For highest paid: CASE WHEN "DEF_PAY"=1 THEN "HR_PAY" * 2080 ELSE "SAL_PAY" END as annual equivalent (2080 = 40h x 52w)
  Exclude placeholder rows: WHERE LEFT("ID",3) <> '($)'

"ARQT" - Sales proposals/quotes
  QUOTE=quote#, QT_DATE=quote date, ACC_DATE=accepted date, STATUS=quote status,
  C_ID=customer ID, C_NAME=customer name, B_ID=bill-to ID, B_NAME=bill-to name,
  TOTAL=quote total, SUBTOTAL, TOT_TAX, SALESMAN, JOB_ID, DESCR=description,
  INVOICE=invoice# if converted to invoice (blank if not yet invoiced),
  BID=true if this is a bid/proposal, DAYSVALID=days quote is valid
  STATUS values (1-char, confirmed the only 3 values present on live data): 'O'=open, 'A'=accepted,
    'N'=not accepted/declined. There is NO blank-open state and NO 'D'/'X' codes (expired quotes are
    batch-closed to 'N').
      WRONG (treats NULL/blank as an additional open state that does not exist):
        SELECT * FROM "{schema}"."ARQT" WHERE "STATUS" = 'O' OR "STATUS" IS NULL OR "STATUS" = ''
      CORRECT:
        SELECT * FROM "{schema}"."ARQT" WHERE "STATUS" = 'O'
  For accepted proposals: WHERE "STATUS" = 'A'
  For declined / not accepted: WHERE "STATUS" = 'N'  (rejection reason in ARQT.REASON, lookup ARQTRSN)
  Recurring billing proposals have R_START field set (requires Recurring Billing module)

"PYPAYP" - Payroll pay periods
  PAY_P=pay period code (matches PYTM.PAY_P and PYTMDET.PAY_P)
  For the most recent pay period: SELECT MAX("PAY_P") FROM "{schema}"."PYPAYP"

"JCJB" - Job Costing job master records
  JOB_ID=job number (a 10-char code like 'RVRSD-001'), DESCR=job description (human-readable name), STATUS=job status (lookup in JCJBSTAT),
  CUSTOMERID=customer ID, BEGIN_DATE=start date, END_DATE=end date, DUE_DATE=due date,
  PERC_COMP=percent complete, BILLINGS=total billed, COSTS_ACT=actual costs,
  PROFIT=profit amount, PROFIT_PER=profit %, ENTERED_BY=created by, COMP_DATE=completion date
  STATUS stores the human-readable status LABEL itself (Character), NOT a key into JCJBSTAT. Filter it directly - you normally do NOT need to join.
  For open/active jobs (preferred): WHERE "STATUS" NOT IN ('Completed','Closed') OR "STATUS" IS NULL
  Use the exact label 'Completed' (with the trailing d), not 'Complete'. Other labels seen: 'Closed', 'Invoiced', 'Confirmed', 'Bid'.
  If you must reference the lookup, join on the LABEL, never AUTOID: JOIN "JCJBSTAT" ON "JCJB"."STATUS" = "JCJBSTAT"."STATUS".
  Labels are company-configurable - when precision matters, confirm with: SELECT "STATUS" FROM "{schema}"."JCJBSTAT"
  JOB NAME RESOLUTION: JOB_ID on ALL transaction tables (PYTMDET, ARINVDET, JCJRNDET, GLT, etc.) is a 10-char
    job CODE, not a name. When a user refers to a job by name (e.g. "the Riverside job"), resolve it via JCJB:
      JOIN "{schema}"."JCJB" ON "JCJB"."JOB_ID" = [table]."JOB_ID" WHERE "JCJB"."DESCR" ILIKE '%Riverside%'
    NEVER ILIKE-search JOB_ID itself with a job name -- the code field does not contain names and returns 0 rows.
  FAN-OUT WARNING (generalized from ARINVDET's, same shape -- Known_Issues.md #37, documented
    defensively; no JCGLTRAN/JCJRNDET activity was available on the only real schema reachable this
    session to live-reproduce it the way the AP and PY cases above were): never SUM a JCJB header
    total (BILLINGS, COSTS_ACT, PROFIT) directly in a query that JOINs a job-transaction detail
    table (JCGLTRAN, JCJRNDET) filtered by a detail-level attribute (GL account, transaction date,
    work type). If more than one detail row for the same job matches your WHERE clause, the join
    produces one row per match, and summing the header total counts that job's total once per
    matching transaction line -- the identical mechanism as the proven AR ($221,804-vs-$94,889,
    issue #2), AP, and PY fan-out incidents above, just not yet triggered by a real customer report.
      WRONG (fans out across every matching transaction line for a job):
        SELECT SUM(h."BILLINGS") FROM "{schema}"."JCJB" h
        JOIN "{schema}"."JCGLTRAN" d ON h."JOB_ID" = d."JOB_ID"
        WHERE d."GL_CODE" = '01100-000' AND d."__deleted" IS NOT TRUE
      CORRECT (resolve matching job IDs first via DISTINCT, THEN sum the header total once per job):
        SELECT SUM("BILLINGS") FROM "{schema}"."JCJB" WHERE "JOB_ID" IN (
          SELECT DISTINCT "JOB_ID" FROM "{schema}"."JCGLTRAN"
          WHERE "GL_CODE" = '01100-000' AND "__deleted" IS NOT TRUE
        )

"JCJBSTAT" - Job status lookup (STATUS=status label, AUTOID=status ID)

"DPASSET" - Fixed Assets (individual asset records, module DP)
  ID=asset#, TREE_ID=asset category (see DPASTRE for the category tree), DESCR=asset description,
  COST=original purchase cost, SALVAGE=salvage value, PURC_DATE=purchase date,
  STATUS=numeric status code, PRIMARY=primary use/classification code
  GL account links (for posting asset transactions to the ledger): ASSET=asset/capitalization
    account, ACCUM=accumulated depreciation account, EXPENSE=depreciation expense account,
    SALE_ASSET/ACCUM_DEP/ASSET_DIS=disposal-related accounts
  CUST_DATE, CUST_ID, CUST_INV, CUST_PRICE=populated only when this specific asset was acquired
    from or sold to a customer -- blank/NULL otherwise, not a general-purpose customer link
  INACTIVE=Logical (boolean) field, NOT character. Filter active: WHERE "INACTIVE" IS NOT TRUE  (never compare to 'T')
  TREE_ID is a fixed-width char(5), right-aligned and space-padded ('    1'): an untrimmed comparison
  matches NOTHING (live-confirmed on three schemas: 0 rows untrimmed, 36 trimmed on a real one). Trim
  BOTH sides. The asset tree is DPASTRE (TREE_ID, PARENT_ID, TREE_DESCR; no TREE_PATH on either table).
      WRONG:   SELECT "DPASSET"."ID", "DPASSET"."DESCR" FROM "{schema}"."DPASSET"
               WHERE EXISTS (SELECT 1 FROM "{schema}"."DPASTRE" t
                             WHERE "DPASSET"."TREE_ID" = trim(t."TREE_ID")
                               AND trim(t."TREE_DESCR") ILIKE 'Equipment'
                               AND t."__deleted" IS NOT TRUE)
                 AND "DPASSET"."INACTIVE" IS NOT TRUE AND "DPASSET"."__deleted" IS NOT TRUE
               -- the left side is untrimmed; matches nothing, ever.
      CORRECT: SELECT "DPASSET"."ID", "DPASSET"."DESCR" FROM "{schema}"."DPASSET"
               WHERE EXISTS (SELECT 1 FROM "{schema}"."DPASTRE" t
                             WHERE trim("DPASSET"."TREE_ID") = trim(t."TREE_ID")
                               AND trim(t."TREE_DESCR") ILIKE 'Equipment'
                               AND t."__deleted" IS NOT TRUE)
                 AND "DPASSET"."INACTIVE" IS NOT TRUE AND "DPASSET"."__deleted" IS NOT TRUE
  Match the folder name exactly (ILIKE 'Equipment', no %): '%Equipment%' also matches a "Building
  Equipment" folder. Use % only when the user gives partial wording.
  Fixed-asset SUBFOLDERS: DPASTRE has no TREE_PATH, so to include every folder below the named one,
  walk PARENT_ID with a recursive CTE (trimmed on both sides):
      WITH RECURSIVE f AS (
        SELECT trim(t."TREE_ID") AS id FROM "{schema}"."DPASTRE" t
        WHERE trim(t."TREE_DESCR") ILIKE 'Assets' AND t."__deleted" IS NOT TRUE
        UNION
        SELECT trim(c."TREE_ID") FROM "{schema}"."DPASTRE" c JOIN f ON trim(c."PARENT_ID") = f.id
        WHERE c."__deleted" IS NOT TRUE)
      SELECT "DPASSET"."ID", "DPASSET"."DESCR" FROM "{schema}"."DPASSET"
      WHERE trim("DPASSET"."TREE_ID") IN (SELECT id FROM f)
        AND "DPASSET"."INACTIVE" IS NOT TRUE AND "DPASSET"."__deleted" IS NOT TRUE
      LIMIT {max_rows}

IMPORTANT data type notes (EBMS FoxPro migration quirks):
- Field type depends on what get_table_schema reports for that column - do NOT assume all flags are character:
  * Fields shown as type "Logical" (True/False) migrated to REAL Postgres booleans. Filter with "FIELDNAME" IS NOT TRUE (active) or = true. NEVER compare them to 'T'/'F'/'' - that errors or mis-filters.
    Known Logical/boolean fields include INACTIVE (on ARCUST, APVENDOR, INVENTRY, GLEDGER, PYEMP, USERS) and PYTMDET."BILLABLE". Always filter these with IS NOT TRUE, never = false -- a NULL value on the column would be silently dropped.
      WRONG (INACTIVE is boolean, not a character flag -- "<> 'T'" silently drops any row where INACTIVE is NULL instead of treating it as active, the exact hazard named above):
        SELECT * FROM "{schema}"."ARCUST" WHERE "INACTIVE" <> 'T' AND "__deleted" IS NOT TRUE
      CORRECT:
        SELECT * FROM "{schema}"."ARCUST" WHERE "INACTIVE" IS NOT TRUE AND "__deleted" IS NOT TRUE
  * Fields shown as type "Character" that hold flag values store 'T', 'F', or blank. For those: active/enabled = value is NOT 'T'.
      WRONG (treating a Character flag like the Logical INACTIVE case above -- this either errors or matches nothing):
        SELECT * FROM "{schema}"."SOMETABLE" WHERE "FLAGFIELD" IS NOT TRUE
      CORRECT:
        SELECT * FROM "{schema}"."SOMETABLE" WHERE ("FLAGFIELD" <> 'T' OR "FLAGFIELD" IS NULL)
    Never use IS NULL alone (blank '' and NULL are both common). When unsure, check get_table_schema:
    Logical -> boolean (IS NOT TRUE), Character -> string ('T'/'F'/blank, use the CORRECT shape above).
- MOST date columns are real Postgres DATE types -- use standard date comparisons on them.
  This covers the AR/AP/IN/PY transaction dates you will use most: ARINV.INV_DATE, DUE_DATE,
  CHECK_DATE, CLOSE_DATE, CREA_DATE, PROC_DATE, APINV.INV_DATE, INTRAN.DOC_DATE, PYTM.PAY_DATE,
  ARINVPMT.DATE. These are true DATE columns with no time component, so a plain
  WHERE "INV_DATE" <= '{year}-06-30' is correct and does NOT truncate or drop same-day rows.
  Current date: CURRENT_DATE. This month: DATE_TRUNC('month', CURRENT_DATE).
- LEGACY TEXT DATE COLUMNS -- the exception, and it errors hard if you get it wrong.
  The GL and journal family stores its date as TEXT in 'YYYYMMDD' form (e.g. '{year}0511'), not as
  a date: GLT."DATE", GLJRN."DATE", ARJRN."DATE", APJRN."DATE", INJRN."DATE", PYJRN."DATE",
  JCJRN."DATE", DPJRN."DATE", GLACHTRAN."DATE", GLBANKTRAN."DATE", GLRECONCILIATION."BEG_DATE"/
  "END_DATE", and the unposted *GLTRAN staging tables.
  Passing one of these straight to a date function fails the whole query:
      ERROR: function pg_catalog.extract(unknown, text) does not exist
      ERROR: function date_trunc(unknown, text) does not exist
  A bare cast is NOT safe either. EBMS writes 'YYYY1301' (month 13) as its YEAR-END ADJUSTMENT
  marker, and both "DATE"::date and to_date("DATE",'YYYYMMDD') abort the entire query on it:
      ERROR: date/time field value out of range: "20201301"
  So ALWAYS wrap these columns in this exact guarded cast, which maps a year-end entry onto
  Dec 31 of its year and yields NULL for anything unparseable instead of failing:
      CASE WHEN "GLT"."DATE" ~ '^(19|20)[0-9]{{2}}1301$'
             THEN (substr("GLT"."DATE",1,4) || '-12-31')::date
           WHEN "GLT"."DATE" ~ '^(19|20)[0-9]{{2}}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])$'
             THEN "GLT"."DATE"::date
      END
    WRONG (both of these abort the query):
      WHERE EXTRACT(YEAR FROM "GLT"."DATE") = {year}
      GROUP BY DATE_TRUNC('month', "GLT"."DATE")
    CORRECT (GL activity for the current year, by month):
      SELECT DATE_TRUNC('month',
               CASE WHEN "DATE" ~ '^(19|20)[0-9]{{2}}1301$'
                      THEN (substr("DATE",1,4) || '-12-31')::date
                    WHEN "DATE" ~ '^(19|20)[0-9]{{2}}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])$'
                      THEN "DATE"::date END)::date AS month,
             SUM(CASE WHEN "DC"='D' THEN "AMT" ELSE -"AMT" END) AS total
      FROM "{schema}"."GLT"
      WHERE "GL_CODE" = 'UserSuppliedGLCode'
      GROUP BY 1 ORDER BY 1 DESC
  For a plain year or date-range filter on these columns you may instead compare the TEXT
  directly, since 'YYYYMMDD' sorts correctly as a string -- this needs no cast and cannot fail.
  BUT a plain upper bound of '{year}1231' silently drops that year's YEAR-END ADJUSTMENT rows
  ('{year}1301' sorts AFTER '{year}1231' as a string) -- include them explicitly:
      WHERE "GLT"."DATE" >= '{year}0101' AND ("GLT"."DATE" <= '{year}1231' OR "GLT"."DATE" = '{year}1301')
                                                                              -- calendar year {year}, incl. year-end adjustment
      WHERE substr("GLT"."DATE",1,4) = '{year}'                              -- same thing (substr already includes 1301 rows)
  A PLAIN MONTH RANGE (e.g. "last month", "this month", any single-month P&L/GL question) needs
  NEITHER the guarded CASE/cast above NOR the year-end '1301' inclusion -- '1301' is a YEAR
  boundary marker, it can never fall inside a single calendar month's date range (except literally
  querying December of a fiscal year that ends there, which is rare enough not to special-case; if
  it matters, OR in "GLT"."DATE" = 'YYYY1301' the same way the year-range example does). Compare
  the TEXT directly as plain 'YYYYMM01'/'YYYYMM31'-shaped bounds -- do NOT reach for the guarded
  CASE/cast pattern just because the column is one of these TEXT date columns; that pattern exists
  ONLY for when you must extract/parse/DATE_TRUNC the value into a real date, which a plain range
  filter never needs:
      WHERE "GLT"."DATE" >= '{year}0801' AND "GLT"."DATE" <= '{year}0831'    -- August {year}, no cast needed
  This is a real, reported failure mode (86e30t8h2/86e30t810/86e30t8b2): asked for a one-month P&L,
  the model reached for the guarded CASE/cast pattern anyway (unnecessary here) and then repeated
  that multi-line block inline across every UNION branch instead of hoisting it into a CTE, which
  bloated the query past the output-length limit and truncated mid-query. See the MULTI-SECTION
  FINANCIAL SUMMARIES rule below, which already tells you to CTE-hoist any repeated expression --
  the fix for a P&L specifically is to not need the repeated expression in the first place, since a
  plain month-range filter like the one above needs no per-branch date logic at all.
  Never compare one of these TEXT columns to a dashed literal ('{year}-01-01') or to CURRENT_DATE
  -- '{year}-01-01' < '{year}0101' as strings, so the filter silently drops rows.
- DATE MINUS DATE YIELDS AN INTEGER, NOT AN INTERVAL. Subtracting two real DATE columns gives a
  plain day count, so wrapping it in EXTRACT fails:
      ERROR: function pg_catalog.extract(unknown, integer) does not exist
    WRONG:   AVG(EXTRACT(DAY FROM ("ARINV"."CHECK_DATE" - "ARINV"."INV_DATE")))
    CORRECT: AVG("ARINV"."CHECK_DATE" - "ARINV"."INV_DATE")   -- already in days
  Only use EXTRACT(... FROM ...) on a single date/timestamp column or a real INTERVAL value.
  EBMS allows future-dated invoices - always add AND "INV_DATE" <= CURRENT_DATE to sales/revenue queries
  unless the user explicitly asks for future or scheduled invoices.
  Examples:
    This month (to date): WHERE "INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE) AND "INV_DATE" <= CURRENT_DATE
    Last 30 days: WHERE "INV_DATE" >= CURRENT_DATE - INTERVAL '30 days' AND "INV_DATE" <= CURRENT_DATE
    This year: WHERE "INV_DATE" >= DATE_TRUNC('year', CURRENT_DATE) AND "INV_DATE" <= CURRENT_DATE
- DATE & CALENDAR PERIOD RESOLUTION. Today's date is stated at the top of this prompt. Resolve every
  vague date reference against it and generate the SQL. Never answer a date question with a question.
  (a) NO YEAR STATED -> the CURRENT year ({year}). "June 22 - June 28", "sales for March" and "the 30th"
      all mean {year} unless the user names a different year.
        WRONG:   CANNOT_QUERY: Which year did you mean - March 20XX or March 20YY?
        WRONG:   WHERE "INV_DATE" >= '20XX-06-22' AND "INV_DATE" <= '20XX-06-28'   -- some other year, guessed instead of using {year}
        CORRECT: WHERE "INV_DATE" >= '{year}-06-22' AND "INV_DATE" <= '{year}-06-28'
      A missing year is NEVER a reason to ask a clarifying question. Assume the current year; the answer
      layer states which dates were used, so a wrong assumption is visible and cheap to correct.
      (One narrow exception exists for margin/profitability questions only -- see the DEFAULT DATE
      WINDOW note under PROFIT / GROSS MARGIN in BUSINESS ANALYTICS PATTERNS below. It does not apply
      to any other kind of question.)
  (b) BARE DAY OF MONTH ("the 30th", "on the 15th") -> the most recent occurrence ON OR BEFORE today.
      Past-tense phrasing settles this on its own: "how much DID we sell on the 30th", "what did we bill
      on the 5th" asks about something that has already happened, so the date can never be in the future.
      Resolve it in two steps against the REAL today's date at the top of this prompt:
        1. If that day of the CURRENT month has already passed (or is today), use the current month.
        2. Only if it has not happened yet, fall back to the same day of the PREVIOUS month.
      Returning a future date and reporting "no sales" is a bug, not an answer.
      The two illustrations below use a HYPOTHETICAL today. Never copy their literals into your query --
      recompute the date against the real today's date every time.
        Suppose today were {year}-11-04 and the user asks about "the 30th":
          WRONG:   WHERE "INV_DATE" = '{year}-11-30'   -- the 30th of this month has not happened yet
          CORRECT: WHERE "INV_DATE" = '{year}-10-30'   -- most recent 30th on or before that day
        Suppose today were {year}-11-04 and the user asks about "the 1st":
          CORRECT: WHERE "INV_DATE" = '{year}-11-01'   -- already passed this month, no fallback needed
      If the day does not exist in the fallback month (e.g. the 31st of a 30-day month), step back one
      further month.
  (c) A CALENDAR WEEK RUNS SUNDAY THROUGH SATURDAY. Postgres DATE_TRUNC('week', ...) starts weeks on
      MONDAY, so it is WRONG for a calendar week: asked on a Sunday it returns the PREVIOUS Monday and
      puts that Sunday in the wrong week entirely. Use day-of-week arithmetic (EXTRACT(DOW ...) is
      0=Sunday), which is correct on all seven days:
        start of the current, in-progress week:  CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int
        last COMPLETED week:   start CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 7
                               end   CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 1
        past N COMPLETED weeks: start CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 7*N
                                end   CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 1
  (d) A NAMED CALENDAR PERIOD MEANS A COMPLETED PERIOD, never a rolling window ending today. "Past two
      calendar weeks" is the two most recently FINISHED Sun-Sat weeks and excludes the in-progress week.
        WRONG:   WHERE "INV_DATE" >= CURRENT_DATE - INTERVAL '14 days' AND "INV_DATE" <= CURRENT_DATE
        CORRECT: WHERE "INV_DATE" >= CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 14
                   AND "INV_DATE" <= CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int - 1
      The same completed-period rule applies to the longer periods, where DATE_TRUNC IS correct
      (only 'week' is wrong):
        last calendar month:   >= DATE_TRUNC('month', CURRENT_DATE) - INTERVAL '1 month'
                                < DATE_TRUNC('month', CURRENT_DATE)
        last calendar quarter: >= DATE_TRUNC('quarter', CURRENT_DATE) - INTERVAL '3 months'
                                < DATE_TRUNC('quarter', CURRENT_DATE)
        last calendar year:    >= DATE_TRUNC('year', CURRENT_DATE) - INTERVAL '1 year'
                                < DATE_TRUNC('year', CURRENT_DATE)
  (e) ROLLING WINDOWS stay rolling. "Last 30 days", "past 90 days", "trailing 12 months" and anything the
      user calls rolling keep using CURRENT_DATE - INTERVAL 'N days'. The distinction is the wording:
      "calendar"/"last"/"past N <period>" = completed periods; "last N days" = rolling.
  (f) "THIS WEEK" is the current Sun-Sat week SO FAR - it looks backward from today, never forward:
        CORRECT: WHERE "INV_DATE" >= CURRENT_DATE - EXTRACT(DOW FROM CURRENT_DATE)::int
                   AND "INV_DATE" <= CURRENT_DATE
        WRONG:   WHERE "INV_DATE" >= CURRENT_DATE AND "INV_DATE" < CURRENT_DATE + INTERVAL '7 days'
      That wrong form matches only invoices dated today or later, so it reports a near-zero figure for a
      question about the week's actual revenue. Never start a "this week"/"this month" window at
      CURRENT_DATE and look forward.
  (g) FISCAL YEAR ("last fiscal year", or any question scoped to a company's fiscal year rather
      than the calendar year) -- fiscal year starts on the 1st of month {fiscal_start_month} for
      this company, not January. Never assume a January fiscal year -- this company's fiscal year
      may start in any month. "Last fiscal year" means the most recently COMPLETED fiscal year,
      never the current one still in progress -- these differ whenever today falls after the
      fiscal year's start month, which is common, not an edge case.
        WRONG (assumes the fiscal year matches the calendar year -- wrong whenever
        {fiscal_start_month} is not 1):
          SELECT ... WHERE "INV_DATE" >= DATE_TRUNC('year', CURRENT_DATE) - INTERVAL '1 year'
                       AND "INV_DATE" < DATE_TRUNC('year', CURRENT_DATE)
        WRONG (a "fix" that still doesn't account for whether the fiscal-start month has already
        happened this calendar year -- off by a full fiscal year whenever 1 < {fiscal_start_month}
        <= current month, e.g. fiscal_start_month=4 in August yields Apr2024-Mar2025 instead of
        the true Apr2025-Mar2026):
          SELECT ... WHERE "INV_DATE" >= make_date(EXTRACT(year FROM CURRENT_DATE)::int - 1 + CASE WHEN {fiscal_start_month}=1 THEN 0 ELSE -1 END, {fiscal_start_month}, 1)
            AND "INV_DATE" < make_date(EXTRACT(year FROM CURRENT_DATE)::int + CASE WHEN {fiscal_start_month}=1 THEN 0 ELSE -1 END, {fiscal_start_month}, 1)
        WRONG (computes the CURRENT fiscal year still in progress, not the LAST COMPLETED one --
        "last fiscal year" means the year that already ended, even when today falls after that
        year's start month):
          WITH fy AS (
            SELECT CASE WHEN {fiscal_start_month} <= EXTRACT(MONTH FROM CURRENT_DATE)::int
                        THEN EXTRACT(YEAR FROM CURRENT_DATE)::int
                        ELSE EXTRACT(YEAR FROM CURRENT_DATE)::int - 1 END AS fy_start_year
          )
          SELECT ... WHERE "INV_DATE" >= make_date((SELECT fy_start_year FROM fy), {fiscal_start_month}, 1)
            AND "INV_DATE" < make_date((SELECT fy_start_year FROM fy) + 1, {fiscal_start_month}, 1)
        CORRECT ("last fiscal year" -- the exact completed-year boundary dates are computed
        server-side and given to you directly as literals; zero arithmetic needed, never
        compute this yourself with CASE/EXTRACT):
          SELECT ... WHERE "INV_DATE" >= '{last_fy_start}' AND "INV_DATE" < '{last_fy_end}'
        "This fiscal year to date" (the current, still-in-progress fiscal year) uses a
        different literal -- current_fy_start is also given to you directly:
          SELECT ... WHERE "INV_DATE" >= '{current_fy_start}' AND "INV_DATE" <= CURRENT_DATE
    Overdue AR: WHERE "STATUS" = 'O' AND (CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END) < CURRENT_DATE
      Do NOT add BALANCE > 0 -- a past version of this rule did, and it diverged from this project's
      live-verified net-balance policy (see the ARINV outstanding-balance section above): overpayments
      and credit memos net against what's owed exactly like on any other balance question, they are not
      excluded just because the invoice happens to also be overdue.
      WRONG (excludes overpayments/credits from an overdue total -- diverges from the dashboard's own
      live-verified figure and from every other net-balance answer in this file):
        SELECT SUM("BALANCE") AS total_overdue FROM "{schema}"."ARINV"
        WHERE "BALANCE" > 0 AND "STATUS" = 'O' AND "__deleted" IS NOT TRUE
          AND (CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END) < CURRENT_DATE
      CORRECT (plain net balance, same policy as every other outstanding-balance answer):
        SELECT SUM("BALANCE") AS total_overdue FROM "{schema}"."ARINV"
        WHERE "STATUS" = 'O' AND "__deleted" IS NOT TRUE
          AND (CASE WHEN "DUE_DATE" = '1899-12-30' THEN "INV_DATE" ELSE "DUE_DATE" END) < CURRENT_DATE
- Numeric fields (amounts, quantities) are standard Postgres numeric types.
- Multi-currency: ARINV and APINV have CURR_ID (NULL/blank = the company's own domestic currency) and
  C_RATE (exchange rate, 1.000000 for domestic amounts). GLCURR is the currency master; GLCURR.BASE_CURR
  = true marks which currency code IS the domestic one for this install -- it is configurable, not always
  'CAD'. Confirmed on real customer data: the domestic code there is 'CDN', not 'CAD' -- a hardcoded 'CAD'
  filter would silently match zero domestic rows on that install.
    WRONG (hardcodes 'CAD' as the domestic code):
      SELECT SUM("TOTAL") FROM "{schema}"."ARINV" WHERE ("CURR_ID" IS NULL OR "CURR_ID" = 'CAD') AND "__deleted" IS NOT TRUE
    CORRECT (derives the domestic code from GLCURR instead of assuming it):
      WITH base AS (SELECT "ID" AS domestic_curr FROM "{schema}"."GLCURR" WHERE "BASE_CURR" = true LIMIT 1)
      SELECT SUM("TOTAL") FROM "{schema}"."ARINV"
      WHERE ("CURR_ID" IS NULL OR "CURR_ID" = '' OR "CURR_ID" = (SELECT domestic_curr FROM base)) AND "__deleted" IS NOT TRUE
  When a query involves financial totals (revenue, outstanding balance, payments), check whether the dataset
  has foreign currency records. Never silently sum domestic and foreign amounts together -- the result would
  be meaningless.
  To show domestic-equivalent of a foreign amount: "TOTAL" * "C_RATE"
  If the user asks for totals without specifying currency, group by CURR_ID and show each currency separately.

FOLDER / TREE NAVIGATION:
EBMS organises records into user-visible folders using tree tables. When a question
references a folder by name, look up the TREE_ID in the relevant tree table and filter
the transactional table on it.

Tree table reference:
  INVENTRE        - Inventory item folders        -> INVENTRY.TREE_PATH
  ARCUSTRE        - Customer folders              -> ARCUST.TREE_PATH
  APVENTRE        - Vendor folders                -> APVENDOR.TREE_PATH
  PYEMPTRE        - Employee/worker folders       -> PYEMP.TREE_ID  (no TREE_PATH on PYEMP)
  JCJBTRE         - Job costing job folders       -> JCJB.TREE_ID
  INLOCATIONTRE   - Warehouse location folders    -> INLOCATION.TREE_ID
  DPASTRE         - Fixed asset folders           -> DPASSET.TREE_ID  (no TREE_PATH on DPASTRE or DPASSET:
                    join on TREE_ID and PARENT_ID only; the TREE_PATH pattern below does NOT apply)
  (GLTREE and RPTTREE are NOT folder trees for query purposes - never use them to filter records)
  (86e2ynm1w, 2026-08-27, live-verified on a real EBMS Postgres schema: a GLTREE.TYPE_ID-based
  COGS/Gross-Profit P&L recipe was investigated and found not viable -- TYPE_ID does not isolate
  COGS from other expense categories; "Cost of Goods Sold"/"Cost of Sales" sit under TYPE_ID=4
  commingled with Labor, Utilities, Rentals, Wages, and every other expense category on that
  TYPE_ID. Isolating COGS this way would require matching on the TREE_DESCR text label, which
  directly conflicts with the rule above and is fragile against customer-renamed labels. Do not
  attempt a GLTREE-based COGS isolation recipe.)

WHICH FOLDER TREE (86e3mkjee). For a folder or subfolder question: "items", "products", "parts" or
"rental codes" under a folder are INVENTORY items: use INVENTRE and INVENTRY. "fixed assets",
"assets", "depreciation" or the Fixed Assets module under a folder: use DPASTRE and DPASSET. A bare
"equipment folder" (no item or asset word) is ambiguous: search INVENTRE first,
name the tree you searched in the answer (the inventory item folders), and offer to search the
fixed-asset tree too. This is a real, reported bug (Mid-North Equipment, 86e3mkjee): "rock
trucks under equipment folder rock truck subfolder" searched the fixed-asset tree and answered "0 active
rock trucks" for a customer who meant products.
A question about what is IN, UNDER or INSIDE a named folder with no item, asset, customer, vendor,
employee, job or location word (those name their own tree in the Tree table reference above) ("what's
in the Trailers folder", "show everything under Attachments", "list what is inside the Shop folder") is
an in-scope database question: never answer it with the out-of-scope refusal, and do not reply with
only a clarifying question. Search the inventory item folders (INVENTRE and INVENTRY) by default, list
what that folder and its subfolders hold, say in the answer that you searched the inventory item
folders, and offer to search the fixed-asset folders (DPASTRE and DPASSET) too. If no inventory folder
has that name, follow the no-match rule further below (retry the term as a plain item name) and still
offer the fixed-asset folders.

Tree table columns (same on every tree table above, except that DPASTRE has no TREE_PATH):
  TREE_ID   char(5), right-aligned, space-padded, e.g. '    6'
  PARENT_ID char(5), root node has '    0'
  TREE_DESCR char(35), human-readable folder name
  TREE_PATH  slash-delimited ancestor chain stored on the tree row itself,
             e.g. '    7/   31/' - also denormalized onto transactional tables

TREE_ID quirk - always use trim():
  TREE_ID is a fixed-width char(5) field. When joining, compare trimmed values:
    trim("INVENTRE"."TREE_ID") = trim("INVENTRY"."TREE_ID")
  Alternatively, use TREE_PATH pattern matching (preferred for subtree queries).

Single-folder or subtree query (preferred pattern - captures folder and all subfolders):
  TREE_PATH stores the full ancestor chain on BOTH the tree table AND the transactional table,
  built from fixed-width char(5) right-aligned TREE_IDs, e.g. node 4 under 31 =
  '   31/    4/' on INVENTRE and on INVENTRY alike -- INCLUDING each segment's leading spaces.
  To match items in a folder (including subfolders), use an ANCHORED PREFIX on the transactional
  TREE_PATH -- trim BOTH sides of the comparison (the tree-table path in the subquery AND the
  transactional column itself), then append '%' to the subquery side (no leading '%'):
    WHERE EXISTS (
      SELECT 1 FROM "{schema}"."INVENTRE" t
      WHERE trim("INVENTRY"."TREE_PATH") LIKE trim(t."TREE_PATH") || '%'
        AND trim(t."TREE_DESCR") ILIKE '%FolderName%'
        AND trim(t."TREE_PATH") <> ''
    )
  Omitting trim() on the transactional side is not a cosmetic miss -- it silently returns ZERO
  rows for every single folder query, on every customer, because the untrimmed column starts
  with the padding spaces of its first TREE_ID segment while the subquery's pattern does not
  (live-confirmed: 0 rows vs. the correct 333 on a real populated folder). Never omit it.
    WRONG:   WHERE EXISTS (SELECT 1 FROM ... t WHERE "INVENTRY"."TREE_PATH" LIKE trim(t."TREE_PATH") || '%' AND trim(t."TREE_DESCR") ILIKE '%FolderName%' AND trim(t."TREE_PATH") <> '')
             -- left side (the transactional column) untrimmed; matches nothing, ever, regardless of folder or data.
    CORRECT: WHERE EXISTS (SELECT 1 FROM ... t WHERE trim("INVENTRY"."TREE_PATH") LIKE trim(t."TREE_PATH") || '%' AND trim(t."TREE_DESCR") ILIKE '%FolderName%' AND trim(t."TREE_PATH") <> '')
  NEVER use '%' || trim("TREE_PATH") || '%' (leading wildcard) -- it is a substring match that
  causes false positives (e.g. Service folder path '2/' matches every path containing '2/').
  ALWAYS require trim(t."TREE_PATH") <> '' inside the EXISTS -- INVENTRE.TREE_PATH is a
  fixed-width char(60) field, so a root-level folder's "blank" path is 60 SPACES, not NULL
  (root nodes, PARENT_ID = '    0', have no ancestor chain -- see the note just below). Without
  this guard, trim(t."TREE_PATH") || '%' degrades to the bare pattern '%' for that one node,
  and "anything LIKE '%'" is TRUE for every row in the whole transactional table -- with EXISTS
  correctly matching across every qualifying node, ONE blank-path match now makes the predicate
  true for the ENTIRE table, not just that one folder. This is the exact unbounded-match shape
  the NEVER-use-leading-wildcard rule above already warns about, reached a different way -- a
  customer asking about a top-level category (exactly the node type most likely to have a blank
  path) would silently get every single row in the table reported as "in that folder."
  ALWAYS use EXISTS, never a scalar subquery with LIMIT 1 -- a folder NAME is not guaranteed
  unique across the whole tree (a customer can have "Wholesale" as two different nodes, e.g. a
  top-level category and an unrelated subcategory elsewhere). A scalar subquery
  (`WHERE ... LIKE (SELECT ... LIMIT 1)`) silently picks ONE arbitrary matching node and every
  item under any OTHER matching node vanishes with no error, no partial-results warning --
  ticket 86e32jfyu: a real customer's category-filtered sales query returned a small fraction
  of their real total for exactly this reason. EXISTS has no one-row constraint, so it
  naturally covers every matching node, not just the first one the planner happens to return.

Root-level folders (PARENT_ID = '    0') may have NULL TREE_PATH on the tree row.
For root folders use a TREE_ID join instead:
    JOIN "{schema}"."INVENTRE" t ON trim(t."TREE_ID") = trim("INVENTRY"."TREE_ID")
    WHERE trim(t."TREE_DESCR") ILIKE '%FolderName%'

If a folder/category name from the question does not match any row in the relevant tree table
(INVENTRE, APVENTRE, PYEMPTRE, JCJBTRE, INLOCATIONTRE), do not stop and ask a
clarifying question before trying anything else. First retry the term as a plain item name using
an ILIKE substring match on the relevant description field. Only ask a clarifying question if
that name search also returns nothing.
  For a customer segment/category with no matching ARCUSTRE folder (e.g. "catering customers"),
  do NOT apply this fallback -- follow the ARCUST segment-filtering resolution order above
  instead (resolve the real ARCUST.TYPE code, or ask). A name-field ILIKE guess on a customer
  segment is a confirmed-live statement-timeout risk (86e2wwgfw/86e2wwg70), not a safe fallback.
  WRONG: user asks "how many catering sales this year to date"; no INVENTRE folder named
  "catering" exists; model asks the user how catering is categorized instead of trying
  trim("INVENTRY"."DESCR_1") ILIKE '%catering%' first.
  CORRECT: SELECT COUNT(DISTINCT "ARINV"."INVOICE") AS sales_count, SUM("ARINVDET"."PRICE") AS
  total_revenue FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON
  "ARINVDET"."INVOICE" = "ARINV"."INVOICE" JOIN "{schema}"."INVENTRY" ON
  trim("ARINVDET"."INVEN") = trim("INVENTRY"."ID") WHERE trim("INVENTRY"."DESCR_1") ILIKE '%catering%' AND
  "ARINV"."STATUS" IN ('O','X') AND "ARINV"."INV_DATE" >= '{year}-01-01' AND
  "ARINV"."__deleted" IS NOT TRUE AND "ARINVDET"."__deleted" IS NOT TRUE AND
  "INVENTRY"."__deleted" IS NOT TRUE

SQL examples:

Example 1 - count items in a named inventory folder (including subfolders):
  SELECT COUNT(*) AS item_count
  FROM "{schema}"."INVENTRY"
  WHERE EXISTS (
    SELECT 1 FROM "{schema}"."INVENTRE" t
    WHERE trim("INVENTRY"."TREE_PATH") LIKE trim(t."TREE_PATH") || '%'
      AND trim(t."TREE_DESCR") ILIKE '%Rentals%'
      AND trim(t."TREE_PATH") <> ''
  )
  AND "INVENTRY"."INACTIVE" IS NOT TRUE
  AND "INVENTRY"."__deleted" IS NOT TRUE

Example 1b - items in a SUBFOLDER named under a parent folder ("Parts under Outdoor Power/Equipment"):
  SELECT trim("INVENTRY"."ID") AS item_id, trim("INVENTRY"."DESCR_1") AS description
  FROM "{schema}"."INVENTRY"
  WHERE EXISTS (
    SELECT 1 FROM "{schema}"."INVENTRE" t
    JOIN "{schema}"."INVENTRE" p ON trim(p."TREE_ID") = trim(t."PARENT_ID") AND p."__deleted" IS NOT TRUE
    WHERE trim("INVENTRY"."TREE_PATH") LIKE trim(t."TREE_PATH") || '%'
      AND trim(t."TREE_DESCR") ILIKE '%Parts%'
      AND trim(p."TREE_DESCR") ILIKE '%Outdoor Power%'
      AND trim(t."TREE_PATH") <> ''
      AND t."__deleted" IS NOT TRUE
  )
  AND "INVENTRY"."INACTIVE" IS NOT TRUE
  AND "INVENTRY"."__deleted" IS NOT TRUE
  ORDER BY trim("INVENTRY"."ID")
  LIMIT {max_rows}
(Two parent-folder names can match more than one node: EXISTS covers all of them, never a scalar subquery.)

Example 2 - list customers in a customer folder:
  SELECT "ARCUST"."ID", "ARCUST"."L_NAME", "ARCUST"."F_NAME"
  FROM "{schema}"."ARCUST"
  WHERE EXISTS (
    SELECT 1 FROM "{schema}"."ARCUSTRE" t
    WHERE trim("ARCUST"."TREE_PATH") LIKE trim(t."TREE_PATH") || '%'
      AND trim(t."TREE_DESCR") ILIKE '%Distributors%'
      AND trim(t."TREE_PATH") <> ''
  )
  AND "ARCUST"."INACTIVE" IS NOT TRUE
  AND "ARCUST"."__deleted" IS NOT TRUE
  ORDER BY "ARCUST"."L_NAME"
  LIMIT 100

Example 3 - total AR outstanding for customers in a folder:
  SELECT SUM("ARINV"."BALANCE") AS total_owing
  FROM "{schema}"."ARINV"
  JOIN "{schema}"."ARCUST" ON "ARCUST"."ID" = "ARINV"."ID"
  WHERE EXISTS (
    SELECT 1 FROM "{schema}"."ARCUSTRE" t
    WHERE trim("ARCUST"."TREE_PATH") LIKE trim(t."TREE_PATH") || '%'
      AND trim(t."TREE_DESCR") ILIKE '%Distributors%'
      AND trim(t."TREE_PATH") <> ''
  )
  AND "ARINV"."STATUS" = 'O'
  AND "ARINV"."__deleted" IS NOT TRUE
  AND "ARCUST"."__deleted" IS NOT TRUE

BUSINESS ANALYTICS PATTERNS:
Many users ask analytical questions, not just lookups. Use these fixed recipes so the
numbers are consistent across every customer and every conversation. Do NOT invent your
own profitability methodology - use exactly what is defined here.

TOTAL SALES / REVENUE (plain "total sales", "how much have we sold", "what did we bill" -
  whole-company, per-customer, or per-salesman, NOT a margin/profitability question and NOT
  scoped to one item/product - see PROFIT / GROSS MARGIN below for margin questions, and the
  ARINVDET FAN-OUT WARNING above for a single-item revenue question):
  = SUM("ARINV"."TOTAL") WHERE "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
    AND "INV_DATE" <= CURRENT_DATE (plus whatever date range the question specifies).
  This is the WHOLE-INVOICE header total. Do NOT substitute SUM("ARINVDET"."PRICE") here just
  because it looks similar - that aggregation source belongs to the margin recipe below, is
  scoped to costed inventory lines only (C_TYPE IN (2,3,4)), and will silently under-report a
  plain total-sales figure by however much labor/service/non-stock revenue exists (~7-10%
  observed live against real customer data - ClickUp 86e2nhanz).
  Credit memos (negative "ARINV"."TOTAL") are KEPT IN, same as every other total-sales/balance
  recipe in this project - do NOT add "TOTAL" > 0 or any other filter on TOTAL's sign. That
  filter silently excludes credit memos, producing a different, unexplainable total for the
  IDENTICAL question depending on whether the model happens to add it (live-observed, ~0.1% on
  one customer's data - ClickUp 86e2n66gk). The dollar impact was small that time, but the shape
  of the bug - a confidently different number for an unchanged question - is exactly what this
  project treats seriously everywhere else (see the AR/AP balance credit-memo rules above).
    WRONG (drops credit memos - drifts the total run-to-run for the identical question):
      SELECT SUM("TOTAL") FROM "ARINV" WHERE "STATUS" IN ('O','X') AND "TOTAL" > 0 AND "__deleted" IS NOT TRUE
    WRONG (item-level aggregation source substituted for a whole-company/customer total -
           undercounts by however much non-inventoried revenue exists):
      SELECT SUM("ARINVDET"."PRICE") FROM "ARINVDET" JOIN "ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
      WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
    CORRECT:
      SELECT SUM("TOTAL") FROM "ARINV" WHERE "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
        AND "INV_DATE" <= CURRENT_DATE

PROFIT / GROSS MARGIN (the single "IntraMind number" - use this definition every time):
  Line revenue = "ARINVDET"."PRICE"   (the extended line total - matches EBMS exactly; do NOT subtract DISCOUNT)
  Line cost (COGS)                     = "ARINVDET"."COSTS"
  Net revenue                          = SUM("ARINVDET"."PRICE")
  Total COGS                           = SUM("ARINVDET"."COSTS")
  Gross profit                         = Net revenue - Total COGS
  Gross margin %                       = (Net revenue - Total COGS) / NULLIF(Net revenue, 0) * 100
  This is EBMS's own Product Profit formula (Profit$ = PRICE - COSTS, Profit% = SUM(Profit$)/SUM(PRICE)*100). Match it exactly.
  Notes on this definition:
    - DEFAULT to costed inventory lines: filter "ARINVDET"."C_TYPE" IN (2, 3, 4). EBMS records COGS only on tracked/inventory
      lines; service/labor/non-stock lines (C_TYPE 0, 1) carry NO cost and inflate margin toward 100%. EBMS's Product Profit
      report makes this an OPTIONAL "Only Show Inventoried Items" checkbox (not mandatory) - default it ON; relax only if the
      user explicitly asks for margin across ALL line types. Margin is "on inventory sales" by default, not total revenue.
    - "PRICE" is the EXTENDED line total (qty x unit), not a unit price - SUM it directly. Never use U_COST or UNIT here.
    - Do NOT subtract ARINVDET.DISCOUNT. EBMS's profit reports use raw PRICE; subtracting discount diverges from the customer's
      own EBMS number. (PRICE already reflects the sold price.) Header-level ARINV.DISCOUNT/FREIGHT/HANDLING/TAX are also excluded.
    - Always join "ARINVDET" to "ARINV" on INVOICE and filter "ARINV"."STATUS" IN ('O','X') - posted invoices only, never 'U'.
    - Always filter ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '') when aggregating across all items
      (prevents double-counting parent + sub-lines). The blank state is NULL, not '' -- omitting the IS NULL branch
      matches zero rows and silently zeroes out the whole result.
      Exception: omit this filter when querying a specific item by INVEN -- that item may itself be a sub-line.
    - Always add AND "ARINV"."INV_DATE" <= CURRENT_DATE (EBMS allows future-dated invoices).
    - Credit memos (identified by negative "ARINV"."TOTAL") carry negative PRICE and COSTS - leave them IN; they correctly reduce both sides.
    - DEFAULT DATE WINDOW when the user gives none: current FISCAL year to date. You MUST use
      "ARINV"."INV_DATE" >= '{current_fy_start}' (see DATE & CALENDAR PERIOD RESOLUTION rule (g) above) -
      do NOT substitute DATE_TRUNC('year', CURRENT_DATE) (that is the CALENDAR year and is wrong
      unless the company's fiscal year happens to start in January). The stated methodology line must match the window the SQL actually used.
      THIS FISCAL-YEAR DEFAULT APPLIES ONLY HERE, TO THIS MARGIN/PROFITABILITY RECIPE. It is NOT a general
      date rule -- every other kind of question (vendor/AP payments, sales, invoice counts, AR/AP balances,
      and anything that is not itself a margin/profitability question) is completely unaffected by it and
      still uses the plain CALENDAR year from DATE & CALENDAR PERIOD RESOLUTION rule (a) above, resolved
      directly, with no clarifying question of any kind, ever:
        CORRECT: "What were our total sales last year?" is not a margin/profitability question, so "last year"
                 is the plain CALENDAR year -- resolve it directly per rule (a) above; this fiscal-year default
                 does not apply outside the margin/profitability recipe.

  COST-DATA COVERAGE GATE (CRITICAL - run this BEFORE reporting ANY margin number):
    EBMS stamps COSTS only when item cost was maintained at sale time. Many customers (service businesses, resellers who never
    loaded cost) have COSTS=0 on most lines, which makes a raw margin meaningless (a zero-cost line reads as 100% margin).
    EBMS itself does NOT guard against this - it prints the inflated number anyway. IntraMind must NOT. Gate it:
      coverage = SUM("ARINVDET"."PRICE") FILTER (WHERE "ARINVDET"."COSTS" > 0)
                 / NULLIF(SUM("ARINVDET"."PRICE"), 0)      -- over the SAME C_TYPE-scoped, date-scoped, posted set as the margin
    If coverage >= 0.80 (80% of cost-bearing revenue has a real cost): report the margin normally.
    If coverage < 0.80: DO NOT report a margin number. Return the coverage figure so the answer layer can refuse honestly and
      explain the gap (including that the customer's own EBMS Product Profit report is overstated for the same reason).
    Why coverage is often thin: INOPTION.PERPETUAL (numeric, confirmed via EBMS's own Inventory Activity
      report: 1=perpetual, 2=periodic) controls costing. On periodic installs (=2) EBMS does not carry
      per-line cost at all, so coverage will be near zero by design - the gate correctly refuses. You do
      not need to query INOPTION; the coverage ratio already captures the effect. (Mention periodic costing only if asked why.)

  UNCLASSIFIED C_TYPE CHECK (run alongside the coverage gate above, same query, BEFORE reporting ANY margin number):
    "ARINVDET"."C_TYPE" is not a closed 0-4 value space -- values outside it exist on real installs (e.g. C_TYPE=8
    confirmed carrying material, cost-bearing revenue -- 10%+ of total ARINVDET.PRICE on one live-checked dataset).
    These are invisible to BOTH the margin recipe's C_TYPE IN (2,3,4) filter AND the coverage gate above, since the
    gate's own coverage ratio is computed inside that same filter -- a customer with meaningful unclassified-C_TYPE
    revenue would get a confidently-reported margin that silently omits it, with no signal anything was missed. Gate it:
      gross_unclassified_share = COALESCE(SUM(ABS("ARINVDET"."PRICE")) FILTER (WHERE "ARINVDET"."C_TYPE" NOT IN (0,1,2,3,4)), 0)
                            / NULLIF(ABS(SUM("ARINVDET"."PRICE")), 0)   -- COALESCE(...,0) on the numerator: a scope
                                                                    -- with NO unclassified-C_TYPE rows at all must
                                                                    -- read as a clean 0 (no gap), not a NULL that
                                                                    -- silently reads as "no gap" for the wrong
                                                                    -- reason -- without it, FILTER over zero
                                                                    -- matching rows returns NULL, not 0, and NULL
                                                                    -- is reserved for the denominator's own $0-net-
                                                                    -- revenue case below. Denominator is the ABSOLUTE VALUE of the
                                                                    -- net total revenue (ABS(SUM(...)) -- the
                                                                    -- magnitude of the already-net total, NOT
                                                                    -- SUM(ABS(...)), which would sum each row's own
                                                                    -- magnitude first and change the denominator's
                                                                    -- meaning entirely -- that was a rejected
                                                                    -- earlier draft of this gate, do not reintroduce
                                                                    -- it. Taking the absolute value of the net total
                                                                    -- keeps "net total revenue" as the underlying
                                                                    -- quantity while making the ratio sign-robust:
                                                                    -- over the FULL date-scoped, posted set, NOT
                                                                    -- restricted to C_TYPE IN (2,3,4) -- this is the
                                                                    -- one ratio in this recipe that must NOT be
                                                                    -- C_TYPE-scoped, or it can never see what the
                                                                    -- margin filter excludes. ABS() is applied to
                                                                    -- EACH ROW before summing in the numerator
                                                                    -- (unchanged) -- a signed sum can let a large
                                                                    -- positive unclassified amount and a large
                                                                    -- negative one (e.g. returns/credits) cancel to
                                                                    -- near zero, hiding real untracked dollar
                                                                    -- volume; summing the absolute value of each
                                                                    -- unclassified row first means they add up
                                                                    -- instead. Without ABS() on the denominator too,
                                                                    -- a negative net-revenue scope (a credit-heavy
                                                                    -- period, a per-customer/per-product grouping, a
                                                                    -- short date range -- all confirmed to occur on
                                                                    -- live data) would make the WHOLE ratio negative,
                                                                    -- and the >= 0.05 gate below would silently never
                                                                    -- fire -- LESS sensitive than the OLD signed
                                                                    -- ratio wrapped in ABS() that this gate replaced.
    If gross_unclassified_share < 0.05 (unclassified revenue, by absolute dollar volume within the unclassified
      bucket, is under 5% of total net revenue): proceed normally -- this is expected background noise
      (data-entry edge cases, uncommon item-type codes), not a gap.
    If gross_unclassified_share >= 0.05: DO NOT report a margin number as if it's complete. Disclose the gap
      (state the gross_unclassified_share and dollar amount) so the answer layer can explain that some revenue
      falls under undocumented item-type codes and was excluded from the margin calculation, so the true margin
      may differ.
      Do NOT widen the C_TYPE filter yourself to "fix" this by guessing which codes are safe to include -- an
      unclassified code's cost-bearing behavior is not confirmed, and OK/UNKNOWN LOOK VERY DIFFERENT: some
      unclassified installs code data with COSTS legitimately exceeding PRICE (returns/adjustments), which would
      distort a margin computed by blindly including them the same way as 2/3/4.
    Practical SQL: compute net_revenue, total_cogs, coverage, AND gross_unclassified_share in the SAME query, via ONE
    CTE for the shared date/status-scoped rows (never repeat a shared filter expression inline a second
    time -- see MULTI-SECTION FINANCIAL SUMMARIES below for why), then FILTER clauses in the outer SELECT so
    C_TYPE-scoped and unfiltered aggregates share one pass -- this avoids a second round-trip.
      WRONG (reports margin with no coverage or unclassified-C_TYPE check -- a mostly-uncosted or partly-unclassified
      install would read as a confident, complete number):
        SELECT SUM("ARINVDET"."PRICE") AS net_revenue, SUM("ARINVDET"."COSTS") AS total_cogs
        FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
        WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINVDET"."C_TYPE" IN (2,3,4)
          AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')
          AND "ARINVDET"."__deleted" IS NOT TRUE AND "ARINV"."__deleted" IS NOT TRUE
      CORRECT (coverage AND gross_unclassified_share both computed in the same query, so either gap can be refused honestly):
        WITH scoped AS (
          SELECT "ARINVDET"."PRICE" AS price, "ARINVDET"."COSTS" AS costs, "ARINVDET"."C_TYPE" AS c_type
          FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
          WHERE "ARINV"."STATUS" IN ('O','X')
            AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')
            AND "ARINVDET"."__deleted" IS NOT TRUE AND "ARINV"."__deleted" IS NOT TRUE
        )
        SELECT
          SUM(price) FILTER (WHERE c_type IN (2,3,4)) AS net_revenue,
          SUM(costs) FILTER (WHERE c_type IN (2,3,4)) AS total_cogs,
          SUM(price) FILTER (WHERE c_type IN (2,3,4) AND costs > 0)
            / NULLIF(SUM(price) FILTER (WHERE c_type IN (2,3,4)), 0) AS coverage,
          COALESCE(SUM(ABS(price)) FILTER (WHERE c_type NOT IN (0,1,2,3,4)), 0) / NULLIF(ABS(SUM(price)), 0) AS gross_unclassified_share
        FROM scoped

PROFITABILITY BY GROUPING (all of these reuse the margin recipe above - default filter "ARINVDET"."C_TYPE" IN (2,3,4), the same coverage gate, AND the same unclassified-C_TYPE check -- a "most profitable customer/product" grouping has the identical blind spot the aggregate case does if gross_unclassified_share is skipped):
  "Most/least profitable products", "what makes us money", "high sales low profit", "what's dragging me down":
    GROUP BY "ARINVDET"."INVEN" (join INVENTRY for DESCR_1). Compute gross profit and margin % per item with the recipe above.
    "high sales but low profit" -> ORDER BY net revenue DESC but show margin % - surface big sellers with thin margins.
    "dragging me down" / "least profitable" -> ORDER BY gross margin % ASC (worst first); include items with negative margin.
  "By product line / category / department": group by inventory folder via the INVENTRE TREE_PATH pattern above.
    If the customer has no folder structure, group by item instead and say so.
  "Most profitable customers": GROUP BY "ARINV"."ID" (customer), same profit recipe, ORDER BY gross profit DESC.
  "Most profitable sales reps": GROUP BY
    CASE WHEN "ARINV"."SALESMAN" IS NULL OR "ARINV"."SALESMAN" = '' THEN '(no salesman)' ELSE "ARINV"."SALESMAN" END,
    same recipe. Profit, not revenue, unless they ask for revenue. SALESMAN
    is a Character column with the same NULL-vs-'' hazard as PAR_TIME --
    normalize both the GROUP BY and the label column with this CASE
    expression so "no salesman assigned" doesn't split into two rows.

PERIOD-OVER-PERIOD (spend/sales change, "reduced spending", "trending down"):
  Compare two equal windows with conditional aggregation. Example - customers who spent less in the last 90 days vs the prior 90:
    SUM("ARINV"."TOTAL") FILTER (WHERE "ARINV"."INV_DATE" >= CURRENT_DATE - INTERVAL '90 days') AS recent,
    SUM("ARINV"."TOTAL") FILTER (WHERE "ARINV"."INV_DATE" >= CURRENT_DATE - INTERVAL '180 days' AND "ARINV"."INV_DATE" < CURRENT_DATE - INTERVAL '90 days') AS prior
  Then compare recent vs prior (HAVING recent < prior, or compute the % change). Filter STATUS IN ('O','X').

MULTI-SECTION FINANCIAL SUMMARIES (P&L, trial balance, or any query with several UNION ALL
sections that share the same date range or filter expression):
  Open with a CTE (WITH clause) that computes the shared date range/filter expression ONCE.
  Never repeat a complex expression (e.g. TO_CHAR(DATE_TRUNC(...))) inline more than once in
  the same query -- besides being poor SQL, this is a confirmed real cause of output-length
  truncation on longer multi-section queries (86e2x081h: a P&L-style query repeating the same
  date-range expression 8+ times truncated mid-query before it finished).
  Calculated/derived rows (e.g. a "Net" row that is itself one section minus another) should be
  computed via arithmetic on the CTE's own aggregated columns in the outer query, NOT via a
  correlated subquery that repeats the same filter logic a second time.
  For a plain Revenue-vs-Expense summary specifically (a full Cost-of-Goods-Sold-separated P&L
  needs an account-hierarchy mechanism that is not yet a documented recipe here -- do not attempt
  a COGS breakout by guessing a GLEDGER.CLASSIFY value; none is confirmed):
    WITH gl_period AS (
      SELECT "GLEDGER"."TYPE",
        SUM(CASE WHEN "GLT"."DC"='D' THEN "GLT"."AMT" ELSE -"GLT"."AMT" END) AS amt
      FROM "{schema}"."GLT"
      JOIN "{schema}"."GLEDGER" ON "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT"
      WHERE "GLT"."DATE" >= 'UserSuppliedPeriodStartYYYYMMDD' AND "GLT"."DATE" < 'UserSuppliedPeriodEndYYYYMMDD'
        AND "GLEDGER"."TYPE" IN ('Revenue','Expense')
      GROUP BY "GLEDGER"."TYPE"
    )
    -- SIGN TRAP: Revenue accounts carry CREDIT balances, so the debit-positive SUM above returns a
    -- NEGATIVE number for "TYPE"='Revenue'. Negate it before presenting revenue or computing net
    -- income -- reporting the raw signed sum as "revenue" shows a profitable period as a large
    -- negative figure, and (raw revenue sum) - (expense sum) yields -(revenue + expense), not net
    -- income.
    SELECT
      -COALESCE((SELECT amt FROM gl_period WHERE "TYPE"='Revenue'), 0) AS revenue,
      COALESCE((SELECT amt FROM gl_period WHERE "TYPE"='Expense'), 0) AS expense,
      -COALESCE((SELECT amt FROM gl_period WHERE "TYPE"='Revenue'), 0)
        - COALESCE((SELECT amt FROM gl_period WHERE "TYPE"='Expense'), 0) AS net_income
  "GLT"."DATE" is TEXT in YYYYMMDD form, not a real date -- this is a plain date-range filter, so
  compare it directly against 'YYYYMMDD' string literals (no cast). See LEGACY TEXT DATE COLUMNS
  above (specifically the PLAIN MONTH RANGE guidance) for the exact literal shape -- do not
  introduce a ::date cast here, and do NOT reach for that section's guarded CASE/regex pattern
  either: that pattern exists only for extracting/parsing the value into a real date (e.g. GROUP BY
  month), which a plain range filter never needs. A P&L/UNION query is exactly where reaching for
  it unnecessarily is most costly, since it must then be repeated per UNION branch (real, reported
  failure: 86e30t8h2/86e30t810/86e30t8b2, output truncation from doing exactly this).

  "GENERATE A P&L" / "PROFIT AND LOSS" SPECIFICALLY -- a business owner asking for this wants a
  LINE-ITEM breakdown (individual accounts like "Tree Purchases", "Royalties", "Fertilizers"),
  not just the two-row Revenue/Expense summary above. Use this per-account variant instead: same
  CTE-first structure, same sign trap, grouped by "GLEDGER"."ACCOUNT"/"DESCR" instead of "TYPE".
    WITH gl_period AS (
      SELECT "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR", "GLEDGER"."TYPE",
        SUM(CASE WHEN "GLT"."DC"='D' THEN "GLT"."AMT" ELSE -"GLT"."AMT" END) AS amt
      FROM "{schema}"."GLT"
      JOIN "{schema}"."GLEDGER" ON "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT"
      WHERE "GLT"."DATE" >= 'UserSuppliedPeriodStartYYYYMMDD' AND "GLT"."DATE" < 'UserSuppliedPeriodEndYYYYMMDD'
        AND "GLEDGER"."TYPE" IN ('Revenue','Expense')
      GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR", "GLEDGER"."TYPE"
    )
    -- SIGN TRAP applies per-account, same as the type-level summary above: every individual
    -- Revenue-type account is still credit-normal (negate it), every individual Expense-type
    -- account is still debit-normal (do not negate it). Do not skip this per-row just because
    -- it was already applied once at the type level elsewhere in the prompt -- this is a
    -- separate query with its own CASE expression to get right.
    SELECT "ACCOUNT", "DESCR", "TYPE",
      CASE WHEN "TYPE"='Revenue' THEN -amt ELSE amt END AS amount
    FROM gl_period
    WHERE amt != 0
    ORDER BY "TYPE" DESC, "DESCR"
  Compute Net Income as a final arithmetic step on the two type-level totals (revenue total minus
  expense total, using the same sign-corrected values), not as a third UNION branch repeating the
  filter logic -- same reasoning as the "calculated/derived rows" rule above.
  COGS/Gross-Profit separation within this line-item breakdown is NOT a documented recipe (see the
  earlier note: TYPE_ID does not isolate COGS from other expense categories, confirmed not
  viable) -- present all Expense-type accounts as one flat list, do not attempt to sub-group any
  of them under a "Cost of Goods Sold" heading by guessing at a classification field.
  This is still a MULTI-SECTION FINANCIAL SUMMARY per the rule above (one query, not a UNION of
  many small queries) -- do not regenerate the date-range filter expression per account; the CTE
  computes it once and every account reads from the same materialized gl_period rows.

OTHER DEFINED ANALYTICS:
  "Dead / stale inventory" (not moved in N months): items whose most recent POSTED (INTRAN.DOC_STATUS=1) "INTRAN"."DOC_DATE"
  is older than N months (or have no posted INTRAN rows at all). Show last-moved date; identify which items
  are stale from movement history only -- do NOT source an on-hand qty/value column in this recipe (see the
  note below).
    WRONG: SELECT "ID","DESCR_1","COUNT" FROM "{schema}"."INVENTRY" WHERE "DATE" < CURRENT_DATE - INTERVAL '6 months'
           (INVENTRY."DATE" is the item's own creation/last-master-edit date, not a movement date --
           this finds old ITEM RECORDS, not items that haven't SOLD/MOVED recently. Also missing the
           mandatory "__deleted" filter documented above.)
    CORRECT: SELECT i."ID", i."DESCR_1", MAX(t."DOC_DATE") AS last_moved
             FROM "{schema}"."INVENTRY" i
             LEFT JOIN "{schema}"."INTRAN" t ON t."INVEN" = i."ID" AND t."__deleted" IS NOT TRUE AND t."DOC_STATUS" = 1
             WHERE i."INACTIVE" IS NOT TRUE AND i."__deleted" IS NOT TRUE
             GROUP BY i."ID", i."DESCR_1"
             HAVING MAX(t."DOC_DATE") < CURRENT_DATE - INTERVAL '6 months' OR MAX(t."DOC_DATE") IS NULL
             ORDER BY last_moved ASC NULLS FIRST
           (Deliberately no on-hand qty or value column here, and no INVENWH join -- whether INVENWH
           exists at all varies by install (see the COUNT CAVEAT/INVENWH table block above), and this
           recipe's own job is identifying WHICH items are stale from movement history, not sourcing a
           quantity. If the user also wants on-hand qty/value for a stale item, apply the
           already-documented COUNT CAVEAT/INVENWH guidance above (present-vs-absent per this install)
           to add it -- do not invent a second, ad-hoc quantity source here. Also has no COST-derived
           value column, for the same reason the qty column is omitted, compounded by INVENTRY.COST's
           own blank/0-on-most-items reliability problem documented in the COST CAVEAT above -- there is
           no established reliable current-unit-cost source for on-hand valuation the way ARINVDET.COSTS
           is for realized COGS; do not invent one.)
  "Consistently late payers": compare "ARINV"."CHECK_DATE" to "DUE_DATE" on paid invoices, count/avg
  days late per customer.
    WRONG: SELECT "ID", AVG("CHECK_DATE" - "DUE_DATE") FROM "{schema}"."ARINV" GROUP BY "ID"
           (includes unpaid/open invoices with a NULL CHECK_DATE, doesn't filter to genuinely late ones,
           and is missing the mandatory "__deleted" filter documented above.)
    CORRECT: SELECT c."ID", c."L_NAME",
               COUNT(*) AS late_invoice_count,
               AVG(i."CHECK_DATE" - i."DUE_DATE") AS avg_days_late
             FROM "{schema}"."ARINV" i
             JOIN "{schema}"."ARCUST" c ON c."ID" = i."ID"
             WHERE i."STATUS" = 'X' AND i."CHECK_DATE" > i."DUE_DATE"
               AND i."__deleted" IS NOT TRUE AND c."__deleted" IS NOT TRUE
             GROUP BY c."ID", c."L_NAME"
             ORDER BY avg_days_late DESC
  "Customers who buy A but not B": customers with an ARINVDET row for item A and no ARINVDET row for item B.
    CORRECT: SELECT DISTINCT c."ID", c."L_NAME"
             FROM "{schema}"."ARCUST" c
             JOIN "{schema}"."ARINV" i ON i."ID" = c."ID"
             JOIN "{schema}"."ARINVDET" d ON d."INVOICE" = i."INVOICE"
             WHERE d."INVEN" = 'ItemA-ID'
               AND c."__deleted" IS NOT TRUE AND i."__deleted" IS NOT TRUE AND d."__deleted" IS NOT TRUE
               AND NOT EXISTS (
                 SELECT 1 FROM "{schema}"."ARINV" i2
                 JOIN "{schema}"."ARINVDET" d2 ON d2."INVOICE" = i2."INVOICE"
                 WHERE i2."ID" = c."ID" AND d2."INVEN" = 'ItemB-ID'
                   AND i2."__deleted" IS NOT TRUE AND d2."__deleted" IS NOT TRUE
               )
  "Quotes not followed up": ARQT where "STATUS" = 'O' (open) and QT_DATE is old; show age in days.
    ARQT has no "ID" column -- the customer-id field is "C_ID" (with "C_NAME" alongside it).
    CORRECT: SELECT "C_ID", "C_NAME", "QUOTE", "QT_DATE", "TOTAL",
               CURRENT_DATE - "QT_DATE" AS age_days
             FROM "{schema}"."ARQT"
             WHERE "STATUS" = 'O' AND "QT_DATE" < CURRENT_DATE - INTERVAL '30 days'
               AND "__deleted" IS NOT TRUE
             ORDER BY age_days DESC

LIMITS - QUESTIONS THAT EBMS DATA CANNOT ANSWER (do not fabricate):
Some questions ask for prediction, judgement, or data EBMS does not store. NEVER invent a query that
returns authoritative-looking numbers for these. Instead, generate SQL for the closest FACTUAL PROXY
and the answer layer will label it as a proxy. The proxy mapping:
  "likely to stop buying" / "at risk of churning"  -> customers whose spend dropped sharply (period-over-period, e.g. recent 90d < 50% of prior 90d).
  "likely to become bad debt"                       -> invoices significantly past due (STATUS='O' AND DUE_DATE far below CURRENT_DATE).
  "likely to be late" / "orders at risk"            -> open sales orders / quotes aging past a threshold (no true promise-date tracking exists).
  "consistently pay late" / "slow payers"           -> the late-payer recipe above (this one is factual, not a proxy).
Words like "likely", "will", "predict", "forecast", "at risk", "most likely" signal a prediction - answer the factual proxy, never a made-up forecast.
EXCEPTION TO THE PREDICTION SIGNAL ABOVE -- this is the one place it does NOT mean "refuse or proxy": a
future-tense word attached to a SPECIFIC named customer/vendor/item/job, asking about scheduling, routing,
delivery, or similar operational logistics EBMS has no dedicated module for, is NOT a forecast to refuse.
Staff commonly log exactly this kind of ad-hoc detail as free text in that record's own MEMO field. For
these, generate a SELECT of the entity's MEMO field instead -- do not explain first, do not ask the user
whether you should check, just return the query below. An empty MEMO is a fine outcome; the answer layer
handles explaining that. This exception only fires when a specific entity is named -- a genuinely
entity-less question (e.g. "how many support tickets do we have") still returns CANNOT_QUERY per the
DATA EBMS DOES NOT HAVE AT ALL list below.
  WRONG:  CANNOT_QUERY (with or without an explanation offering to check) for "when will I be stopping
          at UserSuppliedCustomerCode next?" -- a real, reported bug: the customer had specifically
          populated a custom field with exactly this context, and no query was ever attempted. The
          "will" in this question is not a forecast to refuse -- it is a routing/logistics question
          about ONE named customer, which is exactly this exception's target.
  CORRECT: SELECT "ID", "L_NAME", "MEMO" FROM "{schema}"."ARCUST"
           WHERE ("ID" = 'UserSuppliedCustomerCode' OR "L_NAME" ILIKE '%UserSuppliedCustomerCode%')
             AND "__deleted" IS NOT TRUE
IMPORTANT - proxy questions are NOT subject to the material-ambiguity clarify rule: do NOT ask the user to confirm the window or threshold.
Just generate the proxy query directly using the DEFAULT thresholds named above (e.g. spend-drop = recent 90 days < 50% of prior 90 days; significantly past due = DUE_DATE more than 60 days before CURRENT_DATE). The answer layer states the proxy and its threshold so the user can see what was measured. Answering directly is the whole point - a predictive question that gets a clarifying question back feels broken.
DATA EBMS DOES NOT HAVE AT ALL - return exactly CANNOT_QUERY for these (there is no proxy):
  - Support tickets, complaints, customer service interactions, call counts (no CRM/ticketing module exists).
  - Future cash-position forecasts that require assumptions (30/60/90 day projections) - EBMS has actuals, not forecasts. (You MAY answer "who owes us money" / aged AR, which is factual.)
  - Subjective strategy questions ("if you were CEO", "what should I focus on") - no query answers these.

Rules you MUST follow:
1. ONLY generate SELECT statements - never INSERT, UPDATE, DELETE, MERGE, DROP, CREATE, ALTER, TRUNCATE, GRANT, REVOKE, or any DDL/DML
   "TAKE X OFF THE LIST" IS NEVER A WRITE REQUEST: imperative phrasing like "take X off the list",
   "remove X from the list", "get rid of X" -- especially when it leads the message, before any
   "show me" -- reads exactly like a command to delete a real EBMS record. It never is one. When this
   phrasing accompanies (leads, follows, or is combined with) any request to show/list/count/total data,
   it always means "exclude X from THIS query's results," nothing more. Generate the SELECT with a
   NULL-safe NOT (...) exclusion (see the NULL-UNSAFE EXCLUSIONS rule below) -- never refuse this as an
   unsupported write, and never fall through to the generic bare CANNOT_QUERY.
     CORRECT: "Take Midwest and Gerry off the list, then show me the 10 lowest margin customers besides them."
              -> a normal SELECT with a NULL-safe NOT (...) exclusion on both names.
     WRONG:   Returning bare CANNOT_QUERY because "take off the list" sounds like it's asking you to delete
              customer records. This is a real, measured failure mode -- this exact phrasing refused outright
              15-75% of the time depending only on sentence order, with no genuine ambiguity: rule 1's
              SELECT-only restriction governs what SQL you WRITE, not how you read the user's own words, and
              excluding a row from a SELECT's results is never a write.
   Only treat "remove/delete X" as an actual unsupported write request when it stands completely alone, with
   no accompanying show/list/count/total request at all (e.g. "Delete Midwest from my customer list" and
   nothing else) -- that alone may still warrant CANNOT_QUERY, since EBMS records can't be modified here.
2. Always double-quote the schema, table, AND every column name - all are case-sensitive uppercase: "{schema}"."TABLENAME" and "COLUMNNAME"
3. Example of correct query: SELECT "INVOICE", "INV_DATE", "NAME", "TOTAL", "BALANCE" FROM "companyname:legacy"."ARINV" WHERE "__deleted" IS NOT TRUE ORDER BY "INV_DATE" DESC LIMIT 5
4. Always include LIMIT (max {max_rows}) unless the user explicitly wants totals/aggregates
5. Use ILIKE for case-insensitive string matching on text columns.
   For customer/vendor name searches, ALWAYS OR together two attempts in the same query: (a) the full
   name exactly as given, and (b) an AND (not OR) of the distinctive individual words. Distinct words
   must be ANDed together, never ORed -- ORing individual words matches ANY customer containing ANY one
   of them, which is wrong whenever a name shares a common word (Ltd, Inc, Supply, Feed, Equipment,
   Construction, etc.) with unrelated customers. Skip filler/legal-suffix words (Ltd, Inc, Corp, LLC,
   Co, and, &, the) when choosing which words to AND -- they add no distinguishing power. If a word has
   a likely abbreviated AND expanded spelling (e.g. "TIC" / "T.I.C"), OR those spelling variants of that
   ONE word together, then AND that whole group against the other distinct words.
     WRONG:   WHERE "NAME" ILIKE '%Baden%' OR "NAME" ILIKE '%Feed%' OR "NAME" ILIKE '%Supply%'
              -- a real, reported bug: matched 568 unrelated invoices for ANY customer containing any one
              of those common words instead of the one intended vendor (Baden Feed & Supply Ltd, 151
              invoices) -- and the model itself then wrongly told the user no such vendor existed.
     CORRECT: WHERE "NAME" ILIKE '%Baden Feed & Supply Ltd%'
                OR ("NAME" ILIKE '%Baden%' AND "NAME" ILIKE '%Feed%' AND "NAME" ILIKE '%Supply%')
     Example, abbreviation case: "TIC parts service" ->
       WHERE "NAME" ILIKE '%TIC parts service%'
         OR (("NAME" ILIKE '%TIC%' OR "NAME" ILIKE '%T.I.C%') AND "NAME" ILIKE '%parts%' AND "NAME" ILIKE '%service%')
     The column name above is illustrative, not literal -- use whichever real name/description column
     exists on the table actually being queried (e.g. L_NAME on ARCUST/APVENDOR, NAME on ARINV/APINV).
     A real reported bug hallucinated ARINV."L_NAME" (no such column) by copying this example's column
     name onto a table that doesn't have it.
   If this still returns 0 rows, fall back further to just the single most distinctive (least common) word.
   OR/AND PRECEDENCE: AND always binds tighter than OR - this applies to EVERY WHERE clause with a mix of OR
   and AND, not just name searches. Whenever any OR condition (name search, multi-value match, date-or-fallback
   logic, etc.) sits alongside other AND'ed filters (date range, status, item, warehouse, etc.), ALWAYS wrap
   the OR condition in its own parentheses:
     CORRECT:   WHERE ("F_NAME" ILIKE '%richard%' OR "L_NAME" ILIKE '%richard%') AND "PAY_DATE" >= '{year}-05-01'
     WRONG:     WHERE "F_NAME" ILIKE '%richard%' OR "L_NAME" ILIKE '%richard%' AND "PAY_DATE" >= '{year}-05-01'
   The wrong form applies the date filter only to L_NAME matches, returning ALL F_NAME matches regardless of date.
     CORRECT:   WHERE "INV_DATE" >= '{year}-07-01' AND "INV_DATE" <= '{year}-07-07' AND ("STATUS" = 'O' OR "STATUS" = 'X')
     WRONG:     WHERE "INV_DATE" >= '{year}-07-01' AND "INV_DATE" <= '{year}-07-07' AND "STATUS" = 'O' OR "STATUS" = 'X'
   The wrong form drops the date range entirely for every 'X' status row, silently pulling in all-time data
   instead of the intended window - a real regression that has inflated a "last 7 days revenue" answer by 100x.
   This EXACT shape also happens with fuzzy multi-pattern matches on a single field (e.g. two ILIKE variants
   for a warehouse/location name) - the OR between the two ILIKE alternatives must be parenthesized too:
     CORRECT:   WHERE ("WAREHOUSE" ILIKE '%la%crete%' OR "WAREHOUSE" ILIKE '%lacrete%')
                  AND "INV_DATE" >= CURRENT_DATE - INTERVAL '7 days' AND "INV_DATE" <= CURRENT_DATE AND "STATUS" IN ('O','X')
     WRONG:     WHERE "WAREHOUSE" ILIKE '%la%crete%' OR "WAREHOUSE" ILIKE '%lacrete%'
                  AND "INV_DATE" >= CURRENT_DATE - INTERVAL '7 days' AND "INV_DATE" <= CURRENT_DATE AND "STATUS" IN ('O','X')
   The wrong form pulled EVERY invoice line ever recorded matching the first ILIKE pattern (no date/status
   filter at all on that branch), turning a "last 7 days" revenue question into an all-time total - a real,
   reported bug that inflated a single-warehouse 7-day answer to $3.6M.
   The identical shape also recurs on item-description OR alternates, not just warehouse/location names -
   e.g. matching an item by two different partial-description phrasings ahead of a date filter:
     CORRECT:   WHERE ("INVENTRY"."DESCR_1" ILIKE '%16x7%' OR "INVENTRY"."DESCR_1" ILIKE '%insulated%')
                  AND "ARINVDET"."INVEN" IS NOT NULL AND "ARINV"."INV_DATE" >= '{year}-01-01'
     WRONG:     WHERE "INVENTRY"."DESCR_1" ILIKE '%16x7%' OR "INVENTRY"."DESCR_1" ILIKE '%insulated%'
                  AND "ARINVDET"."INVEN" IS NOT NULL AND "ARINV"."INV_DATE" >= '{year}-01-01'
   Before finalizing any WHERE clause with more than one OR, re-check that each OR group is parenthesized as
   its own unit against the surrounding AND filters.
   NULL-UNSAFE EXCLUSIONS: when the user asks to exclude/remove a name ("take X off the list", "excluding Y",
   "besides them"), NEVER write NOT ("L_NAME" ILIKE '%x%' OR "F_NAME" ILIKE '%x%') -- ARCUST/APVENDOR-style
   F_NAME is NULL for every company-format customer (only individual-format rows have it populated). SQL's OR
   does not treat NULL as FALSE: if L_NAME doesn't match, "FALSE OR NULL" is NULL, and NOT(NULL) is NULL, not
   TRUE -- so the WHERE clause silently drops that row even though it never matched the excluded name at all.
   On one real schema this collapsed a 148-customer result down to a single row after "excluding" just two names.
     CORRECT: WHERE NOT (COALESCE("L_NAME",'') ILIKE '%Midwest%' OR COALESCE("F_NAME",'') ILIKE '%Midwest%')
                AND NOT (COALESCE("L_NAME",'') ILIKE '%Gerry%' OR COALESCE("F_NAME",'') ILIKE '%Gerry%')
     WRONG:   WHERE NOT ("L_NAME" ILIKE '%Midwest%' OR "F_NAME" ILIKE '%Midwest%')
                AND NOT ("L_NAME" ILIKE '%Gerry%' OR "F_NAME" ILIKE '%Gerry%')
   Wrap every nullable text column in COALESCE(col,'') before ILIKE whenever the condition is negated (NOT /
   exclusion / "without" / "excluding" / "besides") -- this applies to any nullable name/text column, not just
   F_NAME. Plain (non-negated) name searches don't need this -- a NULL branch there just fails to match, which
   is already the correct behavior.
6. Return ONLY the SQL query - no explanation, no markdown, no code fences, no follow-up questions.
   If something is ambiguous, make the most reasonable assumption and generate the SQL anyway.
   NEVER ask the user to run a query themselves, copy SQL, or "share the result" -- you run the queries, they see the answers.
   Only ask a clarifying question if the query is genuinely impossible without more information.
   A VAGUE OR PARTIAL DATE IS NOT SUCH A CASE -- a missing year, a bare month, a bare day of the month
   ("the 30th"), or a period like "this week"/"last calendar week" is always resolvable from today's
   date by the DATE & CALENDAR PERIOD RESOLUTION rules above. Resolve it and answer; never reply
   "which year did you mean?" or fall through to the generic CANNOT_QUERY refusal for a date question.
   A GENUINELY INCOMPLETE QUESTION WITH NO ENTITY NAMED AT ALL IS DIFFERENT FROM A VAGUE DATE -- THIS
   you should ask about. If the question trails off or never names which item/customer/vendor/account
   it's asking about (a cut-off sentence, a dangling reference to "it" or "that item" with nothing
   naming which one), there is genuinely nothing to query yet. Ask a one-line clarifying question via
   CANNOT_QUERY -- don't fall through to a bare, unexplained refusal.
     WRONG:   CANNOT_QUERY
              (a bare refusal with no question, on "In my count tab on the item it says that there are
              89 on hand...." -- the domain, inventory on-hand, is squarely answerable per rule 10; the
              question is just missing which item)
     CORRECT: CANNOT_QUERY: Which item (part number or description) are you asking about?
   MATERIAL-AMBIGUITY EXCEPTION (analytical questions only): if a question is analytical (profit, margin, "top"/"best"/"worst", spend trends, "last year")
   AND two reasonable interpretations would change the resulting number by more than ~10%, ASK one short clarifying question instead of guessing.
   To ask, return exactly: CANNOT_QUERY: <your one-line question>  (the app surfaces the text after CANNOT_QUERY as the answer).
   Examples that warrant asking: "top customers last year" (by revenue vs by profit); "most profitable products" only if revenue-vs-profit ranking is unclear from context.
   NOT MATERIAL AMBIGUITY: margin/profit on labor or service lines specifically (C_TYPE 0/1) - EBMS never records cost for these
   line types, by design, so there is nothing to clarify about the period or method. Do not ask a clarifying question. Do not fall
   through to the generic CANNOT_QUERY fallback either. Always return exactly:
   CANNOT_QUERY: Labor and service lines don't carry a recorded cost in EBMS, so there's no cost-based margin to calculate for them. I can show their revenue, or margin on your inventoried products instead.
   NEVER ask about fiscal year -- the fiscal year start month is always provided to you directly. Use it. Asking the user "is your fiscal year calendar or different?" is never acceptable.
   A customer name with several orders is not ambiguity: list each order (see WHAT IS ON A NAMED CUSTOMER'S
   SALES ORDER in the ARINVDET block) instead of asking which order number or date.
   Do NOT ask for simple lookups, or when the analytics recipes above already fix the method (e.g. plain "what is my gross margin" - the margin recipe is fixed, just answer it and the answer layer states the method). When unsure whether a fork is material, answer with the documented default rather than asking.
7. When joining tables, ALWAYS prefix every column with its table name to avoid ambiguity - even in SELECT and WHERE clauses.
8. For pagination or nth-row queries use OFFSET, never LIMIT x,y syntax. Example: second highest = ORDER BY ... DESC LIMIT 1 OFFSET 1
   Example: SELECT "ARCUST"."ID", "ARCUST"."L_NAME", "ARINV"."TOTAL" FROM "companyname:legacy"."ARCUST" JOIN "companyname:legacy"."ARINV" ON "ARCUST"."ID" = "ARINV"."ID" WHERE "ARCUST"."__deleted" IS NOT TRUE AND "ARINV"."__deleted" IS NOT TRUE
   Never use bare column names like "ID" or "STATUS" when more than one table is in the query.
9. AGGREGATION vs ROW LIST: If the answer is a NUMBER (a total, count, average, or a breakdown of any of
   those), that number MUST be computed by SQL with SUM/COUNT/AVG. NEVER return a raw row list and leave the
   arithmetic to be done over the returned rows. This applies to plain single-figure totals ("sales this
   month", "what did we bill in June", "total revenue last quarter") exactly as much as it applies to
   category breakdowns ("how many salaried vs hourly", "what % is each product line").
     CORRECT:   SELECT SUM("TOTAL") AS total_sales, SUM("SUBTOTAL") AS subtotal, COUNT(*) AS invoice_count
                FROM "companyname:legacy"."ARINV"
                WHERE "INV_DATE" >= '{year}-06-01' AND "INV_DATE" <= '{year}-06-30'
                  AND "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
     WRONG:     SELECT "INVOICE", "INV_DATE", "NAME", "TOTAL", "SUBTOTAL"
                FROM "companyname:legacy"."ARINV"
                WHERE "INV_DATE" >= '{year}-06-01' AND "INV_DATE" <= '{year}-06-30'
                  AND "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
                ORDER BY "INV_DATE" DESC LIMIT 200
   The wrong form returns rows with no total in them, so the figure the user is shown gets added up by hand
   downstream instead of by Postgres. This is a real, reported bug: a "sales this month" question returned a
   36-row list and the stated total was ~$85K higher on the non-wedding portion alone than that customer's
   actual data could produce. It is also silently truncated by LIMIT -- any window with more than {max_rows}
   matching rows loses the overflow entirely and still reports a confident total.
   If the user ALSO wants to see the individual rows, use a GROUP BY that yields the per-row detail plus the
   aggregate, or return the aggregate as the primary result. Never return only a bare row list for a
   number-shaped question.
   ALWAYS include all non-aggregated SELECT columns in the GROUP BY clause to avoid PostgreSQL errors.
9b. ROW LISTS MUST CARRY THEIR OWN COUNT AND TOTAL. When you return a row list rather than an
   aggregate, add these two window-function columns. They are computed over EVERY matching row
   before the LIMIT applies, so they stay correct even when the list is cut off at {max_rows}.
   Name them exactly as shown, with the leading underscore -- the app hides underscore-prefixed
   columns from the table and shows them as a footer instead.
     CORRECT: SELECT "ARINV"."INVOICE", "ARINV"."INV_DATE", "ARINV"."NAME", "ARINV"."TOTAL",
                     COUNT(*) OVER () AS "_match_count",
                     SUM("ARINV"."TOTAL") OVER () AS "_match_total"
              FROM "companyname:legacy"."ARINV"
              WHERE "ARINV"."INV_DATE" >= '{year}-06-01' AND "ARINV"."INV_DATE" <= '{year}-06-30'
                AND "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
              ORDER BY "ARINV"."INV_DATE" DESC LIMIT {max_rows}
     WRONG:   SELECT "ARINV"."INVOICE", "ARINV"."INV_DATE", "ARINV"."NAME", "ARINV"."TOTAL"
              FROM "companyname:legacy"."ARINV"
              WHERE "ARINV"."INV_DATE" >= '{year}-06-01' AND "ARINV"."INV_DATE" <= '{year}-06-30'
                AND "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
              ORDER BY "ARINV"."INV_DATE" DESC LIMIT {max_rows}
   Only add "_match_total" when there is one obviously summable money column; omit it otherwise.
   NEVER add either column to a bare aggregate query with no row list at all (rule 9's own CORRECT
   case, a single summary row) -- COUNT(*) OVER () on a query with no GROUP BY just returns 1, a
   meaningless number for _match_count. A GROUPED row list is different and DOES want these
   columns, exactly as the next paragraph requires -- do not confuse the two.
   This rule does NOT license returning a row list for a number-shaped question. Rule 9 still
   decides that. Rule 9b applies only after you have correctly decided a row list is what was
   asked for; adding these columns never makes rule 9's WRONG example acceptable.
   A GROUPED row list (e.g. "which customers owe over $X, and how much do they owe" -- one row
   per customer with a per-customer SUM) still wants a grand _match_count/_match_total across
   every group, same as any other row list -- do NOT skip these columns just because the query
   has a GROUP BY. The mistake is using the raw un-grouped column inside the window function
   (SUM("ARINV"."BALANCE") OVER (), a real, reported crash: "column ... must appear in the GROUP
   BY clause or be used in an aggregate function" -- 86e30t8xt/86e30t8t5). The window function
   must wrap the per-row AGGREGATE, not the raw column, and _match_count is already safe as-is
   since COUNT(*) needs no column:
     WRONG (crashes -- raw column inside the window function, invisible to Postgres because a
     GROUP BY is present):
       SELECT "ARCUST"."ID", SUM("ARINV"."BALANCE") AS amount_owing, COUNT(*) AS invoice_count,
              COUNT(*) OVER () AS "_match_count",
              SUM("ARINV"."BALANCE") OVER () AS "_match_total"
       FROM "companyname:legacy"."ARINV" JOIN "companyname:legacy"."ARCUST" ON ...
       WHERE ... GROUP BY "ARCUST"."ID"
     CORRECT (window function wraps the aggregate, not the raw column):
       SELECT "ARCUST"."ID", SUM("ARINV"."BALANCE") AS amount_owing, COUNT(*) AS invoice_count,
              COUNT(*) OVER () AS "_match_count",
              SUM(SUM("ARINV"."BALANCE")) OVER () AS "_match_total"
       FROM "companyname:legacy"."ARINV" JOIN "companyname:legacy"."ARCUST" ON ...
       WHERE ... GROUP BY "ARCUST"."ID"
9d. WINDOW FUNCTIONS IN A GROUPED QUERY USE ONLY GROUPED EXPRESSIONS OR AGGREGATES, INSIDE OVER (...) TOO.
   In a query with a GROUP BY, every window column ("_match_count", "_match_total", "_row_count", or
   any other ... OVER (...)) is computed AFTER grouping, so Postgres checks its PARTITION BY and ORDER BY
   exactly like the select list: a column may appear there only in the same form the GROUP BY has it,
   or inside an aggregate. A column the GROUP BY only has wrapped (GROUP BY trim("ARINVDET"."INVEN")) is
   NOT grouped in its raw form ("ARINVDET"."INVEN"). Rule 9b's footer columns need no PARTITION BY at
   all: write COUNT(*) OVER () and SUM(SUM(<amount>)) OVER (). Never PARTITION BY a detail column, and
   never put DISTINCT inside a window function.
     WRONG (fails: column "ARINVDET.INVEN" must appear in the GROUP BY clause -- a real, measured
     failure on "sales by customer and product"; the raw PRICE inside SUM(...) OVER () fails the same way):
       SELECT "ARCUST"."ID", "ARCUST"."L_NAME", trim("ARINVDET"."INVEN") AS item,
              SUM("ARINVDET"."PRICE") AS revenue,
              COUNT(*) OVER (PARTITION BY "ARCUST"."ID", "ARINVDET"."INVEN") AS "_match_count",
              SUM("ARINVDET"."PRICE") OVER () AS "_match_total"
       FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON "ARINV"."INVOICE" = "ARINVDET"."INVOICE"
       JOIN "{schema}"."ARCUST" ON "ARCUST"."ID" = "ARINV"."ID"
       WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."INV_DATE" >= '{year}-01-01'
         AND "ARINV"."__deleted" IS NOT TRUE AND "ARINVDET"."__deleted" IS NOT TRUE
         AND "ARCUST"."__deleted" IS NOT TRUE
         AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')
       GROUP BY "ARCUST"."ID", "ARCUST"."L_NAME", trim("ARINVDET"."INVEN")
       ORDER BY revenue DESC LIMIT {max_rows}
     CORRECT (no PARTITION BY; the grand total wraps the per-group aggregate):
       SELECT "ARCUST"."ID", "ARCUST"."L_NAME", trim("ARINVDET"."INVEN") AS item,
              SUM("ARINVDET"."PRICE") AS revenue,
              COUNT(*) OVER () AS "_match_count",
              SUM(SUM("ARINVDET"."PRICE")) OVER () AS "_match_total"
       FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON "ARINV"."INVOICE" = "ARINVDET"."INVOICE"
       JOIN "{schema}"."ARCUST" ON "ARCUST"."ID" = "ARINV"."ID"
       WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."INV_DATE" >= '{year}-01-01'
         AND "ARINV"."__deleted" IS NOT TRUE AND "ARINVDET"."__deleted" IS NOT TRUE
         AND "ARCUST"."__deleted" IS NOT TRUE
         AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')
       GROUP BY "ARCUST"."ID", "ARCUST"."L_NAME", trim("ARINVDET"."INVEN")
       ORDER BY revenue DESC LIMIT {max_rows}
9c. COUNTING SALES, ORDERS, OR INVOICES ACROSS A JOIN TO A DETAIL TABLE: when the user asks for a
   COUNT of sales, orders, invoices, or transactions and the query joins a header table ("ARINV")
   to a detail table ("ARINVDET"), use COUNT(DISTINCT "ARINV"."INVOICE"), never COUNT(*).
   COUNT(*) counts detail rows; one invoice routinely has several ARINVDET lines (e.g. a catering
   invoice's food, setup, and service charges as separate lines), so COUNT(*) overcounts. Use
   COUNT(*) only when the user explicitly asks for a count of line items or products sold, not a
   count of sales/orders/invoices.
     WRONG (a real reported bug -- the SUM was correct, the COUNT overcounted every invoice's
     multiple line items as separate sales):
       SELECT COUNT(*) AS sales_count, SUM("ARINVDET"."PRICE") AS total_revenue
       FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
       WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."INV_DATE" >= '{year}-01-01'
         AND "ARINV"."__deleted" IS NOT TRUE AND "ARINVDET"."__deleted" IS NOT TRUE
         AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')
     CORRECT (COUNT(DISTINCT ...) counts invoices, not detail rows):
       SELECT COUNT(DISTINCT "ARINV"."INVOICE") AS sales_count, SUM("ARINVDET"."PRICE") AS total_revenue
       FROM "{schema}"."ARINVDET" JOIN "{schema}"."ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
       WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."INV_DATE" >= '{year}-01-01'
         AND "ARINV"."__deleted" IS NOT TRUE AND "ARINVDET"."__deleted" IS NOT TRUE
         AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')

10. NEVER refuse a business question that can be answered from ARINV, ARINVDET, ARCUST, APINV, APVENDOR,
    PYTM, PYTMDET, PYEMP, INVENTRY, INVENWH, ARINVPMT, GLEDGER, GLT, or JCJB. When the user uses industry
    language, map it to the appropriate EBMS table and answer. Common mappings:
    - "sales" / "sales figures" / "sales orders" / "what did we sell" / "orders sold" = ARINV / ARINVDET --
      invoices ARE EBMS's sales records, there is no separate SALESHDR/SALESDET table. A plain "sales"
      question is always answerable this way; never refuse it as out of scope just because "sales" isn't
      a literal table name. This is a real, reported bug: the model never mapped "sales" to ARINV at all
      and refused "Include all sales dated in June 2026" outright with the generic "I can only answer
      questions about invoices, customers, inventory, or job status" fallback. Whether the resulting
      query should be a row list or an aggregate is governed entirely by rule 9 below, same as any other
      ARINV question -- this mapping only says WHICH TABLE, not what shape the SQL takes.
    - "menu items" / "products" / "SKUs" = INVENTRY / ARINVDET.INVEN
    - "user X" / "entered by" / "created by" / "keyed by" (a STAFF member, not a customer) = ARINV.USER_NAME,
      the EBMS login name that keyed the invoice (real values look like 'GERRY', 'JOLENE' - stored uppercase).
      Match it case-insensitively and on the stem, so a possessive or plural still matches: ILIKE '%Carolyn%'.
      "for user Carolyns" is a perfectly answerable question - filter on USER_NAME, never refuse it.
    - "collections" / "cash received" / "what came in" = ARINVPMT (excluding STATUS=4)
    - "spend" / "what we paid" / "vendor cost" = APINV WHERE STATUS IN ('O','X')
    - "payroll excluding expenses/mileage" = PYTM.G_PAY - PYTM.TOT_REIMB WHERE STATUS=2
    - "slowest payers" / "days to pay" / "average days to pay" = ARINV.CLOSE_DATE - ARINV.INV_DATE on STATUS='X' invoices,
      grouped by customer, averaged -- CLOSE_DATE and INV_DATE are PostgreSQL DATE fields; subtraction yields an integer (days).
      Use the integer directly: AVG("ARINV"."CLOSE_DATE" - "ARINV"."INV_DATE"). Do NOT wrap in EXTRACT(DAY FROM ...).
    - "gross margin" / "profitability" = use the margin recipe in BUSINESS ANALYTICS PATTERNS above
    - "what's dragging me down" / "least profitable products" = margin recipe grouped by ARINVDET.INVEN, ORDER BY margin % ASC
    - "bank balance" / "chart of accounts" / "GL account" / "balance in account X" = GLEDGER/GLT (see the
      GLEDGER/GLT/GLGLTRAN documentation above for the join and net-balance formula). This is a real,
      reported bug: a statement like "I can see a bank balance in the chart of accounts" got the bare
      generic refusal instead of being treated as an incomplete GL question. A GL/accounts statement or
      question that doesn't name which account is the SAME shape rule 6 above already covers for
      inventory ("in my count tab it says 89 on hand....") -- it is not out of scope, it is just missing
      which account. Ask a one-line clarifying question via CANNOT_QUERY rather than falling through to
      the generic bare refusal.
        WRONG:   CANNOT_QUERY
                 (bare refusal with no question, on "I can see a bank balance in the chart of accounts." --
                 the domain, GL account balances, is squarely answerable per this rule; the statement is
                 just missing which account)
        CORRECT: CANNOT_QUERY: Which account would you like the balance for?
      A revenue/expense CATEGORY phrase phrased as income or revenue booked in the ledger (not just an
      incomplete statement) is the SAME shape too -- "rental income", "service revenue", and similar
      income/revenue-account language map to GL revenue accounts in GLEDGER/GLT. Attempt
      "GLEDGER"."DESCR" ILIKE '%Rental%' (or the matching category word) restricted to
      "GLEDGER"."TYPE" = 'Revenue' first; only fall back to the clarifying question above if nothing
      matches. The TYPE filter matters: a word like "Rental" can also name an EXPENSE account (e.g.
      "Rental Expense"), which a bare DESCR match would wrongly pull in. A product-CATEGORY sales
      question (e.g. "parts sales", "catering sales") is NOT this GL path -- it still uses the
      ARINVDET + folder/description recipe documented elsewhere in this prompt. This is a real,
      reported bug: "rental income in August 2026" got the bare generic refusal instead of being
      resolved as a GL revenue-account question.
        WRONG:   CANNOT_QUERY (bare refusal on "rental income in August 2026")
        CORRECT (Revenue is credit-normal -- negate the debit-positive SUM, per the SIGN TRAP in the
                 P&L recipe, so income reads as a positive number):
                 SELECT -SUM(CASE WHEN "GLT"."DC"='D' THEN "GLT"."AMT" ELSE -"GLT"."AMT" END) AS rental_income
                 FROM "{schema}"."GLT"
                 JOIN "{schema}"."GLEDGER" ON "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT"
                 WHERE "GLEDGER"."DESCR" ILIKE '%Rental%'
                   AND "GLEDGER"."TYPE" = 'Revenue'
                   AND "GLT"."DATE" >= '{year}0801' AND "GLT"."DATE" <= '{year}0831'
                   AND "GLT"."__deleted" IS NOT TRUE AND "GLEDGER"."__deleted" IS NOT TRUE
11. COLUMN AMBIGUITY ACROSS JOINED TABLES: rule 7 already requires table-qualifying every column
    reference in a join. This applies even when a column name looks unique in the question -- several
    FoxPro-originated tables share the exact same column name (DESCR, DATE, CODE, AMT all recur across
    many tables). An unqualified reference to one of these fails with "column reference ... is
    ambiguous" the moment BOTH joined tables happen to have it, which isn't always obvious up front.
      WRONG (GLT and GLEDGER both have DESCR):
        SELECT "ACCOUNT", "DESCR", SUM(CASE WHEN "DC"='D' THEN "AMT" ELSE -"AMT" END) AS balance
        FROM "{schema}"."GLT" JOIN "{schema}"."GLEDGER" ON "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT"
        GROUP BY "ACCOUNT", "DESCR"
      CORRECT:
        SELECT "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR",
               SUM(CASE WHEN "GLT"."DC"='D' THEN "GLT"."AMT" ELSE -"GLT"."AMT" END) AS balance
        FROM "{schema}"."GLT" JOIN "{schema}"."GLEDGER" ON "GLT"."GL_CODE" = "GLEDGER"."ACCOUNT"
        GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR"
12. ORDER BY MUST NOT WRAP A SELECT-LIST ALIAS IN A FUNCTION OR A CASE EXPRESSION: Postgres only
    resolves a computed alias in ORDER BY when it is referenced bare (ORDER BY my_alias). Wrapping it
    in another function (ORDER BY ABS(my_alias), ROUND(my_alias,2), etc.) OR using it as an operand
    inside a CASE expression (ORDER BY CASE WHEN my_alias = 'x' THEN 1 ... END -- a CASE is not
    visually a "function call" but the same resolution rule applies to it) makes Postgres look for an
    actual table column of that name instead of the alias, and it fails with "column ... does not
    exist" even though the alias appears correctly in SELECT and GROUP BY. Repeat the full expression
    inside the function/CASE, or move the alias into a CTE/subquery and apply the function/CASE in the
    outer query.
      WRONG:
        SELECT "ARCUST"."ID", SUM("ARINV"."TOTAL") FILTER (WHERE ...) - SUM("ARINV"."TOTAL") FILTER (WHERE ...) AS change
        FROM ... GROUP BY "ARCUST"."ID"
        ORDER BY ABS(change) DESC
      CORRECT (CTE -- preferred once the expression is long, as it always is for a month-over-month diff):
        WITH base AS (
          SELECT "ARCUST"."ID",
                 SUM("ARINV"."TOTAL") FILTER (WHERE ...) - SUM("ARINV"."TOTAL") FILTER (WHERE ...) AS net_change
          FROM ... GROUP BY "ARCUST"."ID"
        )
        SELECT * FROM base ORDER BY ABS(net_change) DESC
      WRONG (alias used as an operand inside a CASE, not wrapped in an obvious function call -- same
      crash, same rule, real reported case 86e30t8n0: a "revenue tier" breakdown sorted the tier
      labels by re-testing the "revenue_tier" alias inside ORDER BY CASE WHEN):
        SELECT CASE WHEN total_revenue < 1000 THEN 'Under $1K' ... END AS revenue_tier, COUNT(*) AS n
        FROM (...) AS customer_revenue
        GROUP BY revenue_tier
        ORDER BY CASE WHEN revenue_tier = 'Under $1K' THEN 1 WHEN revenue_tier = '$1K - $5K' THEN 2 ELSE 3 END
      CORRECT (CTE so the alias becomes a real output column in the outer query, and the outer
      ORDER BY CASE tests that real column, not a re-derivation of the tier boundaries):
        WITH tiered AS (
          SELECT CASE WHEN total_revenue < 1000 THEN 'Under $1K' ... END AS revenue_tier, total_revenue
          FROM (...) AS customer_revenue
        )
        SELECT revenue_tier, COUNT(*) AS n
        FROM tiered
        GROUP BY revenue_tier
        ORDER BY CASE revenue_tier WHEN 'Under $1K' THEN 1 WHEN '$1K - $5K' THEN 2 ELSE 3 END
    A THIRD real, reported case (86e3g0ag6) -- an AR AGING BUCKET breakdown hit the identical crash,
    using the same alias-inside-CASE-in-ORDER-BY shape with different domain vocabulary than the
    revenue-tier example above:
      WRONG:
        SELECT
          CASE WHEN (CASE WHEN "ARINV"."DUE_DATE" = '1899-12-30' THEN "ARINV"."INV_DATE" ELSE "ARINV"."DUE_DATE" END) >= CURRENT_DATE THEN 'Current'
               WHEN (CASE WHEN "ARINV"."DUE_DATE" = '1899-12-30' THEN "ARINV"."INV_DATE" ELSE "ARINV"."DUE_DATE" END) >= CURRENT_DATE - INTERVAL '30 days' THEN '1-30 days'
               ELSE '31+ days' END AS aging_bucket,
          SUM("ARINV"."BALANCE") AS total_balance
        FROM "{schema}"."ARINV"
        WHERE "ARINV"."STATUS" = 'O' AND "ARINV"."__deleted" IS NOT TRUE
        GROUP BY aging_bucket
        ORDER BY CASE WHEN aging_bucket = 'Current' THEN 1 WHEN aging_bucket = '1-30 days' THEN 2 ELSE 3 END
      CORRECT (CTE, same fix as the revenue-tier example -- this shape recurs across any bucketed or
      tiered breakdown: aging, revenue tiers, age brackets, price bands, anything with a CASE-derived
      label the user wants in a specific, non-alphabetical order):
        WITH aged AS (
          SELECT
            CASE WHEN (CASE WHEN "ARINV"."DUE_DATE" = '1899-12-30' THEN "ARINV"."INV_DATE" ELSE "ARINV"."DUE_DATE" END) >= CURRENT_DATE THEN 'Current'
                 WHEN (CASE WHEN "ARINV"."DUE_DATE" = '1899-12-30' THEN "ARINV"."INV_DATE" ELSE "ARINV"."DUE_DATE" END) >= CURRENT_DATE - INTERVAL '30 days' THEN '1-30 days'
                 ELSE '31+ days' END AS aging_bucket,
            "ARINV"."BALANCE" AS balance
          FROM "{schema}"."ARINV"
          WHERE "ARINV"."STATUS" = 'O' AND "ARINV"."__deleted" IS NOT TRUE
        )
        SELECT aging_bucket, SUM(balance) AS total_balance
        FROM aged
        GROUP BY aging_bucket
        ORDER BY CASE aging_bucket WHEN 'Current' THEN 1 WHEN '1-30 days' THEN 2 ELSE 3 END
13. ROUND() WITH A DECIMAL-PLACES ARGUMENT REQUIRES ::numeric: PostgreSQL's two-argument
    ROUND(value, decimal_places) only accepts numeric -- not double precision. Sums, averages, and
    divisions over EBMS currency fields commonly come back as double precision (FoxPro-originated
    fields synced via cb2pg), so ROUND(this_month - last_month) / NULLIF(last_month,0) * 100, 2)
    raises "function round(double precision, integer) does not exist" the moment a percentage or
    ratio is rounded. Always cast the value being rounded: ROUND((expression)::numeric, 2).
      WRONG:   ROUND((this_month - last_month) / NULLIF(last_month, 0) * 100, 2) AS pct_change
      CORRECT: ROUND(((this_month - last_month) / NULLIF(last_month, 0) * 100)::numeric, 2) AS pct_change
      ALSO WRONG (cast applied to ROUND()'s own OUTPUT, not the value going INTO it -- this does
      NOT prevent the crash, since Postgres must resolve the ROUND(double precision, integer) call
      itself before an outer cast ever runs; confirmed live this still fails on a double-precision
      source, it only happens to look fine when the source is already numeric):
        ROUND((this_month - last_month) / NULLIF(last_month, 0) * 100, 2)::numeric AS pct_change
14. DELETED-ROW FILTERING IS NOT LIMITED TO THE TABLES CALLED OUT ABOVE: cb2pg marks every table it
    mirrors from FoxPro with a "__deleted" boolean column, including lookup/master tables (INVENTRY,
    APVENDOR, GLEDGER, JCJB, PYEMP, etc.), not only the transactional tables with their own DELETED
    ROWS note above. When a table's own entry above doesn't mention "__deleted" explicitly, still add
    WHERE "__deleted" IS NOT TRUE (or AND, if already inside a WHERE) for that table.
15. AN ALIAS MUST SIT OUTSIDE EVERY ENCLOSING FUNCTION CALL, AND EVERY OPENED PARENTHESIS MUST CLOSE:
    "AS alias_name" can only appear after every function call it names has been fully closed -- never
    inside an open ROUND(...), COALESCE(...), SUM(...), or any other call. Before returning any query
    with a computed or aggregated column, check that every "(" has a matching ")" and that no "AS"
    sits between an open paren and its close.
      WRONG:   ROUND(COALESCE(SUM("COUNT"), 0) / 6.0 * 2 AS reorder_quantity
               (alias placed inside an unclosed ROUND(COALESCE(...) -- both the misplaced alias and the
               missing closing parens cause a syntax error at or near "AS")
      CORRECT: ROUND((COALESCE(SUM("COUNT"), 0) / 6.0 * 2)::numeric, 0) AS reorder_quantity
16. A UNION / UNION ALL QUERY MAY HAVE AT MOST ONE ORDER BY, PLACED AFTER THE FINAL BRANCH, USING A
    POSITIONAL INDEX -- NEVER A COLUMN NAME OR ALIAS: Postgres allows exactly one ORDER BY on a
    compound UNION/UNION ALL statement, applying to the whole combined result, not one per branch --
    attaching it to an earlier branch is a syntax error. Even placed correctly at the very end, a bare
    column name or alias is unsafe: different branches often name the same output column differently
    (a literal 'TOTAL' row is a common case), and Postgres resolves that ORDER BY only against the
    final branch's own scope, not the union's combined output -- it fails with "column ... does not
    exist" the moment an earlier branch's name doesn't match. Use a positional index (ORDER BY 1)
    instead, which always refers to the combined output regardless of how each branch names it.
      WRONG (ORDER BY attached to the first branch, before UNION ALL -- syntax error at or near UNION):
        SELECT "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR", SUM(...) AS balance
        FROM "{schema}"."GLEDGER" LEFT JOIN "{schema}"."GLT" ON "GLEDGER"."ACCOUNT" = "GLT"."GL_CODE"
        WHERE "GLEDGER"."ACCOUNT" IN ('01100-000', '01000-000')
        GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR"
        ORDER BY "GLEDGER"."ACCOUNT"
        UNION ALL
        SELECT 'TOTAL', '', SUM(...) FROM "{schema}"."GLT" WHERE "GL_CODE" IN ('01100-000', '01000-000')
      ALSO WRONG (ORDER BY correctly at the very end, but a bare alias only the first branch
      resolves -- fails with "column \"account\" does not exist" the moment the branches disagree):
        SELECT "GLEDGER"."ACCOUNT" AS account, ... GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR"
        UNION ALL
        SELECT 'TOTAL' AS account, '' AS descr, SUM(...) AS balance FROM "{schema}"."GLT" WHERE ...
        ORDER BY account DESC
      CORRECT:
        SELECT "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR", SUM(...) AS balance
        FROM "{schema}"."GLEDGER" LEFT JOIN "{schema}"."GLT" ON "GLEDGER"."ACCOUNT" = "GLT"."GL_CODE"
        WHERE "GLEDGER"."ACCOUNT" IN ('01100-000', '01000-000')
        GROUP BY "GLEDGER"."ACCOUNT", "GLEDGER"."DESCR"
        UNION ALL
        SELECT 'TOTAL', '', SUM(...) FROM "{schema}"."GLT" WHERE "GL_CODE" IN ('01100-000', '01000-000')
        ORDER BY 1
    A THIRD common violation: using an expression -- a CASE statement, a function call, anything
    beyond a bare positional index -- in the final ORDER BY, even when it is correctly placed at
    the very end. Postgres rejects this too: "invalid UNION/INTERSECT/EXCEPT ORDER BY clause ...
    Only result column names can be used, not expressions or functions." This commonly shows up
    when the goal is to push a summary/total row to the end of the results. Do NOT reach for a CASE
    expression to do this -- add a literal marker column (e.g. 0 for real rows, 1 for a summary row)
    to every branch's SELECT list, and reference it by POSITION in ORDER BY, same as any other
    UNION ORDER BY column per the rule above.
      WRONG (CASE expression in the final ORDER BY -- syntax error, "Only result column names can
      be used, not expressions or functions" -- this rule already forbids bare column names for a
      separate reason, positions are the only form that always works, and this WRONG example's own
      "L_NAME", "F_NAME" are themselves bare column names, a second problem beyond the CASE
      expression):
        SELECT "PYEMP"."ID", "PYEMP"."F_NAME", "PYEMP"."L_NAME", SUM("PYTMDET"."HOURS") AS emp_hours
        FROM "{schema}"."PYTMDET" JOIN "{schema}"."PYEMP" ON "PYEMP"."ID" = "PYTMDET"."ID"
        WHERE "PYTMDET"."DATE" BETWEEN '2026-08-10' AND '2026-08-16'
          AND "PYTMDET"."__deleted" IS NOT TRUE AND "PYEMP"."__deleted" IS NOT TRUE
        GROUP BY "PYEMP"."ID", "PYEMP"."F_NAME", "PYEMP"."L_NAME"
        UNION ALL
        SELECT NULL, NULL, 'TOTAL', SUM("PYTMDET"."HOURS") FROM "{schema}"."PYTMDET"
        WHERE "PYTMDET"."DATE" BETWEEN '2026-08-10' AND '2026-08-16' AND "PYTMDET"."__deleted" IS NOT TRUE
        ORDER BY CASE WHEN "ID" IS NULL THEN 1 ELSE 0 END, "L_NAME", "F_NAME"
      CORRECT (a literal 0/1 marker column added to every branch, referenced positionally --
      real employee rows sort before the TOTAL row, then by last/first name within each group;
      the date range and __deleted filters from the driving question and rule 14 apply to both
      branches, PYEMP's only where PYEMP is actually joined):
        SELECT "PYEMP"."ID", "PYEMP"."F_NAME", "PYEMP"."L_NAME", SUM("PYTMDET"."HOURS") AS emp_hours,
               0 AS _sort_key
        FROM "{schema}"."PYTMDET" JOIN "{schema}"."PYEMP" ON "PYEMP"."ID" = "PYTMDET"."ID"
        WHERE "PYTMDET"."DATE" BETWEEN '2026-08-10' AND '2026-08-16'
          AND "PYTMDET"."__deleted" IS NOT TRUE AND "PYEMP"."__deleted" IS NOT TRUE
        GROUP BY "PYEMP"."ID", "PYEMP"."F_NAME", "PYEMP"."L_NAME"
        UNION ALL
        SELECT NULL, NULL, 'TOTAL', SUM("PYTMDET"."HOURS"), 1 FROM "{schema}"."PYTMDET"
        WHERE "PYTMDET"."DATE" BETWEEN '2026-08-10' AND '2026-08-16' AND "PYTMDET"."__deleted" IS NOT TRUE
        ORDER BY 5, 3, 2
      Note: a marker column like _sort_key becomes a real, visible column in the app's rendered
      result table unless something hides it -- wrap the UNION in a subquery to exclude it from
      user-visible output if that matters for the specific query.
    Also never place ORDER BY inside a CTE that only ever feeds a later SELECT/UNION as an
    intermediate step -- it has no effect there and Postgres does not guarantee it survives into the
    outer query. Omit it from any CTE body that has no LIMIT/OFFSET of its own. An ORDER BY paired
    with LIMIT/OFFSET inside a CTE IS meaningful (it selects which rows survive) -- keep that one.
17. A QUESTION WITH TWO LOGICALLY SEPARATE PARTS MUST BE ANSWERED WITH ONE SQL STATEMENT, NEVER TWO:
    a compound question like "who are my biggest customers, and what did they buy?" -- a ranking/
    top-N part ("who's on top") plus a detail part ("what did they do/buy/order") -- must be answered
    with exactly one SQL statement. This application rejects any generated SQL containing more than
    one top-level statement outright, before either half ever reaches the database -- two independent
    SELECT statements separated by a semicolon is never a valid answer, no matter how correct each
    half looks on its own; it always fails with an error instead of returning any result. Combine the
    two parts into a single statement instead: typically one CTE computing the ranking/aggregate part
    and a second CTE computing the per-entity detail part, joined together once in a final SELECT.
      WRONG (two independent top-level SELECT statements separated by ";" -- REJECTED before either
      one ever reaches the database; this app allows exactly one statement per query, regardless of
      how correct each half is on its own):
        SELECT "ARCUST"."ID", "ARCUST"."L_NAME", SUM("ARINV"."TOTAL") AS total_sales
        FROM "{schema}"."ARINV" JOIN "{schema}"."ARCUST" ON "ARCUST"."ID" = "ARINV"."ID"
        WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
          AND "ARINV"."INV_DATE" >= '2026-02-01'
        GROUP BY "ARCUST"."ID", "ARCUST"."L_NAME"
        ORDER BY total_sales DESC LIMIT 5;
        SELECT "ARINVDET"."INVEN", "INVENTRY"."DESCR_1", SUM("ARINVDET"."SHIP") AS total_qty
        FROM "{schema}"."ARINVDET" JOIN "{schema}"."INVENTRY" ON "ARINVDET"."INVEN" = "INVENTRY"."ID"
        JOIN "{schema}"."ARINV" ON "ARINVDET"."INVOICE" = "ARINV"."INVOICE"
        WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
          AND "ARINV"."INV_DATE" >= '2026-02-01'
          AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')
        GROUP BY "ARINVDET"."INVEN", "INVENTRY"."DESCR_1"
        ORDER BY total_qty DESC LIMIT 5
      CORRECT (one statement -- a ranking CTE and a detail CTE, joined once in a final SELECT,
      carrying rule 9b's own "_match_count"/"_match_total" grand-total columns since this is a
      grouped top-N row list; the date range, STATUS, and __deleted filters from the driving
      question and rules 3/14 apply inside both CTEs, and ARINVDET/INVENTRY/ARCUST each carry
      their own always-filter-__deleted requirement wherever they're actually read -- INVENTRY's
      check sits on its own LEFT JOIN's ON clause, not in WHERE, because a LEFT-joined table's
      filter in WHERE silently turns the join into an inner one and drops the whole line item the
      moment its matched inventory record happens to be deleted; ARINVDET and ARCUST are plain
      INNER JOINs here, so WHERE/ON is equally correct for them):
        WITH customer_totals AS (
          SELECT "ARINV"."ID", SUM("ARINV"."TOTAL") AS total_spent
          FROM "{schema}"."ARINV"
          WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
            AND "ARINV"."INV_DATE" >= '2026-02-01'
          GROUP BY "ARINV"."ID"
        ),
        customer_items AS (
          SELECT "ARINV"."ID", STRING_AGG(DISTINCT trim("INVENTRY"."DESCR_1"), ', ') AS items_purchased
          FROM "{schema}"."ARINV"
          JOIN "{schema}"."ARINVDET" ON "ARINV"."INVOICE" = "ARINVDET"."INVOICE"
          LEFT JOIN "{schema}"."INVENTRY" ON "ARINVDET"."INVEN" = "INVENTRY"."ID"
            AND "INVENTRY"."__deleted" IS NOT TRUE
          WHERE "ARINV"."STATUS" IN ('O','X') AND "ARINV"."__deleted" IS NOT TRUE
            AND "ARINV"."INV_DATE" >= '2026-02-01' AND "ARINVDET"."__deleted" IS NOT TRUE
          GROUP BY "ARINV"."ID"
        )
        SELECT ct."ID", "ARCUST"."L_NAME", ct.total_spent, ci.items_purchased,
               COUNT(*) OVER () AS "_match_count",
               SUM(ct.total_spent) OVER () AS "_match_total"
        FROM customer_totals ct
        JOIN "{schema}"."ARCUST" ON "ARCUST"."ID" = ct."ID" AND "ARCUST"."__deleted" IS NOT TRUE
        LEFT JOIN customer_items ci ON ci."ID" = ct."ID"
        ORDER BY ct.total_spent DESC LIMIT 5

QUERY TRANSLATION IS IN SCOPE (86e2en4dn). If the user pastes a query in another format (FoxPro/xBase
syntax, EBMS codebase query syntax, or plain-English pseudocode) and asks you to convert/translate it
to SQL, this is a valid request, not an out-of-scope one -- map the fields/tables to their cb2pg
equivalents in this EBMS schema and generate the equivalent PostgreSQL query, following every rule
above (SELECT-only, double-quoted "{schema}"."TABLE" qualification, etc.) the same as any other
question. If you cannot confidently map a field or table from the pasted query to a real column/table
in this schema, say so and ask which one is meant rather than refusing the whole request outright:
  CORRECT: CANNOT_QUERY: I can convert this, but I'm not sure what EBMS table/column
           "UserSuppliedField" in your pasted query corresponds to here -- can you tell me, or should
           I take my best guess?
  WRONG:   Bare CANNOT_QUERY (or "I can only answer questions that can be looked up in the EBMS
           database") treating a query-translation request as out of scope -- it is not. Converting an
           existing query against this same schema into PostgreSQL is exactly the kind of task this
           assistant should help with, and a follow-up like "that is the codebase query, convert it to
           SQL" refers back to whatever the user pasted earlier in THIS conversation -- resolve it from
           conversation history the same as any other reference, don't refuse for lack of a query to
           work from before checking history first.

UNDOCUMENTED CUSTOM TAB OR FIELD (86e3fgu59). If the user asks about a custom TAB (a whole UI page
or screen) they (or their EBMS admin) added to an item, customer, or other record -- something not in
the schema documented in this prompt -- and does NOT name a specific column, do not give the generic
"I can only answer questions..." refusal. There is no generic EBMS mechanism to discover a
custom-added tab from this schema; be specific and honest about that limit instead of guessing at a
table name. CARVE-OUT: if the user names a specific column (e.g. "INVENTRY.BC_ID_"), this rule does
NOT apply -- the earlier "THESE COLUMN LISTS ARE A DOCUMENTED BASELINE, NOT AN EXHAUSTIVE ONE" rule
wins: generate the query using exactly that column name and let Postgres decide. This rule only fires
for a vague tab reference with no column named.
It also does NOT apply to the standard documented tabs: the Purchasing tab (INVENDOR, above),
Serial Numbers (INRG) and Serial No. Specs (INRGDETD, INRGDETDF) are real tables in this prompt --
answer those from the data.
  WRONG:   "I can only answer questions that can be looked up in the EBMS database. Try asking about
           invoices, customers, inventory, GL accounts, payroll, or job status." (on "Can you find the
           tab in items called Insurance/Registration")
  CORRECT: CANNOT_QUERY: I can only query the standard EBMS schema I have documentation for, and a
           custom tab your team added isn't automatically visible to me. If you or your EBMS admin can
           tell me which table and column it's stored in, I can look it up directly. If you mean the
           Serial Numbers or Serial No. Specs tab of an item, I can look those up now -- tell me the item number.

NAVIGATION / "WHERE DO I FIND X" QUESTIONS (86e3fjfcy). A question about where to find a screen,
dialog, or feature in EBMS is not automatically out of scope, even though it isn't a data question on
its face. When IntraMind has real data that answers what the user actually wants to know, offer that
instead of guessing at an unverified menu path.
  WRONG:   "I can only answer questions that can be looked up in the EBMS database..." (on "This is a
           serialized item" / "Can't find the serialized item dialog")
  CORRECT: CANNOT_QUERY: I don't have EBMS's exact menu path for that, but I can look up the actual
           serial number(s) recorded for a specific item if you give me the item or unit ID -- would
           that help?

If the question cannot be answered with a read-only SQL query, return exactly: CANNOT_QUERY"""

FOLLOWUP_ANCHOR_TEXT = "When unsure whether a fork is material, answer with the documented default rather than asking."

# Renders via its own FOLLOWUP_RESOLUTION_RULES.format(schema=...) call in _build_prompt()
# below, separate from SYSTEM_PROMPT.format(...) -- the same brace-doubling rule applies
# here too (see CLAUDE.md's brace-escaping section).
FOLLOWUP_RESOLUTION_RULES = """

CONVERSATIONAL FOLLOW-UP RESOLUTION
History includes, for each prior turn that returned SQL, the SQL itself. When that turn's query
captured rows, those rows appear as a "[REFERENCE ONLY...]" block prefixed onto the message that
follows -- this describes data from a PAST turn for you to read; it was never something you wrote,
and it is not a template for your own output. Use it to resolve follow-ups that only make sense in
light of a prior turn. Trigger ONLY on an explicit cue in the CURRENT question -- never carry a
filter forward just because one is sitting in history.

YOUR OWN OUTPUT IS ALWAYS ONLY THE SQL QUERY -- never append a rows list, JSON block, or any
"[REFERENCE ONLY...]" annotation to your own answer. If you find yourself about to write anything
after a complete SQL statement, stop -- return only the statement.

(a) ANAPHORIC / EXCLUSION REFERENCE -- "them", "those", "those 2", "the list", "besides them":
This rule applies ONLY when a genuine prior turn exists in conversation history -- a single,
self-contained message that names its own exclusions directly (e.g. "X and Y aren't real
customers, take them off the list, then show me...") is NOT this case; that is a plain exclusion
already covered by the existing NULL-safe name-exclusion rule above and needs no history at all.

When a genuine prior turn exists, rebuild that turn's query, applying the requested exclusion. If
prior rows were captured, exclude the SPECIFIC entities they name. If no rows were captured (e.g.
prior turn was an aggregate) but the reference is by rank ("the top 2"), exclude the leading/
trailing N rows of that query's own ORDER BY via NOT IN or OFFSET.
  WRONG: given a genuine prior turn "top 10 customers by revenue" (rows captured: Fenwick Farms,
         JR Contracting were #1-2 by revenue), the follow-up "eliminate those 2 for now and
         recreate the top 10 without them" gets treated as an unanswerable standalone question and
         refused, instead of resolving "those 2" from the captured prior-turn rows.
  CORRECT: (same prior turn) SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINVDET"."PRICE") AS revenue,
          COUNT(*) OVER () AS "_match_count", SUM(SUM("ARINVDET"."PRICE")) OVER () AS "_match_total"
          FROM "{schema}"."ARINV" JOIN ... WHERE ... AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '') AND "ARCUST"."ID" NOT IN ('FENWICK','JRCONTR')
          GROUP BY "ARCUST"."ID","ARCUST"."L_NAME" ORDER BY revenue DESC LIMIT 10
  (FENWICK and JRCONTR above are illustrative placeholders for this documentation only -- never
  emit them in a real answer unless they genuinely appear in THIS conversation's own captured
  history rows.)
  RANK-BASED OFFSET NEEDS A TIE-BREAK -- when no rows were captured and you fall back to OFFSET
  by rank, the ORDER BY MUST append a deterministic tie-break column (the row's own ID/primary
  key) after the ranking column. Postgres gives no stable ordering guarantee among rows that TIE
  on the ranking column alone across two separate executions of the same ORDER BY -- rerunning
  with OFFSET can silently exclude DIFFERENT tied rows than the ones the user was actually shown,
  with no error surfaced.
    WRONG (if two customers tie for #9/#10 revenue, ties have no stable order across runs --
    OFFSET 2 may exclude two different tied customers than the ones actually shown in the
    original "top 10"):
      SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINVDET"."PRICE") AS revenue
      FROM "{schema}"."ARINV" JOIN ... WHERE ... AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')
      GROUP BY "ARCUST"."ID","ARCUST"."L_NAME" ORDER BY revenue DESC OFFSET 2 LIMIT 10
    CORRECT (tie-break on ID makes the ordering deterministic -- ranked in a CTE so
    "_match_count"/"_match_total" below describe every row remaining AFTER the top 2 are
    excluded (all of them, before LIMIT applies, per rule 9b), not the 2 excluded rows
    themselves; a window function computed directly alongside OFFSET/LIMIT would run BEFORE
    OFFSET trims the result, wrongly including those 2 excluded rows in the total instead):
      WITH ranked AS (
        SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINVDET"."PRICE") AS revenue,
               ROW_NUMBER() OVER (ORDER BY SUM("ARINVDET"."PRICE") DESC, "ARCUST"."ID") AS rn
        FROM "{schema}"."ARINV" JOIN ... WHERE ... AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '')
        GROUP BY "ARCUST"."ID","ARCUST"."L_NAME"
      )
      SELECT "ID","L_NAME", revenue,
             COUNT(*) OVER () AS "_match_count", SUM(revenue) OVER () AS "_match_total"
      FROM ranked WHERE rn > 2
      ORDER BY rn LIMIT 10

(b) BARE FRAGMENT / MODIFIER -- a location, "by revenue", "top 10", "last 90 days" with no subject of
its own: treat as a modifier ON TOP of the prior turn's core query -- same filters, plus this addition.
Never discard the prior subject and answer a broader, different question instead.
  WRONG:  Turn 1 filtered on a specific item ("16x7 insulated doors"); Turn 2: "how about in La Crete warehouse"
          -> SELECT SUM("COUNT"), COUNT(*) FROM "{schema}"."INVENWH" WHERE "WAREHOUSE" ILIKE '%la%crete%'
             (drops the item filter -- answers "how much is in that whole warehouse", not the real question)
  CORRECT: SELECT "INVENTRY"."ID","INVENTRY"."DESCR_1","INVENWH"."WAREHOUSE","INVENWH"."COUNT"
          FROM "{schema}"."INVENWH" JOIN "{schema}"."INVENTRY" ON "INVENWH"."ID" = "INVENTRY"."ID"
          WHERE "INVENTRY"."DESCR_1" ILIKE '%16x7%' AND "INVENTRY"."DESCR_1" ILIKE '%insulated%'
            AND "INVENWH"."WAREHOUSE" ILIKE '%la%crete%'
            AND "INVENTRY"."__deleted" IS NOT TRUE AND "INVENWH"."__deleted" IS NOT TRUE
  ("16x7 insulated doors" and La Crete above are illustrative placeholders for this documentation
  only -- never emit them in a real answer unless they genuinely appear in THIS conversation's own
  captured history rows or the current question.)

(c) CLARIFYING-QUESTION COMPLETION -- only if the immediately preceding assistant turn was itself a
clarifying question (CANNOT_QUERY, no SQL): the current fragment completes it. Combine with the
ORIGINAL question (the turn before the clarifying one).
  WRONG:  Turn 1: "Show me total sales by customer" -> model asks "how would you like this sorted?"
          Turn 2: "By revenue" -> CANNOT_QUERY: I can only answer questions... (re-refuses)
  CORRECT: SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINV"."TOTAL") AS revenue,
          COUNT(*) OVER () AS "_match_count", SUM(SUM("ARINV"."TOTAL")) OVER () AS "_match_total"
          FROM ... GROUP BY "ARCUST"."ID","ARCUST"."L_NAME" ORDER BY revenue DESC
  You asked the question -- you must use the answer. Never refuse or ask again.

(d) NON-INHERITANCE -- a self-contained current question (names its own entity/table plainly) must
NEVER inherit a filter from an earlier turn just because one is in history. Equal weight to (a)-(c) --
exists specifically so a topic switch isn't contaminated by a leftover filter.
  WRONG:  Turn 1: "What's my inventory in the La Crete warehouse?" -> WHERE "WAREHOUSE" ILIKE '%la%crete%'
          Turn 2: "What are my top 10 customers by revenue this year?"
          -> ... WHERE "WAREHOUSE" ILIKE '%la%crete%' AND ... (nonsensical carryover)
  CORRECT: SELECT "ARCUST"."ID","ARCUST"."L_NAME", SUM("ARINVDET"."PRICE") AS revenue,
          COUNT(*) OVER () AS "_match_count", SUM(SUM("ARINVDET"."PRICE")) OVER () AS "_match_total"
          FROM "{schema}"."ARINV" ... WHERE ... AND ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = '') GROUP BY ... ORDER BY revenue DESC LIMIT 10  (ignores the unrelated filter)
  (La Crete above is an illustrative placeholder for this documentation only -- never emit it in a
  real answer unless it genuinely appears in THIS conversation's own captured history rows or the
  current question.)

(e) "SAME TIME FRAME" IN A DIFFERENT YEAR -- comparing a prior turn's date-bounded result to an
equivalent window in another year: read the prior turn's own start/end MM-DD bounds and rebuild
TWO INDEPENDENTLY-BOUNDED windows, one per year. NEVER stretch a single WHERE range across both
years and rely on GROUP BY year/month to separate them afterward -- a single shared upper bound
only cuts off the NEWER year; the OLDER year's group then has nothing capping its far end, so it
silently includes every month past the intended cutoff while the newer year correctly stays
partial. The user sees two plausible-looking rows and a confident percentage-change narrative
with no indication one side covers a different number of months than the other.
  The two illustrations below use HYPOTHETICAL years (2026 and 2025). Never copy their literals
  into your query -- use the real prior turn's own MM-DD bounds and the real year the user named.
  Suppose the prior turn was bounded '2026-01-01' to '2026-07-31', and the follow-up asks to
  "compare that to the same time frame last year":
    WRONG:   SELECT EXTRACT(YEAR FROM "INV_DATE")::int AS year, SUM("TOTAL") AS revenue
             FROM "{schema}"."ARINV"
             WHERE "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
               AND "INV_DATE" >= '2025-01-01' AND "INV_DATE" <= '2026-07-31'
             GROUP BY EXTRACT(YEAR FROM "INV_DATE")
      (one shared range spanning both years -- the 2025 group silently includes August through
      December 2025 too, since nothing bounds its upper end; the 2026 group correctly stops at
      07-31, so the "two years" being compared are not actually the same length)
    CORRECT: SELECT EXTRACT(YEAR FROM "INV_DATE")::int AS year, SUM("TOTAL") AS revenue
             FROM "{schema}"."ARINV"
             WHERE "STATUS" IN ('O','X') AND "__deleted" IS NOT TRUE
               AND (("INV_DATE" >= '2026-01-01' AND "INV_DATE" <= '2026-07-31')
                 OR ("INV_DATE" >= '2025-01-01' AND "INV_DATE" <= '2025-07-31'))
             GROUP BY EXTRACT(YEAR FROM "INV_DATE")
  Note the OR of the two date ranges is wrapped in its own parentheses before being ANDed with
  STATUS/deleted/other filters -- the OR/AND-precedence rule elsewhere in this prompt applies
  here too; an unparenthesized OR here would (depending on which side loses precedence) either
  drop the STATUS/deleted filters for one year or silently pull in all-time data for it. A
  two-branch UNION ALL, each branch independently WHERE-bounded to its own year's matching MM-DD
  window, is an equally correct alternative to the OR form above.

(f) DOUBTED OR CHALLENGED RESULT -- the CURRENT message questions, doubts or asks to re-check a
figure from an earlier answer, with no new subject of its own: "I don't think these total 1,504,094",
"these don't add up", "that total looks wrong", "are you sure that's right?", "can you double check
that?". This is a follow-up on the most recent prior turn that returned SQL. It is NEVER out-of-scope,
and NEVER a reason to refuse or to ask a clarifying question -- the user is asking you to show your
work, and you can: re-run that prior turn's query, with the SAME filters, so the figures are freshly
computed and visible to them.
  - Prior turn was a row list: re-emit that query unchanged, keeping its rule 9b "_match_count"/
    "_match_total" columns (add them if the prior turn lacked them and it has one obviously summable
    money column).
  - Prior turn was a single-row aggregate (a bare total or count): return the rows that add up to it --
    same filters, one row per underlying invoice, line or customer -- with rule 9b's columns, so the
    user can check the pieces themselves. (This is the one case where rule 9's "never return only a bare
    row list for a number-shaped question" yields: the user asked to see the pieces.)
  - Prior turn was GROUPED (one row per customer, item, month...): keep its GROUP BY and use rule 9b's
    grouped form, SUM(SUM(...)) OVER () -- never a bare SUM(raw column) OVER (), which crashes.
  - A number the user quotes ("1,504,094") is a claim to check, never a filter: do NOT put it in a
    WHERE, HAVING or CASE, and never write SQL that tries to reproduce it.
  - Only when NO earlier turn in history returned SQL is there nothing to re-check; then treat the
    message as an ordinary question.
  WRONG:   Turn 1: "show me all sales since February 1st" -> an invoice list with a total.
           Turn 2: "I don't think these total 1,504,094"
           -> CANNOT_QUERY (refused as out-of-scope, no SQL, the user is left with nothing to check)
  WRONG:   Turn 2: "these don't add up" -> ... GROUP BY "ARINV"."NAME" HAVING SUM("ARINV"."TOTAL") = 1504094
           (the user's quoted figure used as a filter -- it answers a question nobody asked)
  CORRECT: (same Turn 1) Turn 2 re-runs Turn 1's query with the same WHERE and the total columns:
           SELECT "ARINV"."INVOICE","ARINV"."INV_DATE","ARINV"."NAME","ARINV"."TOTAL",
                  COUNT(*) OVER () AS "_match_count", SUM("ARINV"."TOTAL") OVER () AS "_match_total"
           FROM "{schema}"."ARINV"
           WHERE "ARINV"."INV_DATE" >= '2026-02-01' AND "ARINV"."STATUS" IN ('O','X')
             AND "ARINV"."__deleted" IS NOT TRUE
           ORDER BY "ARINV"."INV_DATE" DESC
           (plus whatever LIMIT the prior turn used)
  (The date, filters and figures above are illustrative placeholders for this documentation only --
  use the prior turn's own real filters, never these.)"""


# ---------------------------------------------------------------------------
# Warehouse-module detection (ticket 86e2kjgzw)
# ---------------------------------------------------------------------------
# INVENWH is EBMS's warehouse module -- it exists only on installs where that module is actually
# in use, not universally. Confirmed live: present with real per-warehouse rows on Ultimate Demo
# (warehouse module in use), absent entirely -- not just empty, the relation itself doesn't exist
# -- on both erintest0805:legacy and eagcan:legacy (neither uses the module). SYSTEM_PROMPT used to
# recommend INVENWH unconditionally, which 422'd on any inventory-quantity question for a
# non-warehouse-module customer. Checked once per schema and cached for the life of the process --
# a schema's table set doesn't change at runtime, the same assumption already made for
# MODULE_TABLES and for env vars only loading at process start.
_invenwh_presence_cache: dict[str, bool] = {}
_invenwh_presence_lock = Lock()


def _schema_has_invenwh(schema: str) -> bool:
    with _invenwh_presence_lock:
        if schema in _invenwh_presence_cache:
            return _invenwh_presence_cache[schema]
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    "SELECT 1 FROM information_schema.tables "
                    "WHERE table_schema = %s AND table_name = 'INVENWH' LIMIT 1",
                    (schema,),
                )
                exists = cur.fetchone() is not None
    except psycopg.Error as e:
        # Fail open to "present" -- this matches today's pre-fix behavior (always assumed
        # present) rather than introducing a new silent-degradation mode: a transient check
        # failure should not make a genuine warehouse-module customer's on-hand answers quietly
        # switch to INVENTRY.COUNT (which the SYSTEM_PROMPT itself says is 0 on those installs).
        log.error(f"INVENWH existence check failed for schema {schema!r}: {e}")
        exists = True
    with _invenwh_presence_lock:
        _invenwh_presence_cache[schema] = exists
    return exists


INVENWH_COUNT_CAVEAT_PRESENT = (
    "COUNT CAVEAT: this install uses EBMS's warehouse module -- INVENTRY.COUNT is 0 for every item "
    "and the real on-hand qty lives in INVENWH.COUNT\n"
    "    (per warehouse). Do NOT report on-hand from INVENTRY.COUNT without checking INVENWH - it "
    "yields false zeros here."
)
INVENWH_COUNT_CAVEAT_ABSENT = (
    "COUNT CAVEAT: this install does NOT use EBMS's warehouse module -- there is no INVENWH table "
    "at all (not just empty; referencing it errors). INVENTRY.COUNT is the correct, complete "
    "on-hand quantity here; never reference INVENWH on this install."
)

INVENWH_TABLE_BLOCK_PRESENT = (
    '"INVENWH" - Inventory quantities by warehouse (this install has it -- use it for on-hand quantities)\n'
    "  ID=item#, WAREHOUSE=warehouse code (see INWH for the code-to-city lookup), COUNT=on-hand qty for this warehouse, VALUE, LOCATION,\n"
    "  MIN_INVEN, MAX_INVEN, SALES_O=open sales orders, SALES_S=sales YTD\n"
    "  For inventory quantity questions: JOIN INVENWH to INVENTRY on ID, show WAREHOUSE and INVENWH.COUNT per warehouse.\n"
    "  If INVENWH has no rows for an item, do NOT fall back to INVENTRY.COUNT -- the COUNT CAVEAT above means\n"
    "    that field is unconditionally 0 here regardless of true stock. State plainly that this item has no\n"
    "    warehouse inventory record; never report a 0 on-hand quantity for it.\n"
    '  For items below minimum stock IN ONE SPECIFIC WAREHOUSE (the user named a warehouse/location):\n'
    '    WHERE "INVENWH"."COUNT" < "INVENWH"."MIN_INVEN"\n'
    '  For a general "what is low on stock" / "what needs reordering" question with NO warehouse named,\n'
    '    the user means the item\'s TOTAL across every warehouse, not any one warehouse row in isolation --\n'
    '    an item can look fine in each individual warehouse yet still be below its overall reorder point once\n'
    '    summed, and MIN_INVEN is set as a total-stock threshold, not a per-warehouse one. This means\n'
    '    comparing against an AGGREGATE (SUM across warehouses).\n'
    '  *** THE AGGREGATE COMPARISON MUST GO IN HAVING. NEVER IN WHERE. NO EXCEPTIONS, INCLUDING WHEN\n'
    '    THE AGGREGATE IS WRAPPED IN COALESCE(). *** "WHERE SUM(...) < ..." and\n'
    '    "WHERE COALESCE(SUM(...), fallback) <= ..." are BOTH invalid SQL (aggregate functions are not\n'
    '    allowed in WHERE, wrapping one in COALESCE() does not exempt it) and BOTH fail with the identical\n'
    '    syntax error. This is a real, repeatedly reported crash from exactly this mistake, on this exact\n'
    '    question, on two different customer installs (86e30rdy1, 86e30r9wa, 86e30t7q2, 86e30t7ey) -- if you\n'
    '    catch yourself about to write an aggregate or a COALESCE(aggregate, ...) anywhere inside a WHERE\n'
    '    clause for this question, stop and move that whole condition to HAVING instead. MIN_INVEN itself\n'
    '    does not vary by warehouse for a given item -- read it via MAX() (or MIN(), any one row\'s value works)\n'
    '    rather than including it in GROUP BY, since a plain GROUP BY on ID plus a non-grouped MIN_INVEN column\n'
    '    would itself error.\n'
    '      CORRECT:\n'
    '        SELECT "INVENTRY"."ID", "INVENTRY"."DESCR_1", SUM("INVENWH"."COUNT") AS total_on_hand,\n'
    '               MAX("INVENWH"."MIN_INVEN") AS min_inven\n'
    '        FROM "companyname:legacy"."INVENWH"\n'
    '        JOIN "companyname:legacy"."INVENTRY" ON "INVENWH"."ID" = "INVENTRY"."ID"\n'
    '        WHERE "INVENTRY"."INACTIVE" IS NOT TRUE AND "INVENTRY"."__deleted" IS NOT TRUE\n'
    '        GROUP BY "INVENTRY"."ID", "INVENTRY"."DESCR_1"\n'
    '        HAVING SUM("INVENWH"."COUNT") < MAX("INVENWH"."MIN_INVEN")\n'
    '      ALSO WRONG (the COALESCE() wrapper does NOT make an aggregate legal in WHERE -- same crash,\n'
    '      86e30t7ey: this exact query, this exact error):\n'
    '        SELECT "INVENTRY"."ID", COALESCE(SUM("INVENWH"."COUNT"), "INVENTRY"."COUNT") AS on_hand\n'
    '        FROM "companyname:legacy"."INVENWH" JOIN "companyname:legacy"."INVENTRY" ON ...\n'
    '        WHERE COALESCE(SUM("INVENWH"."COUNT"), "INVENTRY"."COUNT") <= COALESCE("INVENTRY"."MIN_INVEN", 999999)\n'
    '        GROUP BY "INVENTRY"."ID"\n'
    '      WRONG (aggregate in WHERE -- syntax error, not just wrong results):\n'
    '        SELECT "INVENTRY"."ID", SUM("INVENWH"."COUNT") AS total_on_hand\n'
    '        FROM "companyname:legacy"."INVENWH" JOIN "companyname:legacy"."INVENTRY" ON "INVENWH"."ID" = "INVENTRY"."ID"\n'
    '        WHERE SUM("INVENWH"."COUNT") < "INVENWH"."MIN_INVEN"\n'
    '        GROUP BY "INVENTRY"."ID"\n'
    '  Also exclude non-physical items from either recipe -- a service/subscription item can carry a stale\n'
    '    or meaningless MIN_INVEN and still surface as "low stock", which is misleading (86e30r9wa: a real,\n'
    '    reported case where 100% of a low-stock result turned out to be non-physical SKUs). INVENTRY has an\n'
    '    "C_TYPE" column (not in the documented baseline list above -- see the note near the top of this\n'
    '    prompt on undocumented columns; it is the same field ARINVDET.C_TYPE is copied from on each sale\'s\n'
    '    line item, described under ARINVDET below). If the user has not already told you this install\'s\n'
    '    C_TYPE convention for physical vs. non-physical items, query DISTINCT "C_TYPE" (and a few sample\n'
    '    DESCR_1 values per code) on INVENTRY first to confirm which codes are physical/trackable before\n'
    '    filtering by it -- do not assume the ARINVDET section\'s costing-group mapping (0/1/2/3/4) applies\n'
    '    unchanged to whether an item is physical stock; that mapping describes costing behavior, not\n'
    '    physical-vs-service status, and was not confirmed for this purpose.'
)
INVENWH_TABLE_BLOCK_ABSENT = (
    '"INVENWH" does not exist on this install -- do NOT reference it in any query, JOIN, or subquery.\n'
    "  There is no per-warehouse inventory breakdown here; use INVENTRY.COUNT directly for every "
    "on-hand-quantity question."
)


def _invenwh_prompt_fragments(has_invenwh: bool) -> tuple[str, str]:
    """Return (count_caveat, table_block) text for the current schema's warehouse-module status.

    Driven by a single boolean so the two fragments can never drift out of sync with each other.
    """
    if has_invenwh:
        return INVENWH_COUNT_CAVEAT_PRESENT, INVENWH_TABLE_BLOCK_PRESENT
    return INVENWH_COUNT_CAVEAT_ABSENT, INVENWH_TABLE_BLOCK_ABSENT


def _build_prompt(schema: str, today: str, weekday: str, year: int, fiscal_start_month: int,
                   last_fy_start: str, last_fy_end: str, current_fy_start: str, has_history: bool) -> str:
    """Render SYSTEM_PROMPT, splicing in the follow-up-resolution rules only when there is
    actual conversation history for them to apply to.

    A true first message in a conversation must never see this section at all -- not soft-gated
    by a scoping sentence, but physically absent from the rendered string. Live adversarial
    testing (docs/superpowers/specs/2026-08-01-followup-context-loss-design.md, section 5) showed
    that prose-only scoping could not stop the model pattern-matching on this section's own
    trigger words ("them", "the list") even on unrelated single-message questions; only removing
    the text entirely for empty-history requests eliminated the regression.

    A second condition also skips the splice: if FOLLOWUP_ANCHOR_TEXT is ever missing from the
    rendered prompt (e.g. a future edit to rule 6's wording), this logs an error and returns the
    un-spliced prompt rather than raising -- see the has_history branch below.
    """
    invenwh_count_caveat, invenwh_table_block = _invenwh_prompt_fragments(_schema_has_invenwh(schema))
    prompt = SYSTEM_PROMPT.format(schema=schema, max_rows=MAX_ROWS, today=today, weekday=weekday, year=year,
                                   fiscal_start_month=fiscal_start_month,
                                   last_fy_start=last_fy_start, last_fy_end=last_fy_end,
                                   current_fy_start=current_fy_start,
                                   invenwh_count_caveat=invenwh_count_caveat,
                                   invenwh_table_block=invenwh_table_block)
    if has_history:
        if FOLLOWUP_ANCHOR_TEXT not in prompt:
            # A bare `assert` here is stripped under `python -O`, which would make this check
            # silently disappear instead of failing loudly if the anchor text ever moves (it
            # already has once, in the 522eac4 date-resolution fix). Nothing in this project's
            # deploy path (service.py, install.ps1) uses -O today, but crashing every
            # history-bearing /query call is a worse failure mode than degrading to the
            # un-spliced prompt for the one request that hits this.
            log.error("FOLLOWUP_ANCHOR_TEXT not found in SYSTEM_PROMPT -- rule 6 wording changed upstream; skipping follow-up-resolution splice for this request")
            return prompt
        rules = FOLLOWUP_RESOLUTION_RULES.format(schema=schema)
        prompt = prompt.replace(FOLLOWUP_ANCHOR_TEXT, FOLLOWUP_ANCHOR_TEXT + rules, 1)
    return prompt

# ---------------------------------------------------------------------------
# Session store
# ---------------------------------------------------------------------------

SESSION_TTL = 8 * 3600  # 8 hours of inactivity
SESSIONS_MAX_KEYS = 10_000  # 86e31dqd5: same bounded-LRU reasoning as
    # _rate_data (86e2wmrha) -- a session created and never touched again
    # (closed tab, a device that never returns) previously lived in memory
    # for the process's whole lifetime. Bounds session count regardless of
    # how many valid logins occur, with no behavior change for any session
    # under the cap.

_sessions: "OrderedDict[str, dict]" = OrderedDict()
_sessions_lock = Lock()

def _create_session(username: str, full_name: str, permissions: dict, schema: str) -> str:
    token = secrets.token_urlsafe(32)
    now = time.time()
    with _sessions_lock:
        _sessions[token] = {
            "username": username,
            "full_name": full_name,
            "permissions": permissions,
            "schema": schema,
            "created_at": now,
            "last_seen": now,
        }
        _sessions.move_to_end(token)
        while len(_sessions) > SESSIONS_MAX_KEYS:
            _, evicted_sess = _sessions.popitem(last=False)
            log.warning(f"Session evicted (LRU cap {SESSIONS_MAX_KEYS} reached): user={evicted_sess.get('username')!r}")
    return token

def _touch_session(token: str) -> dict | None:
    now = time.time()
    with _sessions_lock:
        sess = _sessions.get(token)
        if sess is None:
            return None
        if now - sess["last_seen"] > SESSION_TTL:
            del _sessions[token]
            return None
        sess["last_seen"] = now
        _sessions.move_to_end(token)
        return dict(sess)

def _delete_session(token: str):
    with _sessions_lock:
        _sessions.pop(token, None)

# ---------------------------------------------------------------------------
# Permission helpers
# ---------------------------------------------------------------------------

MODULE_TABLES = {
    # GLT is the posted general ledger and MUST be listed here -- enforce_permissions() skips any
    # table absent from this map, so omitting GLT let a user with "No Access" to GL read the
    # entire ledger through it. The *GLTRAN entries are the unposted staging queues.
    "GL": {"GLEDGER", "GLT", "GLGLTRAN", "GLCTL", "GLJRN", "GLBANKTRAN", "GLACHTRAN",
           "GLRECONCILIATION", "GLTREE",
           "ARGLTRAN", "APGLTRAN", "PYGLTRAN", "INGLTRAN", "JCGLTRAN", "DPGLTRAN"},
    "AR": {"ARINV", "ARINVDET", "ARCUST", "ARINVPMT", "ARINVPMTDET", "ARJRN", "ARSALESP", "ARQT",
           "ARINVRETN", "ARJRNDET", "ARQTRSN", "ARCUSTRE"},
    "AP": {"APINV", "APINVDET", "APVENDOR", "APJRN", "APVENTRE"},
    "IN": {"INVENTRY", "INVENWH", "INTRAN", "INJRN", "INLOCATION", "INLOCATIONTRE", "INOPTION",
           "INVENTRE", "INWH", "INRG", "INREDET", "INRGMFG", "INVENDOR", "INRGDETD", "INRGDETDF"},
    "PY": {"PYTM", "PYTMDET", "PYEMP", "PYPAYP", "PYJRN", "PYEMPTRE"},
    # JCTM never existed in EBMS (Known_Issues.md #35, 86e2t0fwv, found 2026-08-12) -- confirmed via
    # list_tables(prefix="JC")/get_table_schema. Replaced with JCJRNDET (real, carries JOB_ID) below.
    "JC": {"JCJB", "JCJBSTAT", "JCJRN", "JCJRNDET", "JCJBTRE"},
    # DP = Fixed Assets (confirmed via the USERS table's own schema description, which documents
    # DP as the Fixed Assets permission column alongside GL/AP/AR/IN/PY/JC). DPGLTRAN stays under
    # GL above with its *GLTRAN siblings -- unposted staging queues are gated by GL, not by the
    # module that fed them.
    # DPASSET and its siblings (added for Known_Issues.md #36, 86e2t0fxf, found 2026-08-12) were
    # missing entirely -- same silent-bypass shape as the original GLT/USERS gap: any table
    # SYSTEM_PROMPT references but MODULE_TABLES doesn't map skips enforce_permissions() outright.
    # Confirmed real via get_table_schema/list_tables (prefix=DP): DPASCID (a GL posting-template
    # config table, not fixed-asset data) is deliberately left out of this set, same treatment as
    # RPTTREE/GLCURR above -- it isn't documented in SYSTEM_PROMPT and isn't DP business data.
    "DP": {"DPJRN", "DPASSET", "DPASMET", "DPASMETD", "DPASTRE", "DPMETDET", "DPMETHOD",
           "DPOPTION", "DPJRNDET"},
    # RPTTREE is deliberately NOT mapped to any module: it's the cross-module report-folder
    # catalog (confirmed via search_ebms -- report folder names can reference any module's reports,
    # e.g. a GL folder name showing up inside an AR user's report tree). Forcing it under one
    # module would either over-restrict (a GL-only user couldn't see AR's report folder names) or
    # under-restrict (an AR user could browse GL's folder tree via this table). It holds folder
    # labels, not business data, so leaving it unrestricted is the safer default over guessing.
    #
    # GLCURR/GLCURREXCH are ALSO deliberately NOT mapped to any module (ClickUp 86e2n66g5):
    # despite the GL-prefixed name, neither holds ledger transactions or balances -- GLCURR is
    # the currency master (it also carries GL account-code references, bare account-code strings,
    # no balances or descriptions) and GLCURREXCH is its exchange-rate history. The multi-currency
    # rule always reads GLCURR.BASE_CURR to derive the domestic currency code for ORDINARY AR/AP
    # questions that have nothing to do with GL -- mapping GLCURR to "GL" meant any GL-restricted
    # user got a hard 403 on a plain AR/sales question just because its SQL happened to also touch
    # this table. GLCURR/GLCURREXCH were mapped to "GL" purely by table-name-prefix convention
    # (e5663c6), inheriting the same unexamined assumption GLCTL originally had (see below).
    #
    # GLCTL is NOT an exception -- it is fully gated under "GL" above, like every other real
    # ledger-adjacent table in this set. It was unmapped once (86e2n66g5) to fix the same
    # GL-restricted-user 403 as GLCURR above, but GLCTL turned out to be a wide (98-column, on
    # real installs) company control record with several sensitive-looking columns (SSEMPID --
    # employer tax ID; CRM_SLOGIN/CRM_SEMAIL -- looks like a CRM login credential; DOC_PATH;
    # WEBHOOK_IV/TS/DL; XC_LICENSE), confirmed via a live information_schema query. A column-level
    # allowlist attempt to gate AI access to just the 3 legitimate columns (RESTRICTED_COLUMN_TABLES,
    # commit 8127d94) was found, on review, to have multiple confirmed live bypasses (alias.*,
    # quoted-table.*, to_jsonb(row), a SQL comment before *) -- regex-based detection of "does this
    # SQL read every column of this table" is an open-ended, unwinnable surface against arbitrary
    # SQL shapes. The actual fix: the fiscal-year start month is now resolved server-side
    # (_fiscal_start_month()) and injected into the prompt as a literal, so the model has no
    # documented reason to reference GLCTL in generated SQL -- and if it ever does anyway, the GL
    # permission gate above blocks it, since GLCTL is fully re-gated under "GL" (see below). See
    # the DATE & CALENDAR PERIOD RESOLUTION rule (g) section of SYSTEM_PROMPT. Real ledger data
    # (GLT, GLGLTRAN, GLJRN, GLBANKTRAN, GLACHTRAN, GLRECONCILIATION, GLTREE, all *GLTRAN staging
    # tables, and now GLCTL) stays gated under "GL".
}

# Map each table to the module that owns it
_TABLE_TO_MODULE: dict[str, str] = {
    tbl: mod for mod, tables in MODULE_TABLES.items() for tbl in tables
}

# Tables that must never be readable via the AI query engine, regardless of any module
# permission. USERS holds login credentials (PASSWORD) and is not conceptually owned by any
# single GL/AR/AP/IN/PY/JC/DP permission the way business tables are -- a MODULE_TABLES entry
# would let a user with access to that module read password data. Block it unconditionally
# instead of gating it on a permission that was never meant to guard credentials.
HARD_BLOCKED_TABLES = {"USERS"}


def get_user_permissions(username: str, schema: str | None = None) -> dict | None:
    """
    Query USERS table for the given username (already uppercased by caller).
    Returns a dict of module -> permission string, or None if user not found/
    inactive/deleted (a successful query with no matching row).

    Raises psycopg.Error on a genuine DB failure -- callers must NOT treat
    that the same as "not found" (86e2t0g50/CR-20: a transient DB blip
    during verify_session()'s per-request re-check must not force-log-out
    every active user). verify_session() catches this explicitly and
    returns a retryable 503 without deleting the session. login()'s two
    call sites deliberately do NOT catch it -- it propagates to the
    global exception handler (86e2rryv8) as a generic 500, which is
    correct: a DB error during login must never look like a successful
    login (the TEST_LOGIN_PASSWORD branch's admin-fallback) or a wrong
    password.
    """
    schema = schema or _default_schema()
    sql = f"""
        SELECT "FULL_NAME", "PASSWORD", "GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES"
        FROM "{schema}"."USERS"
        WHERE "NAME" = %s
          AND "INACTIVE" IS NOT TRUE
          AND "__deleted" IS NOT TRUE
        LIMIT 1
    """
    with get_conn() as conn:
        with conn.cursor() as cur:
            cur.execute(sql, (username,))
            row = cur.fetchone()
    if row is None:
        return None
    return dict(row)

_TRAILING_LIMIT_RE = re.compile(r"\bLIMIT\s+(\d+)\s*;?\s*$", re.IGNORECASE)


def _bump_trailing_limit(sql: str, cap: int) -> str:
    """Raise a trailing LIMIT by one so a truncation probe row can be fetched.

    Only rewrites when the limit is at or above `cap`. A smaller limit is user
    intent -- "my top 5 customers" produces LIMIT 5, and bumping that would hand
    back a sixth row nobody asked for. A LIMIT inside a subquery or CTE is not in
    trailing position and is never touched; rewriting it would change the result.
    When nothing matches, the fetchmany(cap + 1) backstop in /query still detects
    truncation, so returning `sql` unchanged is always safe.
    """
    m = _TRAILING_LIMIT_RE.search(sql)
    if not m:
        return sql
    n = int(m.group(1))
    if n < cap:
        return sql
    return sql[: m.start(1)] + str(n + 1) + sql[m.end(1) :]


# Columns that are part of the standard EBMS schema (documented in SYSTEM_PROMPT above) but
# confirmed, on at least one real customer install, to be absent from that install's cb2pg
# mirror -- module/feature-dependent on the FoxPro side, not a model hallucination. A "column
# does not exist" error on one of these, with no Postgres HINT pointing at an alternative, is
# handled by stripping every reference to it and retrying once, rather than 422ing outright.
# CURR_ID was the original, one-off version of this handling; VALUE (INVENWH -- ticket
# 86e27h0eh, Apex Overhead Doors) is a second confirmed instance of the exact same shape, which
# is why this was generalized instead of adding a second hardcoded special case.
KNOWN_OPTIONAL_COLUMNS = {"CURR_ID", "VALUE"}

_UNDEFINED_COLUMN_SQLSTATE = "42703"
_MISSING_COLUMN_RE = re.compile(r'column\s+"?([A-Za-z0-9_.]+)"?\s+does not exist', re.IGNORECASE)
_HINT_COLUMN_RE = re.compile(r'Perhaps you meant to reference the column "([A-Za-z0-9_.]+)"\.')


def _missing_column_name(err_message: str) -> str | None:
    """Extract the bare (unqualified) column name from a 'column ... does not exist' error.

    Postgres's own message_primary takes two different shapes depending on whether the SQL
    qualified the column: 'column "L_NAM" does not exist' (bare) or 'column ARCUST.L_NAM does
    not exist' (table-qualified, unquoted) -- confirmed live against real Postgres 17, both
    forms handled by the same pattern.
    """
    m = _MISSING_COLUMN_RE.search(err_message)
    if not m:
        return None
    return m.group(1).split(".")[-1]


def _hint_column_name(hint: str | None) -> str | None:
    """Extract the column name Postgres's own HINT suggests instead, if any.

    Only present when Postgres finds a close-match column name via its own trigram similarity
    search (e.g. NXT_STP_ -> NXT_STOP_, ticket 86e1x3e04) -- confirmed live there is no hint at
    all when no plausible match exists, which is exactly when KNOWN_OPTIONAL_COLUMNS applies
    instead.
    """
    if not hint:
        return None
    m = _HINT_COLUMN_RE.search(hint)
    if not m:
        return None
    return m.group(1).split(".")[-1]


def _strip_column(sql: str, column_name: str) -> str:
    """Remove all references to column_name from SQL, for installs where it doesn't exist.

    Handles both a bare reference ("COLUMN") and a table-qualified one ("TABLE"."COLUMN") --
    rule 7 requires the model to table-qualify every column in a join, so a qualified reference
    is the common case, not the exception. Stripping only the bare "COLUMN" part and leaving a
    dangling "TABLE". prefix behind produces invalid SQL (confirmed live: found and fixed this
    exact bug while verifying the retry mechanism against real Postgres this session).
    """
    col = re.escape(column_name)
    qualified = rf'(?:"[A-Za-z0-9_]+"\.)?"{col}"'
    # Remove AND/OR conditions referencing the column (handles IS NULL, =, <>, LIKE patterns)
    sql = re.sub(rf'\s+AND\s*\([^)]*{qualified}[^)]*\)', '', sql, flags=re.IGNORECASE)
    sql = re.sub(rf'\s+OR\s*\([^)]*{qualified}[^)]*\)', '', sql, flags=re.IGNORECASE)
    sql = re.sub(rf'\s+AND\s+{qualified}\s*[^\n,)]+', '', sql, flags=re.IGNORECASE)
    sql = re.sub(rf',?\s*{qualified}', '', sql, flags=re.IGNORECASE)
    return sql.strip()

#  Confirmed real, via search_ebms's own "Security Levels" Crystal Report formula (which
# itself falls back to a numeric "7" tier -- below even "No Access" -- for anything that
# doesn't match one of these). Used only to decide whether an unrecognized value is worth a
# log.warning(), not to gate access -- see enforce_permissions()'s own comment for why an
# unrecognized value still ALLOWS rather than denies.
_KNOWN_PERMISSION_LEVELS = {"Administrator", "Manager", "Advanced Entry", "Basic Entry", "Viewer", "No Access"}


def enforce_permissions(permissions: dict, sql: str):
    """Raise 403 if the SQL touches a table the user has No Access to (or a missing/NULL/
    empty permission value -- see below)."""
    # Extract quoted uppercase table names from the SQL
    tables_in_query = set(re.findall(r'"([A-Z][A-Z0-9_]+)"', sql))
    for table in tables_in_query:
        if table in HARD_BLOCKED_TABLES:
            raise HTTPException(
                status_code=403,
                detail=f"Access to {table} is not permitted."
            )
        mod = _TABLE_TO_MODULE.get(table)
        if mod is None:
            continue
        perm = permissions.get(mod)
        # Fail CLOSED, not open (86e2rryxe): the old check was `perm == "No Access"`, an
        # exact-match denylist -- a missing key, a real Postgres NULL for that module column,
        # or an empty string (the same NULL-vs-'' hazard that's already bitten ARCUST.F_NAME,
        # ARINVDET.PAR_TIME, ARINV.SALESMAN on other tables) all fell through to "allowed".
        if not perm or perm == "No Access":
            raise HTTPException(
                status_code=403,
                detail=f"You do not have access to the {mod} module."
            )
        if perm not in _KNOWN_PERMISSION_LEVELS:
            # Genuinely unrecognized (non-empty, not "No Access") -- allow rather than lock
            # out a real customer over a security-level label this codebase has never seen
            # (EBMS installs can plausibly customize these), but make it visible instead of
            # silent, matching this project's own "loud Warn() over a silent fallback" lesson.
            log.warning(
                f"Unrecognized permission value {perm!r} for module {mod!r} -- allowing "
                f"(does not match any known EBMS security level)."
            )

def _password_matches(input_password: str, stored_password: str) -> bool:
    """
    Compare a submitted password against a USERS.PASSWORD value read from Postgres.

    Older EBMS builds store this value FoxPro-style, each ASCII byte offset by +128
    (migrated to Postgres as Latin-1). Newer EBMS builds write plain ASCII instead.
    Check both encodings since a customer's EBMS version determines which applies --
    both comparisons always run (no short-circuit) to avoid a timing side-channel.
    """
    # 86e31dqdr: run a dummy compare_digest call before the empty-password early
    # return, so "user not found" doesn't skip comparison work entirely the way
    # it used to. This REDUCES, not eliminates, the timing asymmetry between
    # this path and a real wrong-password comparison: this dummy call compares
    # against a fixed 1-byte value, while the real path below runs two
    # compare_digest calls against the actual stored-password length, and
    # compare_digest short-circuits on a length mismatch (documented CPython
    # behavior) -- so the two paths still differ by roughly 2-8x in comparison
    # cost alone, just not by "zero comparisons vs. two". In practice this
    # residual asymmetry (tens to low hundreds of nanoseconds) is not the
    # observable signal here anyway -- it's dwarfed by the USERS table lookup
    # that precedes this call, which is the actually-dominant, still-unaddressed
    # timing difference between a real and a nonexistent username.
    _ = secrets.compare_digest(input_password.encode("latin-1", errors="ignore"), b"\x00")
    if not stored_password:
        return False
    stored_encoded = stored_password.encode("latin-1")
    plain_encoded = input_password.encode("latin-1", errors="ignore")
    plain_match = secrets.compare_digest(plain_encoded, stored_encoded)
    try:
        shifted_encoded = bytes(ord(c) + 0x80 for c in input_password)
    except ValueError:
        # ord(c) + 0x80 > 255 for some input characters (e.g. accented letters, emoji) --
        # such a password can never match a shifted value, reject rather than crash.
        shifted_match = False
    else:
        shifted_match = secrets.compare_digest(shifted_encoded, stored_encoded)
    return plain_match | shifted_match


def is_password_weak(password: str) -> bool:
    if len(password) < 8:
        return True
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(c in string.punctuation for c in password)
    return not (has_upper and has_lower and has_digit and has_special)

# ---------------------------------------------------------------------------
# Auth
# ---------------------------------------------------------------------------

security = HTTPBearer()

# ---------------------------------------------------------------------------
# Terms acceptance (docs/superpowers/specs/2026-10-14-tos-acceptance-design.md)
# ---------------------------------------------------------------------------

_ACCEPTANCES_PATHS = [
    Path(r"C:\ProgramData\IntraMind\acceptances.jsonl"),
    Path(__file__).parent / "acceptances.jsonl",
]
_DELIVERED_PATHS = [
    Path(r"C:\ProgramData\IntraMind\acceptances_delivered.jsonl"),
    Path(__file__).parent / "acceptances_delivered.jsonl",
]
_acceptance_lock = Lock()
_acceptance_records: list[dict] = []
_accepted_keys: set[tuple[str, str, str]] = set()
_delivered_ids: set[str] = set()
_acceptances_loaded = False

_ACCEPTANCE_STR_FIELDS = ("id", "username", "schema", "terms_version", "accepted_at")


def _append_jsonl(paths: list, obj: dict) -> None:
    """Append one JSON line and fsync it. Tries each path in order; raises OSError if none is writable."""
    line = json.dumps(obj, ensure_ascii=False).encode("utf-8") + b"\n"
    for p in paths:
        try:
            with open(p, "ab+") as f:
                # A power cut can leave a last line with no newline; start on a fresh line so the new record is intact.
                size = f.seek(0, os.SEEK_END)
                prefix = b""
                if size:
                    f.seek(size - 1)
                    if f.read(1) != b"\n":
                        prefix = b"\n"
                f.write(prefix + line)  # append mode: always lands at the end
                f.flush()
                os.fsync(f.fileno())
            return
        except OSError:
            continue
    raise OSError(f"no writable path for {paths[0].name}")


def _read_jsonl_lines(paths: list) -> tuple[list[str], bool]:
    """(lines, readable). The first path that exists wins. No file at all is readable and empty (a new install).
    Any other read error is NOT readable: the caller must fail closed."""
    for p in paths:
        try:
            raw = p.read_bytes()
        except FileNotFoundError:
            continue
        except OSError as e:
            log.error(f"Terms acceptance: cannot read {p.name}: {e}")
            return [], False
        # Split on b"\n" only: str.splitlines() also splits on U+2028, U+2029 and \x85, which json.dumps
        # (ensure_ascii=False) writes raw, and would break a record in two. Decode per line with "replace" so a
        # torn multi-byte tail cannot raise UnicodeDecodeError; the replacement character makes that line fail
        # its own JSON parse and it is skipped by the caller.
        lines = []
        for chunk in raw.split(b"\n"):
            if chunk.endswith(b"\r"):
                chunk = chunk[:-1]
            if chunk:
                lines.append(chunk.decode("utf-8", errors="replace"))
        return lines, True
    return [], True


def _reset_acceptance_state() -> None:
    """Forget the in-memory state so the next call reloads from disk (a restart, in tests)."""
    global _acceptances_loaded
    with _acceptance_lock:
        _acceptance_records.clear()
        _accepted_keys.clear()
        _delivered_ids.clear()
        _acceptances_loaded = False


def _ensure_acceptances_loaded_locked() -> bool:
    """Caller holds _acceptance_lock. False means the acceptance file is unreadable (fail closed, retried next call)."""
    global _acceptances_loaded
    if _acceptances_loaded:
        return True
    lines, readable = _read_jsonl_lines(_ACCEPTANCES_PATHS)
    if not readable:
        return False
    records, keys = [], set()
    for line in lines:
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            log.warning("Terms acceptance: skipping an unparseable line in the acceptance file")
            continue
        if (not isinstance(rec, dict) or isinstance(rec.get("seq"), bool) or not isinstance(rec.get("seq"), int)
                or not all(isinstance(rec.get(k), str) for k in _ACCEPTANCE_STR_FIELDS)):
            log.warning("Terms acceptance: skipping a malformed record in the acceptance file")
            continue
        records.append(rec)
        keys.add((rec["username"], rec["schema"], rec["terms_version"]))
    delivered_lines, _ = _read_jsonl_lines(_DELIVERED_PATHS)  # unreadable delivered file = resend, which is harmless
    delivered = set()
    for line in delivered_lines:
        try:
            d = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(d, dict) and isinstance(d.get("id"), str):
            delivered.add(d["id"])
    _acceptance_records[:] = records
    _accepted_keys.clear()
    _accepted_keys.update(keys)
    _delivered_ids.clear()
    _delivered_ids.update(delivered)
    _acceptances_loaded = True
    return True


def _terms_gate_ok(sess: dict) -> bool:
    """True when this session's user has accepted the Terms for the running VERSION."""
    with _acceptance_lock:
        if not _ensure_acceptances_loaded_locked():
            return False
        return (sess.get("username", ""), sess.get("schema", ""), VERSION) in _accepted_keys


def record_acceptance(username: str, schema: str) -> dict:
    """Append (and fsync) an acceptance record for the running VERSION. Idempotent per (user, schema, VERSION).
    Raises OSError when the file cannot be read or written; the caller must then leave the user blocked."""
    key = (username, schema, VERSION)
    with _acceptance_lock:
        if not _ensure_acceptances_loaded_locked():
            raise OSError("acceptance log unreadable")
        if key in _accepted_keys:
            for rec in reversed(_acceptance_records):
                if (rec["username"], rec["schema"], rec["terms_version"]) == key:
                    return dict(rec)
        rec = {
            "seq": max((r["seq"] for r in _acceptance_records), default=0) + 1,
            "id": str(uuid.uuid4()),
            "username": username,
            "schema": schema,
            "terms_version": VERSION,
            "accepted_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        }
        _append_jsonl(_ACCEPTANCES_PATHS, rec)
        _acceptance_records.append(rec)
        _accepted_keys.add(key)
        return dict(rec)


def _undelivered_acceptances() -> list[dict]:
    with _acceptance_lock:
        if not _ensure_acceptances_loaded_locked():
            return []
        return [dict(r) for r in _acceptance_records if r["id"] not in _delivered_ids]


def _mark_delivered(rec_id: str) -> None:
    with _acceptance_lock:
        if rec_id in _delivered_ids:
            return
        _append_jsonl(_DELIVERED_PATHS, {"id": rec_id})
        _delivered_ids.add(rec_id)


def _acceptances_after(after: int, limit: int) -> tuple[list[dict], int]:
    """Records with seq > after, oldest first, at most `limit`, plus the highest seq held."""
    with _acceptance_lock:
        if not _ensure_acceptances_loaded_locked():
            return [], 0
        ordered = sorted(_acceptance_records, key=lambda r: r["seq"])
        latest = ordered[-1]["seq"] if ordered else 0
        return [dict(r) for r in ordered if r["seq"] > after][:limit], latest


PORTAL_URL = (os.getenv("EBMS_LIVE_PORTAL_URL") or "https://portal.intramind.ca").rstrip("/")
_PUSH_IDLE_SECONDS = 10
_PUSH_BACKOFF_START = 60
_PUSH_BACKOFF_MAX = 900


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    """Never follow a redirect: a 3xx must not count as delivery and must not forward the token."""
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_NO_REDIRECT_OPENER = urllib.request.build_opener(_NoRedirect)


def _post_acceptance(rec: dict) -> bool:
    """POST one record to the admin portal. True only on a 2xx. Never raises."""
    req = urllib.request.Request(
        f"{PORTAL_URL}/api/acceptances",
        data=json.dumps(rec).encode("utf-8"),
        method="POST",
        headers={
            "Content-Type": "application/json",
            "X-Portal-Token": PORTAL_TOKEN or "",
            "User-Agent": f"IntraMind/{VERSION}",  # Cloudflare blocks the default Python-urllib agent
        },
    )
    try:
        with _NO_REDIRECT_OPENER.open(req, timeout=10) as resp:
            return 200 <= resp.status < 300
    except (urllib.error.URLError, OSError, ValueError) as e:
        log.warning(f"Terms acceptance push failed (will retry): {type(e).__name__}: {e}")
        return False


def _push_pending_once() -> bool:
    """Send every undelivered record oldest first, marking each delivered only after a 2xx.
    Stops at the first failure so order is kept. True when nothing is left undelivered."""
    if not PORTAL_TOKEN:
        return False
    for rec in _undelivered_acceptances():
        if not _post_acceptance(rec):
            return False
        try:
            _mark_delivered(rec["id"])
        except OSError as e:
            log.error(f"Terms acceptance: delivered but could not record it (will resend, harmless): {e}")
            return False
    return True


async def _acceptance_pusher() -> None:
    """Background task: keeps trying until every acceptance record has reached the portal."""
    backoff = _PUSH_BACKOFF_START
    warned = False
    if TEST_LOGIN_PASSWORD:
        # A server running the test-login bypass must never push acceptances to the real portal.
        log.warning("Terms acceptance: the test login is enabled, so acceptances are never pushed to the portal")
        return
    while True:
        try:
            if not PORTAL_TOKEN:
                if not warned:
                    log.warning("Terms acceptance: EBMS_LIVE_PORTAL_TOKEN is not set, so records are neither pushed to the portal nor pullable from this server (both need the token)")
                    warned = True
                await asyncio.sleep(_PUSH_IDLE_SECONDS)
                continue
            if not await asyncio.to_thread(_undelivered_acceptances):
                backoff = _PUSH_BACKOFF_START
                await asyncio.sleep(_PUSH_IDLE_SECONDS)
                continue
            if await asyncio.to_thread(_push_pending_once):
                backoff = _PUSH_BACKOFF_START
            else:
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, _PUSH_BACKOFF_MAX)
        except asyncio.CancelledError:
            raise
        except Exception:
            log.exception("Terms acceptance pusher error (will retry)")
            await asyncio.sleep(backoff)


def _verify_session_core(credentials: HTTPAuthorizationCredentials, require_terms: bool) -> dict:
    sess = _touch_session(credentials.credentials)
    if sess is None:
        raise HTTPException(status_code=401, detail="Session expired or invalid. Please sign in again.")
    # Terms gate: checked before the permission re-check so an unaccepted user costs no database round trip.
    if require_terms and not _terms_gate_ok(sess):
        raise HTTPException(status_code=403, detail={"code": "terms_required", "version": VERSION})
    # Re-fetch permissions from DB on every request, using the schema bound to this session
    username = sess["username"]
    try:
        row = get_user_permissions(username, sess.get("schema"))
    except psycopg.Error as e:
        # A transient DB error is not the same as a deleted/inactive account --
        # leave the session intact so the client can retry (86e2t0g50/CR-20).
        log.exception(f"Permission re-check failed for {username}: {e}")
        raise HTTPException(status_code=503, detail="Temporary server error. Please try again.")
    if row is None:
        _delete_session(credentials.credentials)
        raise HTTPException(status_code=401, detail="User account no longer active.")
    sess["permissions"] = {k: row[k] for k in ("GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES") if k in row}
    return sess


def verify_session(credentials: HTTPAuthorizationCredentials = Security(security)) -> dict:
    return _verify_session_core(credentials, require_terms=True)


def verify_session_no_terms(credentials: HTTPAuthorizationCredentials = Security(security)) -> dict:
    """Only POST /accept uses this: a user who has not accepted must still be able to accept."""
    return _verify_session_core(credentials, require_terms=False)


# ---------------------------------------------------------------------------
# Postgres connection
# ---------------------------------------------------------------------------

# 86e3gevdu: every connection server.py opens is read-only at the database (generated SQL, login, sessions, KPIs
# all only SELECT/EXPLAIN; pinned by test_no_execute_call_in_server_py_carries_a_write_statement). The keyword
# scanner is the FIRST line of defense against writes; this makes a scanner miss harmless for writes. It does NOT stop
# pg_advisory_lock / pg_notify (those are handled by the name-consumer denylist, _DENIED_FUNCTIONS) or pg_sleep
# (not denied: it is bounded by statement_timeout below, as ticket 86e38zcdx accepted).
def get_conn():
    return psycopg.connect(
        host=PG_HOST,
        port=PG_PORT,
        dbname=PG_DB,
        user=PG_USER,
        password=PG_PASSWORD,
        connect_timeout=10,
        options=f"-c statement_timeout={SQL_TIMEOUT * 1000} -c default_transaction_read_only=on",
        row_factory=dict_row,
    )

def _default_schema() -> str:
    """Return the first configured dataset's schema, or PG_SCHEMA as fallback."""
    return DATASETS[0]["schema"] if DATASETS else PG_SCHEMA

# ---------------------------------------------------------------------------
# Claude SQL generation
# ---------------------------------------------------------------------------

_claude = None

def get_claude():
    global _claude
    if _claude is None:
        if not ANTHROPIC_KEY:
            log.error(
                "ANTHROPIC_API_KEY is not set or empty -- every /query call will fail with "
                "an opaque Anthropic SDK authentication error until this is fixed and the "
                "service is restarted."
            )
        _claude = anthropic.Anthropic(api_key=ANTHROPIC_KEY)
    return _claude

def fix_schema_quoting(sql: str) -> str:
    """Fix model occasionally quoting schema.TABLE as a single identifier instead of "schema"."TABLE"."""
    return re.sub(r'"([^"]+\.[A-Z_]+)"', lambda m: f'"{m.group(1).split(".", 1)[0]}"."{m.group(1).split(".", 1)[1]}"', sql)

# One message, used by the validator AND by the retry helper's hint, so rewording it cannot silently disable the hint.
_FOREIGN_SCHEMA_REJECTION = "Generated query referenced a schema outside this session - rejected for safety."


def _foreign_schema_qualifiers(sql: str, expected_schema: str) -> set[str]:
    """Return the schema names, excluding `expected_schema`, of every table-position
    schema qualifier in `sql` (the "schema"."TABLE" shape fix_schema_quoting() can
    produce, or a shape the model can emit directly).

    Deliberately excludes a captured span that itself looks like a bare table name
    (all-uppercase, no colon/lowercase) -- that shape is "TABLE"."COLUMN" (a
    table-qualified column reference, mandated by SYSTEM_PROMPT rule 7 and used in
    its own rule 8/9b examples), not a schema qualifier. This codebase's real schema
    names are always cb2pg-style ("company:legacy" -- lowercase with a colon), so a
    bare-uppercase capture can never be a legitimate schema in practice.

    Known limitations, accepted (see this ticket's spec's Known Limitation section):
    like enforce_permissions()'s own table-extraction regex, this cannot distinguish
    a real identifier from the same text inside a string literal; an UNQUOTED schema
    qualifier bypasses this check entirely; and a schema-qualified table name in
    lowercase also bypasses it (enforce_permissions() shares this last one too).
    """
    # A top-level CTE name used as a column qualifier ("works_orders"."INVOICE") is not a schema (F2). Parsed
    # fail-closed: any doubt gives an empty set, so nothing is exempt. Not exempt: a name with ':' (looks like a
    # tenant schema), an occurrence right after FROM/JOIN (schema.table position), or a "column" that is a known
    # table name (blocks the comma-join form FROM "t2", "t2"."ARINV"). Also not exempt: right after ONLY or a '::' cast, or
    # followed by '(' (a function call). Accepted residual: after a comma or '(' a name without ':' is still read
    # as CTE.column (it cannot be told from a select-list column); it reaches no tenant schema (those contain ':').
    ctes = {n for n in _leading_cte_names(sql) if ":" not in n and n != expected_schema}
    all_tables = {t for tables in MODULE_TABLES.values() for t in tables} | set(HARD_BLOCKED_TABLES)
    found = set()
    for m in re.finditer(r'"([^"]+)"\s*\.\s*"([A-Z][A-Z0-9_]*)"', sql):
        s = m.group(1)
        if re.fullmatch(r'[A-Z][A-Z0-9_]*', s):
            continue
        if (s in ctes and m.group(2) not in all_tables
                and not re.search(r'\b(?:FROM|JOIN|ONLY)\s*$|::\s*$', sql[:m.start()], re.IGNORECASE)
                and not sql[m.end():].lstrip().startswith("(")):
            continue
        found.add(s)
    return found - {expected_schema}


_CTE_HEAD_RE = re.compile(
    r'(?:"((?:[^"]|"")+)"|([A-Za-z_][A-Za-z0-9_]*))\s*(?:\(\s*[^()]*\)\s*)?AS\s+'
    r'(?:NOT\s+MATERIALIZED\s+|MATERIALIZED\s+)?\(', re.IGNORECASE)


def _leading_cte_names(sql: str) -> set[str]:
    """Names defined by the statement's leading WITH [RECURSIVE] clause (top level only), exact as written
    (unquoted names lowercased, as Postgres folds them). `sql` must be literal/comment-stripped. Returns an EMPTY
    set on any parse doubt (no WITH, malformed head, unbalanced parentheses, unterminated quote): fail closed."""
    m = re.match(r'\s*WITH\s+(?:RECURSIVE\s+)?', sql, re.IGNORECASE)
    if not m:
        return set()
    pos = m.end()
    n = len(sql)
    names: set[str] = set()
    while True:
        h = _CTE_HEAD_RE.match(sql, pos)
        if not h:
            return set()
        name = h.group(1).replace('""', '"') if h.group(1) is not None else h.group(2).lower()
        i, depth = h.end(), 1
        while i < n and depth:
            c = sql[i]
            if c == '"':
                j = i + 1
                while j < n:
                    if sql[j] == '"':
                        if j + 1 < n and sql[j + 1] == '"':
                            j += 2
                            continue
                        break
                    j += 1
                if j >= n:
                    return set()
                i = j
            elif c == '(':
                depth += 1
            elif c == ')':
                depth -= 1
            i += 1
        if depth:
            return set()
        names.add(name)
        w = re.compile(r'\s*,\s*').match(sql, i)
        if not w:
            return names
        pos = w.end()

def _strip_sql_string_literals(sql: str) -> str:
    """Replace every single-quoted string literal's contents with an empty
    placeholder, so a downstream character/keyword scan over the remaining
    text doesn't false-positive on legitimate literal data (e.g. a customer
    name containing a semicolon, or a business name containing a word that
    looks like a SQL keyword). Handles '' as an escaped quote inside a
    literal (the standard SQL escaping convention).

    Shared infrastructure: 86e2t0g4a (write-keyword filter false-flags
    string literals) needs this identical logic -- reuse this helper there,
    don't re-derive the regex a second time.

    Known limitation, accepted: like enforce_permissions()'s own
    table-extraction regex, this is regex-based text stripping, not a real
    SQL parser -- it cannot handle every edge case a full parser would
    (e.g. dollar-quoted strings, which this codebase's generated SQL never
    uses), but single-quoted literals are the only string syntax the model
    is ever prompted to emit.
    """
    return re.sub(r"'(?:[^']|'')*'", "''", sql)


def _has_multiple_statements(sql: str) -> bool:
    """True if `sql` contains more than one non-empty statement -- i.e. a
    ';' anywhere other than as a single optional trailing terminator.
    Catches statement smuggling that the SELECT-only anchor and write-keyword
    checks miss: a smuggled second statement using no blocked keyword (a
    second SELECT, pg_sleep() for DoS, a session-level SET/COPY/VACUUM,
    etc.) still executes, since psycopg's simple-query protocol runs every
    ';'-separated statement in one call.

    Strips string literals and comments first (see
    _strip_sql_literals_and_comments()) so a legitimate semicolon inside
    free-text data isn't mistaken for a statement separator.
    """
    stripped = _strip_sql_literals_and_comments(sql).rstrip()
    if stripped.endswith(";"):
        stripped = stripped[:-1].rstrip()
    return ";" in stripped

def _strip_sql_comments(sql: str) -> str:
    """Replace every SQL comment ('-- line comment' or '/* block comment */')
    with a single space, so a downstream keyword/character scan doesn't
    false-positive on comment text.

    Must run on text that has ALREADY had string literals stripped (see
    _strip_sql_string_literals()) -- otherwise a '--' or '/*' sequence
    inside a legitimate string literal would be misread as starting a real
    comment. Callers apply both in that order, not this function alone.

    This function remains correct and is tested standalone. Callers that
    need literal-and-comment-aware stripping together should use
    _strip_sql_literals_and_comments() instead of composing this function
    with _strip_sql_string_literals() themselves -- that specific
    composition had a real false-negative (86e2wdz6p, fixed by the new
    single-pass scanner): an apostrophe inside a comment or a
    double-quoted identifier could get paired by
    _strip_sql_string_literals() with the NEXT real single-quote later in
    the SQL string -- potentially across a newline -- blanking everything
    between them, including a genuine write keyword.
    """
    sql = re.sub(r"/\*.*?\*/", " ", sql, flags=re.DOTALL)
    sql = re.sub(r"--[^\n]*", " ", sql)
    return sql

# 86e3b8rwf (from 86e39gxpk): the SQL in agent.log used to be cut to 200 (or 100) characters, so a
# wrong-total report could not be diagnosed from the log. Bounded, not unbounded: a runaway statement
# must not flood the rotated file.
SQL_LOG_MAX_CHARS = 4000


def _sql_for_log(sql) -> str:
    """One-line, bounded rendering of a SQL statement for agent.log. Every whitespace run (including CR/LF
    and tabs) collapses to one space, so a multi-line statement is one log entry and a newline inside the
    SQL cannot forge a second one. Over SQL_LOG_MAX_CHARS it is cut with a visible marker naming the total
    length. None/empty -> ''."""
    one_line = " ".join((sql or "").split())
    if len(one_line) <= SQL_LOG_MAX_CHARS:
        return one_line
    return f"{one_line[:SQL_LOG_MAX_CHARS]} ...[truncated, {len(one_line)} chars total]"


def _strip_sql_literals_and_comments(sql: str) -> str:
    """Single left-to-right scan that strips every single-quoted string
    literal, '--' line comment, and nesting-aware '/* */' block comment
    from `sql` in one pass -- and passes double-quoted identifiers through
    completely unscanned -- so a downstream keyword/character scan doesn't
    false-positive on legitimate literal data or comment text, and doesn't
    false-negative on a write keyword hidden by a misread span boundary.

    Replaces the previous two-sequential-regex composition
    (_strip_sql_comments(_strip_sql_string_literals(sql))), which had a
    real false-negative (86e2wdz6p): an apostrophe inside a comment or a
    double-quoted identifier could get paired by the literal-stripping
    regex with the NEXT real single-quote later in the string --
    potentially across a newline -- blanking everything between them,
    including a genuine write keyword or (in _has_multiple_statements())
    a genuine statement-separating semicolon.

    This eliminates that specific bug class for the string/comment syntax
    it recognizes -- single-quoted literals (with '' escaping), '--' line
    comments, nesting-aware '/* */' block comments, and "..." identifiers
    (with "" escaping) -- by recognizing each span as a whole before ever
    looking at what's inside it, so an apostrophe or '--'/'/*' sequence
    already inside a comment or identifier can never be misread as
    starting a different span.

    _strip_sql_string_literals()/_strip_sql_comments() are NOT replaced by
    this function everywhere -- they remain individually correct and
    directly unit-tested. This function replaces only the vulnerable
    composition at its two call sites (the write-keyword check in
    query(), and _has_multiple_statements()).

    FAIL-CLOSED ON UNRECOGNIZED STRING SYNTAX (86e2wdz6p final-review
    fix): this scanner does not recognize dollar-quoted ($tag$...$tag$)
    string syntax, which the model is never prompted to emit. A raw,
    unescaped quote character inside one of these can make a real literal
    or block comment look unterminated to this scanner. Rather than
    silently consuming the rest of the string in that case (which would
    hide anything after it, including a write keyword -- a real,
    confirmed regression an earlier version of this function had, caught
    in this cluster's own final review), an unterminated literal or block
    comment makes this function return the ORIGINAL `sql` completely
    unchanged, so the caller's regex scans the raw text instead of
    trusting output from a scan that ran off the end. query() also
    rejects generated SQL containing dollar-quote syntax outright (see
    the dollar-quote guard beside the write-keyword check) as a second,
    independent layer, since that syntax is never legitimately needed
    here.

    ACTIVE DETECTION OF E'...'/U&'...' PREFIXES (86e2yq8d0): this scanner
    also does not implement PostgreSQL's E'...' (C-style backslash-escape
    string) or U&'...' (Unicode-escape string) grammars -- both support
    `\'` as an additional way to escape an embedded quote, on top of the
    `''`-doubling this scanner understands, with distinct escaping rules
    from each other. Rather than let this scanner's ''-doubling-only
    logic misread a `\'` inside one of these, 86e2wdz6p's final review
    found that TWO separate E'...'/U&'...' spans, each containing one
    stray escaped quote immediately followed by its own real terminating
    quote, could have their stray-quote-plus-terminator pairs each get
    misread as a single '' doubled escape -- keeping the scanner's notion
    of "still inside a literal" open across the ENTIRE stretch between
    the two spans, silently swallowing whatever real SQL sits there
    (including a write keyword or a statement-separating semicolon)
    without either span ever looking unterminated, so the existing
    unterminated-span fail-closed path never triggered. This is now
    closed by detecting an E'/U&' prefix directly, at the exact point a
    new top-level literal would begin (immediately before the character
    identified as `'` is treated as an ordinary literal's opening quote):
    checking whether the character(s) immediately preceding that quote
    form a bare `E`/`e`, or a bare `U`/`u` immediately followed by `&`,
    themselves not preceded by an identifier character. This can never
    mis-fire on a quote character that is itself inside an
    already-recognized literal/identifier/comment span (like `'E'`'s own
    closing quote) -- those spans are consumed whole by their own
    branches above before control returns to the top of this loop, so
    their interior characters are never re-examined by this check. On a
    match, this function returns the ORIGINAL `sql` unchanged -- the same
    fail-closed sentinel used for the unterminated-literal/
    unterminated-block-comment cases above, not new fail-open/fail-closed
    logic.
    """
    out = []
    i = 0
    n = len(sql)
    while i < n:
        ch = sql[i]
        if sql.startswith("--", i):
            # Postgres ends a '--' comment at either \n or a bare \r; ending
            # only at \n would hide a statement after a bare \r from the scan.
            ends = [k for k in (sql.find("\n", i), sql.find("\r", i)) if k != -1]
            end = min(ends) if ends else n
            out.append(" ")
            i = end
            continue
        if sql.startswith("/*", i):
            depth = 1
            j = i + 2
            while j < n and depth > 0:
                if sql.startswith("/*", j):
                    depth += 1
                    j += 2
                elif sql.startswith("*/", j):
                    depth -= 1
                    j += 2
                else:
                    j += 1
            if depth > 0:
                # Unterminated block comment -- fail closed. See docstring.
                return sql
            out.append(" ")
            i = j
            continue
        if ch == '"':
            j = i + 1
            while j < n:
                if sql[j] == '"':
                    if j + 1 < n and sql[j + 1] == '"':
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            else:
                j = n
            out.append(sql[i:j])
            i = j
            continue
        if ch == "'":
            # 86e2yq8d0: an E'...' or U&'...' prefix uses backslash (\')
            # as an additional way to escape an embedded quote, which this
            # scanner's ''-doubling-only logic doesn't understand -- and
            # two such spans can have their misread quote-pairings chain
            # into EACH OTHER, hiding real SQL between them without ever
            # looking unterminated (see docstring). Detect the prefix
            # HERE, at the exact point a new top-level literal would
            # begin, before any content is consumed -- this can never
            # mis-fire on a quote already inside an open literal/
            # identifier/comment span, since those are consumed whole by
            # their own branches above before control returns to the top
            # of this loop.
            # An unquoted PostgreSQL identifier may contain '$' after its
            # first character, not just alnum/'_' -- an identifier like
            # abc$E directly abutting a quote (abc$E'x') is real PG
            # identifier-then-plain-literal syntax, not an E'...' prefix.
            # Excluding '$' here too avoids fail-closing on that (a purely
            # theoretical case for this project's own generated SQL, but
            # matching the real grammar is cheap and removes the
            # ambiguity entirely rather than leaving it as a known gap).
            is_e_prefix = i >= 1 and sql[i - 1] in ("E", "e") and (
                i < 2 or not (sql[i - 2].isalnum() or sql[i - 2] in ("_", "$"))
            )
            is_u_amp_prefix = (
                i >= 2
                and sql[i - 1] == "&"
                and sql[i - 2] in ("U", "u")
                and (i < 3 or not (sql[i - 3].isalnum() or sql[i - 3] in ("_", "$")))
            )
            if is_e_prefix or is_u_amp_prefix:
                # Unsupported string syntax -- fail closed. See docstring.
                return sql
            j = i + 1
            terminated = False
            while j < n:
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":
                        j += 2
                        continue
                    j += 1
                    terminated = True
                    break
                j += 1
            if not terminated:
                # Unterminated string literal -- fail closed. See docstring.
                return sql
            out.append("''")
            i = j
            continue
        out.append(ch)
        i += 1
    return "".join(out)

def _log_cache_usage(label: str, msg) -> None:
    """Record prompt-cache effectiveness so a silent cache miss is visible in the log.

    A broken cache does not raise -- it just bills full price forever. The one
    reliable signal is cache_read_input_tokens staying at 0 across repeat calls,
    so log the three counts and let agent.log answer "is caching actually working"
    without needing a test harness.
    """
    try:
        u = msg.usage
        read = getattr(u, "cache_read_input_tokens", 0) or 0
        write = getattr(u, "cache_creation_input_tokens", 0) or 0
        fresh = getattr(u, "input_tokens", 0) or 0
        total = read + write + fresh
        hit = "READ" if read else ("WRITE" if write else "MISS")
        log.info(
            f"cache[{label}] {hit} read={read} write={write} uncached={fresh} "
            f"total_input={total}"
        )
    except Exception as e:  # never let telemetry break a query
        log.debug(f"cache usage logging failed: {e}")

def _history_message_content(h: "HistoryMessage") -> str:
    """Build the content sent to Claude for one history turn's OWN text.

    Assistant turns send SQL (unambiguous for date/filter references) rather than the
    natural-language answer. Deliberately NEVER appends row data here, even when the turn
    captured rows -- see _build_messages() for where and why captured rows are surfaced
    instead. An earlier version appended a "[REFERENCE ONLY...]" + JSON rows block directly
    onto the assistant turn's own content. Live verification
    (.superpowers/sdd/2026-08-01-followup-context-loss/task-6-report.md, "Concern found
    during verification") showed the model would sometimes imitate that shape in its OWN
    new output -- appending a fabricated trailing JSON block after an otherwise-correct SQL
    statement and breaking the query with a Postgres syntax error. Softening the wording of
    that same annotation (still embedded in an assistant turn) only changed which literal
    text got echoed (25% -> 20%, live-verified, not a meaningful drop) -- the model was
    imitating the SHAPE of its own past turns, not any particular wording in them. Moving
    the rows out of assistant turns entirely (see _build_messages) is what actually fixed it.
    """
    if h.role == "assistant" and h.sql:
        return h.sql
    return h.content

def _rows_reference_note(rows: list) -> str:
    """Build the '[REFERENCE ONLY...]' block for rows a prior query returned. Callers must
    attach this to a USER-role message, never inside an assistant turn's own content --
    see _build_messages() for why."""
    return (
        "[REFERENCE ONLY -- rows a previous query returned, shown so you can resolve a "
        'follow-up reference (e.g. "those 2"). This describes data from a PAST turn; it is '
        "not something you produced and not a template for your own output.]\n"
        + json.dumps(rows, default=str)
    )

def _build_messages(history: list, question: str) -> list[dict]:
    """Build the Claude messages list for one generate_sql() call.

    Assistant turns are sent as ONLY their own SQL (via _history_message_content) -- never
    with row data attached -- so the model is never shown an assistant turn shaped like
    "SQL followed by a rows/JSON block," which live verification found the model would
    sometimes imitate in its own new output (see _history_message_content's docstring).
    Any rows captured from an assistant turn are instead prefixed onto the NEXT ROLE="USER"
    message -- the following history turn if there is one, otherwise the new question being
    asked right now. A block that only ever appears on a "user" turn in this transcript has
    no assistant-authored precedent for the model to pattern-match against.

    Only the MOST RECENT rows-bearing assistant turn's rows are ever surfaced -- every earlier
    rows-bearing turn's rows are dropped entirely (their SQL is still shown, per the above,
    just not their row data). Anaphoric follow-ups ("those 2", "the list") in every ticket this
    was built for only ever reference the immediately preceding relevant turn; attaching every
    historical turn's rows would mean up to MAX_ROWS captured rows x up to 10 turns of history,
    all sent as UNCACHED per-request content (only the system prompt is cache-breakpointed),
    for no behavioral benefit over surfacing just the latest one.
    """
    last_rows_idx = None
    for i, h in enumerate(history):
        if h.role == "assistant" and h.rows:
            last_rows_idx = i

    messages = []
    pending_rows_note = None
    for i, h in enumerate(history):
        content = _history_message_content(h)
        if h.role == "user" and pending_rows_note:
            content = pending_rows_note + "\n\n" + content
            pending_rows_note = None
        messages.append({"role": h.role, "content": content})
        if h.role == "assistant" and h.rows and i == last_rows_idx:
            pending_rows_note = _rows_reference_note(h.rows)
    q_content = question
    if pending_rows_note:
        q_content = pending_rows_note + "\n\n" + q_content
    messages.append({"role": "user", "content": q_content})
    return messages

# Defense-in-depth guard against the hallucination fixed by _build_messages() above (see its
# docstring): the model occasionally still emits its own SQL followed by a trailing
# "[REFERENCE ONLY..." marker or a JSON-array-looking block. This does not replace the
# prompt-level fix -- it converts "very unlikely to reach the customer" into "structurally
# impossible," for near-zero cost. A line starting with "[{" or '["' (or the literal marker)
# has not been observed as valid standalone SQL in this codebase's generated queries (a
# constructed counter-example like `ANY(ARRAY\n["COL1","COL2"])` could in principle still get
# clipped, though this model has never produced that shape in practice).
#
# Matches either at the very start of the text (\A) or after a newline, both followed by
# optional whitespace then the marker/JSON opener. The \A branch matters for `clarification`
# (see generate_sql()): when the fenced-SQL case's trailing block IS the entire clarification
# text, .strip() has already removed any leading newline before this check ever runs, so a
# newline-only anchor would miss it.
_TRAILING_REFERENCE_BLOCK_RE = re.compile(
    r'(?:\A|\n)\s*\[\s*(?:REFERENCE ONLY\b|[{"]).*', re.IGNORECASE | re.DOTALL
)

def _strip_trailing_reference_block(text: str) -> tuple[str, str]:
    """If `text` contains a '[REFERENCE ONLY...' marker or JSON-array-looking block -- as a
    trailing tail, or as the ENTIRE text -- cut it off. Returns (clean_text, stripped_text) --
    `stripped_text` is empty when nothing was cut, otherwise it is the offending portion, for
    logging only. Callers must NOT surface `stripped_text` to the user; see generate_sql(),
    which applies this to both the extracted `sql` and `clarification`."""
    m = _TRAILING_REFERENCE_BLOCK_RE.search(text)
    if not m:
        return text, ""
    return text[:m.start()].rstrip(), text[m.start():].strip()

def _looks_like_sql_paragraph(paragraph: str) -> bool:
    """True if a blank-line-separated chunk of a would-be SQL response itself looks like
    it begins a SQL statement, clause, or comment, rather than an English sentence.
    Deliberately broad (covers common clause-continuation keywords, not just SELECT/WITH)
    so a legitimately blank-line-formatted multi-clause query is never mistaken for prose --
    false NEGATIVES here (missing a real prose leak) are the accepted cost, not false
    positives against real SQL."""
    return bool(re.match(
        r'^\s*(?:'
        r'SELECT\b|WITH\b|FROM\b|WHERE\b|AND\b|OR\b|GROUP\s+BY\b|ORDER\s+BY\b|HAVING\b|LIMIT\b|UNION\b|'
        r'JOIN\b|INNER\s+JOIN\b|LEFT\s+JOIN\b|RIGHT\s+JOIN\b|ON\b|CASE\b|WHEN\b|--|\(|\)|'
        r'[A-Za-z_][A-Za-z0-9_]*\s+AS\s*\('  # a bare CTE name declaration, e.g. `fy_dates AS (`
        r')',
        paragraph, re.IGNORECASE
    ))

def _detect_self_correction_leak(sql: str) -> tuple[str, str]:
    """Detect the model second-guessing its own SQL mid-response instead of using the
    CANNOT_QUERY path: a complete-looking SQL statement, then (after a blank line) a plain
    English sentence -- sometimes itself followed by a second SQL attempt.

    Found live 2026-08-03 investigating a residual failure on ambiguous "last year"
    questions once the prompt started discussing calendar-vs-fiscal-year resolution: e.g.
        SELECT "FIRST_M"::int AS fiscal_start_month FROM "..."."GLCTL" LIMIT 1

        Once I know your fiscal year structure, I'll query the top 5 vendors...
    -- a syntactically valid probing query, followed by prose that was clearly meant to be
    a CANNOT_QUERY clarification but wasn't formatted as one. The trigger topic (fiscal vs.
    calendar year) is specific to this investigation, but the SHAPE (SQL, blank line, prose,
    optionally more SQL) is general and not itself about fiscal year -- this guard does not
    look for that wording at all, only the structural shape.

    Deliberately conservative: if ANY non-empty paragraph after the first fails to look like
    SQL, the WHOLE response is treated as unresolved and collapsed to CANNOT_QUERY, rather
    than trying to guess which of several candidate SQL paragraphs is the model's real,
    on-topic answer. A later paragraph is sometimes a fully correct second attempt (see the
    example above) and sometimes just a caveat after an already-correct first statement --
    but it can also be a probing query answering a different question entirely (like the
    GLCTL example above), and there is no reliable way to tell those apart without executing
    the SQL. Per this project's own repeated rule (never silently return a wrong-topic
    answer), a clean refusal is the safe default when this shape appears at all; a false
    positive here just costs one refusal on an otherwise-fine answer, which is far cheaper
    than guessing wrong.

    Returns (sql, leaked_text). leaked_text is empty when nothing was detected; otherwise
    sql is forced to "CANNOT_QUERY" and leaked_text is the original text, for logging only
    -- never surfaced to the user, same convention as _strip_trailing_reference_block.

    Never touches a response that already starts with CANNOT_QUERY -- that is a legitimate,
    intentional multi-paragraph shape (e.g. "CANNOT_QUERY: Which warehouse did you mean?\\n\\n
    I found La Crete, Fort Vermilion and Main."), not a self-correction leak. Code-review
    finding: without this guard, the second paragraph's plain English fails the SQL-paragraph
    check the same way a genuine leak would, so the WHOLE clarifying question was being
    collapsed to the generic "I can only answer..." boilerplate -- losing the model's actual,
    answerable question, and (via the caller clearing `clarification` in response) also
    corrupting the follow-up rule (c) history mechanism that lets a user complete the model's
    own prior clarifying question in their next turn.
    """
    if sql.lstrip().upper().startswith("CANNOT_QUERY"):
        return sql, ""
    paragraphs = re.split(r'\n\s*\n', sql)
    if len(paragraphs) < 2:
        return sql, ""
    for p in paragraphs[1:]:
        if p.strip() and not _looks_like_sql_paragraph(p):
            return "CANNOT_QUERY", sql
    return sql, ""

# Backend model for all three LLM calls (generate_sql, format_answer, _self_correct_sql).
# ClickUp 86e3tbtce: moved from Haiku 4.5 to Haiku 5.5. 5.5 has thinking on by default (billed as
# output tokens, counted against max_tokens) and may put a `thinking` block ahead of the text block,
# so never read msg.content[0] directly: use _msg_text().
HAIKU_MODEL = "claude-haiku-5-5"


def _msg_text(msg) -> str:
    """Text of the first `text` block, skipping any leading `thinking` block."""
    for block in msg.content:
        if getattr(block, "type", None) == "text":
            return block.text.strip()
    return ""


def generate_sql(question: str, schema: str, history: list = None) -> tuple[str, str]:
    """Returns (sql, clarification) where clarification is any follow-up text the model appended."""
    now = _today_local()
    fiscal_start_month = _fiscal_start_month(schema)
    fy_boundaries = _fiscal_year_boundaries(fiscal_start_month, now)
    prompt = _build_prompt(schema, now.strftime("%Y-%m-%d"), now.strftime("%A"), now.year, fiscal_start_month,
                            fy_boundaries["last_fy_start"], fy_boundaries["last_fy_end"],
                            fy_boundaries["current_fy_start"], has_history=bool(history))
    messages = _build_messages(history or [], question)
    msg = get_claude().messages.create(
        model=HAIKU_MODEL,
        # Known_Issues.md #42 (ClickUp 86e2uccxg): a broad "CFO health-check" question invites
        # a multi-CTE analytical query (revenue trend + AR health + overdue aging in one
        # statement) long enough to hit a 1024 ceiling mid-string, producing SQL that fails
        # with a confusing Postgres syntax error instead of a clean, diagnosable signal.
        # Raised to 4096 as the primary fix; the stop_reason check below is the backstop for
        # whatever still doesn't fit even at that size. Doubled to 8192 for Haiku 5.5, where
        # default thinking tokens count against this ceiling too.
        max_tokens=8192,
        # Cache the system prompt. It is ~64KB and was previously re-sent as fresh
        # input on every single query -- the dominant cost of this endpoint by far.
        # Cache reads bill at ~0.1x of input, so this is close to a 90% cut on the
        # prompt portion. The breakpoint goes on the whole block: {schema} is fixed
        # per install and the injected date only changes at local midnight. Since
        # _build_prompt() conditionally splices in FOLLOWUP_RESOLUTION_RULES based on
        # has_history, each customer actually holds TWO cache entries per day (with
        # history / without), not one -- a small, already-accepted cost increase.
        system=[{
            "type": "text",
            "text": prompt,
            "cache_control": {"type": "ephemeral"},
        }],
        messages=messages,
    )
    _log_cache_usage("generate_sql", msg)
    if msg.stop_reason == "max_tokens":
        # The model was still writing when it hit the ceiling -- whatever text came back is a
        # cut-off fragment, not valid SQL. Returning it would fail downstream with a cryptic
        # Postgres syntax error (Known_Issues.md #42's original symptom); return a clean,
        # diagnosable refusal instead.
        log.warning(
            "generate_sql: hit the max_tokens ceiling before finishing SQL generation "
            f"(question={question!r}) -- returning CANNOT_QUERY instead of truncated SQL"
        )
        return (
            "CANNOT_QUERY: That question needs a broader query than I can generate in one "
            "pass. Try breaking it into smaller, more specific questions (e.g. one metric or "
            "time period at a time).",
            "",
        )
    if msg.stop_reason == "refusal":
        log.warning(f"generate_sql: model refused (question={question!r})")
        return (
            "CANNOT_QUERY: The model declined to answer that question. Try rephrasing it.",
            "",
        )
    full_response = _msg_text(msg)
    clarification = ""

    # If the model wrapped SQL in a code fence, extract SQL and capture anything after the fence
    fence_match = re.search(r"```(?:sql)?\s*\n(.*?)```(.*)", full_response, re.IGNORECASE | re.DOTALL)
    if fence_match:
        sql = fence_match.group(1).strip()
        clarification = fence_match.group(2).strip()
    else:
        sql = full_response
        # No fences - if model prefixed with explanation, extract from SELECT/WITH onward
        if not re.match(r"^\s*(SELECT|WITH|CANNOT_QUERY)\b", sql, re.IGNORECASE):
            sql_match = re.search(r"^\s*(SELECT|WITH)\b", sql, re.IGNORECASE | re.MULTILINE)
            if sql_match:
                clarification = sql[:sql_match.start()].strip()
                sql = sql[sql_match.start():].strip()
            else:
                # No SQL found at all - treat entire response as a clarification
                clarification = full_response
                sql = "CANNOT_QUERY"

    sql, stripped_reference_block = _strip_trailing_reference_block(sql)
    if stripped_reference_block:
        # Deliberately NOT appended to `clarification` -- that gets shown to the user (see
        # /query's answer-building), and showing the stripped block would just relocate the
        # exact leak this guard exists to prevent. Log only, for visibility into how often
        # the prompt-level fix is still letting this shape through.
        log.warning(
            "generate_sql: stripped a trailing reference/JSON block from the model's own "
            f"SQL output (question={question!r}): {stripped_reference_block[:300]!r}"
        )

    sql, self_correction_leak = _detect_self_correction_leak(sql)
    if self_correction_leak:
        # Same "log only, never surface" convention as the reference-block guard above.
        # This collapses to CANNOT_QUERY rather than trying to salvage a "best" SQL
        # paragraph -- see _detect_self_correction_leak's docstring for why guessing among
        # candidates is unsafe here.
        clarification = ""
        log.warning(
            "generate_sql: detected the model second-guessing its own SQL mid-response "
            f"(question={question!r}); collapsed to CANNOT_QUERY: {self_correction_leak[:300]!r}"
        )

    # Same guard, applied to `clarification` too. The fenced-SQL case above captures
    # everything after the closing fence as `clarification` -- if the model appended the
    # "[REFERENCE ONLY..." / JSON block AFTER the fence rather than inside it, that text
    # never goes near `sql` or the guard above, and `clarification` gets appended verbatim to
    # the user-visible answer (see /query's answer-building). Without this, the fenced-SQL
    # variant of the same hallucination would still reach the customer even though the
    # unfenced variant is now blocked.
    clarification, stripped_from_clarification = _strip_trailing_reference_block(clarification)
    if stripped_from_clarification:
        log.warning(
            "generate_sql: stripped a reference/JSON block from the model's own clarification "
            f"text (question={question!r}): {stripped_from_clarification[:300]!r}"
        )

    return sql.strip(), clarification

# ---------------------------------------------------------------------------
# Answer formatting
# ---------------------------------------------------------------------------

# Rendered via FORMAT_PROMPT.format(year=...) in format_answer() below -- any literal brace in
# this template must be doubled ({{ / }}) or .format() raises (see CLAUDE.md's brace-escaping
# rule; {coverage} and the JSON row example below are deliberately doubled for this reason).
FORMAT_PROMPT = """You are a concise business assistant. The user asked a question about their EBMS ERP data.
You have the raw query results. Format a clear, helpful answer in plain English.
Use dollar formatting for amounts. Be direct - no preamble. Do not build markdown tables of the
result rows; the app renders those itself (see DO NOT TYPE OUT ROW TABLES below).
If results are empty and the question involved a customer, vendor, or item name, suggest the user may have used a different spelling or abbreviation (e.g. "T.I.C. Parts & Service" vs "TIC parts", or "Catering" vs "CATERING") and offer to search again with a different spelling.
If results are empty for any other reason, say so plainly and suggest why (e.g. no open invoices, date range issue).
NEVER ask the user to run a query themselves, copy SQL, or "share the result" -- you run the queries, not the user.

NEVER FABRICATE QUERY RESULTS. If a query executes and returns rows, report those rows
accurately. Do not state that no results were found, or summarize a result as empty/
partial/inconclusive, unless the result set is genuinely empty (zero rows). If you are
uncertain what a query actually returned, say so explicitly rather than asserting a
result you haven't verified. (86e1x3g0m: a customer was told "none found" for a query
that had actually returned 15 rows, and only got the correct answer after pushing back
twice.)

NEVER COMPUTE A TOTAL YOURSELF. Every number you state must already be present in the query results.
Do NOT add up a column across returned rows, do NOT subtotal a subset of the rows, and do NOT derive a
percentage or split from row-by-row arithmetic. If the results are a row list with no aggregate column and
the user asked for a total, report what the rows show and say the total was not part of the result set --
do not supply the figure from your own arithmetic. Hand-summed figures have been wrong by tens of thousands
of dollars in real customer answers, and the customer has no way to tell a computed number from a queried one.
Restating a single value that appears in one returned cell is fine; that is reading, not computing.

WHEN THE USER DOUBTS A NUMBER ("I don't think these total X", "these don't add up", "that total looks wrong"),
the results in front of you were freshly queried to settle exactly that. Report what THESE results say: state
the database's figure (the "_match_total" / "_match_count" value, or the aggregate cell) plainly, and if the
user's own figure does not appear in the results, say so. Do NOT explain a discrepancy by estimating, rounding
or adding up rows ("roughly $188,000", "those two invoices alone come to..."). Do NOT offer an Outstanding/Paid
or any other split unless that split is a column in the results. Do NOT restate or "correct" figures from your
own EARLIER answers that are not in these results -- say only that the current result is the verified one. If
the user wants a breakdown, offer to run it; it is computed in SQL, not by eye.

WHEN THE LIST IS CUT (the Results note says "SHOWING n of m matching rows"): the list under your answer holds
only n of the m matching rows, but "_match_count" and "_match_total" (when present) describe ALL m of them. State that total
only as a total across all m ("across all 13 customers, total sales are $X"). NEVER present it as the total of
"these n", "the top n", "together" or "combined" -- those n rows add up to less than it. NEVER add up the shown
rows yourself or state a total for them; if the user wants that figure, offer to run it (it is computed in SQL).
  WRONG:   "Your top 10 customers account for $308,493.62 in total sales."   (that is all 13 customers)
  WRONG:   "These five represent $286,598.34."   (added up by eye, and wrong)
  CORRECT: "Here are your top 10 customers since February 1 (table below). Across all 13 customers with sales in
           that period, total sales are $308,493.62."
  (The names, counts and figures above are illustrative placeholders for this documentation only -- use the
  real ones from THIS result.)

DO NOT TYPE OUT ROW TABLES. The app renders the result rows as a real scrollable table directly
below your answer, so a markdown table in your text duplicates it, and yours is capped by your own
token budget while the app's is not. Write the summary and the figures; the table is not your job.
  WRONG:   Here are your June invoices:
           | Invoice | Date | Customer | Total |
           | 29185 | {year}-06-19 | Molette Wedding | $10,576.03 |
           | 29186 | {year}-06-20 | Conestogo Agri | $18,791.90 |
           ...and 48 more rows typed out one by one
  CORRECT: Your June {year} invoices are in the table below. If you want the total, ask for it
           directly and it will be computed in SQL rather than added up by eye.
  (Molette Wedding and Conestogo Agri above are illustrative placeholders for this
  documentation only -- never emit them in a real answer unless they genuinely appear in
  THIS conversation's own captured history rows.)
EXCEPTION: when the result is a SINGLE row, state its figures in your text as normal. The app
suppresses the table for single-row results, so there is nothing to duplicate.
If the results carry "_match_count" or "_match_total" columns, those are the true count and total
across EVERY matching row, computed by Postgres before any row limit was applied. Read them off the
first row and state them. They remain correct even when fewer rows came back than actually matched,
so prefer them over anything the visible rows suggest. Reading them is reading a returned cell, not
computing.
IF THE RESULTS SAY TRUNCATED, the row count you were given is a CEILING, not the real number --
UNLESS "_match_count" or "_match_total" are present (see above), in which case those ARE the real
figures and this "at least N" fallback does not apply.
  WRONG (ignoring _match_count/_match_total when they are right there in the data):
    Results (TRUNCATED -- 5 rows returned, but MORE than 5 actually matched):
    [{{"INVOICE": "29185", "TOTAL": "1200.00", "_match_count": 176, "_match_total": "421264.01"}}, ...]
    -> "I can show at least 5 invoices, but the full total was not part of the result."
  CORRECT (reading the true figures off the columns that are actually there):
    -> "There are 176 matching invoices totaling $421,264.01. Showing the first 5 below."
When "_match_count"/"_match_total" are ABSENT from a truncated result, the ceiling caveat still
applies as before: never state the visible row count as the number of matching records. Say
"at least N" or "the first N shown", and state plainly that the full total was not part of the
result. Do not estimate or extrapolate the real figure from the rows you can see. If the user
needs the true total, say that asking for the total directly will compute it in SQL.

EBMS STATUS codes - never mischaracterize these:
  'O' = outstanding (posted, unpaid invoice - money still owed)
  'X' = paid / closed (invoice has been paid - NOT cancelled, NOT voided)
  'U' = unprocessed (sales order not yet invoiced - never a real invoice)
When the SQL includes STATUS IN ('O','X') it means all posted invoices: both outstanding and paid.
When the SQL filters STATUS = 'O' only, it means unpaid/open invoices.

When showing balance totals (this MUST match how the SQL computed them - do not re-net the numbers yourself):
- A credit memo has a negative TOTAL. KEEP it in the total as a negative - it legitimately reduces what is owed. Do NOT drop it.
- A POSITIVE invoice with a negative BALANCE is an overpayment. It nets against what is owed exactly like a
  credit memo does - KEEP it as a negative contribution too. Do NOT floor it to $0.
- A grand total across multiple customers/vendors is: invoices subtotal (TOTAL >= 0, no flooring) PLUS credit
  memos subtotal (TOTAL < 0, kept negative) = net owing. If breaking this out for the user, present three lines:
  Invoices $X / Credit memos -$Y / Net owing $Z.
- For a single customer or vendor, a plain net balance is fine - their own credits net against their own invoices.
- Never silently discard negative rows (credit memos OR overpayments) - dropping either overstates what is owed.

ANALYTICAL ANSWERS (profit, margin, "most profitable", "dragging me down", spend trends, dead stock, late payers):
- These return a calculated number the user cannot eyeball-verify, so always make your method visible and correctable.
- End the answer with ONE plain-English methodology line stating what was measured and over what window, e.g.:
    "Gross margin = (net sales after line discounts - cost of goods) / net sales, on posted invoices this fiscal year. Excludes freight, handling, tax and header-level discounts."
    "Spend compared: last 90 days vs the prior 90 days, on posted invoices."
- Keep it to one line. The point is that the user can spot if your definition differs from their accountant's, not to write an essay.

PROXY ANSWERS (the user asked something predictive or judgemental - "likely to churn", "at risk", "will be late", "bad debt"):
- The data cannot predict; the SQL answered the closest FACTUAL signal instead. Be honest about this up front.
- LEAD with a one-line disclaimer naming the limit and what you measured instead, then give the real data. Example:
    "I can't predict which customers will stop buying, but here are customers whose spend dropped more than 50% in the last 90 days vs the prior 90 - a common early warning sign:"
- Never present a proxy as a prediction. No invented probabilities, scores, or "X% likely" figures - only what the data actually shows.

SANITY CHECK ON CALCULATED PERCENTAGES (flag impossible results - do NOT hide plausible ones):
- A gross margin % ABOVE 100, or any result computed from a NEGATIVE net-revenue figure, is mathematically impossible for a real margin and almost always signals a data issue (a bad join, or cost/credit-memo sign problem), NOT a real business result.
- There is NO lower bound on a real margin: a deep loss can be -150%, -300%, etc. (selling far below cost). Do NOT flag a large negative margin as impossible - it is a valid, if alarming, result. Only >100% and negative-net-revenue are truly impossible.
- When you see an impossible value, DO NOT report it as fact. Instead: state the figure, say plainly it isn't a possible real margin and likely reflects a data issue in how costs/credits are recorded, SHOW the raw underlying numbers (net sales and COGS), and advise verifying before relying on it.
    Example: "That comes out to 312%, which isn't possible for a real gross margin - it likely reflects a data issue in how costs are recorded on these invoices. Raw figures: net sales $X, cost of goods $Y. Worth checking the cost data before relying on this."
- This applies ONLY to mathematically-impossible values. Normal-but-surprising results (a thin 3% margin, a real -12% loss, even a real -200% loss on items dumped below cost) are valid answers - report them normally. NEVER suppress or cast doubt on a plausible number just because it is bad news.

COST-DATA COVERAGE REFUSAL (when the margin query returns a coverage ratio below 0.80):
- The margin recipe gates on cost-data coverage. If the query reports coverage < 80% (most revenue has no recorded cost), DO NOT state a margin %.
- Instead, refuse honestly and explain the gap, then offer what you CAN show. Be specific about the coverage figure if available.
    Example: "I can't give you a reliable gross margin - cost is recorded on only about {{coverage}}% of your sales, so any margin figure would be badly overstated (uncosted lines look like 100% profit). Your EBMS Product Profit report has the same blind spot for the same reason. To get a real margin, item costs need to be maintained at the time of sale. In the meantime I can show revenue, top products by sales, top customers, or AR - just ask."
- Frame this as IntraMind catching a data-quality issue, not as a limitation of IntraMind. It is a trust signal, not a failure.
- COMPOUND LABOR+PRODUCT margin query (e.g. "margin on labor and parts together") that legitimately executes SQL spanning
  C_TYPE 0-4 and lands here on low coverage: explain that labor/service lines never carry a recorded cost in EBMS by design
  (not just "this period"), so blending them with inventoried lines drags coverage down structurally. Offer margin scoped to
  just the inventoried lines as the fix, not merely "try again later" - this is a different situation than "no cost data yet".
- EMPTY RESULT on a margin query (all aggregates NULL / zero rows): this usually means the C_TYPE IN (2,3,4) inventoried-line
  filter matched NOTHING - i.e. the customer made NO inventoried-product sales in this period (common for service businesses).
  Do NOT explain an empty margin result as "no posted invoices this period" - the customer may have many invoices, just none of
  the inventoried type. Say instead: "I don't see any inventoried-product sales (tracked items) in this period, so there's no
  cost-based margin to calculate. If you sell services or labor, those carry no recorded cost. I can show your margin across ALL
  line types (it will note how much is actually cost-backed), or revenue, top customers, or AR - just ask." Only attribute an
  empty result to missing invoices if you have separate evidence there are genuinely no posted invoices at all.

UNCLASSIFIED-CTYPE COVERAGE DISCLOSURE (when a margin query's results include a gross_unclassified_share column):
- gross_unclassified_share is already a non-negative dollar-volume share (it sums ABS() of each unclassified
  line's amount before dividing), so no sign/direction handling is needed -- unlike a signed net ratio, it
  cannot understate the gap through cancellation between positive and negative unclassified amounts. If
  gross_unclassified_share >= 0.05 (5% or more of total revenue, by absolute dollar volume, falls under an
  undocumented ARINVDET.C_TYPE code), DO NOT state the margin % as if it's complete -- disclose the gap
  instead, using the real returned percentage from gross_unclassified_share (the recipe's own SQL does not
  return an unclassified dollar amount -- never compute or estimate one yourself; state the percentage
  only), then offer what you CAN show (same pattern as the cost-coverage refusal above).
    Example: "I can't give you a complete gross margin -- about {{pct}}% of revenue falls under item-type
    codes I don't have documented cost-bearing behavior for, so it's excluded from this margin figure and
    the true margin may differ. In the meantime I can show revenue, top products, or AR -- just ask."
- If gross_unclassified_share < 0.05, no extra disclosure is needed -- report the margin normally.
- gross_unclassified_share CAN legitimately exceed 1.0 (over 100%) on a scope where net revenue is very
  close to zero (a short date range, a single customer/product grouping) -- this is a real, correctly-
  computed value, not an error. State the percentage plainly even when it reads as an unusually large
  number (e.g. "about 340% of revenue") -- do not cap it at 100%, round it down, or treat it as a bug.
- If gross_unclassified_share is NULL: this recipe's SQL only produces NULL here when net revenue for the
  scope is exactly $0 (the ratio's own denominator) -- it is never NULL merely because there happened to be
  no unclassified-C_TYPE rows (that case reads as a clean 0, not NULL). Do NOT silently treat a NULL as "no
  gap" -- say the scope's net revenue came out to exactly $0, so a percentage-of-revenue gap figure isn't
  meaningful for it, and offer to show revenue or margin for a different scope instead.

SANITY CHECK ON NEGATIVE ON-HAND INVENTORY QUANTITIES (flag as unusual - do NOT build a confident narrative on top):
- A negative on-hand quantity (INVENTRY.COUNT, INVENWH.COUNT, or a sum of either) is physically atypical for a real inventory
  item - you cannot have fewer than zero physical units on a shelf. Unlike an impossible margin (which is a hard mathematical
  contradiction), a negative on-hand figure CAN be a genuine, correctly-recorded EBMS state (an unposted return, a warehouse
  transfer in transit, an over-issued adjustment, a legitimate backorder-tracking convention) - so state the number plainly,
  do not suppress or "correct" it, and do not treat it as necessarily wrong the way an impossible margin is.
- What you must NOT do: invent operational commentary or advice on top of the number that the data does not
  support - "you're short," "you owe inventory," "receive stock immediately," "you need to reorder now." A
  negative figure alone tells you the number is unusual, not why, and not what the business should do about it.
    WRONG:   "You have -5.00 units of 1A1316480 on hand. You're 5 units short and should receive stock immediately to
              cover the shortfall and get back to a positive position."
    CORRECT: "On-hand for 1A1316480 comes out to -5.00 units. A negative on-hand count is unusual for a physical item -
              it can reflect a pending transfer, an unposted return, or an inventory adjustment. Worth checking the item's
              transaction history in EBMS before treating this as a real shortage."
- If the figure is a sum across multiple warehouses and any single warehouse's contribution is itself deeply negative while
  others are positive, you may mention that breakdown (it is often the most useful diagnostic detail), but still without
  asserting which warehouse is "wrong" or why - simply state the per-warehouse figures alongside the total. Do not label a
  warehouse a "backorder" or "virtual" bucket unless something in the data itself says so (a warehouse type/flag) - EBMS does
  not universally reserve any particular warehouse code for that purpose, and treating one that way without evidence has
  produced a wrong diagnosis before.

SANITY CHECK ON A NAMED PERSON MISSING FROM SALESMAN (flag the field distinction - do NOT assert zero activity outright):
- ARINV has two distinct name-bearing fields that are easy to confuse: SALESMAN (commission/sales attribution) and
  USER_NAME (the EBMS login that keyed the invoice - office/data-entry staff, not necessarily the salesperson). A person can
  be a real, active EBMS user (showing up under USER_NAME on many invoices) while never appearing under SALESMAN at all, and
  vice versa - these are separate, unrelated concepts in EBMS, not two names for the same thing.
- When a question asks about a specific named person's sales/commission/bonus activity and that name does not appear in
  SALESMAN for the period in question, do NOT conclude the person had zero activity or a $0 result as a confident business
  fact. State the SALESMAN result plainly, then note that SALESMAN and USER_NAME are different fields and
  the person may appear under the other one, and offer to check.
    WRONG:   "Employee A is not in the SALESMAN field for that period. The only salespeople with posted invoices are
              Employee B, Employee C, and Employee D. Employee A has no sales activity during this period, so her bonus is $0."
    CORRECT: "Employee A doesn't appear in the SALESMAN field for that period - the salespeople with posted invoices are
              Employee B, Employee C, and Employee D. SALESMAN (commission attribution) and USER_NAME (who keyed the invoice
              in EBMS) are different fields, though - if Employee A works with this data as EBMS staff rather than as the
              assigned salesperson, she may still show up under USER_NAME. Want me to check that too before concluding there
              was no activity for her?"
- This applies specifically to a MISSING-name scenario, not to every SALESMAN question - if the user's question is
  unambiguously about USER_NAME already (per the "user X" / "entered by" mapping), answer it directly with no need for this
  caveat."""

def _jsonable_rows(rows: list[dict]) -> list[dict]:
    """Coerce psycopg row values into types Pydantic can serialize.

    Postgres hands back Decimal, date and datetime, none of which Pydantic will
    encode. This is the same json.dumps(..., default=str) coercion format_answer
    has always used, applied once so the browser payload and the model's copy can
    never diverge. Numbers and dates come out as strings; the client already
    handles that (appendKPIDetail parseFloats its balance column).
    """
    return json.loads(json.dumps(rows, default=str, allow_nan=False))


def _model_rows(rows: list[dict]) -> list[dict]:
    """The slice of rows the answer-formatting model sees.

    Logs when the slice is smaller than the result, because that gap was invisible
    at every layer before now -- it is why an answer could narrate 200 rows while
    having seen 50, and it survived unnoticed since the initial commit.
    """
    if len(rows) > MODEL_ROWS:
        log.info(f"format_answer sees {MODEL_ROWS} of {len(rows)} rows")
    return rows[:MODEL_ROWS]


def _cut_list_counts(rows: list[dict]) -> tuple[int, int] | None:
    """(rows shown, rows that actually match) when `rows` is a ranked list cut short by a LIMIT, else None.
    Rule 9b's "_match_count" covers EVERY matching row, so it exceeds len(rows) exactly when the list was cut
    (86e3bbw6m). A missing or non-numeric "_match_count" is treated as not cut."""
    if not rows:
        return None
    try:
        matching = int(rows[0].get("_match_count"))
    except (TypeError, ValueError):
        return None
    return (len(rows), matching) if matching > len(rows) else None


def format_answer(question: str, rows: list[dict], sql: str, history: list = None,
                  truncated: bool = False, row_cap: int = 0) -> str:
    if not rows:
        data_str = "Query returned 0 rows."
    else:
        data_str = json.dumps(_model_rows(rows), default=str, indent=2)

    if truncated:
        has_true_figures = bool(rows) and ("_match_count" in rows[0] or "_match_total" in rows[0])
        if has_true_figures:
            count_note = (f"Results (TRUNCATED -- {len(rows)} rows returned, but MORE than {row_cap} "
                          f"actually matched; the TRUE count and total ARE present, in the "
                          f"_match_count/_match_total columns on the first row -- read and state those)")
        else:
            count_note = (f"Results (TRUNCATED -- {len(rows)} rows returned, but MORE than {row_cap} "
                          f"actually matched; the true count and total were NOT returned)")
    else:
        cut = _cut_list_counts(rows)
        if cut:
            shown, matching = cut
            described = "_match_count and _match_total describe" if rows[0].get("_match_total") is not None else "_match_count describes"
            count_note = (f"Results (SHOWING {shown} of {matching} matching rows -- the list was cut to {shown}. "
                          f"{described} ALL {matching} matching rows, NOT the {shown} shown)")
        else:
            count_note = f"Results ({len(rows)} rows)"

    messages = []
    for h in (history or []):
        messages.append({"role": h.role, "content": h.content})
    messages.append({
        "role": "user",
        "content": f"Question: {question}\n\nSQL used: {sql}\n\n{count_note}:\n{data_str}"
    })
    year = _today_local().year
    # Deliberately NOT cached: FORMAT_PROMPT is ~15.5KB, roughly 2-3K tokens, and it was
    # written when Haiku 4.5 would not cache a prefix under 4,096 tokens. Haiku 5.5's minimum
    # is documented as lower (512 tokens, NOT yet confirmed against the caching docs), so this
    # may now be cacheable: revisit once confirmed. The rows appended below are per-query
    # anyway and could never cache.
    msg = get_claude().messages.create(
        model=HAIKU_MODEL,
        max_tokens=4096,  # was 2048 on 4.5; default thinking tokens count against it on 5.5
        system=FORMAT_PROMPT.format(year=year),
        messages=messages,
    )
    _log_cache_usage("format_answer", msg)
    if getattr(msg, "stop_reason", None) == "refusal":
        log.warning(f"format_answer: model refused (question={question!r})")
        return "I couldn't summarize those results. The data is available in the table below."
    return _msg_text(msg)

# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------

# 86e35uf0h: caps sized generously beyond the real USERS table's own column widths
# (NAME char(20), PASSWORD char(10)) -- these bound request-size/cost amplification,
# not an exact mirror of a FoxPro column width (a real password could exceed 10 chars
# in the app-level model even if the underlying FoxPro column is narrower).
class LoginRequest(BaseModel):
    username: str = Field(max_length=100)
    password: str = Field(max_length=256)
    dataset: str = Field(default="", max_length=200)  # schema string of the chosen dataset; empty = use first/default

# 86e30r2zm: none of these fields had any size cap -- a direct API call (bypassing the
# frontend, which only self-limits via conversationHistory.slice(-20) as a courtesy) could
# submit an arbitrarily large history: thousands of turns, each with an unbounded content/sql
# string and an unbounded rows list, all built into the Claude prompt by _build_messages() and
# format_answer(). That's both a memory/cost amplification vector and a way to blow past
# Claude's own context window mid-request. Caps below match what the rest of the codebase
# already treats as the real limits (frontend's own history slice; MAX_ROWS's row-cap intent
# for a single turn's captured rows, per this field's own pre-existing "up to 20 rows" comment)
# -- these are enforcement of documented intent, not new arbitrary numbers.
HISTORY_MAX_TURNS = 20
HISTORY_MAX_ROWS_PER_TURN = 20
HISTORY_TEXT_MAX_LEN = 20_000  # generous headroom over any real answer/SQL text; this is a
                                # denial-of-service/cost cap, not a UX-relevant limit
QUESTION_MAX_LEN = 4_000       # generous headroom over any real typed question

class HistoryMessage(BaseModel):
    role: str     # "user" or "assistant"
    content: str = Field(max_length=HISTORY_TEXT_MAX_LEN)  # English answer (used by format_answer for context)
    sql: str = Field(default="", max_length=HISTORY_TEXT_MAX_LEN)  # SQL query (used by generate_sql for context -- unambiguous for date/filter references)
    rows: list[dict] | None = Field(default=None, max_length=HISTORY_MAX_ROWS_PER_TURN)
                                     # up to 20 rows this turn's SQL returned, used by generate_sql
                                     # to resolve anaphoric references ("those 2") to actual entity
                                     # identities -- format_answer no longer enumerates rows in the
                                     # answer text (see 2026-07-31 large-result-sets work), so neither
                                     # h.content nor h.sql alone carries that detail for a row-list turn

    @field_validator("rows")
    @classmethod
    def _cap_row_size(cls, v):
        if v is None:
            return v
        for row in v:
            # 86e31dqdk: max_length on the list only caps row COUNT; nothing
            # constrained each row dict's own content size, so a client could
            # still submit HISTORY_MAX_ROWS_PER_TURN rows per turn each holding
            # an arbitrarily large string value. Cap each row's serialized
            # size to the same per-field budget the sibling string fields
            # already use.
            # 86e3mgxk6 C4: ensure_ascii=False so the cap counts characters, not \uXXXX escapes (an accented character used to count 6).
            if len(json.dumps(row, default=str, ensure_ascii=False)) > HISTORY_TEXT_MAX_LEN:
                raise ValueError(f"each history row must serialize to at most {HISTORY_TEXT_MAX_LEN} characters")
        return v

class QueryRequest(BaseModel):
    question: str = Field(max_length=QUESTION_MAX_LEN)
    history: list[HistoryMessage] = Field(default=[], max_length=HISTORY_MAX_TURNS)

class QueryResponse(BaseModel):
    model_config = ConfigDict(extra="forbid")  # a misspelled kwarg here must fail loudly, not
    # silently ship a truncated/row_cap default that reads to the client as a complete result

    answer: str
    sql: str
    row_count: int
    db_schema: str
    rows: list[dict] = []       # result rows for the client to render as a table
    truncated: bool = False     # True when more rows matched than row_cap
    row_cap: int = 0            # the cap that was applied, for the client's notice

# ---------------------------------------------------------------------------
# App
# ---------------------------------------------------------------------------

@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info(f"EBMS Live Query Agent starting - schema default: {PG_SCHEMA}, port: {PORT}")
    if TEST_LOGIN_PASSWORD:
        log.warning("EBMS_LIVE_TEST_PASSWORD is set -- the INTRAMIND test-login bypass is ACTIVE. This must never be set in production.")
    # Verify DB connection on startup
    try:
        conn = get_conn()
        conn.close()
        log.info("Postgres connection OK")
    except Exception as e:
        log.error(f"Postgres connection FAILED: {e}")
    pusher = asyncio.create_task(_acceptance_pusher())
    purger = asyncio.create_task(_feedback_purger())
    try:
        yield
    finally:
        pusher.cancel()
        purger.cancel()

app = FastAPI(title="EBMS Live Query Agent", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://intramind.ca", "http://localhost:5173", "http://localhost:3000"],
    allow_methods=["POST", "GET"],
    allow_headers=["Authorization", "Content-Type"],
)

@app.exception_handler(Exception)
async def _unhandled_exception_handler(request: Request, exc: Exception):
    """Catch anything not already an HTTPException (FastAPI JSON-serializes
    those on its own via its own already-registered handler, unaffected by
    this one) and return a clean JSON 500 instead of Starlette's default
    plain-text response. Closes the gap for generate_sql()/format_answer()'s
    unguarded Anthropic calls (86e2rryv8) and any future unguarded call
    elsewhere in this file -- a catch-all safety net, not a substitute for
    handling a specific, anticipated failure mode close to where it occurs.

    The real exception is logged server-side with exc_info=True; the
    client-facing detail stays generic on purpose -- never expose internal
    exception text, type names, or stack traces to the client.

    CORS NOTE: this response is generated by Starlette's ServerErrorMiddleware,
    which sits OUTSIDE CORSMiddleware -- it never gets an Access-Control-Allow-
    Origin header. No impact today (ui.html is same-origin, portal/ui.html only
    calls its own same-origin /api/* with server-side proxying) -- but a future
    genuinely cross-origin browser caller (the CORS allowlist already names
    https://intramind.ca and two localhost dev ports) would have its fetch
    promise reject on the CORS check before ever seeing this body.
    """
    log.error(f"Unhandled exception on {request.method} {request.url.path}: {exc}", exc_info=True)
    return JSONResponse(status_code=500, content={"detail": "Something went wrong. Please try again."})

@app.get("/", response_class=HTMLResponse)
def ui():
    html_path = Path(__file__).parent / "ui.html"
    # The Terms text is embedded in the page, so the page carries the version it was served with. The browser
    # compares it with the server's current version before recording an acceptance (stale open tab).
    html = html_path.read_text(encoding="utf-8").replace(
        '<meta name="terms-version" content="__TERMS_VERSION__">',
        f'<meta name="terms-version" content="{_html.escape(VERSION, quote=True)}">', 1)
    return HTMLResponse(html, headers={"Cache-Control": "no-cache"})

@app.get("/health")
def health():
    resp = {"status": "ok", "schema": PG_SCHEMA, "company": COMPANY_NAME, "version": VERSION}
    last_action = _read_last_admin_action()
    if last_action:
        resp["last_admin_action"] = last_action
    return resp

@app.get("/whats-new")
def whats_new():
    """Return whats_new for current version if a pending update notification exists."""
    pending_path = Path(r"C:\ProgramData\IntraMind\pending_update.txt")
    try:
        pending = json.loads(pending_path.read_text(encoding="utf-8").strip())
    except (OSError, json.JSONDecodeError):
        return {"version": VERSION, "changelog": None}
    pending_version = (pending.get("version") or "").split("-")[0]
    if pending_version != VERSION:
        return {"version": VERSION, "changelog": None}
    changelog = pending.get("whats_new") or None
    return {"version": VERSION, "changelog": changelog}

@app.get("/datasets")
def datasets_list():
    """Return available datasets for the login screen dropdown."""
    return {"datasets": [{"name": d["name"], "schema": d["schema"]} for d in DATASETS]}

@app.post("/login")
def login(req: LoginRequest, request: Request):
    # 86e30r2ny: /login had no rate limiting at all -- real EBMS usernames with
    # FoxPro-era (often weak) passwords were exposed to unthrottled brute-force.
    # check_rate_limit() already exists and is hardened (Cloudflare-aware IP
    # resolution, LRU-bounded key count) and is already used the same way on
    # /query below -- this was simply never wired into this endpoint.
    # 86e3gevvq A1-F4: no per-username lockout, by decision -- the shared per-IP bucket stays; a lockout would let an
    # attacker lock real users out (spec D12). A1-F5: TEST_LOGIN_PASSWORD admin-fallback sessions die on the next
    # request (verify_session re-reads USERS); test-only path, documented, not fixed.
    check_rate_limit(_client_ip(request))

    username_upper = req.username.strip().upper()

    # Resolve and validate the requested dataset schema
    requested_schema = req.dataset.strip()
    if requested_schema:
        if requested_schema not in DATASET_SCHEMAS:
            raise HTTPException(status_code=400, detail="Invalid dataset selection.")
        chosen_schema = requested_schema
    else:
        chosen_schema = _default_schema()

    # Free tier: only the INTRAMIND user is accepted
    if EBMS_LIVE_TIER == "free" and username_upper != "INTRAMIND":
        secrets.compare_digest(req.password.encode(), b"x")
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    # Test-only bypass: EBMS_LIVE_TEST_PASSWORD overrides DB lookup for INTRAMIND ONLY.
    # CR-1 (86e2t0fr4, found 2026-08-11): this used to also gate the final check below via
    # `not TEST_LOGIN_PASSWORD`, which made that check a no-op for every OTHER username too,
    # not just this INTRAMIND branch -- a real user's WRONG password would silently succeed
    # whenever this env var happened to be set (routine for this project's own live testing).
    # The final check is now unconditional -- every branch must set row/password_match such
    # that it correctly reflects whether THIS request should be allowed, and that check runs
    # for every username, every time, regardless of this env var.
    if TEST_LOGIN_PASSWORD and username_upper == "INTRAMIND":
        password_match = _safe_compare(req.password, TEST_LOGIN_PASSWORD)
        if not password_match:
            raise HTTPException(status_code=401, detail="Invalid username or password.")
        row = get_user_permissions(username_upper, chosen_schema) or {
            "FULL_NAME": "INTRAMIND", "GL": "Administrator", "AP": "Administrator",
            "AR": "Administrator", "IN": "Administrator", "DP": "Administrator",
            "PY": "Administrator", "TA": "Administrator", "JC": "Administrator", "ES": "Administrator",
        }
    else:
        row = get_user_permissions(username_upper, chosen_schema)

        # Always do a constant-time compare even when user not found (prevents username enumeration)
        stored_password = row["PASSWORD"] if (row and row.get("PASSWORD")) else ""
        password_match = _password_matches(req.password, stored_password)

    if row is None or not password_match:
        raise HTTPException(status_code=401, detail="Invalid username or password.")

    permissions = {k: row[k] for k in ("GL", "AP", "AR", "IN", "DP", "PY", "TA", "JC", "ES") if k in row}
    full_name = row.get("FULL_NAME") or username_upper
    session_token = _create_session(username_upper, full_name, permissions, chosen_schema)

    password_weak = is_password_weak(req.password)

    log.info(f"Login: {username_upper} schema={chosen_schema} (tier={EBMS_LIVE_TIER})")
    return {
        "token": session_token,
        "full_name": full_name,
        "username": username_upper,
        "schema": chosen_schema,
        "password_weak": password_weak,
        "tier": EBMS_LIVE_TIER,
        "terms_accepted": _terms_gate_ok({"username": username_upper, "schema": chosen_schema}),
        "terms_version": VERSION,
    }

@app.post("/logout")
def logout(credentials: HTTPAuthorizationCredentials = Security(security)):
    _delete_session(credentials.credentials)
    return {"ok": True}

def _fiscal_start_month(schema: str) -> int:
    """Return GLCTL.FIRST_M for the given schema, resolved server-side so the AI query
    engine never needs to generate SQL referencing GLCTL at all (ClickUp 86e2n66g5 --
    GLCTL is a 98-column company control record with several sensitive-looking columns,
    and a prior column-allowlist attempt to gate AI access to it had confirmed live
    bypasses). Falls back to 1 (January) on any failure, matching EBMS's own conventional
    default and company_info()'s existing fallback pattern -- logs a warning so a real
    misconfiguration is visible in agent.log, not silent.
    """
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(f'SELECT "FIRST_M" FROM "{schema}"."GLCTL" LIMIT 1')
                row = cur.fetchone()
                if row and row.get("FIRST_M") is not None:
                    value = int(row["FIRST_M"])
                    if 1 <= value <= 12:
                        return value
                    log.error(
                        f"_fiscal_start_month lookup for schema {schema!r} returned "
                        f"out-of-range FIRST_M={value!r}, defaulting to January"
                    )
    except Exception as e:
        log.error(f"_fiscal_start_month lookup failed for schema {schema!r}, defaulting to January: {e}")
    return 1

def _fiscal_year_boundaries(first_m: int, today: datetime) -> dict[str, str]:
    """Compute the last-completed and current fiscal year boundary dates as ISO strings, so
    the model never needs to generate CASE-expression arithmetic to answer "last fiscal year"
    or "this fiscal year to date" questions. Pure function, no DB access of its own -- takes
    first_m (already resolved by _fiscal_start_month()) and today's date as plain inputs, so
    it's trivially unit-testable without a DB or an API key. Uses plain f-string formatting
    rather than the datetime.date class -- server.py imports only datetime/timezone today, and
    every value here is a plain year/month/day combination with no calendar arithmetic (no
    date subtraction, no timezone handling), so a `date` import buys nothing.

    Live verification found the model unreliable at this arithmetic once given
    fiscal_start_month as a bare literal it could reason about freely (ClickUp 86e2n66g5,
    ~15-25% wrong-year rate on "last fiscal year" questions, confirmed via ground-truth
    dollar-total comparison against real Postgres data) -- removing the arithmetic from the
    model's job entirely, rather than adding more prompt text warning against it, is the fix
    (a wording/example-only attempt was tried first and did not help).
    """
    if first_m <= today.month:
        last_fy_start_year = today.year - 1
    else:
        last_fy_start_year = today.year - 2
    current_fy_start_year = last_fy_start_year + 1
    return {
        "last_fy_start": f"{last_fy_start_year}-{first_m:02d}-01",
        "last_fy_end": f"{last_fy_start_year + 1}-{first_m:02d}-01",
        "current_fy_start": f"{current_fy_start_year}-{first_m:02d}-01",
    }

@app.get("/company")
def company_info(request: Request, *, _rl: None = Depends(_dashboard_rate_limit_dependency), sess: dict = Depends(verify_session)):
    """Return company name from GLCTL for the session's schema."""
    s = (sess.get("schema") or _default_schema()).strip()
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(f'SELECT "NAME" FROM "{s}"."GLCTL" LIMIT 1')
                row = cur.fetchone()
                name = row["NAME"].strip() if row and row.get("NAME") else COMPANY_NAME
    except Exception:
        name = COMPANY_NAME
    return {"company": name}

@app.get("/kpis")
def kpis(request: Request, *, _rl: None = Depends(_dashboard_rate_limit_dependency), sess: dict = Depends(verify_session)):
    """Return 8 dashboard KPIs as structured numbers - no Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()
    queries = {
        # Net AR = plain balance sum, no flooring (matches EBMS AR Aging; ClickUp 86e2nj6k7 --
        # live-verified 2026-08 to an exact-cent match against a real customer's EBMS AR Aging
        # report grand total. The old floor-and-net-only-credit-memos formula silently excluded
        # overpayments on normal invoices from netting, overstating this KPI by $791 on that data.)
        "ar_outstanding": f"""
            SELECT
                COALESCE(SUM("{s}"."ARINV"."BALANCE"), 0) AS val,
                COUNT(CASE WHEN "{s}"."ARINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
        "sales_this_month": f"""
            SELECT COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS val,
                   COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
        "sales_last_month": f"""
            SELECT COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS val,
                   COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '1 month')
              AND "{s}"."ARINV"."INV_DATE" < DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
        # Net overdue = plain balance sum, no flooring (same fix as ar_outstanding above)
        "overdue": f"""
            SELECT
                COALESCE(SUM("{s}"."ARINV"."BALANCE"), 0) AS val,
                COUNT(CASE WHEN "{s}"."ARINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
              AND (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) < CURRENT_DATE
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
        # Net AP = plain balance sum, no flooring (same fix as ar_outstanding above)
        "ap_outstanding": f"""
            SELECT
                COALESCE(SUM("{s}"."APINV"."BALANCE"), 0) AS val,
                COUNT(CASE WHEN "{s}"."APINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
              AND "{s}"."APINV"."__deleted" IS NOT TRUE
        """,
        "bills_due_week": f"""
            SELECT
                COALESCE(SUM(GREATEST("{s}"."APINV"."BALANCE", 0)), 0) AS val,
                COUNT(CASE WHEN "{s}"."APINV"."TOTAL" > 0 THEN 1 END) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
              AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) >= CURRENT_DATE
              AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= CURRENT_DATE + INTERVAL '7 days'
              AND "{s}"."APINV"."TOTAL" > 0
              AND "{s}"."APINV"."__deleted" IS NOT TRUE
        """,
        "payroll_this_month": f"""
            SELECT
                COALESCE(SUM("{s}"."PYTM"."G_PAY" - "{s}"."PYTM"."TOT_REIMB"), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."PYTM"
            WHERE "{s}"."PYTM"."PAY_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."PYTM"."PAY_DATE" <= CURRENT_DATE
              AND "{s}"."PYTM"."G_PAY" > 0
              AND "{s}"."PYTM"."__deleted" IS NOT TRUE
        """,
        "payments_received": f"""
            SELECT
                COALESCE(SUM("{s}"."ARINVPMT"."AMOUNT"), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."ARINVPMT"
            WHERE "{s}"."ARINVPMT"."DATE" >= DATE_TRUNC('month', CURRENT_DATE)
              AND "{s}"."ARINVPMT"."DATE" <= CURRENT_DATE
              AND "{s}"."ARINVPMT"."AMOUNT" > 0
              AND "{s}"."ARINVPMT"."STATUS" <> 4
              AND "{s}"."ARINVPMT"."__deleted" IS NOT TRUE
        """,
        "avg_days_to_pay": f"""
            SELECT
                COALESCE(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                ), 0) AS val,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """,
    }
    result = {}
    denied_keys = []
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                for key, sql in queries.items():
                    try:
                        enforce_permissions(sess["permissions"], sql)
                    except HTTPException:
                        denied_keys.append(key)
                        continue  # denied module -- omit this KPI entirely (86e2rrye3)
                    try:
                        cur.execute(sql)
                        row = dict(cur.fetchone())
                        result[key] = {"value": float(row["val"]), "count": int(row["cnt"])}
                    except Exception as e:
                        conn.rollback()
                        log.warning(f"KPI query failed for {key}: {e}")
                        result[key] = {"value": None, "count": None}
    except psycopg.Error as e:
        log.error(f"KPI connection error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")
    if denied_keys:
        log.info(f"KPIs omitted due to permission denial: {denied_keys}")
    return result

@app.get("/kpis/detail/{key}")
def kpi_detail(key: str, request: Request, *, _rl: None = Depends(_dashboard_rate_limit_dependency), sess: dict = Depends(verify_session)):
    """Return drill-down rows + verified summary for a KPI card. No Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()

    detail_queries = {
        "ar_outstanding": {
            "title": "Outstanding Customer Invoices",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINV"."INVOICE" AS invoice,
                    "{s}"."ARINV"."INV_DATE" AS date,
                    "{s}"."ARINV"."NAME" AS customer,
                    "{s}"."ARINV"."TOTAL" AS total,
                    "{s}"."ARINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."ARINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."ARINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."ARINV"."INV_DATE" DESC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."ARINV"."TOTAL", 0) >= 0), 0) AS gross,
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."ARINV"."TOTAL", 0) < 0), 0) AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            """,
        },
        "ap_outstanding": {
            "title": "Outstanding Vendor Bills",
            "rows_sql": f"""
                SELECT
                    "{s}"."APINV"."INVOICE" AS invoice,
                    "{s}"."APINV"."INV_DATE" AS date,
                    "{s}"."APINV"."NAME" AS vendor,
                    "{s}"."APINV"."TOTAL" AS total,
                    "{s}"."APINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."APINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."APINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                  AND "{s}"."APINV"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."APINV"."INV_DATE" DESC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."APINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."APINV"."TOTAL", 0) >= 0), 0) AS gross,
                    COALESCE(SUM("{s}"."APINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."APINV"."TOTAL", 0) < 0), 0) AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                  AND "{s}"."APINV"."__deleted" IS NOT TRUE
            """,
        },
        "overdue": {
            "title": "Overdue AR Invoices",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINV"."INVOICE" AS invoice,
                    "{s}"."ARINV"."DUE_DATE" AS due_date,
                    "{s}"."ARINV"."NAME" AS customer,
                    "{s}"."ARINV"."TOTAL" AS total,
                    "{s}"."ARINV"."BALANCE" AS balance,
                    CASE WHEN "{s}"."ARINV"."TOTAL" < 0 THEN 'credit'
                         WHEN "{s}"."ARINV"."BALANCE" < 0 THEN 'overpaid'
                         ELSE 'invoice' END AS row_type
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) < CURRENT_DATE
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
                ORDER BY (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) ASC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."ARINV"."TOTAL", 0) >= 0), 0) AS gross,
                    COALESCE(SUM("{s}"."ARINV"."BALANCE") FILTER (WHERE COALESCE("{s}"."ARINV"."TOTAL", 0) < 0), 0) AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" = 'O'
                  AND (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) < CURRENT_DATE
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            """,
        },
        "bills_due_week": {
            "title": "AP Bills Due This Week",
            "rows_sql": f"""
                SELECT
                    "{s}"."APINV"."INVOICE" AS invoice,
                    "{s}"."APINV"."DUE_DATE" AS due_date,
                    "{s}"."APINV"."NAME" AS vendor,
                    "{s}"."APINV"."TOTAL" AS total,
                    "{s}"."APINV"."BALANCE" AS balance,
                    'invoice' AS row_type
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                  AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) >= CURRENT_DATE
                  AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= CURRENT_DATE + INTERVAL '7 days'
                  AND "{s}"."APINV"."TOTAL" > 0
                  AND "{s}"."APINV"."__deleted" IS NOT TRUE
                ORDER BY (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) ASC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM(GREATEST("{s}"."APINV"."BALANCE", 0)) FILTER (WHERE "{s}"."APINV"."TOTAL" > 0), 0) AS gross,
                    0::numeric AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."APINV"
                WHERE "{s}"."APINV"."STATUS" = 'O'
                  AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) >= CURRENT_DATE
                  AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= CURRENT_DATE + INTERVAL '7 days'
                  AND "{s}"."APINV"."TOTAL" > 0
                  AND "{s}"."APINV"."__deleted" IS NOT TRUE
            """,
        },
        "payroll_this_month": {
            "title": "Payroll This Month",
            "rows_sql": f"""
                SELECT
                    "{s}"."PYTM"."NAME" AS employee,
                    "{s}"."PYTM"."PAY_DATE" AS pay_date,
                    "{s}"."PYTM"."PAY_TYPE" AS pay_type,
                    "{s}"."PYTM"."G_PAY" AS gross_pay,
                    "{s}"."PYTM"."T_DED" AS deductions,
                    "{s}"."PYTM"."N_PAY" AS net_pay,
                    'payroll' AS row_type
                FROM "{s}"."PYTM"
                WHERE "{s}"."PYTM"."PAY_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."PYTM"."PAY_DATE" <= CURRENT_DATE
                  AND "{s}"."PYTM"."G_PAY" > 0
                  AND "{s}"."PYTM"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."PYTM"."PAY_DATE" DESC, "{s}"."PYTM"."NAME"
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."PYTM"."G_PAY" - "{s}"."PYTM"."TOT_REIMB"), 0) AS gross,
                    0::numeric AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."PYTM"
                WHERE "{s}"."PYTM"."PAY_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."PYTM"."PAY_DATE" <= CURRENT_DATE
                  AND "{s}"."PYTM"."G_PAY" > 0
                  AND "{s}"."PYTM"."__deleted" IS NOT TRUE
            """,
        },
        "sales_this_month": {
            "title": "Sales This Month",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINV"."INVOICE" AS invoice,
                    "{s}"."ARINV"."INV_DATE" AS date,
                    "{s}"."ARINV"."NAME" AS customer,
                    "{s}"."ARINV"."TOTAL" AS total,
                    "{s}"."ARINV"."STATUS" AS status,
                    'invoice' AS row_type
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
                  AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
                  AND "{s}"."ARINV"."TOTAL" > 0
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."ARINV"."INV_DATE" DESC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS gross,
                    0::numeric AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."ARINV"
                WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
                  AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
                  AND "{s}"."ARINV"."TOTAL" > 0
                  AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            """,
        },
        "payments_received": {
            "title": "Payments Received This Month",
            "rows_sql": f"""
                SELECT
                    "{s}"."ARINVPMT"."DATE" AS date,
                    "{s}"."ARINVPMT"."AMOUNT" AS amount,
                    "{s}"."ARINVPMT"."CHECK_NO" AS check_no,
                    "{s}"."ARINVPMT"."CUSTOMER" AS customer_id,
                    COALESCE("{s}"."ARCUST"."L_NAME", '(unknown customer)') AS customer,
                    "{s}"."ARINVPMT"."TYPE" AS type,
                    'payment' AS row_type
                FROM "{s}"."ARINVPMT"
                LEFT JOIN "{s}"."ARCUST" ON "{s}"."ARCUST"."ID" = "{s}"."ARINVPMT"."CUSTOMER"
                                        AND "{s}"."ARCUST"."__deleted" IS NOT TRUE
                WHERE "{s}"."ARINVPMT"."DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."ARINVPMT"."DATE" <= CURRENT_DATE
                  AND "{s}"."ARINVPMT"."AMOUNT" > 0
                  AND "{s}"."ARINVPMT"."STATUS" <> 4
                  AND "{s}"."ARINVPMT"."__deleted" IS NOT TRUE
                ORDER BY "{s}"."ARINVPMT"."DATE" DESC
                LIMIT 100
            """,
            "summary_sql": f"""
                SELECT
                    COALESCE(SUM("{s}"."ARINVPMT"."AMOUNT"), 0) AS gross,
                    0::numeric AS credits,
                    COUNT(*) AS total_row_count
                FROM "{s}"."ARINVPMT"
                WHERE "{s}"."ARINVPMT"."DATE" >= DATE_TRUNC('month', CURRENT_DATE)
                  AND "{s}"."ARINVPMT"."DATE" <= CURRENT_DATE
                  AND "{s}"."ARINVPMT"."AMOUNT" > 0
                  AND "{s}"."ARINVPMT"."STATUS" <> 4
                  AND "{s}"."ARINVPMT"."__deleted" IS NOT TRUE
            """,
        },
    }

    # Days to pay uses a different query/response shape
    if key == "days_to_pay":
        rows_sql = f"""
            SELECT
                COALESCE("{s}"."ARCUST"."L_NAME", '(unknown customer)') AS customer,
                COUNT(*) AS invoices_paid,
                ROUND(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                )) AS avg_days
            FROM "{s}"."ARINV"
            LEFT JOIN "{s}"."ARCUST" ON "{s}"."ARCUST"."ID" = "{s}"."ARINV"."ID"
                                    AND "{s}"."ARCUST"."__deleted" IS NOT TRUE
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            GROUP BY COALESCE("{s}"."ARCUST"."L_NAME", '(unknown customer)')
            ORDER BY avg_days DESC
            LIMIT 100
        """
        summary_sql = f"""
            SELECT
                ROUND(AVG(
                    "{s}"."ARINV"."CLOSE_DATE"::date - "{s}"."ARINV"."INV_DATE"::date
                )) AS avg_days,
                COUNT(*) AS total_invoices
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'X'
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."CLOSE_DATE" >= '2000-01-01'
              AND "{s}"."ARINV"."CLOSE_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."CLOSE_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."INV_DATE" IS NOT NULL
              AND "{s}"."ARINV"."CLOSE_DATE" > "{s}"."ARINV"."INV_DATE"
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
        """
        enforce_permissions(sess["permissions"], rows_sql)
        try:
            with get_conn() as conn:
                with conn.cursor() as cur:
                    cur.execute(rows_sql)
                    rows = [dict(r) for r in cur.fetchall()]
                    cur.execute(summary_sql)
                    summary_row = dict(cur.fetchone())
        except psycopg.Error as e:
            log.error(f"KPI detail query error for days_to_pay: {e}")
            raise HTTPException(status_code=503, detail="Database unavailable")
        return {
            "title": "Average Days to Payment (This Year)",
            "rows": rows,
            "summary": {
                "avg_days": int(summary_row["avg_days"] or 0),
                "total_invoices": int(summary_row["total_invoices"] or 0),
                "type": "days_to_pay",
            },
        }

    if key not in detail_queries:
        raise HTTPException(status_code=404, detail=f"Unknown KPI key: {key}")

    q = detail_queries[key]
    enforce_permissions(sess["permissions"], q["rows_sql"])
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(q["rows_sql"])
                rows = [dict(r) for r in cur.fetchall()]
                cur.execute(q["summary_sql"])
                summary_row = dict(cur.fetchone())
    except psycopg.Error as e:
        log.error(f"KPI detail query error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")

    gross = float(summary_row["gross"])
    credits = float(summary_row["credits"])
    net = gross + credits
    total_row_count = int(summary_row["total_row_count"])

    return {
        "title": q["title"],
        "rows": rows,
        "summary": {"gross": gross, "credits": credits, "net": net, "total_row_count": total_row_count},
    }

@app.get("/charts")
def charts(request: Request, *, _rl: None = Depends(_dashboard_rate_limit_dependency), sess: dict = Depends(verify_session)):
    """Return chart datasets - all deterministic SQL, no Claude involved."""
    s = (sess.get("schema") or _default_schema()).strip()

    chart_queries = {
        "ar_aging": f"""
            SELECT
                CASE
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) <= 30 THEN '0-30'
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) <= 60 THEN '31-60'
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) <= 90 THEN '61-90'
                    ELSE '90+'
                END AS bucket,
                COALESCE(SUM("{s}"."ARINV"."BALANCE"), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" = 'O'
              AND (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END) < CURRENT_DATE
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            GROUP BY bucket
            ORDER BY MIN(CURRENT_DATE - (CASE WHEN "{s}"."ARINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."ARINV"."INV_DATE" ELSE "{s}"."ARINV"."DUE_DATE" END))
        """,
        "sales_by_month": f"""
            SELECT
                TO_CHAR(DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"), 'Mon YY') AS month,
                DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE") AS month_start,
                COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('month', CURRENT_DATE - INTERVAL '5 months')
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            GROUP BY DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"),
                     TO_CHAR(DATE_TRUNC('month', "{s}"."ARINV"."INV_DATE"), 'Mon YY')
            ORDER BY month_start
        """,
        "top_customers": f"""
            SELECT
                "{s}"."ARINV"."NAME" AS name,
                COALESCE(SUM("{s}"."ARINV"."TOTAL"), 0) AS amount
            FROM "{s}"."ARINV"
            WHERE "{s}"."ARINV"."STATUS" IN ('O', 'X')
              AND "{s}"."ARINV"."INV_DATE" >= DATE_TRUNC('year', CURRENT_DATE)
              AND "{s}"."ARINV"."INV_DATE" <= CURRENT_DATE
              AND "{s}"."ARINV"."TOTAL" > 0
              AND "{s}"."ARINV"."__deleted" IS NOT TRUE
            GROUP BY "{s}"."ARINV"."NAME"
            ORDER BY amount DESC
            LIMIT 10
        """,
        "ap_aging": f"""
            SELECT
                CASE
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= 30 THEN '0-30'
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= 60 THEN '31-60'
                    WHEN CURRENT_DATE - (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) <= 90 THEN '61-90'
                    ELSE '90+'
                END AS bucket,
                COALESCE(SUM("{s}"."APINV"."BALANCE"), 0) AS amount,
                COUNT(*) AS cnt
            FROM "{s}"."APINV"
            WHERE "{s}"."APINV"."STATUS" = 'O'
              AND (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END) < CURRENT_DATE
              AND "{s}"."APINV"."__deleted" IS NOT TRUE
            GROUP BY bucket
            ORDER BY MIN(CURRENT_DATE - (CASE WHEN "{s}"."APINV"."DUE_DATE" = '1899-12-30' THEN "{s}"."APINV"."INV_DATE" ELSE "{s}"."APINV"."DUE_DATE" END))
        """,
    }

    result = {}
    denied_keys = []
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                for key, sql in chart_queries.items():
                    try:
                        enforce_permissions(sess["permissions"], sql)
                    except HTTPException:
                        denied_keys.append(key)
                        continue  # denied module -- omit this chart entirely (86e2rrye3)
                    try:
                        cur.execute(sql)
                        rows = [dict(r) for r in cur.fetchall()]
                        # Drop month_start helper column from sales_by_month
                        if key == "sales_by_month":
                            rows = [{k: v for k, v in r.items() if k != "month_start"} for r in rows]
                        # Coerce numeric fields to float
                        for row in rows:
                            for k, v in row.items():
                                if isinstance(v, (int, float)) or (hasattr(v, '__float__') and k in ('amount',)):
                                    try:
                                        row[k] = float(v)
                                    except (TypeError, ValueError):
                                        pass
                        result[key] = rows
                    except Exception as e:
                        conn.rollback()
                        log.warning(f"Chart query failed for {key}: {e}")
                        result[key] = None
    except psycopg.Error as e:
        log.error(f"Charts connection error: {e}")
        raise HTTPException(status_code=503, detail="Database unavailable")
    if denied_keys:
        log.info(f"Charts omitted due to permission denial: {denied_keys}")

    return result

# The '?' single-quote alternative here is NOT dead code, even though a
# normal single-quoted literal is blanked by _strip_sql_literals_and_comments
# before this regex ever runs. An E'...'/U&'...'-prefixed literal makes that
# stripper's own fail-closed design return the ORIGINAL sql unchanged (no
# recognized string-delimiter form), so a raw single-quoted INTO 'evil'
# elsewhere in the same query CAN reach here. Live-verified during Batch A's
# Final Review (2026-09-16): removing this alternative let
# "SELECT * INTO 'evil' FROM t WHERE x = E'y'" pass validation. Keep it.
#
# 86e3a4mb3: the double-quoted alternative's closing `"` is now OPTIONAL
# (`"?` instead of a mandatory `"`). An unterminated double-quoted
# identifier (e.g. `INTO "abc FROM ARCUST`, no closing quote anywhere in
# the string) used to fall through every alternative and silently pass
# validation -- a real regression from an earlier, simpler version of this
# pattern (b94760a) that DID reject it. Postgres itself rejects this exact
# shape as a syntax error ("unterminated quoted identifier"), so it isn't
# actually exploitable, but the check stays internally consistent with the
# single-quote alternative's own identical "defense in depth" reasoning
# above. Fuzz-verified (1,353 regression cases + 6 legitimate
# near-miss shapes, e.g. "INTONATION"/"INTO_DATE") with no catastrophic-
# backtracking risk to n=60,000.
#
# 86e39rr28: the trailing BARE (unquoted) identifier alternative now
# excludes a small set of SQL keywords via a negative lookahead. Without
# it, a legitimate bare `into` token (e.g. `a.into AS x`, a column/alias
# reference -- INTO is a reserved word unlikely to be a real EBMS/cb2pg
# column name, but SYSTEM_PROMPT-generated SQL can still reference one via
# `a.into`) greedily matched the very next token as if it were a new DDL
# target table name, e.g. treating `AS` in `a.into AS x` as the target.
# This lookahead applies ONLY to the bare-identifier alternative -- a real
# quoted identifier used as an actual DDL target (e.g. `INTO "WHERE"`)
# must still be caught, so the quoted alternatives are deliberately left
# unguarded.
#
# 86e39t6rr: a quoted multi-word alias whose own text happens to contain
# the word "into" (e.g. `AS "paid into account"`) can still make this
# regex match -- the alias's internal space satisfies `\bINTO\s+` even
# though "into" is plain English text inside one continuous quoted span,
# not the SQL keyword at all. A regex alone cannot reliably tell "is this
# INTO token inside an already-open double-quoted span" (that requires
# counting quote-boundary toggles, not a single pattern), so this is
# handled by _has_select_into_ddl() below, the sole wrapper around this
# regex's one real call site -- see its own docstring.
# 86e3geve1: INTO"x" (no whitespace before a quoted identifier) is valid Postgres and used to slip past \bINTO\s+; the lookahead alternative catches it.
_SELECT_INTO_RE = re.compile(
    r'\bINTO(?:\s+|(?=")\s*)(?:TEMP(?:ORARY)?\s+|UNLOGGED\s+)?(?:TABLE\s+)?'
    r'(?:"(?:[^"]|"")+"?|\'[A-Za-z_][A-Za-z0-9_]*|'
    r'(?!(?:AS|WHERE|FROM|GROUP|ORDER|LIMIT|JOIN|ON|AND|OR|HAVING|UNION)\b)[A-Za-z_][A-Za-z0-9_]*)',
    re.IGNORECASE,
)


def _has_select_into_ddl(stripped_sql: str, *, literals_stripped: bool = True) -> bool:
    """True iff `stripped_sql` contains a genuine SELECT-INTO DDL attempt.

    `literals_stripped` states what `stripped_sql` actually is, and callers
    MUST pass it accurately -- this function cannot infer it on its own:

    - True (the default): `stripped_sql` came from a SUCCESSFUL run of
      _strip_sql_literals_and_comments() -- single-quoted literals and
      comments are genuinely blanked, but double-quoted identifiers are
      passed through VERBATIM. In this case (and only this case) is the
      quote-parity logic below sound: for every regex match, this counts
      the quote-boundary-toggling `"` characters that appear before it. A
      `"` immediately followed by another `"` is Postgres's own
      `""`-escaping for a literal quote INSIDE an already-open
      double-quoted identifier -- it does not toggle whether we're inside
      a quoted span, so it is not counted. An ODD count means the match's
      own `INTO` sits inside an already-open quoted span (86e39t6rr: it's
      quoted-identifier TEXT, e.g. `AS "paid into account"`, not the real
      keyword) -- skip it. An EVEN count means it's real, unquoted-context
      SQL -- a genuine SELECT-INTO DDL attempt.

    - False: `stripped_sql` is actually the RAW, un-stripped SQL, because
      _strip_sql_literals_and_comments() itself FAILED CLOSED (an
      E'...'/U&'...'-prefixed literal, an unterminated literal, or an
      unterminated block comment -- see that function's own docstring) and
      returned the original string unchanged. Quote-parity counting over
      un-stripped text is unreliable here: a stray, unrelated `"` sitting
      inside a comment or an ordinary (still-unblanked) string literal can
      make the count odd at the position of a REAL `INTO evil_table` DDL
      attempt, silently skipping it -- e.g.
      `SELECT 1 /* " */, 2 INTO evil FROM t WHERE x = E'y'` has exactly one
      `"` before the real `INTO evil` match (inside the comment), making
      the naive count odd even though nothing is actually quoted there.
      When `literals_stripped` is False, this function does NOT trust
      quote-parity counting at all -- it falls back to the older, more
      paranoid behavior of treating ANY regex match as real. This is
      exactly the fail-closed posture _strip_sql_literals_and_comments()
      itself takes in this situation, applied consistently downstream.
    """
    for m in _SELECT_INTO_RE.finditer(stripped_sql):
        if not literals_stripped:
            return True
        prefix = stripped_sql[:m.start()]
        quote_count = 0
        i = 0
        n = len(prefix)
        while i < n:
            if prefix[i] == '"':
                if i + 1 < n and prefix[i + 1] == '"':
                    i += 2
                    continue
                quote_count += 1
            i += 1
        if quote_count % 2 == 0:
            return True
    return False

# 86e3gevdm: _validate_generated_sql scans literal-STRIPPED SQL, so a table name passed to a function as a STRING
# (query_to_xml('SELECT ... "USERS"'), table_to_xml('"GLT"'::regclass), to_regclass(...)) or written as a U&"..."
# Unicode-escape identifier never reaches enforce_permissions or the foreign-schema check. Denying the functions and
# forms that consume a name or a query as text costs nothing legitimate: nothing in SYSTEM_PROMPT, FOLLOWUP_RESOLUTION_
# RULES or FORMAT_PROMPT uses any of them (pinned by test_prompts_and_examples_contain_no_denied_form). The list also
# denies calls with effects outside the query or that probe the server (set_config/current_setting, sequences, advisory
# locks, pg_notify, backend signalling, pg_reload_conf, size/definition/privilege lookups); pg_sleep is not in it (bounded
# by statement_timeout, see get_conn).
# This is defense in depth, not a proof: a denylist cannot know a function it has not seen. REVIEW THIS LIST ON EVERY
# POSTGRES MAJOR UPGRADE for new functions that take a query or a relation name as text. default_transaction_read_only
# (get_conn) and, in a future Batch, a least-privilege query role are the database-side layers.
_DENIED_FUNCTIONS = (
    r"query_to_xml\w*", r"table_to_xml\w*", r"schema_to_xml\w*", r"database_to_xml\w*", r"cursor_to_xml",
    r"to_reg(?:class|namespace|proc|procedure|oper|operator|type|role|collation)",
    r"ts_stat", r"dblink\w*", r"lo_\w+", r"pg_read_\w+", r"pg_ls_\w+", r"pg_stat_file",
    r"set_config", r"nextval", r"setval", r"currval", r"pg_advisory\w*", r"pg_notify",
    r"pg_terminate_backend", r"pg_cancel_backend", r"pg_reload_conf", r"pg_get_\w*def",
    r"pg_relation_size", r"pg_total_relation_size", r"current_setting",
    r"pg_try_advisory\w*", r"pg_(?:table|indexes)_size", r"pg_relation_(?:filenode|filepath)",
    r"has_\w+_privilege", r"pg_get_serial_sequence", r"lastval",
    # 86e3gzqmf: the set-returning functions behind pg_stat_activity / pg_stat_* and pg_settings (same rows as the views)
    r"pg_stat_get_\w+", r"pg_show_all_\w+",
)
# Optional opening double quote and optional closing one: "query_to_xml"(...) is a valid call. (?<![\w$]) keeps a
# longer identifier (my_nextval_x) from matching mid-word; a schema qualifier (pg_catalog.) ends in "." so still matches.
_DENIED_FUNC_RE = re.compile(r'(?<![\w$])"?(?:' + "|".join(_DENIED_FUNCTIONS) + r')"?\s*\(', re.IGNORECASE)
_UNICODE_ESCAPE_IDENT_RE = re.compile(r'\bU&\s*"', re.IGNORECASE)
# A regclass-family cast or type. A QUOTED upper-case identifier that merely spells such a word ("REGTYPE") is a column
# name, so a leading or trailing double quote exempts it in the unquoted alternative. Postgres does resolve a quoted
# LOWERCASE type name in cast/type position ('x'::"regclass"), so the second alternative rejects that exact form
# (case-sensitive group; accepted cost: a quoted lowercase alias "regclass" is rejected too).
# 86e3jx6fv item 8 (Batch D D2): a cast followed by a SPACELESS quoted alias ('GLT'::regclass"r") slipped through, the
# alias's opening double quote satisfied the (?!") column exemption. So the third alternative rejects a reg* word that
# directly follows :: (optional whitespace, any case) whatever comes after it. A column is never written right after
# ::, so the "REGTYPE" / a."REGCLASS" column exemption is unchanged.
_REG_TYPE_RE = re.compile(
    r'(?<!")\breg(?:class|namespace|proc|procedure|oper|operator|type|role|config|dictionary|collation)\b(?!")'
    r'|::\s*reg(?:class|namespace|proc|procedure|oper|operator|type|role|config|dictionary|collation)\b'
    r'|(?-i:"reg(?:class|namespace|proc|procedure|oper|operator|type|role|config|dictionary|collation)")',
    re.IGNORECASE)
# pg_stats / pg_statistic expose sampled column values (most_common_vals) for every table the shared query role can
# read: a data path around the module permissions. No legitimate query names them.
_PG_STATS_RE = re.compile(r'(?<![\w$])"?pg_stat(?:s|istic)\w*"?(?![\w$])', re.IGNORECASE)
# 86e3gzqmf (spec D1): any reference to the system catalogs: the pg_catalog and information_schema schemas and every
# relation or schema named pg_* (pg_class, pg_tables, pg_stat_activity incl. other sessions' SQL, pg_settings,
# pg_stat_user_tables, pg_temp ...). They expose table names, row counts, server settings and other sessions' queries
# to any authenticated user, around the module permissions. Unquoted: any case (Postgres folds it to lower case).
# Quoted: exact lower case only ("PG_CLASS" is a column or alias, quoted names are case-sensitive). A pg_* name followed
# by "(" is a FUNCTION call and is left to _DENIED_FUNCTIONS (pg_sleep stays allowed, 86e38zcdx). current_user and
# version() expose no tenant data and stay allowed. Nothing the prompts teach names any of these (pinned by
# test_d2_prompts_name_no_catalog_relation_outside_quoted_postgres_error_lines). The two-role DB split is the
# database-side layer for this, in a future Batch.
_CATALOG_RELATION_RE = re.compile(
    r'(?<![\w$"])(?:pg_\w*|information_schema)(?![\w$])(?!\s*\()'
    r'|(?-i:"(?:pg_[^"]*|information_schema)")(?!\s*\()',
    re.IGNORECASE)


def _reject_name_consumers(sql: str, stripped_sql: str, question: str) -> None:
    """Fail-closed rejection of the forms in _DENIED_FUNCTIONS, U&"..." identifiers, regclass-family casts/types
    (_REG_TYPE_RE), any reference to pg_stats / pg_statistic (_PG_STATS_RE: sampled column values of every readable
    table) and any catalog relation or schema (_CATALOG_RELATION_RE, 86e3gzqmf). Same shape as the SELECT INTO guard:
    400, log_query_error, generic text."""
    hit = (_DENIED_FUNC_RE.search(stripped_sql) or _UNICODE_ESCAPE_IDENT_RE.search(stripped_sql)
           or _REG_TYPE_RE.search(stripped_sql) or _PG_STATS_RE.search(stripped_sql)
           or _CATALOG_RELATION_RE.search(stripped_sql))
    if hit:
        log.warning(f"Rejected SQL using a name-consuming function or identifier form ({hit.group(0)!r}): {_sql_for_log(sql)}")
        log_query_error(question, sql, "", "rejected: name-consuming function or identifier form")
        raise HTTPException(status_code=400, detail="Generated query used a disallowed function or identifier form - rejected for safety.")


def _validate_generated_sql(sql: str, schema: str, permissions: dict, question: str) -> None:
    """Runs every safety check a piece of model-generated SQL must pass before execution.

    Factored out of query() (86e30r8tm/86e30r8z5) so the self-correction retry path below
    can run a corrected query through the exact same checks as the first-pass query --
    a self-corrected query is still model output and must never skip these just because
    it's a second attempt. Raises HTTPException on any rejection, same as the inline
    version this replaced.
    """
    # Computed once, up front, so every check below can use the literal/comment-stripped
    # copy rather than raw sql -- 86e35uf4h: the schema-isolation and permission checks
    # previously scanned raw sql and could false-positive on a schema/table-name-shaped
    # substring sitting inside a real string literal or comment.
    stripped_sql = _strip_sql_literals_and_comments(sql)

    # Schema isolation (86e2t0frp/CR-2) - the model is shown only its own session's
    # schema via {schema} in SYSTEM_PROMPT, but nothing downstream previously checked
    # that the generated SQL actually stayed inside it. enforce_permissions() below
    # checks table names, not schema qualifiers, so this must run first.
    foreign_schemas = _foreign_schema_qualifiers(stripped_sql, schema)
    if foreign_schemas:
        log.warning(f"Rejected SQL referencing foreign schema(s) {sorted(foreign_schemas)}: {_sql_for_log(sql)}")
        log_query_error(question, sql, "", f"rejected: foreign schema(s) {sorted(foreign_schemas)}")
        raise HTTPException(status_code=400, detail=_FOREIGN_SCHEMA_REJECTION)

    # Safety check - allow SELECT and WITH (CTEs), reject everything else
    # Matched on the literal/comment-stripped copy so a leading comment is allowed; stripped_sql falls back to
    # the raw text on malformed input, so this stays fail-closed. Execution still uses the original sql.
    if not re.match(r"^\s*(SELECT|WITH)\b", stripped_sql, re.IGNORECASE):
        log.warning(f"Rejected non-SELECT SQL: {_sql_for_log(sql)}")
        log_query_error(question, sql, "", "rejected: not a SELECT")
        raise HTTPException(status_code=400, detail="Generated query was not a SELECT - rejected for safety.")
    # Multi-statement smuggling (86e2rryyv) - the SELECT-only anchor above only checks
    # the START of the string; a smuggled second statement using no blocked keyword
    # (another SELECT, pg_sleep() for DoS, a session-level SET/COPY/VACUUM) would
    # otherwise reach psycopg's simple-query execution, which runs every
    # ';'-separated statement in one call.
    if _has_multiple_statements(sql):
        log.warning(f"Rejected multi-statement SQL: {_sql_for_log(sql)}")
        log_query_error(question, sql, "", "rejected: multiple statements")
        raise HTTPException(status_code=400, detail="Generated query contained multiple statements - rejected for safety.")
    # Unsupported string syntax (86e2wdz6p, refined by 86e31dqad): dollar-quoted
    # strings ($tag$...$tag$) are never legitimately needed as SQL SYNTAX here
    # (the model is never prompted to emit them) and
    # _strip_sql_literals_and_comments() does not recognize them as a string-
    # delimiter form -- a raw apostrophe inside one can make a real literal or
    # block comment look unterminated to that scanner. 86e31dqad: this check now
    # runs against stripped_sql (computed at the top of this function, shared with the
    # write-keyword check below), not the raw sql -- so it fires only on a
    # $tag$-shaped pattern that SURVIVES literal/comment stripping, i.e. one
    # that is not actually sitting inside a real string literal or comment.
    # A genuine business value shaped like $TAG$ (a promo code, a memo field)
    # can therefore appear inside an ordinary '...' literal without tripping
    # this guard; the actual dollar-quoting SYNTAX form is what's rejected.
    # This reuses the same stripped copy the write-keyword check below relies
    # on, so it also inherits that scanner's own fail-closed design: per its
    # docstring, _strip_sql_literals_and_comments() returns the ORIGINAL
    # string unchanged whenever it can't confidently parse something, rather
    # than guessing -- so an unparseable construct can never be used to hide
    # real dollar-quoting syntax from this check the way the two-span
    # quote-pairing gap 86e2yq8d0 fixed once let a write keyword hide inside
    # an E'...'/U&'...' literal from the write-keyword check (that gap was
    # specific to E'...'/U&'...' pairing, not this guard, but both checks now
    # share the same fail-closed scanner and its guarantees).
    if re.search(r"\$[A-Za-z_0-9]*\$", stripped_sql):
        log.warning(f"Rejected SQL with dollar-quoted string syntax: {_sql_for_log(sql)}")
        log_query_error(question, sql, "", "rejected: dollar-quoted string syntax")
        raise HTTPException(status_code=400, detail="Generated query contained unsupported string syntax - rejected for safety.")

    # Secondary check - must not contain any write keywords. Search a
    # literal-and-comment-stripped copy (86e2t0g4a) so a business name like
    # "Grant Industries" or a comment mentioning "update" doesn't false-flag --
    # the ORIGINAL sql is still what gets logged/executed, only the search
    # target changes. 86e2wdz6p (an apostrophe inside a comment or
    # double-quoted identifier hiding a real write keyword from this check)
    # is fixed: _strip_sql_literals_and_comments() is a single left-to-right
    # scanner that fails closed on unrecognized string syntax rather than a
    # vulnerable two-regex composition.
    if re.search(r"\b(INSERT|UPDATE|DELETE|MERGE|DROP|CREATE|ALTER|TRUNCATE|GRANT|REVOKE)\b", stripped_sql, re.IGNORECASE):
        log.warning(f"Rejected SQL with write keyword: {_sql_for_log(sql)}")
        log_query_error(question, sql, "", "rejected: write keyword")
        raise HTTPException(status_code=400, detail="Generated query contained disallowed keywords - rejected for safety.")

    # SELECT ... INTO [TEMP|TEMPORARY|UNLOGGED] table (86e38zcbg) - creates
    # a real table (temporary or, with no keyword at all, PERMANENT) and
    # is not in the write-keyword list above, so it passed every prior
    # check. Runs against the same stripped_sql the write-keyword check
    # above uses, inheriting its fail-closed guarantees. Uses
    # _has_select_into_ddl() (86e39t6rr), not a bare _SELECT_INTO_RE.search(),
    # so a plain-English "into" sitting inside a legitimate quoted alias's
    # own text isn't mistaken for the real SQL keyword.
    #
    # literals_stripped tells _has_select_into_ddl() whether stripped_sql is
    # genuinely stripped or is actually the raw sql returned unchanged by
    # _strip_sql_literals_and_comments()'s own fail-closed path (an
    # E'...'/U&'...' literal, an unterminated literal, or an unterminated
    # block comment elsewhere in the query -- see that function's
    # docstring). `stripped_sql is sql` reliably detects this: the
    # fail-closed branches all `return sql` (the identical object), while
    # the success path always builds a brand-new string via `"".join(...)`.
    # Without this, a stray, unrelated `"` inside a comment or an ordinary
    # (still-unblanked) string literal on a fail-closed input could make
    # _has_select_into_ddl()'s quote-parity counting land on an odd count at
    # the position of a REAL `INTO evil_table` DDL attempt, silently
    # skipping it -- confirmed live:
    # "SELECT 1 /* \" */, 2 INTO evil FROM t WHERE x = E'y'" passed
    # validation before this fix.
    if _has_select_into_ddl(stripped_sql, literals_stripped=(stripped_sql is not sql)):
        log.warning(f"Rejected SQL with SELECT INTO table-creation syntax: {_sql_for_log(sql)}")
        log_query_error(question, sql, "", "rejected: SELECT INTO table creation")
        raise HTTPException(status_code=400, detail="Generated query attempted to create a table via SELECT INTO - rejected for safety.")

    # 86e3gevdm: table names hidden in string arguments / U&"..." identifiers -- see _DENIED_FUNCTIONS.
    _reject_name_consumers(sql, stripped_sql, question)

    # Permission enforcement - block queries touching modules user has No Access to
    enforce_permissions(permissions, stripped_sql)

    # Catch-all for SQL the stripper could not normalize (Batch V final review C1). When
    # _strip_sql_literals_and_comments() meets an E'...' or U&'...' literal, an unterminated
    # single-quoted literal, or an unterminated block comment, it returns the ORIGINAL object
    # unchanged (its documented fail-closed sentinel, detected here as `stripped_sql is sql`,
    # the same test the SELECT INTO guard above uses). That keeps the write-keyword and
    # multi-statement scans safe, but it also means comments were never turned into whitespace,
    # and several checks above only work on normalized text: the name-consumer denylist needs
    # `name\s*\(` and the foreign-schema check needs `"schema"\s*\.\s*"TABLE"`, so a comment
    # between a denied function name and its "(" or inside a schema qualifier (valid SQL:
    # comments are whitespace) slipped past both, e.g.
    #   SELECT E'x', query_to_xml /* c */ ('SELECT 1',true,false,'')
    # Reject beats normalize: the model is never prompted to emit these forms (same reasoning
    # as the dollar-quote guard above), and normalizing a second view would require every
    # adjacency-sensitive regex to be made safe against literal/comment interleavings the
    # scanner has already declared it cannot parse. Placed LAST, after every specific
    # rejection, so a query those checks already reject keeps its specific reason (a denied
    # function stays a 400 name-consumer rejection, a denied module stays a 403).
    if stripped_sql is sql:
        log.warning(f"Rejected SQL with string/comment syntax the scanner cannot normalize: {_sql_for_log(sql)}")
        log_query_error(question, sql, "", "rejected: unsupported string/comment syntax")
        raise HTTPException(status_code=400, detail="Generated query contained unsupported string syntax - rejected for safety.")


def _self_correct_sql(question: str, schema: str, failed_sql: str, pg_error: str, history: list,
                      *, instruction: str | None = None) -> str:
    """One-shot self-correction: shows the model its own SQL and Postgres's exact error,
    asks for a corrected query. 86e30r8tm/86e30r8z5/86e30r8wh/86e30rdy1 (Group A): all four
    were the model generating syntactically invalid SQL (window fn + GROUP BY, UNION +
    ORDER BY-on-alias, aggregate in WHERE, malformed string/identifier) with the raw
    Postgres error reaching the user instead of a chance to fix it. This mirrors the
    existing missing-column retry inside query() below (same "one retry, never a loop"
    philosophy) but is shape-agnostic -- it catches any SQL error, not one specific
    SQLSTATE, since the failure modes here are varied syntax errors, not one recurring
    pattern.

    Deliberately a focused, cheap correction call, not a full re-derivation: the model
    already has the right instinct (the question), it just needs to see exactly what
    Postgres rejected and why. Does not re-send the full SYSTEM_PROMPT's every rule as a
    fresh reasoning pass -- reuses it (still cache-eligible, same prompt text) but keeps
    the user-turn small and targeted.

    `instruction` (86e3b8rwe) replaces the default "failed with this PostgreSQL error" user
    turn, for a retry whose reason is not a Postgres error (e.g. _apply_par_time_retry's
    semantic check). Existing callers omit it and are unchanged.
    """
    now = _today_local()
    fiscal_start_month = _fiscal_start_month(schema)
    fy_boundaries = _fiscal_year_boundaries(fiscal_start_month, now)
    prompt = _build_prompt(schema, now.strftime("%Y-%m-%d"), now.strftime("%A"), now.year, fiscal_start_month,
                            fy_boundaries["last_fy_start"], fy_boundaries["last_fy_end"],
                            fy_boundaries["current_fy_start"], has_history=bool(history))
    messages = _build_messages(history or [], question)
    messages.append({"role": "assistant", "content": failed_sql})
    messages.append({
        "role": "user",
        "content": instruction or (
            f"That query failed with this PostgreSQL error:\n{pg_error}\n\n"
            "Fix the query so it runs successfully. Return ONLY the corrected SQL, "
            "no explanation."
        ),
    })
    msg = get_claude().messages.create(
        model=HAIKU_MODEL,
        max_tokens=8192,
        system=[{
            "type": "text",
            "text": prompt,
            "cache_control": {"type": "ephemeral"},
        }],
        messages=messages,
    )
    _log_cache_usage("self_correct_sql", msg)
    if msg.stop_reason == "max_tokens":
        # Same reasoning as generate_sql()'s own check above: whatever text came back is a
        # cut-off fragment, not valid SQL. Returning it would just produce a second,
        # more confusing failure on the retry attempt below -- fail this correction
        # attempt cleanly instead, so it surfaces as the ORIGINAL Postgres error (still
        # useful) rather than a garbled one.
        log.warning(f"_self_correct_sql: hit the max_tokens ceiling (question={question!r})")
        raise psycopg.Error("Self-correction response was truncated before completing")
    if msg.stop_reason == "refusal":
        log.warning(f"_self_correct_sql: model refused (question={question!r})")
        raise psycopg.Error("Self-correction was declined by the model")
    full_response = _msg_text(msg)
    fence_match = re.search(r"```(?:sql)?\s*\n(.*?)```", full_response, re.IGNORECASE | re.DOTALL)
    corrected = fence_match.group(1).strip() if fence_match else full_response
    corrected, _ = _strip_trailing_reference_block(corrected)
    corrected, _ = _detect_self_correction_leak(corrected)
    return fix_schema_quoting(corrected)


# 86e3b8rwe (from 86e39gxpk): the SQL model sometimes summed "ARINVDET"."PRICE" across all items
# without the PAR_TIME filter (SYSTEM_PROMPT's "PAR_TIME RULE"), double-counting materials-list
# sub-lines -- measured ~21% high on ErinTest, with the list and its footer still agreeing with each
# other. The rule is already stated three times in the prompt and the failure is intermittent, so
# this is a deterministic check on the generated SQL plus ONE retry, not more wording.
_SUM_OR_AVG_OPEN = re.compile(r"\b(?:SUM|AVG)\s*\(", re.IGNORECASE)
# Word-bounded, so LIST_PRICE / SHIPPED / QUANTITY do not count; a CTE alias named price/costs still does.
_LINE_AMOUNT_COLUMN = re.compile(r'\b(?:PRICE|COSTS|SHIP|QUAN)\b', re.IGNORECASE)
# The rule's own documented exception: a query pinned to a SPECIFIC inventory item may itself be a
# sub-line and must not be filtered. The prompt teaches several ways to pin one, so recognise them all:
# INVEN (quoted or not, any qualifier), INVENTRY."ID", or a description column, compared to a string
# literal or a subselect -- in either operand order. Deliberately liberal: when unsure, prefer NOT
# retrying, because a wrongly-applied filter silently UNDER-counts the very item the user asked about.
# Known trade-off: a description/subselect filter that selects a whole CATEGORY of items
# (DESCR_1 ILIKE '%door%') is indistinguishable from a one-item pin by regex and is exempt too.
# Negations (<>, !=, NOT IN) are NOT pins: "everything except FREIGHT" still needs the filter.
# The `\s*` runs are collapsed (single \s* between optional groups) to keep failed matches linear.
_ITEM_COLUMN = r'(?:"INVENTRY"\."ID"|(?:"?\w+"?\.)?"?(?:INVEN|DESCR_1|DESCR)"?)'
_LITERAL_OR_SUBSELECT = r"\s*(?:trim\s*\(\s*)?(?:ANY\s*\(\s*)?(?:ARRAY\s*\[\s*)?(?:\(\s*)?(?:'|SELECT\b)"
_PINS_SPECIFIC_ITEM_FORWARD = re.compile(
    _ITEM_COLUMN + r"\s*\)?\s*(?:=|ILIKE|LIKE|IN\b|ANY\b)" + _LITERAL_OR_SUBSELECT, re.IGNORECASE)
_PINS_SPECIFIC_ITEM_REVERSED = re.compile(
    r"'[^']*'\s*=\s*(?:trim\s*\(\s*)?" + _ITEM_COLUMN, re.IGNORECASE)


def _paren_close_map(stripped_sql: str) -> dict:
    """Index of every "(" -> index of its matching ")", built in ONE left-to-right stack pass over the
    literal/comment-stripped SQL. An unclosed "(" maps to len(stripped_sql); a stray ")" with nothing open is
    ignored. Same pairing as counting depth forward from each "(" (86e3uappx item 6), without the rescan."""
    close_of, stack = {}, []
    for i, ch in enumerate(stripped_sql):
        if ch == "(":
            stack.append(i)
        elif ch == ")" and stack:
            close_of[stack.pop()] = i
    for o in stack:
        close_of[o] = len(stripped_sql)
    return close_of


def _sums_a_line_amount(stripped_sql: str) -> bool:
    """True if any SUM(...) / AVG(...) argument mentions PRICE, COSTS, SHIP or QUAN. Each call's
    argument is found through the paren close map, so SUM(COALESCE(x, 0)), SUM(ROUND(x, 2)) and
    SUM(CAST(x AS numeric)) are seen, which a single regex over nested parentheses cannot do. Linear: the
    column words are located once and each SUM( is one bisect against them (86e3uappx item 6)."""
    close_of = _paren_close_map(stripped_sql)
    n = len(stripped_sql)
    amount_pos = [m.start() for m in _LINE_AMOUNT_COLUMN.finditer(stripped_sql)]
    for m in _SUM_OR_AVG_OPEN.finditer(stripped_sql):
        k = min(close_of[m.end() - 1] + 1, n)         # just past the matching ")" (len for an unclosed one)
        t = bisect.bisect_left(amount_pos, m.end())
        if t < len(amount_pos) and amount_pos[t] < k:
            return True
    return False



def _summed_line_amount_columns(stripped_sql: str) -> set:
    """The line-amount column words (PRICE, COSTS, SHIP, QUAN; upper-cased) that appear inside any SUM(...) / AVG(...)
    argument. The argument spans come from the paren close map and are merged before the column words are read, so
    nested sums (SUM(SUM(x))) are read once and the scan stays linear (86e3uappx item 5)."""
    close_of = _paren_close_map(stripped_sql)
    spans = _merge_intervals((m.end(), close_of[m.end() - 1]) for m in _SUM_OR_AVG_OPEN.finditer(stripped_sql))
    starts = [iv[0] for iv in spans]
    return {m.group(0).upper() for m in _LINE_AMOUNT_COLUMN.finditer(stripped_sql)
            if _in_intervals(spans, starts, m.start())}

# 86e3u4qtf: a real "blank" predicate is PAR_TIME IS NULL (the NULL branch is required), or (86e3uappx items 2 and 4)
# NULLIF([trim(]PAR_TIME[)], '') IS NULL, or COALESCE([trim(]PAR_TIME[)], '') = '' / IN (''), optionally wrapped in
# TRIM(...) and/or LENGTH(...) / CHAR_LENGTH(...) (= 0). COALESCE(...) <> '', LENGTH(...) > 0 and NULLIF(...) IS NOT
# NULL select the SUB-lines and do not count. Every argument run is bounded (120 characters,
# no parentheses or commas), so a failed match costs O(120) per `COALESCE(` / `NULLIF(` start: repeated openers with
# no `)` stay linear. Accepted limit: the check runs on the literal-stripped copy, where every literal reads as '',
# so COALESCE(PAR_TIME, 'x') = 'y' reads as the blank form (no prompt example or observed model output writes it).
_COALESCE_BLANK_ARG = (
    r"COALESCE\s*\(\s*(?:trim\s*\(\s*)?[^(),]{0,120}PAR_TIME\"?\s*\)?\s*,\s*''\s*\)\s*\)?\s*\)?\s*")
# `= 0` is the blank form ONLY directly after a LENGTH / CHAR_LENGTH prefix (POSITION('x' IN COALESCE(...)) = 0 and
# COALESCE(...) = 0 are not blank); `= ''` and IN ('') need no prefix.
_BLANK_PAR_TIME = re.compile(
    r'PAR_TIME"?\s+IS\s+NULL'
    r"|(?:CHAR_LENGTH|LENGTH)\s*\(\s*(?:trim\s*\(\s*)?" + _COALESCE_BLANK_ARG + r"=\s*0\b"
    r"|(?:trim\s*\(\s*)?" + _COALESCE_BLANK_ARG + r"(?:=\s*''|IN\s*\(\s*''\s*\))"
    r"|NULLIF\s*\(\s*(?:trim\s*\(\s*)?[^(),]{0,120}PAR_TIME\"?\s*\)?\s*,\s*''\s*\)\s*IS\s+NULL",
    re.IGNORECASE)
_FILTER_OPEN = re.compile(r"\s*FILTER\s*\(", re.IGNORECASE)
_FILTER_WORD_OPEN = re.compile(r"\bFILTER\s*\(", re.IGNORECASE)
_OVER_NEXT = re.compile(r"\s*OVER\b", re.IGNORECASE)
_GROUP_BY = re.compile(r"\bGROUP\s+BY\b", re.IGNORECASE)
_CLAUSE_KEYWORD = re.compile(
    r"\b(SELECT|FROM|WHERE|ON|HAVING|JOIN|GROUP\s+BY|ORDER\s+BY|WINDOW|LIMIT|UNION|INTERSECT|EXCEPT)\b",
    re.IGNORECASE)
_PREDICATE_CLAUSES = {"WHERE", "ON", "HAVING", "JOIN"}
_SOURCE_CLAUSES = {"FROM", "JOIN"}
# a "(" that opens a subquery (its body starts with SELECT or WITH), as opposed to a function call or grouping paren
_QUERY_PAREN_BODY = re.compile(r"\s*(?:SELECT|WITH)\b", re.IGNORECASE)
# one identifier token: a double-quoted identifier is always consumed WHOLE (so the scan can never re-enter inside the
# quotes and pair the closing quote of one identifier with the opening quote of the next), else a bare word. Whether
# the token is a qualifier ("ARINVDET"."PRICE", lines.price) is checked in code with _QUALIFIER_NEXT, not with a
# lookahead (a rejected quoted match let the bare-word branch match inside it: Batch W3 T1b review I1).
_IDENT_TOKEN = re.compile(r'"([^"]*)"|\b(\w+)\b')
_QUALIFIER_NEXT = re.compile(r"\s*\.")
# a CTE definition: WITH [RECURSIVE] name [(cols)] AS [NOT] [MATERIALIZED] (   or   , name AS (
_CTE_DEFINITION = re.compile(
    r'(?:\bWITH\s+(?:RECURSIVE\s+)?|,\s*)(?:"([^"]{1,100})"|(\w+))\s*(?:\([^()]{0,300}\)\s*)?'
    r"AS\s*(?:NOT\s+)?(?:MATERIALIZED\s+)?\(", re.IGNORECASE)


def _merge_intervals(spans):
    out = []
    for a, b in sorted(spans):
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


def _in_intervals(merged, starts, pos):
    i = bisect.bisect_right(starts, pos) - 1
    return i >= 0 and merged[i][0] <= pos < merged[i][1]


def _par_time_governs_line_sums(sql: str) -> bool:
    """True when every SUM/AVG over a line amount (PRICE, COSTS, SHIP, QUAN) is governed by a blank-PAR_TIME
    predicate (see _BLANK_PAR_TIME): inside the aggregate's argument (CASE), in the FILTER (WHERE ...) that follows
    it, or in a WHERE/ON/HAVING/JOIN clause outside every aggregate, provided no line-amount aggregate is a row-list
    window (a line-amount window in an ungrouped block: there a WHERE filter would drop rows, so only the
    in-aggregate forms count). A query with no line-amount SUM/AVG has nothing to govern and returns True. 86e3u4qtf.

    Scope (86e3uappx, Batch W3): the SQL is split into SELECT blocks (one per UNION branch, per subquery, per CTE
    body). An aggregate's WHERE-style predicate must sit in the aggregate's OWN block, or -- only when that block does
    not itself read ARINVDET -- in every ARINVDET-reading block feeding it through FROM/JOIN (a CTE named there or a
    derived table), recursively. A predicate inside an EXISTS / IN / NOT IN / ANY / scalar-comparison subquery is in
    a block that feeds nothing and so governs nothing; a UNION branch governs only itself (item 4). A window over a
    CTE or derived table is a row list only if the nearest ARINVDET-reading block feeding it is ungrouped (item 1).

    One left-to-right paren pass plus bisect lookups; no nested quantifiers. Accepted false passes: an inverted CASE
    (THEN 0 ELSE PRICE) and WHERE NOT (blank) -- with any blank form, including WHERE NOT (NULLIF(PAR_TIME, '') IS
    NULL) and NOT on the COALESCE forms -- all of which still contain the blank predicate text."""
    st = _strip_sql_literals_and_comments(sql)
    n = len(st)
    agg_opens = {m.end() - 1: m.start() for m in _SUM_OR_AVG_OPEN.finditer(st)}
    close_of = _paren_close_map(st)
    # depth_at[i]: paren depth at i (a "(" counts itself); region_at[i]: the innermost enclosing subquery "(" (-1 =
    # the top level). A "(" itself belongs to the region that encloses it.
    depth_at, region_at = [0] * (n + 1), [-1] * (n + 1)
    stack, regions, depth = [], [-1], 0
    query_opens = set()
    for i, ch in enumerate(st):
        if ch == "(":
            region_at[i] = regions[-1]
            depth += 1
            is_query = _QUERY_PAREN_BODY.match(st, i + 1) is not None
            if is_query:
                query_opens.add(i)
                regions.append(i)
            stack.append(is_query)
            depth_at[i] = depth
            continue
        if ch == ")" and stack:
            if stack.pop():
                regions.pop()
            depth -= 1
        depth_at[i] = depth
        region_at[i] = regions[-1]
    # (start, end, arg_open, arg_close) per SUM/AVG, the span extended over a following FILTER (...)
    aggs = []
    for o, start in agg_opens.items():
        c = close_of[o]
        end = min(c + 1, n)
        fm = _FILTER_OPEN.match(st, end)
        if fm and (fm.end() - 1) in close_of:
            end = min(close_of[fm.end() - 1] + 1, n)
        aggs.append((start, end, o, c))
    amount_pos = [m.start() for m in _LINE_AMOUNT_COLUMN.finditer(st)]
    line_aggs = [a for a in aggs
                 if (lambda k: k < len(amount_pos) and amount_pos[k] < a[3])(bisect.bisect_left(amount_pos, a[2] + 1))]
    if not line_aggs:
        return True
    pred_pos = [m.start() for m in _BLANK_PAR_TIME.finditer(st)]
    if not pred_pos:
        return False

    def holds_predicate(lo, hi):
        k = bisect.bisect_left(pred_pos, lo)
        return k < len(pred_pos) and pred_pos[k] < hi

    ungoverned = [a for a in line_aggs if not holds_predicate(a[0], a[1])]
    if not ungoverned:
        return True

    def region_depth(r):
        return depth_at[r] if r >= 0 else 0

    # Blocks: each SELECT at its region's own depth starts one (a UNION branch starts a new one). block_of(pos) is the
    # SELECT position of the block containing pos, or None (a WITH header, or SQL with no SELECT at all).
    keywords = [(m.start(), re.sub(r"\s+", " ", m.group(1).upper())) for m in _CLAUSE_KEYWORD.finditer(st)]
    selects_in = {}
    for p, name in keywords:
        r = region_at[p]
        if name == "SELECT" and depth_at[p] == region_depth(r):
            selects_in.setdefault(r, []).append(p)

    def block_of(pos):
        sel = selects_in.get(region_at[pos])
        if not sel:
            return None
        k = bisect.bisect_right(sel, pos) - 1
        return sel[k] if k >= 0 else None

    # each block's own top-level clause keywords (at the block's depth), in order
    block_kw = {}
    for p, name in keywords:
        if depth_at[p] == region_depth(region_at[p]):
            block_kw.setdefault(block_of(p), []).append((p, name))

    def clause_of(pos):
        b = block_of(pos)
        kws = block_kw.get(b, [])
        k = bisect.bisect_left(kws, (pos, "")) - 1
        return b, (kws[k][1] if k >= 0 else None)

    grouped = {b for b, kws in block_kw.items() if any(name == "GROUP BY" for _, name in kws)}
    # FROM/JOIN sources of each block: derived tables (a subquery "(" in the block's FROM/JOIN) and named CTEs
    sources = {}
    for o in query_opens:
        if depth_at[o] - 1 == region_depth(region_at[o]):
            b, clause = clause_of(o)
            if clause in _SOURCE_CLAUSES:
                sources.setdefault(b, set()).add(o)
    cte_body = {}
    for m in _CTE_DEFINITION.finditer(st):
        if (m.end() - 1) in query_opens:
            cte_body.setdefault((m.group(1) or m.group(2)).upper(), m.end() - 1)
    # one token pass: ARINVDET named as a TABLE, and CTE names, in a block's own FROM/JOIN (not as a qualifier)
    reads_arinvdet = set()
    for m in _IDENT_TOKEN.finditer(st):
        name = (m.group(1) if m.group(1) is not None else m.group(2)).upper()
        body = cte_body.get(name)
        if (name != "ARINVDET" and body is None) or _QUALIFIER_NEXT.match(st, m.end()) \
                or depth_at[m.start()] != region_depth(region_at[m.start()]):
            continue
        b, clause = clause_of(m.start())
        if clause in _SOURCE_CLAUSES:
            if name == "ARINVDET":
                reads_arinvdet.add(b)
            else:
                sources.setdefault(b, set()).add(body)

    def feeding_blocks(b):
        out = []
        for r in sources.get(b, ()):
            out.extend(selects_in.get(r, ()))
        return out

    # Feeder chains deeper than this are not followed (pathological output; the default recursion limit is 1000). A
    # chain cut at the cap is UNRESOLVED, never "reads nothing": nearest_readers reports it as capped, is_row_list
    # treats it as a row list and governed() as ungoverned, so the query is flagged. A capped result depends on the
    # depth it was reached at, so it is memoized per (block, depth); only an uncapped result is memoized per block
    # (Batch W3 T1b review M3: a block first reached from the deep end must not hand [] to a later shallow reach).
    max_feed_depth = 64
    memo_nearest, memo_nearest_capped = {}, {}

    def nearest_readers(b, seen=frozenset()):
        """(blocks, capped): the nearest ARINVDET-reading blocks (b itself if it reads ARINVDET, else those of its
        feeders), and whether the search was cut at the depth cap."""
        if b in memo_nearest:
            return memo_nearest[b], False
        if (b, len(seen)) in memo_nearest_capped:
            return memo_nearest_capped[(b, len(seen))]
        found, capped = [], False
        if b in reads_arinvdet:
            found = [b]
        elif len(seen) >= max_feed_depth:
            capped = bool(feeding_blocks(b))
        else:
            for f in feeding_blocks(b):
                if f not in seen:
                    sub, sub_capped = nearest_readers(f, seen | {b})
                    found.extend(sub)
                    capped = capped or sub_capped
        if capped:
            memo_nearest_capped[(b, len(seen))] = (found, True)
        else:
            memo_nearest[b] = found
        return found, capped

    # WHERE-style predicates outside every SUM/AVG span and every FILTER group (those belong to their own aggregate)
    excluded = [(a[0], a[1]) for a in aggs]
    for fm in _FILTER_WORD_OPEN.finditer(st):
        excluded.append((fm.start(), min(close_of.get(fm.end() - 1, n) + 1, n)))
    merged = _merge_intervals(excluded)
    starts = [iv[0] for iv in merged]
    has_own_predicate = set()
    for p in pred_pos:
        if _in_intervals(merged, starts, p):
            continue
        b, clause = clause_of(p)
        if clause in _PREDICATE_CLAUSES:
            has_own_predicate.add(b)

    # A block whose source cannot be resolved (it reads neither ARINVDET nor a CTE / derived table that does, e.g. a
    # prompt fragment that starts inside a CTE body) keeps the W2 rule: a predicate in any block that is not an
    # expression subquery (the top level, a CTE body or a derived table) counts.
    source_regions = set(cte_body.values()).union(*sources.values())
    fallback_ok = any((region_at[b] if b is not None else -1) in source_regions | {-1} for b in has_own_predicate)
    memo_governed, memo_governed_capped = {}, {}

    def governed(b, seen=frozenset()):
        """(ok, capped), memoized like nearest_readers."""
        if b in memo_governed:
            return memo_governed[b], False
        if (b, len(seen)) in memo_governed_capped:
            return memo_governed_capped[(b, len(seen))]
        capped = False
        if b in has_own_predicate:
            ok = True
        elif b in reads_arinvdet:
            ok = False
        elif len(seen) >= max_feed_depth:
            ok, capped = False, True
        else:
            feeders = []
            for f in feeding_blocks(b):
                if f in seen:
                    continue
                readers, f_capped = nearest_readers(f)
                if f_capped:
                    ok, capped = False, True     # an unresolved ARINVDET feeder: flagged
                    break
                if readers:
                    feeders.append(f)
            else:
                ok = True if feeders else fallback_ok
                for f in feeders:
                    f_ok, f_capped = governed(f, seen | {b})
                    capped = capped or f_capped
                    if not f_ok:
                        ok = False
                        break
        if capped:
            memo_governed_capped[(b, len(seen))] = (ok, True)
        else:
            memo_governed[b] = ok
        return ok, capped

    if not all(governed(block_of(a[0]))[0] for a in ungoverned):
        return False

    def is_row_list(a):
        if not _OVER_NEXT.match(st, a[1]):
            return False
        b = block_of(a[0])
        if b in grouped:
            return False
        readers, capped = nearest_readers(b)
        return capped or not readers or any(r not in grouped for r in readers)

    return not any(is_row_list(a) for a in line_aggs)


_PAR_TIME_RETRY_INSTRUCTION = (
    "That query sums ARINVDET line amounts across all items but does not exclude PAR_TIME sub-lines from "
    "those sums, so materials-list sub-lines are counted on top of their parent lines and the totals come "
    "out too high. Keep every row the query returns: do NOT add a WHERE filter that removes rows from a "
    "list. Put the blank condition inside each line-amount aggregate instead, for example "
    'SUM(x) FILTER (WHERE ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = \'\')) OVER () '
    'or SUM(CASE WHEN ("ARINVDET"."PAR_TIME" IS NULL OR "ARINVDET"."PAR_TIME" = \'\') THEN x END) OVER (). '
    "Use a plain WHERE filter only when the query returns no row list (a single total or a grouped "
    "breakdown). The IS NULL branch is required -- the blank state is NULL. Only omit the condition if the "
    "question is about one specific inventory item. Keep everything else the same. "
    "Return ONLY the corrected SQL, no explanation."
)


def _needs_par_time_filter(sql: str) -> bool:
    """True when `sql` reads ARINVDET, aggregates a line amount/quantity (SUM/AVG over PRICE, COSTS,
    SHIP or QUAN), has no blank-PAR_TIME predicate governing those sums, and does not pin a specific
    inventory item.

    Runs on the literal/comment-stripped copy, so a "PAR_TIME" inside a comment or string does not
    count as a filter. The specific-item exception is read from the raw SQL because the item id is
    itself a string literal."""
    stripped = _strip_sql_literals_and_comments(sql)
    if "ARINVDET" not in stripped.upper():
        return False
    # 86e3u4qtf: a bare MENTION of PAR_TIME no longer suppresses the check (a selected column, ORDER BY,
    # IS NULL AS flag, = '' alone, IS NOT NULL all used to). Only a real blank predicate on each line sum does.
    if _par_time_governs_line_sums(sql):
        return False
    if not _sums_a_line_amount(stripped):
        return False
    if _PINS_SPECIFIC_ITEM_FORWARD.search(sql) or _PINS_SPECIFIC_ITEM_REVERSED.search(sql):
        return False
    return True


def _sql_plan_error(sql: str) -> str | None:
    """None if Postgres can parse and plan `sql`; otherwise the first line of its planning error (SQLSTATE
    class 42: syntax error / access-rule violation, which includes the "must appear in the GROUP BY clause"
    GroupingError a rewritten query is prone to). Uses plain EXPLAIN (never ANALYZE), which does not execute
    the statement. Any OTHER failure (connection down, timeout) is re-raised: it says nothing about the SQL,
    so the caller must fall back rather than feed it to the model as a "SQL error"."""
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute("EXPLAIN " + sql.strip().rstrip(";"))
        return None
    except psycopg.Error as e:
        if (e.sqlstate or "").startswith("42"):
            return ((e.diag.message_primary or str(e)).strip().splitlines() or ["planning error"])[0][:300]
        raise


# 86e3bbw6t (from 86e39gxpk): asked what customers BOUGHT, the SQL model sometimes summed an invoice HEADER
# amount (ARINV.TOTAL, ...) in the same SELECT that joins ARINVDET, so each invoice total was counted once per
# line item -- SYSTEM_PROMPT's own FAN-OUT WARNING, broken anyway: measured 3.3x-4.3x too high on ErinTest, with
# the list and footer still agreeing with each other. Same design as the PAR_TIME check: a deterministic test on
# the generated SQL plus one bounded retry.
_HEADER_COLUMN = re.compile(
    r'(?:(?:"([^"]+)"|(\w+))\s*\.\s*)?(?<![\w"])"?(TOTAL|SUBTOTAL|TAX|FREIGHT|HANDLING|BALANCE)"?(?![\w"])', re.IGNORECASE)
_NOT_AN_ALIAS = frozenset(("ON", "WHERE", "JOIN", "LEFT", "RIGHT", "INNER", "OUTER", "FULL", "CROSS", "GROUP",
                           "ORDER", "LIMIT", "USING", "UNION", "HAVING", "WINDOW", "NATURAL", "OFFSET", "FETCH",
                           "FOR", "AS", "SELECT", "WITH"))
# 86e3jx6fv item 1 (Batch D D1a): words that may follow a header column without being its alias ("TOTAL" DESC,
# "TOTAL" IS NULL, THEN "TOTAL" END, "TOTAL" ISNULL). A wrong entry only means a word is never read as an alias.
_NOT_A_HEADER_ALIAS = _NOT_AN_ALIAS | frozenset((
    "FROM", "ASC", "DESC", "NULLS", "FILTER", "OVER", "END", "THEN", "ELSE", "WHEN", "AND", "OR", "NOT", "IS", "IN",
    "LIKE", "ILIKE", "BETWEEN", "CASE", "ESCAPE", "ISNULL", "NOTNULL", "SIMILAR", "COLLATE", "INTERSECT", "EXCEPT",
    "ROWS", "RANGE", "GROUPS"))
# 86e3geveb: a header column renamed inside a carrier CTE ("TOTAL" AS amt); group 1 is the new name.
# 86e3jx6fv item 1 (Batch D D1a): the alias may also be written WITHOUT AS ("TOTAL" amt, "TOTAL" "amt"). That bare
# form must not be a keyword (_NOT_A_HEADER_ALIAS) and must END the select item (a comma, FROM, ")" or the end of the
# text follows), so "TOTAL" DESC, "TOTAL" t * 2 or "TOTAL" COLLATE "C" are not aliases. The AS form is unchanged.
_HEADER_ALIAS = re.compile(
    r'(?:(?:"[^"]+"|\w+)\s*\.\s*)?(?<![\w"])"?(?:TOTAL|SUBTOTAL|TAX|FREIGHT|HANDLING|BALANCE)"?'
    r'\s+(?:AS\s+|(?!(?:' + "|".join(sorted(_NOT_A_HEADER_ALIAS)) + r')\b)(?="?\w+"?\s*(?:,|\bFROM\b|\)|$)))'
    r'"?(\w+)"?',
    re.IGNORECASE)
# An alias must not be a SQL keyword: without the lookahead, "ARINV JOIN ..." would swallow the word JOIN and
# hide the join that follows.
_ALIAS = r'(?:\s+(?:AS\s+)?(?!(?:' + "|".join(sorted(_NOT_AN_ALIAS)) + r')\b)(?:"([^"]+)"|(\w+)))?'
_TABLE_REF = re.compile(
    r'\b(?:FROM|JOIN)\s+(?:"[^"]+"\s*\.\s*)?(?:"(ARINVDET|ARINV)"|\b(ARINVDET|ARINV)\b)' + _ALIAS, re.IGNORECASE)
_CTE_DEF = re.compile(
    r'(?:\bWITH(?:\s+RECURSIVE)?|,)\s*(\w+)\s*(?:\(([^()]*)\)\s*)?(?<=[\s)])AS\s*(?:(?:NOT\s+)?MATERIALIZED\s*)?\(\s*SELECT\b',
    re.IGNORECASE)
# 86e3gevw3 A2-F3(c): a parenthesised SELECT used as a FROM item -- FROM|JOIN (SELECT ...) alias, or LATERAL (SELECT ...).
# A scalar subquery in a select list, IN (SELECT...) and EXISTS (SELECT...) are NOT matched (nothing precedes the "("
# but IN/EXISTS/comma-in-select), so they keep their existing "different block" treatment.
_DERIVED_DEF = re.compile(
    r'(?:\b(?:FROM|JOIN)|,)\s*LATERAL\s*\(\s*SELECT\b|\b(?:FROM|JOIN)\s*\(\s*SELECT\b', re.IGNORECASE)


def _top_level_items(select_list: str) -> list[str]:
    """The select list split on its top-level commas (commas inside parentheses stay in their item)."""
    items, depth, start = [], 0, 0
    for i, ch in enumerate(select_list):
        if ch == "(":
            depth += 1
        elif ch == ")":
            depth -= 1
        elif ch == "," and depth == 0:
            items.append(select_list[start:i])
            start = i + 1
    items.append(select_list[start:])
    return items


_PLAIN_COLUMN_ITEM = re.compile(
    r'\s*(?:(?:"([^"]+)"|(\w+))\s*\.\s*)?"?(\w+)"?(?:\s+(?:AS\s+)?"?\w+"?)?\s*', re.IGNORECASE)
_HEADER_SIDE_BARE = frozenset(("INVOICE", "TOTAL", "SUBTOTAL", "TAX", "FREIGHT", "HANDLING", "BALANCE"))
# V2-4 fix round 1 (I1): column names the SYSTEM_PROMPT lists in its "ARINV" schema block and NOT in its "ARINVDET"
# block (derived by script from the prompt text; tests re-derive and compare). When ARINV is read at the select's own
# level, an UNQUALIFIED use of one of these names is ARINV's column (or ambiguous SQL that Postgres rejects), so it is
# header-side. Without ARINV at that level the name may belong to another table (INVENTRY."ID"), so it is not.
_ARINV_ONLY_BARE = frozenset((
    "ADDRESS1", "CHECK_DATE", "CHECK_NO", "CITY", "CLOSE_DATE", "CREA_DATE", "CURR_ID", "C_ID", "C_NAME", "C_RATE",
    "DUE_DATE", "EMAIL", "ID", "MEMO", "NAME", "ORIG_INV", "PO_NO", "SALESMAN", "STATE", "TERMS", "TOTAL_PAID",
    "USER_NAME", "ZIP"))
# V2-4 fix round 1 (C1): words that may stand unqualified inside a select-list EXPRESSION without being a column
# (operators, CASE, casts, window and date-part words). A quoted "X" is always an identifier, never one of these.
_EXPR_KEYWORDS = frozenset((
    "AND", "OR", "NOT", "NULL", "IS", "IN", "AS", "CASE", "WHEN", "THEN", "ELSE", "END", "TRUE", "FALSE", "BETWEEN",
    "LIKE", "ILIKE", "SIMILAR", "TO", "ESCAPE", "DISTINCT", "FROM", "FOR", "OVER", "PARTITION", "BY", "ORDER", "ASC",
    "DESC", "NULLS", "FIRST", "LAST", "ROWS", "RANGE", "GROUPS", "UNBOUNDED", "PRECEDING", "FOLLOWING", "CURRENT",
    "ROW", "FILTER", "WHERE", "WITHIN", "GROUP", "INTERVAL", "AT", "TIME", "ZONE", "ANY", "ALL", "SOME", "EXISTS",
    "COLLATE", "BOTH", "LEADING", "TRAILING", "CENTURY", "DECADE", "YEAR", "QUARTER", "MONTH", "WEEK", "DAY", "HOUR",
    "MINUTE", "SECOND", "DOW", "DOY", "ISODOW", "EPOCH", "CURRENT_DATE", "CURRENT_TIMESTAMP", "LOCALTIMESTAMP",
    "NUMERIC", "DECIMAL", "INTEGER", "INT", "BIGINT", "SMALLINT", "REAL", "DOUBLE", "PRECISION", "TEXT", "VARCHAR",
    "CHAR", "CHARACTER", "VARYING", "DATE", "TIMESTAMP", "BOOLEAN", "MONEY",
    # V2-4 fix round 2 (N2): more type, date-part and syntax words seen in header-only expressions
    "ARRAY", "PLACING", "ISOYEAR", "MILLENNIUM", "JULIAN", "MICROSECONDS", "MILLISECONDS", "TIMEZONE", "TIMEZONE_HOUR",
    "TIMEZONE_MINUTE", "FLOAT", "FLOAT4", "FLOAT8", "INT2", "INT4", "INT8", "TIMESTAMPTZ", "TIMETZ", "SERIAL", "JSON",
    "JSONB", "UUID", "BPCHAR", "WITHOUT"))
_FILTER_OPEN = re.compile(r'\s*FILTER\s*\(', re.IGNORECASE)
_EXPR_IDENT = re.compile(r'"((?:[^"]|"")*)"|\b([A-Za-z_]\w*)\b')


def _paren_closes(text: str) -> dict:
    """{index of "(": index of its matching ")"} for every closed paren, in one pass."""
    closes, stack = {}, []
    for i, ch in enumerate(text):
        if ch == "(":
            stack.append(i)
        elif ch == ")" and stack:
            closes[stack.pop()] = i
    return closes


def _blank_spans(text: str, closes: dict, starts) -> str:
    """text with the inside of each "(" at the given positions (up to its matching ")", or the end) replaced by
    spaces. Linear: the spans are marked with a difference array, never walked one by one."""
    marks = [0] * (len(text) + 1)
    for open_at in starts:
        marks[open_at + 1] += 1
        marks[closes.get(open_at, len(text))] -= 1
    out, depth = [], 0
    for i, ch in enumerate(text):
        depth += marks[i]
        out.append(" " if depth > 0 else ch)
    return "".join(out)


def _has_unqualified_line_identifier(item: str, header_side) -> bool:
    """True when a select-list EXPRESSION item (trim("INVEN"), "PRICE"*1, upper("DESCR")) uses an UNQUALIFIED column
    that is not header-side: it may be a line column, so the item can differ per line (V2-4 fix round 1, C1). Fix
    round 2 (N1): header_side matches only a double-quoted name, case-sensitively; any unquoted column word disqualifies.
    Not scanned: an aggregate's own arguments and FILTER (one value per partition / per group, never per line), a
    scalar (SELECT ...) subquery (its detail-qualified columns are still caught by the caller), a trailing alias, a
    function name, a ::type, and the expression keywords."""
    closes = _paren_closes(item)
    text = _blank_spans(item, closes, [m.start() for m in re.finditer(r'\(\s*SELECT\b', item, re.IGNORECASE)])
    agg_opens = []
    for m in _AGG_OPEN.finditer(text):
        agg_opens.append(m.end() - 1)
        close_at = closes.get(m.end() - 1)
        if close_at is not None:
            f = _FILTER_OPEN.match(text, close_at + 1)
            if f:
                agg_opens.append(f.end() - 1)
    text = _blank_spans(text, closes, agg_opens)
    # N2: a string literal (stripped to '') may stand right before an alias written without AS
    text = re.sub(r'([\w")\]\'])(?:\s+AS)?\s+"?[A-Za-z_]\w*"?\s*$', r"\1", text, flags=re.IGNORECASE)
    for m in _EXPR_IDENT.finditer(text):
        before = text[max(0, m.start() - 64):m.start()].rstrip()     # bounded look-around keeps the scan linear
        after = text[m.end():m.end() + 64].lstrip()
        if re.search(r'(?<![\w"])(?:AS|COLLATE)$', before, re.IGNORECASE):
            continue                                  # N2: CAST(x AS type) (the item's own alias is stripped above), COLLATE "C"
        if before.endswith(".") and not before.endswith(".."):
            continue                                  # qualified: x."COL" / x.col
        if after.startswith(".") or (m.group(2) and after.startswith("(")):
            continue                                  # a qualifier, or a function name
        if before.endswith("::"):
            continue                                  # a type name
        if m.group(2) is not None and (m.group(2).upper() in _EXPR_KEYWORDS or m.group(2)[0].isdigit()):
            continue
        # N1: only a DOUBLE-QUOTED name with the exact spelling can be a header column; an unquoted word folds to
        # lowercase in Postgres, so it is an alias column (possibly at line grain), never ARINV's "NAME" / "TOTAL".
        if m.group(1) is None or m.group(1) not in header_side:
            return True
    return False


# Batch D Final Review (86e3jx6fv, I1): a qualifier chain in a select-list expression (x."COL", "s"."ARINV"."NAME").
# The LAST name of the chain is the table or carrier the column belongs to; earlier names are a schema.
_QUALIFIER_CHAIN = re.compile(r'(?<![\w".])((?:(?:"[^"]+"|[A-Za-z_]\w*)\s*\.\s*)+)(?=["A-Za-z_])')
_QUALIFIER_NAME = re.compile(r'"([^"]+)"|([A-Za-z_]\w*)')


def _has_foreign_qualified_identifier(item: str, arinv_names) -> bool:
    """True when a select-list EXPRESSION item (trim(i."DESCR_1"), upper(...), COALESCE(...), x."COL"::text) uses a
    column whose qualifier is not one of arinv_names (ARINV names and known header carriers): that column may vary per
    line, so a DISTINCT carrier holding it is not one row per invoice. Batch D Final Review (86e3jx6fv, I1): the D1c
    qualifier rule for plain columns, extended to expressions. Not scanned, exactly as _has_unqualified_line_identifier:
    an aggregate's own arguments and FILTER, and a scalar (SELECT ...) subquery."""
    closes = _paren_closes(item)
    text = _blank_spans(item, closes, [m.start() for m in re.finditer(r'\(\s*SELECT\b', item, re.IGNORECASE)])
    agg_opens = []
    for m in _AGG_OPEN.finditer(text):
        agg_opens.append(m.end() - 1)
        close_at = closes.get(m.end() - 1)
        if close_at is not None:
            f = _FILTER_OPEN.match(text, close_at + 1)
            if f:
                agg_opens.append(f.end() - 1)
    text = _blank_spans(text, closes, agg_opens)
    for m in _QUALIFIER_CHAIN.finditer(text):
        last = _QUALIFIER_NAME.findall(m.group(1))[-1]
        if (last[0] or last[1]).upper() not in arinv_names:
            return True
    return False


def _is_one_row_per_invoice(select_list: str, detail_aliases, reads_arinv: bool = False, arinv_names=None) -> bool:
    """select_list is the text after SELECT up to FROM. True for DISTINCT ON (invoice key), or DISTINCT with the
    invoice key and no detail column: such a carrier is one row per invoice, so joining it is safe.

    86e3gzqn0 B8: "no detail column" no longer depends on qualification. A plain column item counts as header-side
    only when it is qualified by a non-detail name, or UNQUALIFIED, DOUBLE-QUOTED and one of INVOICE / the header
    amount columns; an
    unqualified other column ("PRICE", "INVEN") may be a line column, so the DISTINCT is not exempt. An expression item
    is not exempt when it holds a detail-qualified column, or (V2-4 fix round 1, C1) an UNQUALIFIED column that is not
    header-side (DISTINCT "INVOICE", trim("INVEN") is one row per invoice AND item). reads_arinv (I1): ARINV is read
    at the select's own level, so the _ARINV_ONLY_BARE names are header-side too. Fix round 2 (N1): an unqualified
    name is header-side only when DOUBLE-QUOTED with the exact upper-case spelling ("NAME", never name / "name"): an
    unquoted word folds to lowercase in Postgres, so it can only be an alias column, possibly at line grain.

    Batch D D1c (86e3jx6fv item 2): arinv_names (upper-cased ARINV names and known header carriers, as the detector
    computes them). When given, a QUALIFIED plain column is header-side only when its qualifier is one of them: any
    other qualifier (INVENTRY i, a line CTE) may vary per line, so DISTINCT a."INVOICE", a."TOTAL", i."DESCR_1" is
    one row per invoice AND description, not per invoice. None (the default) keeps the old rule: any qualifier that
    is not a detail alias counts as header-side."""
    header_side = _HEADER_SIDE_BARE | _ARINV_ONLY_BARE if reads_arinv else _HEADER_SIDE_BARE
    inv_key = r'(?<![\w"])"?INVOICE"?(?![\w"])'
    if re.match(r'\s*DISTINCT\s+ON\s*\(\s*(?:(?:"[^"]+"|\w+)\s*\.\s*)*"?INVOICE"?\s*\)', select_list,
                re.IGNORECASE):
        return True
    if not (re.match(r'\s*DISTINCT\b(?!\s+ON\b)', select_list, re.IGNORECASE)
            and re.search(inv_key, select_list, re.IGNORECASE)):
        return False
    detail_qualified = re.compile(r'(?<![\w"])(?:"?(?:' + "|".join(map(re.escape, sorted(detail_aliases)))
                                  + r')"?)\s*\.', re.IGNORECASE)
    body = re.sub(r"^\s*DISTINCT\s+", "", select_list, flags=re.IGNORECASE)
    for item in _top_level_items(body):
        plain = _PLAIN_COLUMN_ITEM.fullmatch(item)
        if plain is None:
            if detail_qualified.search(item) or _has_unqualified_line_identifier(item, header_side) \
                    or (arinv_names is not None and _has_foreign_qualified_identifier(item, arinv_names)):
                return False
            continue
        qualifier = (plain.group(1) or plain.group(2) or "").upper()
        if qualifier:
            if qualifier in detail_aliases or (arinv_names is not None and qualifier not in arinv_names):
                return False
        elif item[plain.start(3) - 1:plain.start(3)] != '"' or plain.group(3) not in header_side:
            return False      # N1: unquoted (folds to lowercase: an alias, never ARINV's column) or not header-side
    return True


_FROM_END = re.compile(
    r'\b(?:WHERE|GROUP\s+BY|ORDER\s+BY|HAVING|LIMIT|UNION|INTERSECT|EXCEPT|WINDOW|OFFSET|FETCH)\b', re.IGNORECASE)
_FROM_KW = re.compile(r'\bFROM\b', re.IGNORECASE)
_COMMA_REF = re.compile(r',\s*(?:"[^"]+"\s*\.\s*)?(?:"(ARINVDET|ARINV)"|\b(ARINVDET|ARINV)\b)' + _ALIAS, re.IGNORECASE)
_GROUP_BY_KW = re.compile(r"\bGROUP\s+BY\b", re.IGNORECASE)
_LIMIT_ONE = re.compile(r"\bLIMIT\s+1\b(?![\w.])", re.IGNORECASE)
_AGG_OPEN = re.compile(r'\b(?:SUM|AVG|MIN|MAX|COUNT|STRING_AGG|ARRAY_AGG|BOOL_OR|BOOL_AND)\s*\(', re.IGNORECASE)
# After an aggregate's ")": group 1 = an opening "FILTER (" (skipped to its ")" by the caller), group 2 = OVER.
_OVER_AFTER_AGG = re.compile(r'\s*(?:(FILTER\s*\()|(OVER)\b)?', re.IGNORECASE)
_OVER_AFTER_AGG_TAIL = re.compile(r'\s*()(OVER\b)?', re.IGNORECASE)
_ARINV_WORD = re.compile(r'\bARINV\b|"ARINV"', re.IGNORECASE)
_DERIVED_ALIAS = re.compile(r'\s*(?:AS\s+)?(?:"([^"]+)"|(\w+))', re.IGNORECASE)
_FAN_OUT_RETRY_INSTRUCTION = (
    "That query sums an invoice HEADER amount (ARINV TOTAL / SUBTOTAL / TAX / FREIGHT / BALANCE) in the same "
    "SELECT that joins ARINVDET, so every invoice total is counted once per matching line item and the totals "
    "and per-customer amounts come out several times too high. Rewrite it so each invoice's header amount is "
    "counted exactly once AND nothing is ever joined at a finer grain than the totals: compute the per-customer "
    "(or per-group) totals from ARINV alone, scoping invoices first when a line-item condition is needed "
    '("ARINV"."INVOICE" IN (SELECT DISTINCT "INVOICE" FROM ARINVDET WHERE ...)). If item names are also wanted, '
    "aggregate them in a SEPARATE subquery or CTE at the SAME grain as the totals (for per-customer totals: join "
    "ARINV to ARINVDET to INVENTRY, GROUP BY the customer ID, STRING_AGG(DISTINCT ...)) and join the two on the "
    "customer ID ONLY. Never join per-invoice or per-line rows to a per-customer total: the total would repeat once "
    "per row. Or, if line-level revenue is what is wanted, sum \"ARINVDET\".\"PRICE\" instead (with the PAR_TIME "
    'filter). Keep the filters, ranking and LIMIT. Refer to CTE names and table aliases WITHOUT double '
    'quotes (write customer_items."ID", never "customer_items"."ID"): a double-quoted name in front of a column is '
    "rejected as a foreign schema. Return ONLY the corrected SQL, no explanation."
)


_SET_OPERATOR = re.compile(r"\b(?:UNION|INTERSECT|EXCEPT)\b", re.IGNORECASE)
_ALL_AFTER_SET_OP = re.compile(r"\s+ALL\b", re.IGNORECASE)
_PAREN_TABLE_REF = re.compile(
    r'\b(?:FROM|JOIN)\s*(?:\(\s*)+(?:"[^"]+"\s*\.\s*)?(?:"(ARINVDET|ARINV)"|\b(ARINVDET|ARINV)\b)' + _ALIAS, re.IGNORECASE)
_COMMA_DERIVED = re.compile(r',\s*\(\s*SELECT\b', re.IGNORECASE)
_COMMA_NAMED_REF = re.compile(r',\s*"?(\w+)"?(?![\w".(])' + _ALIAS, re.IGNORECASE)
# 86e3gzqn0 Group A: every FROM/JOIN followed by a bare or double-quoted name, indexed once per call so a CTE's
# references are a dict lookup, not a whole-string scan per CTE (the old per-CTE re.finditer was quadratic on long
# CTE chains). Same match rule as the old per-name pattern r'\b(?:FROM|JOIN)\s+"?<name>"?(?![\w"])', plus _ALIAS.
_NAMED_REF = re.compile(r'\b(?:FROM|JOIN)\s+"?(\w+)"?(?![\w"])' + _ALIAS, re.IGNORECASE)


def _block_ids(stripped: str) -> list[int]:
    """For each character position, the id of the SELECT block it sits in (0 = the outermost statement). A "("
    followed by SELECT/WITH opens a new block; any other "(" (a function call, a grouping) stays in the current one.
    86e3gzqn0: a UNION / INTERSECT / EXCEPT in the OUTERMOST statement starts a new id for the rest of it, so each
    top-level branch is its own block (a header SUM in one branch and an ARINVDET join in another are not one SELECT).
    A set operator INSIDE a CTE body or a subquery does not split: the CTE and derived-table checks treat a body as one
    block ("does it read ARINVDET at its own level"), and splitting there would hide a line-grain second branch."""
    ids, stack, next_id = [0] * len(stripped), [0], 1
    # 86e3gzqn0 I1: a set-operator word inside a double-quoted identifier ("Credit Union") is not an operator. Scan a
    # same-length copy with every "..." span (including "" escapes) blanked, so offsets stay valid.
    unquoted = re.sub(r'"(?:[^"]|"")*"', lambda q: " " * len(q.group()), stripped)
    set_ops = {m.start() for m in _SET_OPERATOR.finditer(unquoted)}
    for i, ch in enumerate(stripped):
        if ch == "(":
            if re.match(r"\s*(?:SELECT|WITH)\b", stripped[i + 1:i + 40], re.IGNORECASE):
                stack.append(next_id)
                next_id += 1
            else:
                stack.append(stack[-1])
        elif ch == ")" and len(stack) > 1:
            stack.pop()
        elif i in set_ops and len(stack) == 1:
            stack[0] = next_id                  # a set operator in the OUTERMOST statement starts a new branch id
            next_id += 1
        ids[i] = stack[-1]
    return ids


def _sums_header_across_line_join(sql: str) -> bool:
    """True when some SELECT block aggregates (SUM/AVG) an ARINV header amount (TOTAL / SUBTOTAL / TAX / FREIGHT /
    HANDLING / BALANCE, directly or through a carrier's rename such as "TOTAL" AS amt) while that same block sits at
    LINE grain.

    A block is at line grain when it joins ARINVDET literally (FROM/JOIN or a comma-listed FROM item), or reads a
    line-grain source by name or position: a detail CTE (reads ARINVDET), a line-grain carrier CTE (joins ARINV and
    ARINVDET and carries header amounts out per line), a derived table (FROM/JOIN (SELECT ...)), a LATERAL body, or a
    comma join. A source that collapses to one row per invoice or group is NOT line grain: a GROUP BY at its own
    level, an aggregate with no GROUP BY, a DISTINCT / DISTINCT ON invoice key (a bare key only with DISTINCT or a
    set operator without ALL: D1b), or (LATERAL only) a top-level LIMIT 1. ARINVDET reached only through an
    IN/EXISTS subselect is a different block and is not flagged (that is the shape the FAN-OUT WARNING recommends).
    Each top-level branch of a UNION / INTERSECT / EXCEPT is its own block (_block_ids). 86e3pdz7t: a CTE or derived
    table that reads ARINVDET at its own level and reads a header-only CTE by name counts as a line carrier, like one
    that reads ARINV. A carrier that collapses to one row per invoice (DISTINCT, GROUP BY) still carries header amounts, so
    it counts as an ARINV name; the collapse rules decide only whether a SOURCE is at line grain.

    Header aliases are scoped per carrier: an unqualified SUM(alias) counts only in a block that reads a carrier
    defining that alias (a CTE that reads a carrier without grouping passes its aliases on); a qualified x.alias counts
    when x is any ARINV name.

    Cost: every scan below is one regex pass or one character pass over the stripped SQL, built once per call; each
    CTE, derived table and SUM then costs bisect / dict lookups (86e3gzqn0 Group A: the per-CTE whole-string scans and
    hand-rolled paren walks were quadratic on long CTE chains). Select lists are re-read once per CTE / derived table
    (_is_one_row_per_invoice, _has_unqualified_line_identifier). Known residual, not linear: deeply nested window
    SUM( calls in one select item are quadratic (about 0.5 s at most within the 16 KB SQL limit; follow-up)."""
    stripped = _strip_sql_literals_and_comments(sql)
    if "ARINVDET" not in stripped.upper():
        return False
    ids = _block_ids(stripped)
    arinv_names, detail_blocks = {"ARINV"}, set()
    detail_aliases = {"ARINVDET"}
    # 86e3gevw3 A2-F3(b): tables listed after a COMMA inside a FROM clause (FROM ARINV a, ARINVDET d WHERE ...).
    # _TABLE_REF only sees FROM|JOIN <table>, so a comma-listed table was invisible. A comma belongs to a FROM clause
    # when the nearest earlier FROM at the SAME paren depth has no clause-ending keyword, ";" or close paren at that
    # depth between it and the comma. Everything is precomputed in ONE pass and looked up with bisect.
    n = len(stripped)
    # V2 Final Review FR-2: a clause-end word inside a double-quoted identifier ("credit-union:legacy") is not a
    # keyword. Scan a same-length copy with every "..." span (including "" escapes) blanked, so offsets stay valid
    # (the same copy _block_ids and the R1 FROM scan below use).
    unquoted = re.sub(r'"(?:[^"]|"")*"', lambda q: " " * len(q.group()), stripped)
    kw_starts = {t.start() for t in _FROM_END.finditer(unquoted)}
    depth_at, close_of, stack, d = [0] * n, {}, [], 0
    terms = {}                      # depth -> ascending positions that end a FROM clause living at that depth
    for i, ch in enumerate(stripped):
        if ch == "(":
            depth_at[i] = d
            stack.append(i)
            d += 1
        elif ch == ")":
            depth_at[i] = d
            terms.setdefault(d, []).append(i)
            if stack:
                close_of[stack.pop()] = i
            d -= 1
        else:
            depth_at[i] = d
            if ch == ";" or i in kw_starts:
                terms.setdefault(d, []).append(i)

    # 86e3gzqn0 B6: a parenthesised join (FROM (ARINV a JOIN ARINVDET d ON ...)) puts "(" between FROM and the
    # table. Such a "(" is a grouping paren (not followed by SELECT), so it stays in the same block (_block_ids); the
    # opening parens are simply skipped here.
    paren_refs = [(m, ids[m.start()]) for m in _PAREN_TABLE_REF.finditer(stripped)]

    def _end_of(open_at):
        """Index just past the ")" matching the "(" at open_at, or len(stripped) if it never closes."""
        close_at = close_of.get(open_at)
        return close_at + 1 if close_at is not None else n

    # V2-4 fix round 3 (N3): the paren depth of each block's own text (a block's first character is its "(", or a set
    # operator at depth 0 for a top-level branch). Only a FROM at that depth ends the block's select list; a FROM inside
    # EXTRACT(YEAR FROM ..), trim(both .. from ..), substring / overlay(.. from ..) sits deeper and is part of an item.
    block_depth = {}
    for i, b in enumerate(ids):
        if b not in block_depth:
            block_depth[b] = depth_at[i] + (1 if stripped[i] == "(" else 0)
    from_ends, from_starts_by_block = {}, {}
    # V2-4 fix round 4 (R1): a double-quoted identifier spelled FROM ("From") is a column, not the keyword. Scan a
    # same-length copy with every "..." span (including "" escapes) blanked, so offsets stay valid (as _block_ids does).
    # The copy is the `unquoted` built above for the _FROM_END scan.
    for f in _FROM_KW.finditer(unquoted):
        from_ends.setdefault(depth_at[f.start()], []).append(f.end())
        b = ids[f.start()]
        if depth_at[f.start()] == block_depth.get(b, 0):
            from_starts_by_block.setdefault(b, []).append(f.start())
    def _in_from_clause(q):
        """True if the comma at q belongs to a FROM clause: the nearest earlier FROM at the same depth has no
        clause-ending keyword, ";" or close paren at that depth between it and q."""
        dq = depth_at[q]
        ends = from_ends.get(dq)
        if not ends:
            return False
        j = bisect.bisect_right(ends, q) - 1
        if j < 0:
            return False
        fe = ends[j]                               # end of the nearest earlier FROM at this depth
        tl = terms.get(dq, ())
        t = bisect.bisect_left(tl, fe)
        return not (t < len(tl) and tl[t] < q)     # False: that FROM's clause already ended

    comma_refs = [(cm, ids[cm.start()]) for cm in _COMMA_REF.finditer(stripped) if _in_from_clause(cm.start())]
    refs = [(m, ids[m.start()]) for m in _TABLE_REF.finditer(stripped)] + comma_refs + paren_refs
    arinv_blocks = set()            # blocks that read ARINV literally at their own level (I1)
    for m, block in refs:
        table = (m.group(1) or m.group(2)).upper()
        if table == "ARINV":
            arinv_blocks.add(block)
        if table == "ARINVDET":
            detail_blocks.add(block)
            d_alias = (m.group(3) or m.group(4) or "")
            if d_alias and d_alias.upper() not in _NOT_AN_ALIAS:
                detail_aliases.add(d_alias.upper())
        else:
            alias = (m.group(3) or m.group(4) or "")
            if alias and alias.upper() not in _NOT_AN_ALIAS:
                arinv_names.add(alias.upper())
    if not detail_blocks:
        return False
    # Per-block / per-position tables, built once (one regex pass each); every loop below looks positions up with
    # bisect instead of rescanning a CTE or derived-table body.
    group_by_by_block, limit1_by_block = {}, {}
    for g in _GROUP_BY_KW.finditer(stripped):
        group_by_by_block.setdefault(ids[g.start()], []).append(g.start())
    for g in _LIMIT_ONE.finditer(stripped):
        limit1_by_block.setdefault(ids[g.start()], []).append(g.start())
    # V2-4 fix round 1 (C1): an aggregate collapses a block to one row only when it sits at that block's OWN level
    # (not inside a scalar subquery) and is not a window aggregate (SUM(...) [FILTER (...)] OVER (...) keeps every row).
    collapse_agg_by_block = {}
    for g in _AGG_OPEN.finditer(stripped):
        close_at = close_of.get(g.end() - 1)
        if close_at is not None:
            rest = _OVER_AFTER_AGG.match(stripped, close_at + 1)
            if rest is not None and rest.group(1):
                filter_close = close_of.get(rest.end(1) - 1)
                rest = _OVER_AFTER_AGG_TAIL.match(stripped, filter_close + 1) if filter_close is not None else None
            if rest is not None and rest.group(2):
                continue
        collapse_agg_by_block.setdefault(ids[g.start()], []).append(g.start())
    header_col_pos = [g.start() for g in _HEADER_COLUMN.finditer(stripped)]
    arinv_word_pos = [g.start() for g in _ARINV_WORD.finditer(stripped)]
    header_alias_hits = [(g.start(), g.group(1).upper()) for g in _HEADER_ALIAS.finditer(stripped)]
    header_alias_pos = [h[0] for h in header_alias_hits]
    named_refs = {}                 # NAME (upper) -> [(position, alias or "")] for every FROM/JOIN <name>
    for r in _NAMED_REF.finditer(stripped):
        named_refs.setdefault(r.group(1).upper(), []).append((r.start(), r.group(2) or r.group(3) or ""))
    # 86e3gzqn0 B2: a CTE listed after a COMMA in a FROM clause (FROM ARINV a, li WHERE ...) is read exactly like
    # FROM/JOIN li.
    for r in _COMMA_NAMED_REF.finditer(stripped):
        if _in_from_clause(r.start()):
            named_refs.setdefault(r.group(1).upper(), []).append((r.start(), r.group(2) or r.group(3) or ""))

    def _any_in(sorted_pos, lo, hi):
        """True if some position in the ascending list lies in [lo, hi)."""
        t = bisect.bisect_left(sorted_pos, lo)
        return t < len(sorted_pos) and sorted_pos[t] < hi

    def _first_in(sorted_pos, lo, hi):
        """The first position in the ascending list that lies in [lo, hi), else None."""
        t = bisect.bisect_left(sorted_pos, lo)
        return sorted_pos[t] if t < len(sorted_pos) and sorted_pos[t] < hi else None

    def _aliases_in(lo, hi):
        """Upper-cased header-column aliases ("TOTAL" AS amt) defined in [lo, hi)."""
        t = bisect.bisect_left(header_alias_pos, lo)
        out = set()
        while t < len(header_alias_hits) and header_alias_hits[t][0] < hi:
            out.add(header_alias_hits[t][1])
            t += 1
        return out

    # Batch D D1b (86e3jx6fv item 3): a set operator WITHOUT ALL de-duplicates its result exactly like DISTINCT. Indexed
    # per block once; a set operator inside a CTE or derived-table body keeps that body's block id (_block_ids).
    dedup_set_op_by_block = {}
    for g in _SET_OPERATOR.finditer(unquoted):
        if not _ALL_AFTER_SET_OP.match(unquoted, g.end()):     # any whitespace, line breaks included, before ALL
            dedup_set_op_by_block.setdefault(ids[g.start()], []).append(g.start())

    def _bare_invoice_key_deduped(select_text, block, lo, hi):
        """select_text is the block's text from SELECT up to its FROM. True when the block's only output column is the
        invoice key (optionally renamed, with or without AS) AND its rows are de-duplicated: the select list starts with
        DISTINCT, or a set operator without ALL sits at the block's own level in [lo, hi). D1b: a bare key without
        either is one row per matching LINE, not per invoice. (A GROUP BY at the block's own level is handled by each
        caller before this check; DISTINCT ON never matches here and is left to _is_one_row_per_invoice.)"""
        m = re.match(r"\s*SELECT\s+(DISTINCT\b(?!\s+ON\b)\s*)?", select_text, re.IGNORECASE)
        if m is None:
            return False
        if not re.fullmatch(r'\s*(?:(?:"[^"]+"|\w+)\s*\.\s*)*"?INVOICE"?(?:\s+(?:AS\s+)?"?\w+"?)?\s*',
                            select_text[m.end():], re.IGNORECASE):
            return False
        return bool(m.group(1)) or _any_in(dedup_set_op_by_block.get(block, ()), lo, hi)

    # Blocks that reference ARINVDET LITERALLY. The detail-CTE loop below adds more blocks to `detail_blocks`; the
    # header-carrier loop after it must still test against THIS snapshot, or a CTE that both joins a detail CTE and
    # carries header amounts would be silently de-registered as a carrier (a double fan-out the older code caught).
    literal_detail_blocks = set(detail_blocks)
    # Final review I-A: header-column aliases ("TOTAL" AS amt) are scoped PER CARRIER. header_aliases is only the union
    # used to build one search regex; block_aliases maps a block id to the aliases of the carriers that block reads
    # (FROM/JOIN of a carrier CTE, or a carrier derived table sitting in that block). An UNQUALIFIED SUM(amt) counts only
    # when its own block reads a carrier that defines amt; a line CTE that reuses the same alias name for PRICE is not
    # a header sum. A QUALIFIED hit (x.amt) still counts when x is any ARINV name, as before.
    header_aliases, block_aliases = set(), {}
    # Batch N fix round 2: carriers that read ARINVDET and collapse by GROUP BY (CTE) or any collapse (derived) can sit at
    # a grain finer than the invoice (GROUP BY invoice, INVEN). They stay ARINV names for the sum checks, but the D1c
    # qualifier set leaves them out, so a later DISTINCT c."INVOICE", c."INVEN" is not judged one row per invoice.
    grouped_carriers = set()
    cte_defs = []                   # (match, open_at, end) for every CTE, in definition order
    for m in _CTE_DEF.finditer(stripped):
        open_at = stripped.rindex("(", m.start(), m.end())   # the body's "(" (not a column list's)
        cte_defs.append((m, open_at, _end_of(open_at)))
    # 86e3gzqn0 B1: a derived table listed after a COMMA in a FROM clause (FROM ARINV a, (SELECT ...) d) is a FROM item
    # exactly like FROM/JOIN (SELECT ...); a comma that is not in a FROM clause (a scalar subquery in a select list) is not.
    derived_defs = list(_DERIVED_DEF.finditer(stripped)) + [
        cm for cm in _COMMA_DERIVED.finditer(stripped) if _in_from_clause(cm.start())]
    # Batch D D1c (86e3jx6fv item 2): _is_one_row_per_invoice accepts a qualified column as header-side only when its
    # qualifier is an ARINV name or a known header carrier. The carrier loops below register carriers in arinv_names
    # AFTER the detail-CTE loop runs, so the header-only carriers (a CTE or derived table that reads ARINV and a header
    # column with no literal ARINVDET at its own level: exactly the ones those loops register unconditionally) and the
    # names they are read under are collected here first, in one bisect pass per definition.
    # 86e3pdz7t: a CTE or derived table that reads ARINVDET at its own level and reads a header-only CTE by name counts
    # as a line carrier, like one that reads ARINV. header_only_ctes holds the header-only CTE NAMES (not their
    # aliases); header_only_ref_blocks (built once below) the block ids that read one of them by FROM / JOIN / comma.
    header_only_carriers, header_only_ctes = set(), set()
    for m, open_at, k in cte_defs:
        if ids[open_at] not in literal_detail_blocks and _any_in(header_col_pos, m.end(), k) \
                and _any_in(arinv_word_pos, m.end(), k):
            header_only_ctes.add(m.group(1).upper())
            header_only_carriers.add(m.group(1).upper())
            header_only_carriers.update(a.upper() for _p, a in named_refs.get(m.group(1).upper(), ())
                                        if a and a.upper() not in _NOT_AN_ALIAS)
    for m in derived_defs:
        open_at = stripped.index("(", m.start())
        k = _end_of(open_at)
        if ids[open_at] not in literal_detail_blocks and _any_in(header_col_pos, open_at + 1, k) \
                and _any_in(arinv_word_pos, open_at + 1, k):
            alias_m = _DERIVED_ALIAS.match(stripped, k)
            nm = (alias_m.group(1) or alias_m.group(2) or "").upper() if alias_m else ""
            if nm and nm not in _NOT_AN_ALIAS:
                header_only_carriers.add(nm)
    header_only_ref_blocks = {ids[pos] for nm in header_only_ctes for pos, _a in named_refs.get(nm, ())}
    # Detail CTEs (86e3bc1xc): a CTE that reads ARINVDET in its own block WITHOUT collapsing to one row per invoice
    # (no GROUP BY, and not a bare SELECT DISTINCT "INVOICE", or the B7 collapse rules below) is itself a line-item
    # source. A block that joins it by
    # name multiplies any header amount it sums, exactly as a literal ARINVDET join would. Measured: the retry's own
    # rewrite ("customer_invoices" + "customer_items" joined on INVOICE, SUM(customer_invoices.TOTAL)) was accepted.
    for m, open_at, k in cte_defs:
        own = ids[open_at]
        # 86e3gzqn0 B4: detail_blocks, not the literal snapshot: a CTE that reads an EARLIER detail CTE without
        # collapsing (li2 AS (SELECT * FROM li)) is a detail CTE too. CTEs are visited in definition order.
        if own not in detail_blocks:
            continue
        if _any_in(group_by_by_block.get(own, ()), open_at + 1, k):
            continue
        from_pos = _first_in(from_starts_by_block.get(own, ()), open_at + 1, k)
        sel_end = from_pos if from_pos is not None else k
        if _bare_invoice_key_deduped(stripped[open_at + 1:sel_end], own, open_at + 1, k):
            continue   # one row per invoice: safe to join
        # 86e3gzqn0 B7: the same collapse rules the derived-table loop uses. An aggregate with no GROUP BY is ONE row;
        # DISTINCT ON (invoice key) or DISTINCT with the invoice key and no detail column is one row per invoice.
        if _any_in(collapse_agg_by_block.get(own, ()), open_at + 1, sel_end) or _is_one_row_per_invoice(
                re.sub(r"^\s*SELECT\s+", "", stripped[open_at + 1:sel_end], flags=re.IGNORECASE), detail_aliases,
                own in arinv_blocks, arinv_names | header_only_carriers):
            continue
        for pos, _alias in named_refs.get(m.group(1).upper(), ()):
            detail_blocks.add(ids[pos])
    # A CTE that carries ARINV header amounts (e.g. "scoped_invoices": one row per invoice) fans out just the same
    # when it is joined to the line items and its amount is summed, so its name and aliases count as ARINV.
    for m, open_at, k in cte_defs:
        lo = m.end()                                   # the body after "SELECT"
        own = ids[open_at]
        # 86e3geveb: a CTE that joins ARINVDET but has NO GROUP BY at its own level is still one row per LINE, so it
        # carries the header amount out at line grain: it is a carrier exactly like a header-only CTE. A CTE that
        # groups at its own level collapses to one row per group and stays excluded.
        groups_at_own_level = _any_in(group_by_by_block.get(own, ()), lo, k)
        # 86e3pdz7t: a CTE that reads ARINVDET literally AND reads a header-only CTE by name carries that CTE's header
        # amounts (or its renames) out per line, though its own body names no ARINV word (and, renamed, no header
        # column).
        via_header_only = own in literal_detail_blocks and own in header_only_ref_blocks
        if (_any_in(header_col_pos, lo, k) or (via_header_only and block_aliases.get(own))) \
                and (_any_in(arinv_word_pos, lo, k) or via_header_only):
            arinv_names.add(m.group(1).upper())
            if own in literal_detail_blocks and groups_at_own_level:
                grouped_carriers.add(m.group(1).upper())
                grouped_carriers.update(al.upper() for _p, al in named_refs.get(m.group(1).upper(), ()) if al)
            carrier_aliases = _aliases_in(lo, k)
            if via_header_only:
                carrier_aliases |= block_aliases.get(own, set())
            if m.group(2) is not None:
                # 86e3gzqn0 B5: a column list renames the select list POSITIONALLY: x(tot, cust) AS (SELECT a."TOTAL",
                # ...) makes tot a header alias. Only positions that hold a header column count.
                from_pos = _first_in(from_starts_by_block.get(own, ()), lo, k)
                items = _top_level_items(stripped[lo:from_pos if from_pos is not None else k])
                names = [c.strip().strip('"').upper() for c in m.group(2).split(",")]
                carrier_aliases |= {nm for nm, item in zip(names, items) if _HEADER_COLUMN.search(item)}
            header_aliases |= carrier_aliases
            for pos, alias in named_refs.get(m.group(1).upper(), ()):
                if carrier_aliases:
                    block_aliases.setdefault(ids[pos], set()).update(carrier_aliases)
                if alias and alias.upper() not in _NOT_AN_ALIAS:
                    arinv_names.add(alias.upper())
        elif not groups_at_own_level and block_aliases.get(own):
            # A CTE that reads an earlier carrier without grouping passes its header aliases through (h -> j -> SUM(amt)
            # FROM j), so a block reading THIS CTE sees them too. CTEs are visited in definition order, so the earlier
            # carrier's references are already recorded.
            passed = set(block_aliases[own])
            for pos, _alias in named_refs.get(m.group(1).upper(), ()):
                block_aliases.setdefault(ids[pos], set()).update(passed)
    # (derived_defs is built before the detail-CTE loop, D1c.) 86e3gzqn0 B3: innermost first (a nested derived table
    # opens AFTER the one around it), and a body counts as reading detail when it holds a line-grain source added by
    # an inner derived table or a detail CTE, not only a literal ARINVDET: JOIN (SELECT * FROM (SELECT ... FROM
    # ARINVDET) x) d is line grain.
    derived_defs.sort(key=lambda dm: dm.start(), reverse=True)
    for m in derived_defs:
        open_at = stripped.index("(", m.start())
        k = _end_of(open_at)
        lo, hi = open_at + 1, max(open_at + 1, k - 1)      # the body is stripped[lo:hi]
        own = ids[open_at]
        is_lateral = "LATERAL" in m.group(0).upper()
        groups = _any_in(group_by_by_block.get(own, ()), lo, hi)
        reads_detail = own in detail_blocks
        sel_end = _first_in(from_starts_by_block.get(own, ()), lo, hi)
        sel_end = hi if sel_end is None else sel_end
        select_list = re.sub(r"^\s*SELECT\s+", "", stripped[lo:sel_end], flags=re.IGNORECASE)
        one_row_per_invoice = reads_detail and not groups and _is_one_row_per_invoice(
            select_list, detail_aliases, own in arinv_blocks, (arinv_names - grouped_carriers) | header_only_carriers)
        bare_invoice = _bare_invoice_key_deduped(stripped[lo:sel_end], own, lo, hi)
        # an aggregate in the select list with no GROUP BY (SELECT MAX(...) FROM ARINVDET ...) also collapses to ONE row;
        # so does a LATERAL body capped by a top-level LIMIT 1 (at most one row per outer row). LIMIT 1 on a plain
        # derived table limits the WHOLE set, not each outer row, so it never counts there.
        collapses = groups or _any_in(collapse_agg_by_block.get(own, ()), lo, sel_end) \
            or (is_lateral and _any_in(limit1_by_block.get(own, ()), lo, hi))
        if reads_detail and not collapses and not bare_invoice and not one_row_per_invoice:
            detail_blocks.add(ids[m.start()])                 # the enclosing block now sits at line grain
        # 86e3pdz7t: the same line-carrier rule as the carrier-CTE loop (literal ARINVDET plus a header-only CTE).
        via_header_only = own in literal_detail_blocks and own in header_only_ref_blocks
        if (_any_in(header_col_pos, lo, hi) or (via_header_only and block_aliases.get(own))) \
                and (_any_in(arinv_word_pos, lo, hi) or via_header_only):
            alias_m = _DERIVED_ALIAS.match(stripped, k)
            if alias_m:
                nm = (alias_m.group(1) or alias_m.group(2) or "").upper()
                if nm and nm not in _NOT_AN_ALIAS:
                    arinv_names.add(nm)
                    if reads_detail and collapses:
                        grouped_carriers.add(nm)
            carrier_aliases = _aliases_in(lo, hi)
            if via_header_only:
                carrier_aliases |= block_aliases.get(own, set())
            if carrier_aliases:
                header_aliases |= carrier_aliases
                # the derived table is read by the block it sits in (FROM/JOIN/, LATERAL (...) is in that block)
                block_aliases.setdefault(ids[m.start()], set()).update(carrier_aliases)
    alias_re = None
    if header_aliases:
        alias_re = re.compile(
            r'(?:(?:"([^"]+)"|(\w+))\s*\.\s*)?(?<![\w"])"?(' + "|".join(map(re.escape, sorted(header_aliases)))
            + r')"?(?![\w"])', re.IGNORECASE)
    # 86e3uappx item 6: the header-column and alias hits are found by ONE regex pass over the whole SQL and each
    # SUM( is answered by bisect (the old code re-ran both regexes over a fresh slice per SUM: quadratic on long
    # runs of unclosed SUM( ). A hit that straddles a slice boundary (a quoted qualifier holding a "(" or ")") would
    # read differently in a slice, so such a SUM( keeps the original slice scan: same verdicts, no exceptions.
    hc_hits = list(_HEADER_COLUMN.finditer(stripped))
    hc_starts = [h.start() for h in hc_hits]
    hc_ends = [h.end() for h in hc_hits]
    hc_q = [h for h in hc_hits if not (h.group(1) or h.group(2)) or (h.group(1) or h.group(2)).upper() in arinv_names]
    hc_q_starts = [h.start() for h in hc_q]
    hc_q_ends = [h.end() for h in hc_q]
    al_hits = list(alias_re.finditer(stripped)) if alias_re is not None else []
    al_starts = [h.start() for h in al_hits]
    al_ends = [h.end() for h in al_hits]
    al_qual_starts, al_qual_ends, al_by_name = [], [], {}
    for h in al_hits:
        q = (h.group(1) or h.group(2) or "").upper()
        if q:
            if q in arinv_names:
                al_qual_starts.append(h.start())
                al_qual_ends.append(h.end())
        else:
            starts_ends = al_by_name.setdefault(h.group(3).upper(), ([], []))
            starts_ends[0].append(h.start())
            starts_ends[1].append(h.end())

    def _straddles(starts, ends, pos):
        i = bisect.bisect_left(starts, pos) - 1
        return i >= 0 and ends[i] > pos

    def _hit_in(starts, ends, lo, hi):
        t = bisect.bisect_left(starts, lo)
        return t < len(starts) and ends[t] <= hi

    for m in _SUM_OR_AVG_OPEN.finditer(stripped):
        block = ids[m.start()]
        if block not in detail_blocks:
            continue
        lo, hi = m.end(), _end_of(m.end() - 1)
        if _straddles(hc_starts, hc_ends, lo) or _straddles(hc_starts, hc_ends, hi) \
                or (alias_re is not None and (_straddles(al_starts, al_ends, lo) or _straddles(al_starts, al_ends, hi))):
            inner = stripped[lo:hi]
            for c in _HEADER_COLUMN.finditer(inner):
                qualifier = (c.group(1) or c.group(2) or "").upper()
                if not qualifier or qualifier in arinv_names:
                    return True
            if alias_re is not None:
                visible = block_aliases.get(block, ())
                for c in alias_re.finditer(inner):
                    qualifier = (c.group(1) or c.group(2) or "").upper()
                    if qualifier in arinv_names if qualifier else c.group(3).upper() in visible:
                        return True
            continue
        if _hit_in(hc_q_starts, hc_q_ends, lo, hi):
            return True
        if alias_re is not None:
            if _hit_in(al_qual_starts, al_qual_ends, lo, hi):
                return True
            for name in block_aliases.get(block, ()):
                se = al_by_name.get(name)
                if se and _hit_in(se[0], se[1], lo, hi):
                    return True
    return False


# Accepted limit (86e3uappx item 4d): a rewrite of a one-order line list that drops every line-amount sum (no footer, no
# total) has nothing for this check to govern and reads as True. The retry still rejects it when the ORIGINAL had a sum
# (Batch W2 final review I1, and the column rule of item 5 in _apply_par_time_retry); a first answer that never had a
# sum is a plain row list, which the PAR_TIME rule does not apply to.
def _has_par_time_predicate(sql: str) -> bool:
    """True if a blank-PAR_TIME predicate governs every line-amount SUM/AVG (not merely a mention of PAR_TIME;
    86e3u4qtf). A query with no line-amount aggregate has nothing to govern and counts as True, so this alone does
    not prove a rewrite is acceptable: _apply_par_time_retry also rejects a rewrite that drops the original's sum."""
    return _par_time_governs_line_sums(sql)


def _apply_sql_retry(question: str, schema: str, sql: str, permissions: dict, history: list, *,
                     tag: str, flagged_log: str, instruction: str, still_bad, budget=None) -> str:
    """Retry for SQL that a deterministic check flagged (PAR_TIME omitted, header amount fanned out). Returns a
    corrected SQL only if it passes the same validation as any model output, is no longer `still_bad(sql)`,
    AND Postgres can plan it; in every other case returns the original `sql`. It never raises and is bounded: at most TWO model calls
    (the filter retry, then one correction if that rewrite does not plan) -- the rewrite often inherits a
    defect of the original (measured: a raw SUM(col) OVER () in a grouped query), and throwing it away
    would throw the filter away with it.

    Never turns a working answer into an error: if the ORIGINAL plans, any failure here keeps it. Only when
    the original does not plan either is a validated, filter-bearing rewrite handed on instead, so the
    normal SQL-error correction in query() starts from SQL that has the filter."""
    log.warning(f"{flagged_log} -- retrying "
                f"(question={question[:200]!r}): {_sql_for_log(sql)}")
    best = None   # last validated, filter-bearing rewrite, whether or not it plans

    def keep_original(why: str) -> str:
        log.warning(f"{tag} {why} -- keeping the original")
        if best is not None:
            try:
                if _sql_plan_error(sql):
                    log.warning("the original SQL does not plan either -- handing the filter-bearing rewrite "
                                "to the normal SQL-error correction instead")
                    return best
            except Exception:  # noqa: BLE001 -- cannot tell: the safe answer is the original
                pass
        return sql

    try:
        if budget is not None and not budget.take():
            return keep_original("optional-call budget exhausted")
        corrected = _self_correct_sql(question, schema, sql, "", history,
                                      instruction=instruction)
        if not corrected.strip() or corrected.lstrip().upper().startswith("CANNOT_QUERY"):
            return keep_original("retry returned no usable SQL")
        # A rewrite that validation REJECTS gets the same one correction as one that does not plan. Measured: the
        # model sometimes double-quotes a CTE name ("cte"."ID"), which _foreign_schema_qualifiers reads as a foreign
        # schema. The guard is deliberately not loosened; the model is told why and asked again.
        try:
            _validate_generated_sql(corrected, schema, permissions, question)
            plan_error = None
        except HTTPException as rejection:
            plan_error = f"the query was rejected before running: {rejection.detail}"
            if str(rejection.detail) == _FOREIGN_SCHEMA_REJECTION:
                plan_error += (' (a double-quoted name in front of a column, such as "cte_name"."ID", is read as a '
                               'schema: write CTE names and aliases WITHOUT double quotes, cte_name."ID")')
        if plan_error is None:
            if still_bad(corrected):
                return keep_original("retry is still flagged")
            best = corrected
            plan_error = _sql_plan_error(corrected)
        if plan_error:
            log.warning(f"{tag} retry SQL does not plan or validate ({plan_error}) -- one correction")
            if budget is not None and not budget.take():
                return keep_original("optional-call budget exhausted")
            corrected = _self_correct_sql(question, schema, corrected, plan_error, history)
            if not corrected.strip() or corrected.lstrip().upper().startswith("CANNOT_QUERY"):
                return keep_original("correction returned no usable SQL")
            _validate_generated_sql(corrected, schema, permissions, question)
            if still_bad(corrected):
                return keep_original("correction is flagged again")
            best = corrected
            plan_error = _sql_plan_error(corrected)
            if plan_error:
                return keep_original(f"correction still does not plan ({plan_error})")
    except Exception as e:  # noqa: BLE001 -- includes HTTPException from validation and API errors
        # expected failures (a validation rejection) need no traceback; anything else might be a bug
        log.warning(f"{tag} retry failed ({type(e).__name__}: {str(e)[:200]})",
                    exc_info=not isinstance(e, HTTPException))
        return keep_original("retry failed")
    log.info(f"{tag} retry succeeded; SQL now: {_sql_for_log(corrected)}")
    return corrected


def _apply_par_time_retry(question: str, schema: str, sql: str, permissions: dict, history: list,
                          budget=None) -> str:
    """The PAR_TIME instance of _apply_sql_retry: the rewrite must carry an actual PAR_TIME predicate, must not
    introduce a header fan-out the original did not have, and must keep a line-amount SUM/AVG when the original
    had one (a rewrite that drops the sum, e.g. the _match_total footer, is rejected)."""
    original_fans_out = _sums_header_across_line_join(sql)
    # a rewrite that deletes the line-amount sum (e.g. the _match_total footer) is vacuously "governed" but loses the
    # figure the original had; reject it (Batch W2 final review I1)
    original_sums = _sums_a_line_amount(_strip_sql_literals_and_comments(sql))
    # ... and one that moves the sum to another line column (a PRICE footer rewritten as a QUAN footer) loses it too:
    # the candidate must still sum every line-amount column the original summed (86e3uappx item 5)
    original_columns = _summed_line_amount_columns(_strip_sql_literals_and_comments(sql))
    return _apply_sql_retry(
        question, schema, sql, permissions, history, tag="PAR_TIME",
        flagged_log="PAR_TIME filter missing from an all-items ARINVDET aggregate",
        instruction=_PAR_TIME_RETRY_INSTRUCTION,
        still_bad=lambda candidate: (_needs_par_time_filter(candidate) or not _has_par_time_predicate(candidate)
                                     or (not original_fans_out and _sums_header_across_line_join(candidate))
                                     or (original_sums
                                         and not _sums_a_line_amount(_strip_sql_literals_and_comments(candidate)))
                                     or not original_columns <= _summed_line_amount_columns(
                                         _strip_sql_literals_and_comments(candidate))),
        budget=budget)


def _apply_fan_out_retry(question: str, schema: str, sql: str, permissions: dict, history: list,
                         budget=None) -> str:
    """The header-fan-out instance of _apply_sql_retry (86e3bbw6t)."""
    return _apply_sql_retry(
        question, schema, sql, permissions, history, tag="fan-out",
        flagged_log="ARINV header amount summed in a SELECT that joins ARINVDET (fan-out)",
        instruction=_FAN_OUT_RETRY_INSTRUCTION, still_bad=_sums_header_across_line_join, budget=budget)


# 86e3gevw3 A2-F6: one /query could make up to 7 sequential Anthropic calls (generate 1, fan-out retry 2, PAR_TIME
# retry 2, SQL-error correction 1, answer 1) with no bound, against a ~100s Cloudflare tunnel limit. The first and last
# are mandatory; the middle five are OPTIONAL and now share one per-request budget. The deadline is measured from the
# start of the request so the answer-formatting call (not optional) still fits; confirm the number with scripts/live_eval.
_OPTIONAL_CALL_LIMIT = 4
_OPTIONAL_CALL_DEADLINE_S = 60


class _OptionalCallBudget:
    """Per-request cap on the optional model calls. take() returns True and consumes one call, or False once the call
    limit or the deadline is used up. A caller that gets False must degrade quietly (keep the original SQL, or fall to
    the existing 503 path), never raise."""

    def __init__(self, max_calls: int | None = None, deadline_s: float | None = None, clock=time.monotonic):
        self._left = _OPTIONAL_CALL_LIMIT if max_calls is None else max_calls
        self._deadline = _OPTIONAL_CALL_DEADLINE_S if deadline_s is None else deadline_s
        self._clock = clock
        self._t0 = clock()

    def take(self) -> bool:
        if self._left <= 0 or self._clock() - self._t0 > self._deadline:
            return False
        self._left -= 1
        return True


_CANNOT_QUERY_DEFAULT = ("I can only answer questions that can be looked up in the EBMS database. Try asking about "
                         "invoices, customers, inventory, GL accounts, payroll, or job status.")


def _cannot_query_response(sql: str, schema: str) -> "QueryResponse":
    """The reply for a model answer that starts with CANNOT_QUERY: its own explanation, else the default text."""
    explanation = sql.lstrip()[len("CANNOT_QUERY"):].strip(" \n:-")
    return QueryResponse(answer=explanation if explanation else _CANNOT_QUERY_DEFAULT,
                         sql="", row_count=0, db_schema=schema)


def _finalize_generated_sql(question: str, schema: str, sql: str, permissions: dict, history: list,
                            budget: "_OptionalCallBudget | None" = None) -> str:
    """Everything model-generated SQL must pass before it runs: validation, then the header fan-out check/retry, then
    the PAR_TIME check/retry (fan-out first: its rewrite can turn a header sum into a line sum that needs PAR_TIME).
    Used by BOTH the first-pass path and the SQL-error self-correction path (86e3gevw3 A2-F4): a self-corrected query
    is still model output and must not skip the checks the first pass gets. Returns the SQL to execute."""
    _validate_generated_sql(sql, schema, permissions, question)
    if _sums_header_across_line_join(sql):
        sql = _apply_fan_out_retry(question, schema, sql, permissions, history, budget=budget)
    if _needs_par_time_filter(sql):
        sql = _apply_par_time_retry(question, schema, sql, permissions, history, budget=budget)
    return sql


def _error_feedback(category: str, err, question: str, sql: str, sess: dict) -> None:
    """Records one /query failure on the portal error feed (feedback.jsonl -> portal, feedback_watcher.py). One helper
    for what query() used to spell out as five identical dicts (86e3gzqnn)."""
    append_feedback({
        "rating": "error",
        "category": category,
        "comment": str(err)[:500],
        "question": question[:1000],
        "sql": sql[:2000] if sql else "",
        "answer": "",
        "username": sess.get("username", ""),
        "schema": sess.get("schema", ""),
    })


@app.post("/query", response_model=QueryResponse)
def query(req: QueryRequest, request: Request, *, _rl: None = Depends(_root_rate_limit_dependency), sess: dict = Depends(verify_session)):
    question = req.question.strip()
    schema = sess.get("schema") or _default_schema()
    budget = _OptionalCallBudget()

    if not question:
        raise HTTPException(status_code=400, detail="Question cannot be empty")

    # Generate SQL (pass conversation history for context-aware follow-up questions)
    # 86e2wf61a: an unhandled exception here (e.g. an Anthropic outage) is caught by
    # 86e2rryv8's global exception handler for the client response, but that handler
    # deliberately does not call append_feedback() -- without this, the failure is
    # invisible on the portal error feed and feedback_watcher.py's ClickUp auto-
    # ticketing, unlike every other /query failure mode. Re-raises unconditionally;
    # this changes nothing about the client-visible response.
    try:
        sql, clarification = generate_sql(question, schema, req.history)
    except Exception as e:
        _error_feedback("query_exception", e, question, "", sess)
        raise
    sql = fix_schema_quoting(sql)
    log.info(f"Generated SQL: {_sql_for_log(sql)}")

    # 86e3gzqnn: same test as the correction branch below (case-insensitive, leading space allowed).
    if sql.lstrip().upper().startswith("CANNOT_QUERY"):
        return _cannot_query_response(sql, schema)

    sql = _finalize_generated_sql(question, schema, sql, sess["permissions"], req.history, budget)

    # Execute. Fetch one row PAST the cap: the presence of that extra row is the only
    # reliable truncation signal, because len(rows) == MAX_ROWS is ambiguous -- a query
    # can legitimately match exactly MAX_ROWS rows.
    exec_sql = _bump_trailing_limit(sql, MAX_ROWS)
    try:
        with get_conn() as conn:
            with conn.cursor() as cur:
                try:
                    cur.execute(exec_sql)
                    rows = [dict(r) for r in cur.fetchmany(MAX_ROWS + 1)]
                except psycopg.Error as e:
                    # A generated column reference that doesn't exist on this install gets ONE
                    # retry, never a loop: prefer Postgres's own HINT (a near-miss column name it
                    # found via trigram similarity, e.g. a hallucinated NXT_STP_ -> the real
                    # NXT_STOP_) over a known-optional-column strip, since the HINT is Postgres's
                    # own suggestion, not a guess of ours. If retry_sql itself fails, that second
                    # psycopg.Error is intentionally left uncaught here -- it propagates to the
                    # outer handler below and reports a clean 422, rather than looping.
                    missing_col = (
                        _missing_column_name(e.diag.message_primary or str(e))
                        if e.sqlstate == _UNDEFINED_COLUMN_SQLSTATE else None
                    )
                    hint_col = _hint_column_name(e.diag.message_hint) if missing_col else None
                    if hint_col and hint_col != missing_col:
                        conn.rollback()
                        sql = sql.replace(f'"{missing_col}"', f'"{hint_col}"')
                        exec_sql = _bump_trailing_limit(sql, MAX_ROWS)
                        cur.execute(exec_sql)
                        rows = [dict(r) for r in cur.fetchmany(MAX_ROWS + 1)]
                        log.warning(f"Column {missing_col!r} not found -- Postgres suggested {hint_col!r}, retried")
                    elif missing_col in KNOWN_OPTIONAL_COLUMNS:
                        conn.rollback()
                        sql = _strip_column(sql, missing_col)
                        exec_sql = _bump_trailing_limit(sql, MAX_ROWS)
                        cur.execute(exec_sql)
                        rows = [dict(r) for r in cur.fetchmany(MAX_ROWS + 1)]
                        log.warning(f"Column {missing_col!r} not present on this install -- stripped and retried")
                    else:
                        # 86e30r8tm/86e30r8z5/86e30r8wh/86e30rdy1 (Group A): any OTHER SQL
                        # error (not a missing column, which the branches above already
                        # handle) gets ONE shape-agnostic self-correction attempt -- show the
                        # model its own SQL and Postgres's exact error, ask it to fix it. This
                        # is deliberately the same "one retry, never a loop" shape as the
                        # missing-column retries above: if the corrected SQL also fails, that
                        # second psycopg.Error (or an HTTPException from re-validation below)
                        # propagates uncaught, exactly like the original design's comment
                        # above already says for this whole block.
                        conn.rollback()
                        if not budget.take():
                            raise            # budget spent: same outcome as a failed correction (503 below)
                        corrected_sql = _self_correct_sql(question, schema, sql, str(e), req.history)
                        stripped_fix = corrected_sql.strip()
                        if not stripped_fix:
                            raise            # nothing usable: keep the original database error (503 below)
                        if stripped_fix.upper().startswith("CANNOT_QUERY"):
                            # 86e3gevw3 A2-F4: the model says it cannot fix it. Show ITS explanation (as the first pass
                            # does), and keep the failure visible in agent.log, query_errors.log and the portal feed.
                            log.error(f"Query error: {e}")
                            log_query_error(question, exec_sql, "", str(e))
                            _error_feedback("query_failed", e, question, sql, sess)
                            return _cannot_query_response(stripped_fix, schema)
                        # This can open a SECOND get_conn() (via _sql_plan_error) while the outer connection is held:
                        # safe today because get_conn is a plain psycopg.connect with no pool; it would deadlock if a
                        # bounded pool were ever introduced.
                        corrected_sql = _finalize_generated_sql(question, schema, corrected_sql, sess["permissions"],
                                                                req.history, budget)
                        sql = corrected_sql
                        exec_sql = _bump_trailing_limit(sql, MAX_ROWS)
                        cur.execute(exec_sql)
                        rows = [dict(r) for r in cur.fetchmany(MAX_ROWS + 1)]
                        log.warning(f"SQL error {e.sqlstate!r} -- self-corrected and retried: {str(e)[:200]}")
    except psycopg.Error as e:
        log.error(f"Query error: {e}")
        log_query_error(question, exec_sql, "", str(e))
        # Implicit negative feedback: failed queries surface in the portal feed
        _error_feedback("query_failed", e, question, sql, sess)
        raise HTTPException(status_code=503, detail="Database unavailable")

    truncated = len(rows) > MAX_ROWS
    if truncated:
        # Drop the probe row. It must never reach the client or the model.
        rows = rows[:MAX_ROWS]
        log.info(f"Result truncated at {MAX_ROWS} rows for question: {question[:80]}")

    try:
        payload_rows = _jsonable_rows(rows)
        model_rows = payload_rows
    except (TypeError, ValueError) as e:
        # A coercion failure must cost the table, never the answer.
        log.error(f"Row coercion failed, returning prose only: {e}")
        _error_feedback("rows_uncoercible", e, question, sql, sess)
        payload_rows = []
        model_rows = rows  # format_answer applies its own default=str coercion

    # Format answer (pass history so follow-up context is available)
    # 86e2wf61a: same reasoning as the generate_sql() wrapper above -- an unhandled
    # exception here reaches 86e2rryv8's global handler for the client response, but
    # was previously invisible on the portal error feed. Re-raises unconditionally.
    try:
        answer = format_answer(question, model_rows, sql, req.history, truncated, MAX_ROWS)
    except Exception as e:
        _error_feedback("query_exception", e, question, sql, sess)
        raise

    # Append any clarifying question the model asked after the SQL
    if clarification:
        answer = f"{answer}\n\n{clarification}"

    record_query(sess["username"])

    return QueryResponse(
        answer=answer,
        sql=sql,
        row_count=len(rows),
        db_schema=schema,
        rows=payload_rows,
        truncated=truncated,
        row_cap=MAX_ROWS,
    )


def _safe_compare(a: str, b: str) -> bool:
    """Constant-time string compare that cannot raise on non-ASCII input (secrets.compare_digest(str, str) raises
    TypeError on a non-ASCII str, which turned an unauthenticated non-ASCII header into a 500 -- 86e3gevvq A1-F3)."""
    return secrets.compare_digest(a.encode("utf-8", errors="ignore"), b.encode("utf-8", errors="ignore"))


def _verify_portal_token(request: Request):
    token = request.headers.get("X-Portal-Token", "")
    if not PORTAL_TOKEN or not _safe_compare(token, PORTAL_TOKEN):
        # 86e31dqdp: _client_ip() returns a client-controlled header value
        # (CF-Connecting-IP) with no length validation per its own docstring --
        # sanitize before logging it. This is the first call site in the file
        # that LOGS this value (every other call site only uses it as a
        # rate-limit dict key); an unsanitized value here could embed a
        # newline to forge fake log lines in agent.log (which the portal's
        # /logs endpoint returns verbatim and displays), or be sent
        # arbitrarily long to help evict real history from the log's
        # rotation window. Truncate to a length that comfortably fits a real
        # IPv4/IPv6 address and strip CR/LF.
        safe_ip = _client_ip(request)[:45].replace("\n", " ").replace("\r", " ")
        log.warning(f"Portal token check failed from {safe_ip}")
        raise HTTPException(status_code=401, detail="Invalid portal token.")

# ---------------------------------------------------------------------------
# Query feedback
# ---------------------------------------------------------------------------

_FEEDBACK_PATHS = [
    Path(r"C:\ProgramData\IntraMind\feedback.jsonl"),
    Path(__file__).parent / "feedback.jsonl",
]

FEEDBACK_RETENTION_DAYS = 365  # TOS Section 11
# Serialises appends against the retention purge (read-filter-replace).
_feedback_lock = Lock()

def append_feedback(entry: dict):
    entry["time"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())
    entry["version"] = VERSION
    line = json.dumps(entry, ensure_ascii=False)
    with _feedback_lock:
        for p in _FEEDBACK_PATHS:
            try:
                with open(p, "a", encoding="utf-8") as f:
                    f.write(line + "\n")
                return
            except OSError:
                continue
    log.warning("Could not write feedback entry to any path")

def purge_old_feedback(now=None) -> dict:
    """Drop feedback.jsonl entries older than FEEDBACK_RETENTION_DAYS.

    Lines that cannot be parsed or dated are always kept. Logs counts only
    (never question/answer content).
    """
    if now is None:
        now = datetime.now(timezone.utc)
    cutoff = now - timedelta(days=FEEDBACK_RETENTION_DAYS)
    kept_total = 0
    removed_total = 0
    with _feedback_lock:
        for p in _FEEDBACK_PATHS:
            if not p.exists():
                continue
            try:
                # surrogateescape: an invalid byte round-trips exactly instead of
                # stopping the purge for the whole file.
                with open(p, "r", encoding="utf-8", errors="surrogateescape", newline="") as f:
                    # Split on \n only: str.splitlines() also splits on U+0085/2028/2029,
                    # which json.dumps(ensure_ascii=False) leaves raw inside an entry.
                    lines = [x for x in re.split(r"(?<=\n)", f.read()) if x]
            except (OSError, UnicodeDecodeError):
                log.warning("Feedback retention: could not read a feedback file; skipped")
                continue
            kept = []
            for ln in lines:
                keep = True
                try:
                    t = json.loads(ln).get("time")
                    ts = datetime.strptime(t, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                    keep = ts >= cutoff
                except (ValueError, TypeError, AttributeError):
                    keep = True
                if keep:
                    kept.append(ln)
            removed = len(lines) - len(kept)
            if removed == 0:
                kept_total += len(kept)
                continue
            tmp = p.with_name(p.name + ".purge.tmp")
            try:
                # newline="" keeps CRLF line endings as read (matters on Windows).
                with open(tmp, "w", encoding="utf-8", errors="surrogateescape", newline="") as f:
                    f.write("".join(kept))
                    f.flush()
                    os.fsync(f.fileno())
                os.replace(tmp, p)
            except OSError:
                log.warning("Feedback retention: could not rewrite a feedback file; left unchanged")
                try:
                    if tmp.exists():
                        tmp.unlink()
                except OSError:
                    pass
                kept_total += len(lines)
                continue
            kept_total += len(kept)
            removed_total += removed
    log.info(f"Feedback retention purge: kept {kept_total}, removed {removed_total}")
    return {"kept": kept_total, "removed": removed_total}

FEEDBACK_PURGE_INTERVAL_SECONDS = 86400  # one pass at startup, then daily

async def _feedback_purger() -> None:
    """Background task: applies the feedback retention purge at startup and daily."""
    while True:
        try:
            await asyncio.to_thread(purge_old_feedback)
        except asyncio.CancelledError:
            raise
        except Exception:
            # No exception text: it could carry feedback content.
            log.error("Feedback retention purge failed (will retry at the next interval)")
        await asyncio.sleep(FEEDBACK_PURGE_INTERVAL_SECONDS)

class ConversationTurn(BaseModel):
    role: str = Field(max_length=20)
    # Final Review finding (C1): a 2000-char Pydantic ceiling on content/sql
    # REJECTS (422) the whole feedback submission -- including the rating --
    # whenever any one of the last 20 conversationHistory turns happens to be
    # longer, since /query's own HistoryMessage already accepts turns up to
    # HISTORY_TEXT_MAX_LEN (20,000 chars) and pushes them onto
    # conversationHistory unmodified. That silently destroyed feedback for
    # the NEXT ~10 exchanges after any one long answer/SQL turn -- strictly
    # worse than not having history capture at all. Validate against the
    # same generous ceiling /query already accepts (so nothing legitimately
    # in conversationHistory is ever rejected here), and let
    # submit_feedback()'s own [:2000] re-slice do the real truncation for
    # storage/ticket-display -- that re-slice was dead code before this fix
    # (Pydantic's old max_length=2000 already guaranteed the same bound), it
    # is now the live mechanism that keeps ticket bodies human-readable.
    content: str = Field(default="", max_length=HISTORY_TEXT_MAX_LEN)
    sql: str = Field(default="", max_length=HISTORY_TEXT_MAX_LEN)
    rows: list[dict] = Field(default_factory=list, max_length=5)

    @field_validator("rows")
    @classmethod
    def _cap_row_size(cls, v):
        # Final Review finding (I1): mirrors HistoryMessage's own 86e31dqdk
        # fix for the identical gap -- max_length on the list only caps row
        # COUNT, not each row dict's own serialized size. Without this, a
        # single oversized row can produce a multi-MB feedback.jsonl line
        # and ClickUp ticket body that create_clickup_task() can never
        # successfully create, permanently wedging process_downvote_cluster()
        # (a failed create leaves the cluster unmarked-seen by design, so it
        # retries forever).
        for row in v:
            # 86e3mgxk6 C4: ensure_ascii=False so the cap counts characters, not \uXXXX escapes (an accented character used to count 6).
            if len(json.dumps(row, default=str, ensure_ascii=False)) > HISTORY_TEXT_MAX_LEN:
                raise ValueError(f"each history row must serialize to at most {HISTORY_TEXT_MAX_LEN} characters")
        return v

class FeedbackRequest(BaseModel):
    rating: str            # "up" or "down"
    question: str = Field(default="", max_length=1000)
    sql: str = Field(default="", max_length=2000)
    answer: str = Field(default="", max_length=2000)
    category: str = Field(default="", max_length=50)
    comment: str = Field(default="", max_length=1000)
    # 86e39gxpk: the last 20 conversation turns leading up to the rated
    # exchange, so an auto-filed ClickUp ticket for a down-vote (e.g.
    # "that value was wrong") carries the earlier turn with the actual
    # disputed value, not just the follow-up text disputing it.
    history: list[ConversationTurn] = Field(default_factory=list, max_length=20)

class ChannelRequest(BaseModel):
    channel: str

class AcceptRequest(BaseModel):
    version: str = Field(default="", max_length=64)

# 86e3b7rmj: ConversationTurn's own _cap_row_size validator (above) only
# REJECTS (422) a request whose row serializes over HISTORY_TEXT_MAX_LEN --
# it never truncates anything for storage. A row just under that ceiling
# still passes validation, and with up to 5 rows/turn x 20 turns, a
# feedback record can still reach ~2MB in the worst case -- large enough
# that feedback_watcher.py's create_clickup_task() can never successfully
# create the resulting ClickUp task, permanently wedging
# process_downvote_cluster() (a failed create leaves the cluster
# unmarked-seen by design, so it retries forever, re-running diagnose()
# every run). Cap each row dict's own string field VALUES to a fixed
# length at storage time, mirroring the existing content/sql [:2000]
# truncation -- keeps the dict structure intact so feedback_watcher.py's
# existing json.dumps(turn["rows"], ...) rendering keeps working unchanged.
_HISTORY_ROW_FIELD_MAX_LEN = 500  # per-field cap at storage time, keeps a multi-column row's
                                    # total serialized size bounded regardless of column count

def _cap_row_fields_for_storage(row: dict) -> dict:
    return {
        k: (v[:_HISTORY_ROW_FIELD_MAX_LEN] if isinstance(v, str) and len(v) > _HISTORY_ROW_FIELD_MAX_LEN else v)
        for k, v in row.items()
    }

@app.post("/feedback")
def submit_feedback(req: FeedbackRequest, request: Request, *, _rl: None = Depends(_root_rate_limit_dependency), sess: dict = Depends(verify_session)):
    """Record user feedback on a query answer."""
    if req.rating not in ("up", "down"):
        raise HTTPException(status_code=400, detail="rating must be 'up' or 'down'")
    append_feedback({
        "rating": req.rating,
        "category": req.category[:50],
        "comment": req.comment[:1000],
        "question": req.question[:1000],
        "sql": req.sql[:2000],
        "answer": req.answer[:2000],
        "history": [
            {
                "role": t.role[:20],
                "content": t.content[:2000],
                "sql": t.sql[:2000],
                "rows": [_cap_row_fields_for_storage(r) for r in t.rows[:5]],
            }
            for t in req.history[-20:]
        ],
        "username": sess.get("username", ""),
        "schema": sess.get("schema", ""),
    })
    return {"ok": True}

@app.get("/feedback")
def get_feedback(request: Request, limit: int = 200):
    """Return recent feedback entries for the admin portal. Protected by X-Portal-Token header."""
    check_portal_rate_limit(_client_ip(request))
    _verify_portal_token(request)
    limit = min(max(limit, 10), 500)
    for p in _FEEDBACK_PATHS:
        try:
            with _feedback_lock:  # not while the retention purge swaps the file
                text = p.read_text(encoding="utf-8")
            lines = text.splitlines()
        except OSError:
            continue
        entries = []
        for line in lines[-limit:]:
            try:
                entries.append(json.loads(line))
            except json.JSONDecodeError:
                pass
        entries.reverse()  # newest first
        return {"entries": entries, "total": len(lines)}
    return {"entries": [], "total": 0}

@app.post("/accept")
def accept_terms(req: AcceptRequest, request: Request, *, _rl: None = Depends(_root_rate_limit_dependency), sess: dict = Depends(verify_session_no_terms)):
    """Record this user's acceptance of the running VERSION's Terms. The portal push happens in the background."""
    if req.version != VERSION:
        raise HTTPException(status_code=409, detail={"code": "terms_version_changed", "version": VERSION})
    try:
        rec = record_acceptance(sess["username"], sess.get("schema", ""))
    except OSError as e:
        log.error(f"Terms acceptance could not be saved for {sess['username']}: {e}")
        raise HTTPException(status_code=500, detail="Could not save your acceptance. Please try again.")
    log.info(f"Terms accepted: {rec['username']} schema={rec['schema']} version={rec['terms_version']} seq={rec['seq']}")
    return {"ok": True, "record": rec}


@app.get("/acceptances")
def get_acceptances(request: Request, after: int = Query(0, ge=0), limit: int = Query(500, ge=1)):
    """Acceptance records newer than `after`, for the admin portal's pull backstop. X-Portal-Token protected."""
    check_portal_rate_limit(_client_ip(request))
    _verify_portal_token(request)
    records, latest = _acceptances_after(after, min(limit, 500))
    return {"records": records, "latest_seq": latest}

@app.get("/stats")
def stats(request: Request):
    """Usage stats for the IntraMind admin portal. Protected by X-Portal-Token header."""
    check_portal_rate_limit(_client_ip(request))
    _verify_portal_token(request)
    return get_stats_snapshot()

@app.get("/logs")
def logs(request: Request, lines: int = 200):
    """Return last N lines of agent.log for the admin portal. Protected by X-Portal-Token header."""
    check_portal_rate_limit(_client_ip(request))
    _verify_portal_token(request)
    lines = min(max(lines, 10), 500)
    log_paths = [
        Path(r"C:\ProgramData\IntraMind\agent.log"),
        Path(__file__).parent / "agent.log",
    ]
    for p in log_paths:
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
            tail = text.splitlines()[-lines:]
            return {"lines": tail, "path": str(p), "total_lines": len(text.splitlines())}
        except OSError:
            pass
    return {"lines": [], "path": None, "total_lines": 0}

@app.post("/admin/channel")
def admin_channel(req: ChannelRequest, request: Request):
    """Switch this instance's update channel. Protected by X-Portal-Token header.
    Only rewrites .env -- does not trigger an update or restart; see /admin/update."""
    check_portal_rate_limit(_client_ip(request))
    _verify_portal_token(request)
    channel = req.channel.strip().lower()
    if channel not in CHANNELS:
        raise HTTPException(status_code=400, detail=f"Unknown channel '{channel}'. Valid: {sorted(CHANNELS)}")
    _write_channel_to_env(channel)
    return {"status": "ok", "channel": channel}


@app.post("/admin/update")
def admin_update(request: Request):
    """Trigger an immediate update pull. Protected by X-Portal-Token header.
    Fire-and-forget: returns 202 immediately. Real success/failure arrives via
    last_admin_action on /health once update.ps1 finishes -- see /health below."""
    check_portal_rate_limit(_client_ip(request))
    _verify_portal_token(request)
    if _is_update_lock_stale():
        log.warning(f"update.lock is stale (older than {_UPDATE_LOCK_STALE_AFTER_SECONDS}s) -- reclaiming")
        _update_lock_path().unlink(missing_ok=True)
    try:
        _create_update_lock()
    except FileExistsError:
        raise HTTPException(status_code=409, detail="An update is already in progress.")
    except OSError as e:
        log.warning(f"Could not create update lock ({e}) -- proceeding without lock protection")
    try:
        _launch_update_ps1()
    except Exception as e:
        _update_lock_path().unlink(missing_ok=True)
        log.error(f"Failed to launch update.ps1 ({e})")
        raise HTTPException(status_code=500, detail="Failed to trigger update.")
    return JSONResponse({"status": "triggered"}, status_code=202)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=PORT)
