import sys
import os
import subprocess
import win32serviceutil
import win32service
import win32event
import win32job
import win32api
import win32con
import servicemanager

INSTALL_DIR = r"C:\Program Files\IntraMind"
DATA_DIR    = r"C:\ProgramData\IntraMind"
LOG_FILE    = os.path.join(DATA_DIR, "agent.log")

# sys.executable inside a pywin32 service points to pythonservice.exe, not python.exe.
# Resolve the real interpreter from the same directory as pythonservice.exe.
_svc_exe = sys.executable
PYTHON_EXE = os.path.join(os.path.dirname(_svc_exe), "python.exe")
if not os.path.exists(PYTHON_EXE):
    # Fallback: walk up one level (Scripts/ -> pythoncore-x.xx-64/)
    PYTHON_EXE = os.path.join(os.path.dirname(os.path.dirname(_svc_exe)), "python.exe")


def _read_port():
    port = "8767"
    env_path = os.path.join(DATA_DIR, ".env")
    try:
        with open(env_path) as f:
            for line in f:
                if line.startswith("EBMS_LIVE_PORT="):
                    port = line.strip().split("=", 1)[1]
    except Exception:
        pass
    return port


class EBMSLiveService(win32serviceutil.ServiceFramework):
    _svc_name_         = "EBMSLiveAgent"
    _svc_display_name_ = "EBMS Live Agent"
    _svc_description_  = "IntraMind EBMS Live Query Agent"

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self._stop_event = win32event.CreateEvent(None, 0, 0, None)
        self._process    = None
        self._job        = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        if self._process:
            self._process.terminate()
        win32event.SetEvent(self._stop_event)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, "")
        )
        port = _read_port()
        log  = open(LOG_FILE, "a")
        self._process = subprocess.Popen(
            [PYTHON_EXE, "-m", "uvicorn", "server:app",
             "--host", "127.0.0.1", "--port", port,
             "--log-config", os.path.join(INSTALL_DIR, "log_config.json")],
            cwd=INSTALL_DIR,
            stdout=log,
            stderr=log,
        )

        # 86e2z2u1b: bind the uvicorn child's lifetime to THIS process via a
        # Windows Job Object with JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE. Without
        # this, an unexpected death of this process (a genuine crash, or an
        # external kill of the wrong PID) orphans the child -- it survives,
        # keeps the port bound, and every sc.exe-failure restart attempt that
        # follows then fails to bind, so Windows exhausts its recovery
        # actions and gives up with the service permanently Stopped even
        # though recovery "fired." Confirmed live 2026-08-25: killing the
        # service's registered process left the uvicorn child running and
        # serving traffic, unsupervised, while SCM reported the service
        # Stopped. This is the inverse of the crashed-child-surviving-parent
        # case the poll loop below already guards -- both halves of the
        # parent/child pair need to die together.
        #
        # Best-effort: on any failure here, log and continue running WITHOUT
        # this protection rather than refusing to serve at all -- "the agent
        # doesn't start" is a strictly worse outcome than "the agent starts
        # without this one extra safety net."
        try:
            self._job = win32job.CreateJobObject(None, "")
            job_info = win32job.QueryInformationJobObject(
                self._job, win32job.JobObjectExtendedLimitInformation)
            job_info['BasicLimitInformation']['LimitFlags'] |= win32job.JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            win32job.SetInformationJobObject(
                self._job, win32job.JobObjectExtendedLimitInformation, job_info)
            hProcess = win32api.OpenProcess(
                win32con.PROCESS_SET_QUOTA | win32con.PROCESS_TERMINATE,
                False, self._process.pid)
            win32job.AssignProcessToJobObject(self._job, hProcess)
        except Exception as e:
            servicemanager.LogErrorMsg(
                f"EBMSLiveAgent: could not bind uvicorn child (PID "
                f"{self._process.pid}) to a kill-on-close job object ({e}) "
                f"-- continuing without this protection. If this service's "
                f"own process dies unexpectedly, the uvicorn child may be "
                f"orphaned and block subsequent restart attempts (86e2z2u1b)."
            )
            self._job = None

        # Poll for either a stop request or the child dying on its own.
        # WaitForSingleObject(..., INFINITE) here previously meant a crashed
        # uvicorn subprocess went unnoticed forever -- Windows still saw this
        # service as "Running" (this wrapper was fine), so its own recovery
        # actions (sc.exe failure) never fired. See Known_Issues.md / 86e2nuxz5
        # for the incident this protects against.
        crashed = False
        while True:
            rc = win32event.WaitForSingleObject(self._stop_event, 1000)
            if rc == win32event.WAIT_OBJECT_0:
                break  # SvcStop() was called -- clean shutdown requested
            if self._process.poll() is not None:
                crashed = True
                servicemanager.LogErrorMsg(
                    f"EBMSLiveAgent: uvicorn subprocess exited unexpectedly "
                    f"(exit code {self._process.returncode}). Stopping the "
                    f"service so Windows' recovery actions can restart it."
                )
                break

        if self._process.poll() is None:
            self._process.terminate()
        log.close()

        if crashed:
            # Report a non-clean stop (nonzero win32ExitCode) so the Service
            # Control Manager treats this as a failure and invokes the
            # configured recovery actions, rather than as a deliberate stop
            # (which it would not act on).
            self.ReportServiceStatus(win32service.SERVICE_STOPPED, win32ExitCode=1)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(EBMSLiveService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(EBMSLiveService)
