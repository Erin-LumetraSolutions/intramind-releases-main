import sys
import os
import subprocess
import threading
import logging
import queue
from logging.handlers import RotatingFileHandler, QueueHandler, QueueListener
import win32serviceutil
import win32service
import win32event
import win32job
import win32api
import win32con
import servicemanager

INSTALL_DIR = r"C:\Program Files\IntraMind"
DATA_DIR    = r"C:\ProgramData\IntraMind"
LOG_FILE    = os.path.join(DATA_DIR, "agent.log")

# sys.executable inside a pywin32 service points to pythonservice.exe, not python.exe.
# Resolve the real interpreter from the same directory as pythonservice.exe.
_svc_exe = sys.executable
PYTHON_EXE = os.path.join(os.path.dirname(_svc_exe), "python.exe")
if not os.path.exists(PYTHON_EXE):
    # Fallback: walk up one level (Scripts/ -> pythoncore-x.xx-64/)
    PYTHON_EXE = os.path.join(os.path.dirname(os.path.dirname(_svc_exe)), "python.exe")

# 86e31dqg1: neither the primary nor the fallback path panned out -- the
# Popen() call in SvcDoRun() below will throw an opaque, uncaught
# FileNotFoundError with no diagnostic context once the service actually
# tries to start. Log a clear pointer to what's wrong NOW, at import
# time, rather than let that failure be the only trace. Deliberately does
# NOT sys.exit()/raise here -- SvcDoRun() hasn't started yet, and this
# check's only job is a diagnostic line in the event log before the
# opaque failure, not a change in control flow.
if not os.path.exists(PYTHON_EXE):
    servicemanager.LogErrorMsg(
        f"EBMSLiveAgent: could not locate python.exe at either expected "
        f"path (primary or one-level-up fallback from {_svc_exe}) -- "
        f"the service will fail to start its uvicorn child."
    )


def _read_port():
    port = "8767"
    env_path = os.path.join(DATA_DIR, ".env")
    try:
        with open(env_path) as f:
            for line in f:
                if line.startswith("EBMS_LIVE_PORT="):
                    port = line.strip().split("=", 1)[1]
    except Exception:
        pass
    return port


class EBMSLiveService(win32serviceutil.ServiceFramework):
    _svc_name_         = "EBMSLiveAgent"
    _svc_display_name_ = "EBMS Live Agent"
    _svc_description_  = "IntraMind EBMS Live Query Agent"

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self._stop_event = win32event.CreateEvent(None, 0, 0, None)
        self._process    = None
        self._job        = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        if self._process:
            self._process.terminate()
        win32event.SetEvent(self._stop_event)

    def SvcDoRun(self):
        servicemanager.LogMsg(
            servicemanager.EVENTLOG_INFORMATION_TYPE,
            servicemanager.PYS_SERVICE_STARTED,
            (self._svc_name_, "")
        )
        port = _read_port()

        # 86e30r30g: agent.log used to be a plain open(..., "a") handle shared
        # directly with the uvicorn child via stdout=log/stderr=log -- that
        # handle lives for the child's entire lifetime (weeks, between
        # restarts), so the file grew unbounded with no way to rotate it.
        # RotatingFileHandler (already used the same way for query_errors.log
        # in server.py) can't be bolted onto that setup: Windows won't let the
        # parent rename/delete a file out from under a handle the child still
        # holds open (Python's open() doesn't request FILE_SHARE_DELETE, and
        # CPython has never added it -- see bpo-15244), so a rename attempt
        # from this side would raise WinError 32 deterministically. And even
        # if the rename were forced through, the child's own handle would just
        # keep writing into the renamed-away file forever, since nothing ever
        # tells uvicorn to reopen it -- not real rotation either way.
        #
        # Fixed instead by not sharing a raw file handle with the child at
        # all: the child's stdout/stderr are piped back to THIS process, and
        # a reader thread here drains them into a RotatingFileHandler this
        # process owns outright. Rotation becomes an ordinary single-process
        # file operation with no cross-process handle hazard -- the same
        # architecture NSSM and most Windows service wrappers use for exactly
        # this reason.
        log = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        # No prefix added -- uvicorn's own log_config.json formatters already
        # timestamp each line; this just relays the pre-formatted text as-is.
        log.setFormatter(logging.Formatter("%(message)s"))

        # 86e31dqfx: _drain_child_output() below is the SOLE reader of the
        # uvicorn child's stdout pipe. Previously, _child_log's handler was
        # this RotatingFileHandler directly -- every line synchronously
        # triggered doRollover() (a blocking file rename) once maxBytes was
        # crossed. If that rename stalls (this codebase has a documented
        # Windows-rename-hang history, 86e2zbm5q), the drain thread stops
        # reading and the child can block on a full OS pipe buffer -- the
        # same failure class 86e2zbm5q/86e2zk7p3 already fought hard to fix
        # elsewhere in this file. Decoupled here via QueueHandler/
        # QueueListener: _child_log's handler only ever enqueues (never
        # touches disk), and a separate listener thread owns the real
        # RotatingFileHandler and performs the actual (possibly slow) I/O
        # on ITS OWN thread -- a stall there no longer blocks the pipe
        # drain.
        log_queue = queue.Queue()
        queue_handler = QueueHandler(log_queue)
        listener = QueueListener(log_queue, log)
        listener.start()

        self._process = subprocess.Popen(
            [PYTHON_EXE, "-m", "uvicorn", "server:app",
             "--host", "127.0.0.1", "--port", port,
             "--log-config", os.path.join(INSTALL_DIR, "log_config.json")],
            cwd=INSTALL_DIR,
            # 86e30r30g follow-up, live-confirmed on ErinTest 2026-08-28: without an explicit
            # stdin=, the child inherits this service's own stdin -- which does not exist in a
            # console-less pythonservice.exe context. The service reported "started" and the
            # update script confirmed it, but the uvicorn child never became responsive on
            # /health within the poll window, causing a rollback. DEVNULL gives the child a
            # real, immediately-EOF stdin instead of an inherited handle to nothing.
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            bufsize=1,
            # The child's stdout is a pipe, not a TTY, so CPython in the child defaults to
            # full block-buffering rather than line-buffering -- bufsize=1 above only governs
            # THIS process's read side, it has no effect on the child's own write-side
            # buffering. Without this, uvicorn's log lines can sit in the child's internal
            # buffer rather than reach agent.log promptly, which would have made this exact
            # startup failure harder to diagnose from the log alone.
            env={**os.environ, "PYTHONUNBUFFERED": "1"},
        )

        _child_log = logging.getLogger("ebms_live.child")
        _child_log.setLevel(logging.INFO)
        _child_log.propagate = False
        _child_log.addHandler(queue_handler)

        def _drain_child_output():
            # Runs until the child's stdout pipe closes -- which happens when
            # the child exits on its own, or when SvcStop()/the crash-poll
            # loop below calls self._process.terminate(). No explicit stop
            # signal needed: iterating a closed pipe just ends the for-loop.
            # uvicorn's own log_config.json formatters already timestamp each
            # line, so this just relays the raw text through -- no extra
            # logging.Formatter wrapping (that would double-timestamp it).
            try:
                for line in self._process.stdout:
                    _child_log.info(line.rstrip("\n"))
            except Exception:
                pass

        _drain_thread = threading.Thread(target=_drain_child_output, daemon=True)
        _drain_thread.start()

        # 86e2z2u1b: bind the uvicorn child's lifetime to THIS process via a
        # Windows Job Object with JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE. Without
        # this, an unexpected death of this process (a genuine crash, or an
        # external kill of the wrong PID) orphans the child -- it survives,
        # keeps the port bound, and every sc.exe-failure restart attempt that
        # follows then fails to bind, so Windows exhausts its recovery
        # actions and gives up with the service permanently Stopped even
        # though recovery "fired." Confirmed live 2026-08-25: killing the
        # service's registered process left the uvicorn child running and
        # serving traffic, unsupervised, while SCM reported the service
        # Stopped. This is the inverse of the crashed-child-surviving-parent
        # case the poll loop below already guards -- both halves of the
        # parent/child pair need to die together.
        #
        # Best-effort: on any failure here, log and continue running WITHOUT
        # this protection rather than refusing to serve at all -- "the agent
        # doesn't start" is a strictly worse outcome than "the agent starts
        # without this one extra safety net."
        #
        # 86e2zk7p3: also allow explicit breakaway (JOB_OBJECT_LIMIT_BREAKAWAY_OK).
        # Without this, EVERY descendant of the uvicorn child -- including
        # update.ps1, launched from within server.py's own /admin/update
        # handler -- is automatically pulled into this same job (Windows job
        # membership propagates to descendants by default; CREATE_NEW_PROCESS_GROUP
        # does not grant an exemption). update.ps1's own normal, intentional
        # Stop-Service call on ITS OWN service triggers this process's clean
        # shutdown -- and when this process's job handle closes at the end of
        # that shutdown, KILL_ON_JOB_CLOSE fires and kills every job member,
        # including update.ps1 itself, mid-execution, wherever it happens to
        # be. Live-confirmed 2026-08-26: two separate live update attempts
        # both died silently at the exact same point (right after "Stopping
        # EBMSLiveAgent for install swap...", before any further script
        # output), with no exception raised and no crash logged anywhere --
        # consistent with an external job-object kill, not a hang, and
        # explaining why the 86e2zbm5q rename-timeout fix (which can only
        # catch something that fails to return, not a process killed from
        # outside) had no effect either time. This flag alone only PERMITS
        # breakaway -- a child still has to explicitly request it via
        # CREATE_BREAKAWAY_FROM_JOB (see server.py's _launch_update_ps1()) to
        # actually escape, so any future descendant that doesn't ask stays
        # protected by KILL_ON_JOB_CLOSE exactly as before.
        #
        # 86e31dqg1: this binding happens AFTER Popen() above has already
        # started the child -- a narrow startup race exists between the
        # child starting and AssignProcessToJobObject() actually running,
        # during which this process dying would still orphan the child.
        # Mirrors a race Rename-DirectoryWithRetry (update.ps1) already
        # documents and accepts for the same reason: fully closing it
        # needs CREATE_SUSPENDED + ResumeThread instead of an
        # immediately-running Popen(), judged out of scope here (Low
        # severity -- the window is narrow, and 86e2z2u1b's protection
        # still covers the overwhelming majority of this process's
        # lifetime).
        try:
            self._job = win32job.CreateJobObject(None, "")
            job_info = win32job.QueryInformationJobObject(
                self._job, win32job.JobObjectExtendedLimitInformation)
            job_info['BasicLimitInformation']['LimitFlags'] |= (
                win32job.JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
                | win32job.JOB_OBJECT_LIMIT_BREAKAWAY_OK
            )
            win32job.SetInformationJobObject(
                self._job, win32job.JobObjectExtendedLimitInformation, job_info)
            hProcess = win32api.OpenProcess(
                win32con.PROCESS_SET_QUOTA | win32con.PROCESS_TERMINATE,
                False, self._process.pid)
            win32job.AssignProcessToJobObject(self._job, hProcess)
        except Exception as e:
            servicemanager.LogErrorMsg(
                f"EBMSLiveAgent: could not bind uvicorn child (PID "
                f"{self._process.pid}) to a kill-on-close job object ({e}) "
                f"-- continuing without this protection. If this service's "
                f"own process dies unexpectedly, the uvicorn child may be "
                f"orphaned and block subsequent restart attempts (86e2z2u1b)."
            )
            self._job = None

        # Poll for either a stop request or the child dying on its own.
        # WaitForSingleObject(..., INFINITE) here previously meant a crashed
        # uvicorn subprocess went unnoticed forever -- Windows still saw this
        # service as "Running" (this wrapper was fine), so its own recovery
        # actions (sc.exe failure) never fired. See Known_Issues.md / 86e2nuxz5
        # for the incident this protects against.
        crashed = False
        while True:
            rc = win32event.WaitForSingleObject(self._stop_event, 1000)
            if rc == win32event.WAIT_OBJECT_0:
                break  # SvcStop() was called -- clean shutdown requested
            if self._process.poll() is not None:
                crashed = True
                servicemanager.LogErrorMsg(
                    f"EBMSLiveAgent: uvicorn subprocess exited unexpectedly "
                    f"(exit code {self._process.returncode}). Stopping the "
                    f"service so Windows' recovery actions can restart it."
                )
                break

        if self._process.poll() is None:
            self._process.terminate()
        # 86e30uxzb: terminate()/the child's own exit closes its end of the stdout
        # pipe, which ends _drain_child_output()'s for-loop -- joining it before
        # closing the handler underneath it avoids racing a close() on the stream
        # it's still writing to. BUT this used to block up to 5+5=10s, where the
        # pre-rewrite shutdown (a bare log.close() on a plain file handle) was
        # near-instant -- and
        # update.ps1's real update path (Stop-Service, immediately followed by a
        # directory rename with its own tuned retry/timeout assumptions) is
        # live-confirmed to intermittently fail its post-swap /health
        # verification with this added latency in place, even though the same
        # build starts and runs correctly every time via a plain stop-copy-start
        # cycle that isn't racing a rename. Cut to a short bound instead: losing
        # the last couple log lines on an ordinary stop (a real event, but not a
        # customer-visible one) is a strictly better tradeoff than risking every
        # customer's actual update pipeline on a 10s shutdown window it was never
        # tuned to tolerate.
        try:
            self._process.wait(timeout=0.5)
        except subprocess.TimeoutExpired:
            pass
        _drain_thread.join(timeout=0.5)
        # 86e31dqfx follow-up: QueueListener.stop()'s stdlib implementation
        # (enqueue_sentinel() + an UNCONDITIONAL, unbounded self._thread.join())
        # has no timeout parameter anywhere in its public API. If the listener
        # thread is mid-record at the exact moment shutdown runs -- specifically
        # stuck inside RotatingFileHandler.emit()'s doRollover() on the same
        # stalled Windows file-rename this whole fix exists to keep off the
        # pipe-drain thread (86e2zbm5q) -- a bare listener.stop() would just move
        # that same unbounded hang from the drain thread onto the shutdown path
        # instead of actually eliminating it. Reimplemented here with a bound,
        # mirroring the two calls directly above (86e30uxzb's same discipline).
        # This reaches into QueueListener's private _thread attribute because
        # the stdlib genuinely offers no public bounded-stop alternative.
        listener.enqueue_sentinel()
        listener._thread.join(timeout=2.0)
        if listener._thread.is_alive():
            servicemanager.LogErrorMsg(
                "EBMSLiveAgent: log listener did not stop within 2s at shutdown "
                "(86e31dqfx) -- proceeding anyway; any log lines still queued may "
                "be lost, but the service must not hang here the way 86e2zbm5q's "
                "own file-rename stall would otherwise cause."
            )
        log.close()

        if crashed:
            # Report a non-clean stop (nonzero win32ExitCode) so the Service
            # Control Manager treats this as a failure and invokes the
            # configured recovery actions, rather than as a deliberate stop
            # (which it would not act on).
            self.ReportServiceStatus(win32service.SERVICE_STOPPED, win32ExitCode=1)


if __name__ == "__main__":
    if len(sys.argv) == 1:
        servicemanager.Initialize()
        servicemanager.PrepareToHostSingle(EBMSLiveService)
        servicemanager.StartServiceCtrlDispatcher()
    else:
        win32serviceutil.HandleCommandLine(EBMSLiveService)
