"""Drafts and the write audit log: storage for v3 Phase 4 (ClickUp 86e3q4zc9, PO 86e3q4ze6).

Contract: docs/design/v3-drafts-contract.md. Spec: docs/design/intramind-redesign-spec.md
sections 5 (Phase 4), 8.9, 8.10 and 11.

Pure module, same rules as pins_store.py: no FastAPI, no psycopg, no EBMS connection, and it
does NOT import server.py. It owns IntraMind's own drafts file (SQLite, never EBMS's Postgres).

STORAGE
  File: EBMS_LIVE_DRAFTS_DB if set, else C:\\ProgramData\\IntraMind\\drafts.sqlite3 when that
  directory exists (production), else <this file's dir>/drafts.sqlite3 (dev only). One file holds
  both tables (drafts + audit) so a save's status change and its audit row commit in ONE
  transaction; a separate audit file could record a save that never happened, or miss one.
  One connection per call, WAL, 5 s busy timeout, PRAGMA user_version migrations.

AUDIT IS APPEND-ONLY
  This module never issues UPDATE or DELETE against `audit` (tests/test_drafts_store.py greps
  for it), and the schema adds BEFORE UPDATE / BEFORE DELETE triggers that abort, so even a
  hand-written statement through this file can't rewrite history.

USERNAMES / SCHEMAS
  username .strip().upper() (same as server.py login() and pins_store); schema whitespace-trimmed,
  compared exactly. Every draft read/write is scoped to (username, schema): someone else's draft
  is indistinguishable from a missing one (the routes answer 404 for both).

STATUS MACHINE (optimistic: every transition checks the current status inside BEGIN IMMEDIATE)
  draft  --update-->  draft            (also failed --update--> draft)
  draft|failed --claim_save--> saving --mark_saved--> saved --mark_undone--> draft
                                      --mark_failed--> failed
  draft|failed --discard--> discarded --restore--> draft
  draft|failed|reading --clear_drafts--> discarded      (one transaction; 'saving' never cleared)
  saved --clear_drafts(include_saved=True)--> discarded (simulated-EBMS reset only; keeps the EBMS fields)
  saving --fail_interrupted_saves (startup)--> failed   (idempotency key kept; imports: fail_interrupted_imports)

IDEMPOTENCY (spec 11.5)
  The browser sends an idempotency key with Save. Every key ever used is kept in `idem_keys`
  (key -> draft), so a replayed request (double-click, network retry, a stale tab after Undo)
  never starts a second save. drafts.idempotency_key is the key sent to EBMS for the CURRENT
  save cycle (it becomes EXTERNALID on the EBMS document): it is set by the first claim, kept
  across failed retries (so a retry after a timeout finds the document the timed-out call may
  have created instead of creating another one), and cleared by Undo (the next save is a new
  document). It is UNIQUE, nullable.

UPLOADED DOCUMENTS (vendor bills, ClickUp 86e3q4zeb)
  The original bytes of an uploaded bill (PDF or photo) live in the `documents` table of this
  same file, one row per draft, keyed by draft id and carrying the owner (username, schema):
  get_document() only returns a row to its owner, like every draft read. They are kept for
  DOCUMENT_RETENTION_DAYS (30) from upload, whatever the draft's status, then purged by
  purge_documents() (run on every upload). The draft and its card survive the purge; only the
  "View PDF" bytes go. Documents are not audit rows: purging them never touches `audit`.

REVIEW LIST AND BACKGROUND READING (86e3q4ze8)
  review_state: 'needs_review' for drafts made from an uploaded document or plain text,
  'reviewed' once opened, edited or saved. A document dropped in the background first lands as
  a placeholder (type 'doc', status 'reading', its file stored); the reader then fills it
  (fill_draft -> status 'draft') or fails it (fail_reading -> 'failed' with a human `detail`).
  Reading jobs live in server memory, so at startup fail_interrupted() turns any leftover
  'reading' draft into a failed one. Open drafts list needs_review / reading first, then newest.

DUPLICATES AND CLEARING (batch 2)
  find_bill_conflict(): another user's (or the same user's) saved/saving bill for the same vendor
  and invoice number in this dataset; any other saving draft counts, except a stale one
  (STALE_SAVING_SECONDS); startup fail_interrupted_saves() fails drafts left saving by a restart.
  find_open_by_sha(): this user's open draft with an identical upload. clear_drafts(): discards a user's Review list (and
  optionally saved drafts) in one transaction, deleting their stored uploads; audit rows are only
  added, never removed; 'saving' drafts are never cleared.
"""

from __future__ import annotations

import json
import os
import sqlite3
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

SCHEMA_VERSION = 5  # 2: documents table (86e3q4zeb); 3: review_state + detail (86e3q4ze8); 4: user_settings; 5: company_settings
BUSY_TIMEOUT_SECONDS = 5.0
# A save stuck in 'saving' this long (process killed mid-call) may be claimed again. The retry
# reuses the same EBMS key, so the client's EXTERNALID lookup finds anything the dead call made.
# It must stay well above the client's worst case for one create (ebms_api.max_create_seconds(),
# 389 s with a 55 s timeout and 2 GET retries; httpx applies the timeout per phase, so a single
# request can run longer), or a second claim could POST while the first call is still in flight
# (86e3q4zc9 review #4). tests/test_drafts_store.py pins STALE >= 3 x that worst case. A sales
# order save can also create up to MAX_NEW_RECORDS new customers/parts first (86e3q4ze8), one
# create each, so the window covers (1 + MAX_NEW_RECORDS) creates with the same 3x margin.
MAX_NEW_RECORDS = 5
STALE_SAVING_SECONDS = 7200
MAX_DRAFT_ID = 2 ** 63 - 1

STATUSES = ("draft", "saving", "saved", "discarded", "failed", "reading")
OPEN_STATUSES = ("draft", "failed")
LIST_STATUSES = ("draft", "failed", "reading")
TYPES = ("po", "bill", "so", "doc", "import")   # "doc": a background upload not read yet (or unreadable);
                                                # "import": a part import (86e3q4zek)
REVIEW_STATES = ("needs_review", "reviewed")
INTERRUPTED_DETAIL = "Reading was interrupted. Drop the file again."
DOCUMENT_RETENTION_DAYS = 30
IDEMPOTENCY_KEY_MAX = 64
AUDIT_ACTIONS = ("created", "updated", "discarded", "restored", "save_failed", "saved",
                 "undo_failed", "undone", "attached", "attach_failed", "retyped", "read_failed",
                 "record_created", "record_deleted", "record_delete_failed", "record_kept",
                 "part_updated", "part_restored",   # part import (86e3q4zek)
                 "setting_changed")

_DB_PATHS = [
    Path(r"C:\ProgramData\IntraMind\drafts.sqlite3"),
    Path(__file__).parent / "drafts.sqlite3",
]

_init_lock = threading.Lock()


class DraftNotFound(Exception):
    """No such draft for this user and dataset (or it isn't theirs)."""


class StatusConflict(Exception):
    """The draft is not in a status that allows this step. The message is safe to show."""

    def __init__(self, message: str, draft: dict | None = None):
        super().__init__(message)
        self.draft = draft


class IdempotencyConflict(Exception):
    """The idempotency key was already used for a different draft or user."""


# ---------------------------------------------------------------------------
# Paths, connections, schema
# ---------------------------------------------------------------------------

def db_path(override: str | os.PathLike | None = None) -> Path:
    """Explicit argument > EBMS_LIVE_DRAFTS_DB > ProgramData (if the dir exists) > next to this file."""
    if override:
        return Path(override)
    env = os.getenv("EBMS_LIVE_DRAFTS_DB")
    if env:
        return Path(env)
    # os.name guard: on Linux/macOS a backslash path has no separators, so its parent is "."
    # (same trap pins_store.db_path documents).
    for p in _DB_PATHS if os.name == "nt" else _DB_PATHS[1:]:
        try:
            if p.parent.exists():
                return p
        except OSError:
            pass
    return _DB_PATHS[-1]


def _ensure_schema(conn: sqlite3.Connection) -> None:
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version >= SCHEMA_VERSION:
        return
    conn.execute("BEGIN IMMEDIATE")
    try:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS drafts (
                   id INTEGER PRIMARY KEY,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   type TEXT NOT NULL,
                   status TEXT NOT NULL,
                   payload TEXT NOT NULL,
                   card TEXT,
                   idempotency_key TEXT UNIQUE,
                   cycle INTEGER NOT NULL DEFAULT 0,
                   ebms_doc_number TEXT,
                   ebms_doc_id TEXT,
                   saved_by TEXT,
                   saved_at TEXT,
                   created_at TEXT NOT NULL,
                   updated_at TEXT NOT NULL
               )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS drafts_owner ON drafts (username, schema, status)")
        conn.execute(
            """CREATE TABLE IF NOT EXISTS idem_keys (
                   key TEXT PRIMARY KEY,
                   draft_id INTEGER NOT NULL,
                   cycle INTEGER NOT NULL,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   created_at TEXT NOT NULL
               )"""
        )
        conn.execute(
            """CREATE TABLE IF NOT EXISTS audit (
                   id INTEGER PRIMARY KEY,
                   at TEXT NOT NULL,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   draft_id INTEGER,
                   action TEXT NOT NULL,
                   type TEXT,
                   doc_number TEXT,
                   before TEXT,
                   after TEXT,
                   request_id TEXT,
                   response_id TEXT,
                   api_user TEXT,
                   detail TEXT
               )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS audit_schema ON audit (schema, id)")
        # v2 (86e3q4zeb): an uploaded bill's original bytes, one per draft. Every statement
        # above is IF NOT EXISTS, so a v1 file upgrades by running this whole block again.
        conn.execute(
            """CREATE TABLE IF NOT EXISTS documents (
                   draft_id INTEGER PRIMARY KEY,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   filename TEXT NOT NULL,
                   content_type TEXT NOT NULL,
                   size INTEGER NOT NULL,
                   sha256 TEXT NOT NULL,
                   pages INTEGER,
                   data BLOB NOT NULL,
                   created_at TEXT NOT NULL
               )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS documents_created ON documents (created_at)")
        # v3 (86e3q4ze8): review list. ADD COLUMN has no IF NOT EXISTS, so check first.
        cols = {r[1] for r in conn.execute("PRAGMA table_info(drafts)").fetchall()}
        if "review_state" not in cols:
            conn.execute("ALTER TABLE drafts ADD COLUMN review_state TEXT NOT NULL DEFAULT 'reviewed'")
        if "detail" not in cols:
            conn.execute("ALTER TABLE drafts ADD COLUMN detail TEXT")
        # v4: per-user data-entry settings (Settings > Data entry)
        conn.execute(
            """CREATE TABLE IF NOT EXISTS user_settings (
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   key TEXT NOT NULL,
                   value TEXT NOT NULL,
                   updated_at TEXT NOT NULL,
                   PRIMARY KEY (username, schema, key)
               )"""
        )
        # v5: company-wide settings per dataset (Settings > Company, EBMS Administrators)
        conn.execute(
            """CREATE TABLE IF NOT EXISTS company_settings (
                   schema TEXT NOT NULL,
                   key TEXT NOT NULL,
                   value TEXT NOT NULL,
                   updated_at TEXT NOT NULL,
                   updated_by TEXT NOT NULL,
                   PRIMARY KEY (schema, key)
               )"""
        )
        # Append-only, enforced by the database too (spec 11.9).
        conn.execute(
            "CREATE TRIGGER IF NOT EXISTS audit_no_update BEFORE UPDATE ON audit "
            "BEGIN SELECT RAISE(ABORT, 'audit is append-only'); END"
        )
        conn.execute(
            "CREATE TRIGGER IF NOT EXISTS audit_no_delete BEFORE DELETE ON audit "
            "BEGIN SELECT RAISE(ABORT, 'audit is append-only'); END"
        )
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise


def _connect(path: str | os.PathLike | None = None) -> sqlite3.Connection:
    p = db_path(path)
    conn = sqlite3.connect(str(p), timeout=BUSY_TIMEOUT_SECONDS, isolation_level=None)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute(f"PRAGMA busy_timeout = {int(BUSY_TIMEOUT_SECONDS * 1000)}")
        if conn.execute("PRAGMA user_version").fetchone()[0] < SCHEMA_VERSION:
            with _init_lock:
                conn.execute("PRAGMA journal_mode = WAL")
                _ensure_schema(conn)
    except BaseException:
        conn.close()
        raise
    return conn


def _norm_user(username: str) -> str:
    return (username or "").strip().upper()


def _norm_schema(schema: str) -> str:
    return (schema or "").strip()


def _owner(username: str, schema: str) -> tuple[str, str]:
    u, s = _norm_user(username), _norm_schema(schema)
    if not u or not s:
        raise ValueError("A draft needs a signed-in user and a dataset.")
    return u, s


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")


def _dumps(value) -> str | None:
    if value is None:
        return None
    return json.dumps(value, default=str, sort_keys=True)


def _row(row: sqlite3.Row | None) -> dict | None:
    if row is None:
        return None
    d = dict(row)
    d["payload"] = json.loads(d["payload"]) if d.get("payload") else {}
    d["card"] = json.loads(d["card"]) if d.get("card") else None
    return d


def _pid(draft_id) -> int:
    try:
        pid = int(draft_id)
    except (TypeError, ValueError, OverflowError):
        raise DraftNotFound()
    if not 1 <= pid <= MAX_DRAFT_ID:  # SQLite INTEGER range (review #8: OverflowError -> 503)
        raise DraftNotFound()
    return pid


def _load(conn, u: str, s: str, draft_id: int) -> dict:
    row = conn.execute(
        "SELECT * FROM drafts WHERE id = ? AND username = ? AND schema = ?", (draft_id, u, s)
    ).fetchone()
    if row is None:
        raise DraftNotFound()
    return _row(row)


def _audit(conn, *, username: str, schema: str, draft_id, action: str, type_: str | None,
           doc_number=None, before=None, after=None, request_id=None, response_id=None,
           detail=None, api_user=None) -> int:
    """api_user: the EBMS username the API call ran as (each call runs as the signed-in user,
    owner decision 2026-10-14). NEVER a password: only the name is passed in."""
    if action not in AUDIT_ACTIONS:
        raise ValueError(f"unknown audit action {action!r}")
    cur = conn.execute(
        "INSERT INTO audit (at, username, schema, draft_id, action, type, doc_number, before,"
        " after, request_id, response_id, api_user, detail) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (_now(), username, schema, draft_id, action, type_,
         None if doc_number is None else str(doc_number), _dumps(before), _dumps(after),
         None if request_id is None else str(request_id)[:200],
         None if response_id is None else str(response_id)[:200],
         None if api_user is None else str(api_user)[:100],
         None if detail is None else str(detail)[:2000]),
    )
    return cur.lastrowid


class _Tx:
    """BEGIN IMMEDIATE ... COMMIT/ROLLBACK on a fresh connection."""

    def __init__(self, path):
        self.path = path

    def __enter__(self):
        self.conn = _connect(self.path)
        self.conn.execute("BEGIN IMMEDIATE")
        return self.conn

    def __exit__(self, exc_type, exc, tb):
        try:
            self.conn.execute("ROLLBACK" if exc_type else "COMMIT")
        finally:
            self.conn.close()
        return False


# ---------------------------------------------------------------------------
# Drafts
# ---------------------------------------------------------------------------

def _store_document(conn, draft_id: int, u: str, s: str, document: dict, now: str) -> None:
    data = document["data"]
    if not isinstance(data, (bytes, bytearray)) or not data:
        raise ValueError("The document is empty.")
    conn.execute(
        "INSERT INTO documents (draft_id, username, schema, filename, content_type, size, sha256,"
        " pages, data, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (draft_id, u, s, str(document.get("filename") or "document")[:200],
         str(document["content_type"]), len(data), str(document.get("sha256") or ""),
         document.get("pages"), sqlite3.Binary(bytes(data)), now),
    )


def create_draft(username: str, schema: str, type_: str, payload: dict, card: dict | None = None,
                 *, audit_after=None, document: dict | None = None, review_state: str = "reviewed",
                 path=None) -> dict:
    """Insert a new draft (status draft) and its 'created' audit row in one transaction.
    document (bills, orders): {filename, content_type, data (bytes), sha256, pages} stored with it.
    review_state: 'needs_review' for drafts made from a document or plain text."""
    u, s = _owner(username, schema)
    if type_ not in TYPES or type_ == "doc":
        raise ValueError("Unsupported document type.")
    if review_state not in REVIEW_STATES:
        raise ValueError("Unknown review state.")
    now = _now()
    with _Tx(path) as conn:
        cur = conn.execute(
            "INSERT INTO drafts (username, schema, type, status, payload, card, review_state, created_at, updated_at)"
            " VALUES (?, ?, ?, 'draft', ?, ?, ?, ?, ?)",
            (u, s, type_, _dumps(payload or {}), _dumps(card), review_state, now, now),
        )
        draft_id = cur.lastrowid
        if document is not None:
            _store_document(conn, draft_id, u, s, document, now)
        _audit(conn, username=u, schema=s, draft_id=draft_id, action="created", type_=type_,
               after=audit_after)
        return _load(conn, u, s, draft_id)


def create_placeholder(username: str, schema: str, *, payload: dict, card: dict | None,
                       document: dict, path=None) -> dict:
    """A background upload not read yet: type 'doc', status 'reading', needs_review, with its
    file stored. No audit row until it is read (fill_draft) or fails (fail_reading)."""
    u, s = _owner(username, schema)
    now = _now()
    with _Tx(path) as conn:
        cur = conn.execute(
            "INSERT INTO drafts (username, schema, type, status, payload, card, review_state, created_at, updated_at)"
            " VALUES (?, ?, 'doc', 'reading', ?, ?, 'needs_review', ?, ?)",
            (u, s, _dumps(payload or {}), _dumps(card), now, now),
        )
        _store_document(conn, cur.lastrowid, u, s, document, now)
        return _load(conn, u, s, cur.lastrowid)


def fill_draft(username: str, schema: str, draft_id, type_: str, payload: dict, card: dict | None, *,
               audit_after=None, path=None) -> dict:
    """reading -> draft once the document has been read, with the 'created' audit row."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    if type_ not in TYPES or type_ == "doc":
        raise ValueError("Unsupported document type.")
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "reading":
            raise StatusConflict("This document is no longer being read.", d)
        conn.execute("UPDATE drafts SET type = ?, status = 'draft', payload = ?, card = ?, detail = NULL,"
                     " updated_at = ? WHERE id = ?", (type_, _dumps(payload or {}), _dumps(card), _now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="created", type_=type_, after=audit_after)
        return _load(conn, u, s, pid)


def fail_reading(username: str, schema: str, draft_id, detail: str, *, path=None) -> dict:
    """reading -> failed with a human `detail` (shown in the Review list)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "reading":
            return d
        conn.execute("UPDATE drafts SET status = 'failed', detail = ?, updated_at = ? WHERE id = ?",
                     (str(detail)[:500], _now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="read_failed", type_=d["type"],
               detail=str(detail)[:500])
        return _load(conn, u, s, pid)


def fail_interrupted(*, path=None) -> int:
    """Startup: reading jobs are in memory, so any draft still 'reading' was interrupted."""
    with _Tx(path) as conn:
        rows = conn.execute("SELECT id, username, schema, type FROM drafts WHERE status = 'reading'").fetchall()
        for r in rows:
            conn.execute("UPDATE drafts SET status = 'failed', detail = ?, updated_at = ? WHERE id = ?",
                         (INTERRUPTED_DETAIL, _now(), r["id"]))
            _audit(conn, username=r["username"], schema=r["schema"], draft_id=r["id"], action="read_failed",
                   type_=r["type"], detail=INTERRUPTED_DETAIL)
        return len(rows)


IMPORT_INTERRUPTED_DETAIL = ("IntraMind restarted while this import was running. The parts already done are "
                             "kept; press Save to do the rest.")


def fail_interrupted_imports(*, path=None) -> int:
    """Startup: an import save runs in a background thread, so an import still 'saving' was
    interrupted. Its progress is in the payload (import_results); a new Save does the rest."""
    with _Tx(path) as conn:
        rows = conn.execute("SELECT id, username, schema, type FROM drafts WHERE status = 'saving' AND type = 'import'"
                            ).fetchall()
        for r in rows:
            conn.execute("UPDATE drafts SET status = 'failed', detail = ?, updated_at = ? WHERE id = ?",
                         (IMPORT_INTERRUPTED_DETAIL, _now(), r["id"]))
            _audit(conn, username=r["username"], schema=r["schema"], draft_id=r["id"], action="save_failed",
                   type_=r["type"], detail=IMPORT_INTERRUPTED_DETAIL)
        return len(rows)


SAVE_INTERRUPTED_DETAIL = ("IntraMind restarted while this was being saved. Check EBMS or Activity to see "
                           "whether it went through. If not, press Save to try again.")


def fail_interrupted_saves(*, path=None) -> int:
    """Startup: a PO, sales order or bill save runs inside a request, so any such draft still
    'saving' when the service starts was cut off. It becomes 'failed' (visible in Review) and keeps
    its idempotency key, so Save again goes through claim_save, reuses that key and EBMS finds
    the document if the cut-off call did create it. Imports are handled by
    fail_interrupted_imports. Returns how many were changed."""
    with _Tx(path) as conn:
        rows = conn.execute("SELECT id, username, schema, type FROM drafts WHERE status = 'saving' AND type != 'import'"
                            ).fetchall()
        for r in rows:
            conn.execute("UPDATE drafts SET status = 'failed', detail = ?, updated_at = ? WHERE id = ?",
                         (SAVE_INTERRUPTED_DETAIL, _now(), r["id"]))
            _audit(conn, username=r["username"], schema=r["schema"], draft_id=r["id"], action="save_failed",
                   type_=r["type"], detail=SAVE_INTERRUPTED_DETAIL)
        return len(rows)


def set_review_state(username: str, schema: str, draft_id, state: str, *, path=None) -> dict:
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    if state not in REVIEW_STATES:
        raise ValueError("Unknown review state.")
    with _Tx(path) as conn:
        _load(conn, u, s, pid)
        conn.execute("UPDATE drafts SET review_state = ? WHERE id = ?", (state, pid))
        return _load(conn, u, s, pid)


def retype_draft(username: str, schema: str, draft_id, type_: str, payload: dict, card: dict | None, *,
                 before=None, after=None, path=None) -> dict:
    """An unsaved draft from a document, re-read as the other type (same id and document)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    if type_ not in TYPES or type_ == "doc":
        raise ValueError("Unsupported document type.")
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] not in OPEN_STATUSES:
            raise StatusConflict(_status_message(d["status"], "changed"), d)
        conn.execute("UPDATE drafts SET type = ?, status = 'draft', payload = ?, card = ?, detail = NULL,"
                     " idempotency_key = NULL, cycle = cycle + 1, updated_at = ? WHERE id = ?",
                     (type_, _dumps(payload or {}), _dumps(card), _now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="retyped", type_=type_,
               before=before, after=after)
        return _load(conn, u, s, pid)


def get_draft(username: str, schema: str, draft_id, *, path=None) -> dict:
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    conn = _connect(path)
    try:
        return _load(conn, u, s, pid)
    finally:
        conn.close()


def list_drafts(username: str, schema: str, statuses=LIST_STATUSES, *, path=None) -> list[dict]:
    """This user's drafts for this dataset in the given statuses: needs_review and reading
    first, then newest first."""
    u, s = _owner(username, schema)
    statuses = tuple(statuses)
    marks = ",".join("?" for _ in statuses)
    conn = _connect(path)
    try:
        rows = conn.execute(
            f"SELECT * FROM drafts WHERE username = ? AND schema = ? AND status IN ({marks})"
            " ORDER BY CASE WHEN status = 'reading' OR review_state = 'needs_review' THEN 0 ELSE 1 END,"
            " updated_at DESC, id DESC",
            (u, s, *statuses),
        ).fetchall()
    finally:
        conn.close()
    return [_row(r) for r in rows]


def update_draft(username: str, schema: str, draft_id, payload: dict, card: dict | None, *,
                 audit_before=None, audit_after=None, rotate_key: bool = False, path=None) -> dict:
    """Replace payload + card. Only from draft|failed; a failed draft goes back to draft.
    rotate_key=True clears the cycle's EBMS key and starts a new cycle: the caller checked
    EBMS has no document for the old key, so the edited lines can never be answered by a
    document an earlier attempt made with the old lines (review #6)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] not in OPEN_STATUSES:
            raise StatusConflict(_status_message(d["status"], "edited"), d)
        if rotate_key:
            conn.execute("UPDATE drafts SET idempotency_key = NULL, cycle = cycle + 1 WHERE id = ?", (pid,))
        conn.execute(
            "UPDATE drafts SET payload = ?, card = ?, status = 'draft', review_state = 'reviewed', detail = NULL,"
            " updated_at = ? WHERE id = ?",
            (_dumps(payload or {}), _dumps(card), _now(), pid),
        )
        _audit(conn, username=u, schema=s, draft_id=pid, action="updated", type_=d["type"],
               before=audit_before, after=audit_after)
        return _load(conn, u, s, pid)


def set_card(username: str, schema: str, draft_id, card: dict, *, path=None) -> dict:
    """Store the last rendered card without changing status (no audit: nothing changed)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        _load(conn, u, s, pid)
        conn.execute("UPDATE drafts SET card = ? WHERE id = ?", (_dumps(card), pid))
        return _load(conn, u, s, pid)


def set_payload(username: str, schema: str, draft_id, payload: dict, *, path=None) -> dict:
    """Replace the payload of a draft that is being saved (status 'saving'), without changing
    status. Match to PO stores the PO's "before" snapshot here BEFORE it PATCHes EBMS, so undo
    and a retry after a timeout can always find it."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saving":
            raise StatusConflict("This draft is no longer being saved.", d)
        conn.execute("UPDATE drafts SET payload = ?, updated_at = ? WHERE id = ?", (_dumps(payload or {}), _now(), pid))
        return _load(conn, u, s, pid)


def set_saved_card(username: str, schema: str, draft_id, card: dict, payload: dict, *, path=None) -> dict:
    """A saved draft keeps status 'saved' with a new card and payload: a part import that was
    only partly undone (the payload says what is still in EBMS; Undo again tries the rest)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saved":
            raise StatusConflict("This draft is no longer saved.", d)
        conn.execute("UPDATE drafts SET card = ?, payload = ?, updated_at = ? WHERE id = ?",
                     (_dumps(card), _dumps(payload or {}), _now(), pid))
        return _load(conn, u, s, pid)


def discard_draft(username: str, schema: str, draft_id, *, summary=None, path=None) -> dict:
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] == "discarded":
            return d
        if d["status"] not in OPEN_STATUSES:
            raise StatusConflict(_status_message(d["status"], "discarded"), d)
        conn.execute("UPDATE drafts SET status = 'discarded', updated_at = ? WHERE id = ?", (_now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="discarded", type_=d["type"],
               before={"status": d["status"], **(summary or {})},
               after={"status": "discarded", **(summary or {})})
        return _load(conn, u, s, pid)


def restore_draft(username: str, schema: str, draft_id, *, summary=None, path=None) -> dict:
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] in OPEN_STATUSES:
            return d
        if d["status"] != "discarded":
            raise StatusConflict(_status_message(d["status"], "restored"), d)
        conn.execute("UPDATE drafts SET status = 'draft', updated_at = ? WHERE id = ?", (_now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="restored", type_=d["type"],
               before={"status": "discarded", **(summary or {})},
               after={"status": "draft", **(summary or {})})
        return _load(conn, u, s, pid)


def _key(value) -> str:
    return str(value or "").strip().upper()


def find_bill_conflict(schema: str, vendor_id: str, invoice: str, exclude_id, *, path=None) -> dict | None:
    """The first bill draft of ANY user in this dataset that is saved or saving for the same
    vendor and invoice number (trimmed, upper-cased), other than exclude_id. Any other saving
    draft counts, whatever its id: two saves that start at the same instant both refuse (no bill
    is made and each can be retried), which is safer than letting the older one through while the
    newer one is already creating. A saving draft that is stale (STALE_SAVING_SECONDS, the same
    rule claim_save uses) is ignored: its save died with a restart or crash. A saved draft never
    goes stale. Returns {id, status, doc_number} or None. Payload keys (drafts_bill.py): "vendor" is the
    resolved vendor ID, "new_vendor"["id"] a vendor being created (used only while "vendor" is
    empty), "invoice_number" the invoice number. An empty vendor or invoice never matches."""
    s = _norm_schema(schema)
    v, inv = _key(vendor_id), _key(invoice)
    if not s or not v or not inv:
        return None
    try:
        ex = int(exclude_id) if exclude_id is not None else None
    except (TypeError, ValueError):
        ex = None
    conn = _connect(path)
    try:
        rows = conn.execute(
            "SELECT id, status, payload, ebms_doc_number, updated_at FROM drafts WHERE schema = ? AND type = 'bill'"
            " AND status IN ('saved', 'saving') ORDER BY id", (s,)).fetchall()
    finally:
        conn.close()
    for r in rows:
        if ex is not None and r["id"] == ex:
            continue
        if r["status"] == "saving" and _stale(r["updated_at"]):
            continue
        try:
            p = json.loads(r["payload"]) if r["payload"] else {}
        except ValueError:
            continue
        if not isinstance(p, dict):
            continue
        nv = p.get("new_vendor")
        pv = _key(p.get("vendor")) or _key(nv.get("id") if isinstance(nv, dict) else None)
        if pv == v and _key(p.get("invoice_number")) == inv:
            return {"id": r["id"], "status": r["status"], "doc_number": r["ebms_doc_number"]}
    return None


def find_open_by_sha(username: str, schema: str, sha256: str, exclude_id=None, *, path=None) -> dict | None:
    """This user's draft (same dataset) whose stored upload has this SHA-256 and whose status is
    draft, failed, reading or saving. Returns {id, status} or None."""
    u, s = _owner(username, schema)
    sha = str(sha256 or "").strip()
    if not sha:
        return None
    try:
        ex = int(exclude_id) if exclude_id is not None else None
    except (TypeError, ValueError):
        ex = None
    conn = _connect(path)
    try:
        row = conn.execute(
            "SELECT d.id AS id, d.status AS status FROM drafts d JOIN documents x ON x.draft_id = d.id"
            " WHERE d.username = ? AND d.schema = ? AND x.sha256 = ?"
            " AND d.status IN ('draft', 'failed', 'reading', 'saving') AND d.id != ?"
            " ORDER BY d.id LIMIT 1", (u, s, sha, -1 if ex is None else ex)).fetchone()
    finally:
        conn.close()
    return None if row is None else {"id": row["id"], "status": row["status"]}


_ACTIVITY_KEYS = ("vendor", "vendor_name", "customer", "customer_name", "po", "invoice", "parts", "total")


def _activity_summary_of(card_json) -> dict:
    """The vendor / invoice / total keys of a stored card's _summary, for audit rows (the same
    keys server._activity_brief puts on a single discard, so Activity reads the same)."""
    try:
        card = json.loads(card_json) if card_json else {}
        sm = card.get("_summary") if isinstance(card, dict) else None
    except ValueError:
        return {}
    if not isinstance(sm, dict):
        return {}
    return {k: sm.get(k) for k in _ACTIVITY_KEYS if k in sm}


def clear_drafts(username: str, schema: str, *, include_saved: bool = False, path=None) -> int:
    """Discard every draft of this user in this dataset that is in the Review list (draft,
    failed, reading), plus saved ones when include_saved, in ONE transaction: soft discard, one
    'discarded' audit row each, and the stored upload deleted. 'saving' drafts and other users'
    drafts are never touched. Not touching 'saving' is deliberate (a live save must not be killed);
    a saving row left by a restart is failed at startup (fail_interrupted_saves). include_saved is
    for a simulated-EBMS reset only: the discarded row keeps its EBMS fields. Returns how many were cleared."""
    u, s = _owner(username, schema)
    statuses = LIST_STATUSES + (("saved",) if include_saved else ())
    marks = ",".join("?" for _ in statuses)
    with _Tx(path) as conn:
        rows = conn.execute(
            f"SELECT id, type, status, card FROM drafts WHERE username = ? AND schema = ? AND status IN ({marks})"
            " ORDER BY id", (u, s, *statuses)).fetchall()
        now = _now()
        for r in rows:
            conn.execute("UPDATE drafts SET status = 'discarded', updated_at = ? WHERE id = ?", (now, r["id"]))
            conn.execute("DELETE FROM documents WHERE draft_id = ? AND username = ? AND schema = ?",
                         (r["id"], u, s))
            _audit(conn, username=u, schema=s, draft_id=r["id"], action="discarded", type_=r["type"],
                   before={"status": r["status"], **_activity_summary_of(r["card"])},
                   after={"status": "discarded", **_activity_summary_of(r["card"])})
        return len(rows)


def _status_message(status: str, verb: str) -> str:
    return {
        "saving": "This draft is being saved right now.",
        "saved": f"This draft is already saved to EBMS, so it can't be {verb}. Undo it first.",
        "discarded": f"This draft was discarded. Restore it before it can be {verb}.",
    }.get(status, f"This draft can't be {verb} right now.")


# ---------------------------------------------------------------------------
# Save: idempotency claim, then saved/failed
# ---------------------------------------------------------------------------

def _stale(updated_at: str) -> bool:
    try:
        t = datetime.fromisoformat(updated_at)
    except (TypeError, ValueError):
        return True
    return datetime.now(timezone.utc) - t > timedelta(seconds=STALE_SAVING_SECONDS)


def claim_save(username: str, schema: str, draft_id, key: str, *, path=None) -> tuple[str, dict]:
    """Claim the right to call EBMS for this draft with this browser key, atomically.

    Returns (outcome, draft):
      "claimed"      status is now 'saving'; the caller must call EBMS with
                     draft["idempotency_key"] (the cycle's EBMS key, which may be an earlier
                     key when retrying a failed save) and then mark_saved / mark_failed.
      "in_progress"  another request is saving this draft right now; poll, don't call EBMS.
      "replay"       nothing to do: this key was already used for this draft, or the draft is
                     already saved. Return the current card.
    Raises DraftNotFound, IdempotencyConflict (key used for a different draft/user),
    StatusConflict (discarded), ValueError (bad key)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    key = (key or "").strip() if isinstance(key, str) else ""
    if not key or len(key) > IDEMPOTENCY_KEY_MAX or not all(c.isalnum() or c in "-_" for c in key):
        raise ValueError("Save needs a valid idempotency key.")
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        seen = conn.execute("SELECT * FROM idem_keys WHERE key = ?", (key,)).fetchone()
        if seen is not None and (seen["draft_id"] != pid or seen["username"] != u or seen["schema"] != s):
            raise IdempotencyConflict()

        def remember():
            if seen is None:
                conn.execute("INSERT INTO idem_keys (key, draft_id, cycle, username, schema, created_at)"
                             " VALUES (?, ?, ?, ?, ?, ?)", (key, pid, d["cycle"], u, s, _now()))

        status = d["status"]
        if status == "saving" and not _stale(d["updated_at"]):
            remember()
            return "in_progress", d
        if status == "saved":
            remember()
            return "replay", d
        if status == "discarded":
            raise StatusConflict(_status_message(status, "saved"), d)
        if seen is not None and status == "draft" and seen["cycle"] != d["cycle"]:
            # A key from an earlier cycle (a stale request from before an Undo or an edit that
            # rotated the EBMS key): never a second document.
            return "replay", d
        # status draft (new key, or a key of THIS cycle whose save was released by a block/503
        # check: review #7) | failed (new or same key) | stale saving
        remember()
        ebms_key = d["idempotency_key"] or key
        conn.execute(
            "UPDATE drafts SET status = 'saving', idempotency_key = ?, updated_at = ? WHERE id = ?",
            (ebms_key, _now(), pid),
        )
        return "claimed", _load(conn, u, s, pid)


def mark_saved(username: str, schema: str, draft_id, *, doc_number: str, doc_id: str | None,
               card: dict, payload: dict | None = None, before=None, after=None,
               request_id=None, response_id=None, api_user=None, path=None) -> dict:
    """saving -> saved, with the 'saved' audit row, in one transaction."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saving":
            raise StatusConflict("This draft is no longer being saved.", d)
        now = _now()
        conn.execute(
            "UPDATE drafts SET status = 'saved', ebms_doc_number = ?, ebms_doc_id = ?, card = ?,"
            " payload = ?, saved_by = ?, saved_at = ?, review_state = 'reviewed', updated_at = ? WHERE id = ?",
            (str(doc_number), doc_id, _dumps(card), _dumps(payload if payload is not None else d["payload"]),
             u, now, now, pid),
        )
        _audit(conn, username=u, schema=s, draft_id=pid, action="saved", type_=d["type"],
               doc_number=doc_number, before=before, after=after, request_id=request_id,
               response_id=response_id, api_user=api_user)
        return _load(conn, u, s, pid)


def recover_saved(username: str, schema: str, draft_id, *, doc_number: str, doc_id: str | None,
                  card: dict | None, after=None, detail=None, api_user=None, path=None) -> dict:
    """failed -> saved: an earlier, timed-out save did create the document in EBMS (found by
    the cycle's EBMS key). Recorded as a 'saved' audit row with a note (review #6)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "failed":
            raise StatusConflict("This draft is no longer waiting on a failed save.", d)
        now = _now()
        conn.execute(
            "UPDATE drafts SET status = 'saved', ebms_doc_number = ?, ebms_doc_id = ?, card = COALESCE(?, card),"
            " saved_by = ?, saved_at = ?, updated_at = ? WHERE id = ?",
            (str(doc_number), doc_id, _dumps(card), u, now, now, pid),
        )
        _audit(conn, username=u, schema=s, draft_id=pid, action="saved", type_=d["type"],
               doc_number=doc_number, before=None, after=after, detail=detail, api_user=api_user)
        return _load(conn, u, s, pid)


def mark_failed(username: str, schema: str, draft_id, *, card: dict | None, detail: str,
                before=None, request_id=None, response_id=None, api_user=None, payload: dict | None = None,
                path=None) -> dict:
    """saving -> failed (keeps the EBMS key so a retry finds what a timed-out call made).
    payload (optional) replaces the stored payload (e.g. new records this attempt kept)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saving":
            raise StatusConflict("This draft is no longer being saved.", d)
        conn.execute("UPDATE drafts SET status = 'failed', card = COALESCE(?, card), payload = COALESCE(?, payload),"
                     " updated_at = ? WHERE id = ?", (_dumps(card), _dumps(payload), _now(), pid))
        _audit(conn, username=u, schema=s, draft_id=pid, action="save_failed", type_=d["type"],
               before=before, request_id=request_id, response_id=response_id, detail=detail,
               api_user=api_user)
        return _load(conn, u, s, pid)


def release_save(username: str, schema: str, draft_id, *, card: dict | None = None, path=None) -> dict:
    """saving -> draft without calling EBMS (a check turned block at save time). The cycle's
    EBMS key is kept: if an earlier attempt of this cycle timed out, the next save must still
    look that document up first; a key that was never sent is harmless (the lookup finds
    nothing and the create goes ahead)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saving":
            return d
        conn.execute("UPDATE drafts SET status = 'draft', card = COALESCE(?, card), updated_at = ? WHERE id = ?",
                     (_dumps(card), _now(), pid))
        return _load(conn, u, s, pid)


def mark_undone(username: str, schema: str, draft_id, *, card: dict | None, before=None,
                request_id=None, response_id=None, detail=None, api_user=None, payload: dict | None = None,
                path=None) -> dict:
    """saved -> draft, with the 'undone' audit row. Clears the doc number and the cycle's EBMS key.
    payload (optional) replaces the stored payload (e.g. records the undo removed or kept)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    with _Tx(path) as conn:
        d = _load(conn, u, s, pid)
        if d["status"] != "saved":
            raise StatusConflict("Only a saved draft can be undone.", d)
        conn.execute(
            "UPDATE drafts SET status = 'draft', ebms_doc_number = NULL, ebms_doc_id = NULL,"
            " idempotency_key = NULL, cycle = cycle + 1, saved_by = NULL, saved_at = NULL, card = COALESCE(?, card),"
            " payload = COALESCE(?, payload), updated_at = ? WHERE id = ?",
            (_dumps(card), _dumps(payload), _now(), pid),
        )
        _audit(conn, username=u, schema=s, draft_id=pid, action="undone", type_=d["type"],
               doc_number=d["ebms_doc_number"], before=before, after=None,
               request_id=request_id, response_id=response_id, detail=detail, api_user=api_user)
        return _load(conn, u, s, pid)


# ---------------------------------------------------------------------------
# Uploaded documents (bills, 86e3q4zeb)
# ---------------------------------------------------------------------------

def get_document(username: str, schema: str, draft_id, *, path=None) -> dict:
    """The stored upload for this user's draft: {filename, content_type, size, sha256, pages,
    data, created_at}. DraftNotFound when the draft isn't theirs, has no document, or the
    document was purged (older than DOCUMENT_RETENTION_DAYS)."""
    u, s = _owner(username, schema)
    pid = _pid(draft_id)
    conn = _connect(path)
    try:
        row = conn.execute(
            "SELECT filename, content_type, size, sha256, pages, data, created_at FROM documents"
            " WHERE draft_id = ? AND username = ? AND schema = ?", (pid, u, s)).fetchone()
    finally:
        conn.close()
    if row is None:
        raise DraftNotFound()
    d = dict(row)
    d["data"] = bytes(d["data"])
    return d


def retention_days(schema: str, *, path=None) -> int:
    """How long this dataset keeps uploads (company setting, default DOCUMENT_RETENTION_DAYS)."""
    try:
        return int(get_company_settings(schema, path=path)["document_retention_days"])
    except (ValueError, KeyError):
        return DOCUMENT_RETENTION_DAYS


def purge_documents(*, days: int | None = None, path=None) -> int:
    """Delete uploads older than `days` (any user), or, when days is None, older than each
    dataset's own retention setting. Returns how many went. Audit is untouched."""
    def cutoff(d):
        return (datetime.now(timezone.utc) - timedelta(days=d)).isoformat(timespec="microseconds")
    if days is not None:
        with _Tx(path) as conn:
            return conn.execute("DELETE FROM documents WHERE created_at < ?", (cutoff(days),)).rowcount
    conn = _connect(path)
    try:
        schemas = [r["schema"] for r in conn.execute("SELECT DISTINCT schema FROM documents").fetchall()]
    finally:
        conn.close()
    gone = 0
    for sch in schemas:
        keep = retention_days(sch, path=path)
        with _Tx(path) as conn:
            gone += conn.execute("DELETE FROM documents WHERE schema = ? AND created_at < ?",
                                 (sch, cutoff(keep))).rowcount
    return gone


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------

def record_audit(username: str, schema: str, draft_id, action: str, type_: str | None, *,
                 doc_number=None, before=None, after=None, request_id=None, response_id=None,
                 detail=None, api_user=None, path=None) -> int:
    """Append one audit row on its own (e.g. undo_failed). Returns its id."""
    u, s = _owner(username, schema)
    with _Tx(path) as conn:
        return _audit(conn, username=u, schema=s, draft_id=draft_id, action=action, type_=type_,
                      doc_number=doc_number, before=before, after=after, request_id=request_id,
                      response_id=response_id, detail=detail, api_user=api_user)


def list_audit(schema: str, *, actions=None, types=None, limit: int = 200, path=None) -> list[dict]:
    """Audit rows for this dataset (every user), newest first. before/after decoded."""
    s = _norm_schema(schema)
    if not s:
        raise ValueError("A dataset is required.")
    where, args = ["schema = ?"], [s]
    if actions:
        where.append(f"action IN ({','.join('?' for _ in actions)})")
        args.extend(actions)
    if types:
        where.append(f"type IN ({','.join('?' for _ in types)})")
        args.extend(types)
    conn = _connect(path)
    try:
        rows = conn.execute(
            f"SELECT * FROM audit WHERE {' AND '.join(where)} ORDER BY id DESC LIMIT ?",
            (*args, max(1, min(int(limit), 1000))),
        ).fetchall()
    finally:
        conn.close()
    out = []
    for r in rows:
        d = dict(r)
        d["before"] = json.loads(d["before"]) if d.get("before") else None
        d["after"] = json.loads(d["after"]) if d.get("after") else None
        out.append(d)
    return out


# ---------------------------------------------------------------------------
# Settings. Per user and dataset (Settings > Data entry / Display) and per dataset for the
# whole company (Settings > Company, EBMS Administrators only; every change is audited).
# A value is on/off (default bool) or one of a fixed list (default str, CHOICES). server.py
# owns the labels and which server switches may still force a feature off.
# ---------------------------------------------------------------------------

USER_SETTINGS = {
    "bill_po_match": True,     # offer to save a bill on the open PO it matches (research K.6)
    "new_records": True,       # offer to create a missing customer, vendor or part
    "auto_refresh": "15",      # dashboard refresh, minutes ("off" = never)
    "theme": "dark",
    "hide_sql": False,
}
COMPANY_SETTINGS = {
    "bill_writes": True,
    "so_writes": True,
    "new_party_records": True,     # new customers and vendors (parts are always allowed)
    "bill_po_match": True,
    "old_invoice_days": "90",
    "document_retention_days": "30",
}
CHOICES = {
    "auto_refresh": ("off", "5", "15", "30"),
    "theme": ("dark", "light"),
    "old_invoice_days": ("30", "60", "90", "180", "365"),
    "document_retention_days": ("7", "14", "30", "60", "90"),
}


def _encode(defaults: dict, key: str, value) -> str:
    if key not in defaults:
        raise ValueError("Unknown setting.")
    if isinstance(defaults[key], bool):
        if not isinstance(value, bool):
            raise ValueError("That setting is on or off.")
        return "1" if value else "0"
    v = str(value).strip().lower() if isinstance(value, (str, int)) and not isinstance(value, bool) else None
    if v not in CHOICES[key]:
        raise ValueError("Pick one of: " + ", ".join(CHOICES[key]) + ".")
    return v


def _decoded(defaults: dict, rows) -> dict:
    out = dict(defaults)
    for r in rows:
        k, v = r["key"], r["value"]
        if k not in defaults:
            continue
        if isinstance(defaults[k], bool):
            out[k] = v == "1"
        elif v in CHOICES[k]:
            out[k] = v
    return out


def get_settings(username: str, schema: str, *, path=None) -> dict:
    """{key: value} for every user setting: the stored choice, else the default."""
    u, s = _owner(username, schema)
    conn = _connect(path)
    try:
        rows = conn.execute("SELECT key, value FROM user_settings WHERE username = ? AND schema = ?",
                            (u, s)).fetchall()
    finally:
        conn.close()
    return _decoded(USER_SETTINGS, rows)


def saved_setting_keys(username: str, schema: str, *, path=None) -> list[str]:
    """The user settings this user has actually chosen (the rest are defaults)."""
    u, s = _owner(username, schema)
    conn = _connect(path)
    try:
        return sorted(r["key"] for r in conn.execute(
            "SELECT key FROM user_settings WHERE username = ? AND schema = ?", (u, s)).fetchall())
    finally:
        conn.close()


def set_setting(username: str, schema: str, key: str, value, *, path=None) -> dict:
    """Save one user setting and return them all. ValueError (safe to show) on a bad key/value."""
    u, s = _owner(username, schema)
    enc = _encode(USER_SETTINGS, key, value)
    conn = _connect(path)
    try:
        conn.execute(
            "INSERT INTO user_settings (username, schema, key, value, updated_at) VALUES (?, ?, ?, ?, ?)"
            " ON CONFLICT(username, schema, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at",
            (u, s, key, enc, _now()))
    finally:
        conn.close()
    return get_settings(username, schema, path=path)


def get_company_settings(schema: str, *, path=None) -> dict:
    s = _norm_schema(schema)
    if not s:
        return dict(COMPANY_SETTINGS)
    conn = _connect(path)
    try:
        rows = conn.execute("SELECT key, value FROM company_settings WHERE schema = ?", (s,)).fetchall()
    finally:
        conn.close()
    return _decoded(COMPANY_SETTINGS, rows)


def set_company_setting(username: str, schema: str, key: str, value, *, path=None) -> dict:
    """Save one company setting and append a 'setting_changed' audit row in the same
    transaction (before/after = {key: value}). Returns all company settings."""
    u, s = _owner(username, schema)
    enc = _encode(COMPANY_SETTINGS, key, value)
    before = get_company_settings(s, path=path)[key]
    with _Tx(path) as conn:
        conn.execute(
            "INSERT INTO company_settings (schema, key, value, updated_at, updated_by) VALUES (?, ?, ?, ?, ?)"
            " ON CONFLICT(schema, key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at,"
            " updated_by = excluded.updated_by",
            (s, key, enc, _now(), u))
        after = _decoded(COMPANY_SETTINGS, [{"key": key, "value": enc}])[key]
        _audit(conn, username=u, schema=s, draft_id=None, action="setting_changed", type_="setting",
               before={key: before}, after={key: after})
    return get_company_settings(s, path=path)
