"""Pinned answers: storage and execution planning for v3 Phase 3 (ClickUp 86e3q4zb3).

Spec: docs/design/intramind-redesign-spec.md, section 5 "Phase 3: Pins" and section 8.3.

This module is deliberately pure: no FastAPI, no psycopg, no EBMS connection, and it does
NOT import server.py (importing server.py loads .env, builds the app and the logging
handlers). It owns IntraMind's own pin store (a SQLite file, never EBMS's Postgres) plus the
helpers the routes need. The routes themselves live in server.py.

STORAGE
  File: EBMS_LIVE_PINS_DB if set, else C:\\ProgramData\\IntraMind\\pins.sqlite3 when that
  directory exists (production, the same DATA_DIR install.ps1 creates and server.py's
  _STATS_PATHS / _ADMIN_ACTION_PATHS prefer), else <this file's dir>/pins.sqlite3 (dev only:
  update.ps1 swaps the whole install directory on every update, so a pin file stored next to
  the code would be lost; production always has ProgramData).
  One connection per call (safe under uvicorn's threadpool), WAL, 5 s busy timeout,
  PRAGMA user_version = SCHEMA_VERSION for later migrations.

USERNAME NORMALISATION
  server.py login() stores req.username.strip().upper() in the session ("username" key,
  server.py ~line 4481/4526), and get_user_permissions() matches USERS."NAME" with that exact
  value. This module applies the same .strip().upper() to every username it reads or writes,
  so " jsmith " and "JSMITH" are the same owner. Schema is compared exactly (cb2pg schema
  names like "company:legacy" are case-sensitive in Postgres), only whitespace-trimmed.
  Every tier signs in with named EBMS users (1dfk76vpaby), so pins are per person on free installs
  too; before that change, free installs shared the INTRAMIND login and so one set of pins.

WIRING NOTES FOR server.py (line numbers as of 2026-10-14, dev @ 8b26c88)
  Session keys: sess["username"] (normalised upper), sess.get("schema") or _default_schema()
  (line ~3409), sess["permissions"] (re-read from USERS on every request by verify_session,
  line ~3367, so a revoked module is enforced on the very next pin refresh).

  Dependency pattern (same as /kpis line ~4796, /charts ~5335): rate limit BEFORE session so an
  unauthenticated flood is throttled before verify_session's per-request DB hit:
      def pins(request: Request, *, _rl: None = Depends(_dashboard_rate_limit_dependency),
               sess: dict = Depends(verify_session)): ...
  (_dashboard_rate_limit_dependency line ~437. Consider check_rate_limit's stricter /query
  bucket via _root_rate_limit_dependency for POST /pins, since it runs a query.)

  Running a pin's SQL with the /query guardrails, without any model call:
    1. sql = fix_schema_quoting(sql)                                    (line ~3430)
    2. _validate_generated_sql(sql, schema, sess["permissions"], label)  (line ~5938)
       It is the full /query validator: foreign-schema check, SELECT/WITH anchor,
       _has_multiple_statements, dollar-quote guard, write keywords, _has_select_into_ddl,
       _reject_name_consumers, enforce_permissions (line ~3279) on the literal/comment-
       stripped SQL, and the fail-closed "scanner could not normalise" reject. Raises
       HTTPException(400/403). Re-run on EVERY execution, not only at save time.
       Do NOT call _finalize_generated_sql (line ~7037): its fan-out / PAR_TIME retries call
       the model, and the spec says refresh never calls the model. The pinned SQL already
       passed _finalize_generated_sql when /query produced it.
    3. exec_sql = _bump_trailing_limit(sql, MAX_ROWS) (line ~3189); with get_conn() (line
       ~3396: read-only transaction + statement_timeout=SQL_TIMEOUT) run cur.execute(exec_sql)
       and rows = [dict(r) for r in cur.fetchmany(MAX_ROWS + 1)][:MAX_ROWS] (MAX_ROWS line 290).
       No column-HINT / KNOWN_OPTIONAL_COLUMNS / self-correction retries: a failing pin
       reports failure.
    4. rows = _jsonable_rows(rows) (line ~4228: json default=str, Decimals and dates become
       strings, exactly what /query returns).
    5. return pins_store.build_pin_result(pin, rows, len(rows), None)
    Error mapping: HTTPException from step 2 -> build_pin_result(pin, None, None, e.detail);
    psycopg.Error -> log it (log.error + _sql_for_log), build_pin_result(..., "Couldn't
    refresh this pin."). Never echo raw Postgres text to the browser.

  GET /pins
      schema = sess.get("schema") or _default_schema()
      return {"pins": [run_pin(p) for p in pins_store.list_pins(sess["username"], schema)],
              "limit": pins_store.pin_limit()}
      (Run pins sequentially, or in a small ThreadPoolExecutor; each opens its own get_conn.)

  POST /pins  body {label, question, sql, headline: {column, format}}
      try: data = pins_store.validate_pin_input(label, question, sql, headline)
      except ValueError as e: 400 detail=str(e)
      run the pin once exactly as above (steps 1-4) with data["sql"];
      if it errored (HTTPException or psycopg.Error) -> 400 "This answer can't be pinned: ...",
      do NOT save; if data["headline_column"] not in rows[0] -> 400, do NOT save.
      try: pin = pins_store.add_pin(sess["username"], schema, **data,
                                     limit=pins_store.pin_limit())
      except pins_store.PinLimitReached as e: 409 detail=str(e)
      return build_pin_result(pin, rows, len(rows), None)   # fixed_period drives the UI warning
      Save the SQL that actually ran (after fix_schema_quoting).

  DELETE /pins/{pin_id}
      if not pins_store.delete_pin(sess["username"], schema, pin_id): 404 "Pin not found."
      return {"deleted": pin_id}
      (404 for "not yours" too, so pin ids from other users are not probeable.)

  logout() in ui.html must clear the pin state (spec section 2).
"""

from __future__ import annotations

import os
import re
import sqlite3
import threading
from datetime import datetime, timezone
from pathlib import Path

SCHEMA_VERSION = 1
DEFAULT_PIN_LIMIT = 4
MIN_PIN_LIMIT = 1
MAX_PIN_LIMIT = 12
BUSY_TIMEOUT_SECONDS = 5.0

HEADLINE_FORMATS = frozenset({"money", "days", "percent", "count", "number"})
LABEL_MAX = 60
QUESTION_MAX = 1000
SQL_MAX = 20000
COLUMN_MAX = 128

MISSING_COLUMN_ERROR = "The pinned column is no longer in the result"

_DB_PATHS = [
    Path(r"C:\ProgramData\IntraMind\pins.sqlite3"),
    Path(__file__).parent / "pins.sqlite3",
]

_init_lock = threading.Lock()


class PinLimitReached(Exception):
    """The user already has `limit` pins for this dataset."""

    def __init__(self, limit: int):
        self.limit = limit
        super().__init__(f"You can pin up to {limit} answers. Unpin one to add another.")


# ---------------------------------------------------------------------------
# Paths, connections, schema
# ---------------------------------------------------------------------------

def db_path(override: str | os.PathLike | None = None) -> Path:
    """Explicit argument > EBMS_LIVE_PINS_DB > ProgramData (if the dir exists) > next to this file."""
    if override:
        return Path(override)
    env = os.getenv("EBMS_LIVE_PINS_DB")
    if env:
        return Path(env)
    # os.name guard: on Linux/macOS a backslash path has no separators, so its parent is "." and
    # server.py's identical loop picks it (a file literally named "C:\ProgramData\..." in cwd).
    for p in _DB_PATHS if os.name == "nt" else _DB_PATHS[1:]:
        try:
            if p.parent.exists():
                return p
        except OSError:
            pass
    return _DB_PATHS[-1]


def _ensure_schema(conn: sqlite3.Connection) -> None:
    version = conn.execute("PRAGMA user_version").fetchone()[0]
    if version >= SCHEMA_VERSION:
        return
    conn.execute("BEGIN IMMEDIATE")
    try:
        conn.execute(
            """CREATE TABLE IF NOT EXISTS pins (
                   id INTEGER PRIMARY KEY,
                   username TEXT NOT NULL,
                   schema TEXT NOT NULL,
                   label TEXT NOT NULL,
                   question TEXT NOT NULL,
                   sql TEXT NOT NULL,
                   headline_column TEXT NOT NULL,
                   headline_format TEXT NOT NULL,
                   created_at TEXT NOT NULL
               )"""
        )
        conn.execute("CREATE INDEX IF NOT EXISTS pins_owner ON pins (username, schema)")
        conn.execute(f"PRAGMA user_version = {SCHEMA_VERSION}")
        conn.execute("COMMIT")
    except BaseException:
        conn.execute("ROLLBACK")
        raise


def _connect(path: str | os.PathLike | None = None) -> sqlite3.Connection:
    """One connection per call. isolation_level=None: transactions are explicit (BEGIN IMMEDIATE)."""
    p = db_path(path)
    conn = sqlite3.connect(str(p), timeout=BUSY_TIMEOUT_SECONDS, isolation_level=None)
    try:
        conn.row_factory = sqlite3.Row
        conn.execute(f"PRAGMA busy_timeout = {int(BUSY_TIMEOUT_SECONDS * 1000)}")
        # Checked on every connect (one cheap pragma) rather than cached per process, so a pin
        # file deleted while the service runs is recreated instead of failing every call.
        if conn.execute("PRAGMA user_version").fetchone()[0] < SCHEMA_VERSION:
            with _init_lock:
                conn.execute("PRAGMA journal_mode = WAL")  # persistent once set on the file
                _ensure_schema(conn)
    except BaseException:
        conn.close()
        raise
    return conn


def _norm_user(username: str) -> str:
    return (username or "").strip().upper()


def _norm_schema(schema: str) -> str:
    return (schema or "").strip()


def _owner(username: str, schema: str) -> tuple[str, str]:
    u, s = _norm_user(username), _norm_schema(schema)
    if not u or not s:
        raise ValueError("A pin needs a signed-in user and a dataset.")
    return u, s


# ---------------------------------------------------------------------------
# API
# ---------------------------------------------------------------------------

def pin_limit() -> int:
    """EBMS_LIVE_PIN_LIMIT (default 4), clamped to 1..12; an unparseable value means 4."""
    raw = os.getenv("EBMS_LIVE_PIN_LIMIT")
    if raw is None or not raw.strip():
        return DEFAULT_PIN_LIMIT
    try:
        value = int(raw.strip())
    except ValueError:
        return DEFAULT_PIN_LIMIT
    return max(MIN_PIN_LIMIT, min(MAX_PIN_LIMIT, value))


def list_pins(username: str, schema: str, *, path=None) -> list[dict]:
    """This user's pins for this dataset, oldest first. Includes `sql` (server-side use only)."""
    u, s = _owner(username, schema)
    conn = _connect(path)
    try:
        rows = conn.execute(
            "SELECT * FROM pins WHERE username = ? AND schema = ? ORDER BY created_at, id", (u, s)
        ).fetchall()
    finally:
        conn.close()
    return [dict(r) for r in rows]


def add_pin(username: str, schema: str, label: str, question: str, sql: str,
            headline_column: str, headline_format: str, limit: int, *, path=None) -> dict:
    """Insert a pin and return its row. Raises PinLimitReached when the user already has
    `limit` pins for this dataset (count + insert under BEGIN IMMEDIATE, so concurrent adds
    can never overshoot), ValueError on invalid input."""
    u, s = _owner(username, schema)
    data = validate_pin_input(label, question, sql, {"column": headline_column, "format": headline_format})
    limit = int(limit)
    if limit < 1:
        raise PinLimitReached(limit)
    created = datetime.now(timezone.utc).isoformat(timespec="microseconds")
    conn = _connect(path)
    try:
        conn.execute("BEGIN IMMEDIATE")
        try:
            (count,) = conn.execute(
                "SELECT COUNT(*) FROM pins WHERE username = ? AND schema = ?", (u, s)
            ).fetchone()
            if count >= limit:
                raise PinLimitReached(limit)
            cur = conn.execute(
                "INSERT INTO pins (username, schema, label, question, sql, headline_column,"
                " headline_format, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (u, s, data["label"], data["question"], data["sql"], data["headline_column"],
                 data["headline_format"], created),
            )
            pin_id = cur.lastrowid
            conn.execute("COMMIT")
        except BaseException:
            conn.execute("ROLLBACK")
            raise
        row = conn.execute("SELECT * FROM pins WHERE id = ?", (pin_id,)).fetchone()
    finally:
        conn.close()
    return dict(row)


def delete_pin(username: str, schema: str, pin_id, *, path=None) -> bool:
    """Delete one of this user's pins for this dataset. False if it doesn't exist or isn't theirs."""
    u, s = _owner(username, schema)
    try:
        pid = int(pin_id)
    except (TypeError, ValueError):
        return False
    conn = _connect(path)
    try:
        cur = conn.execute("DELETE FROM pins WHERE id = ? AND username = ? AND schema = ?", (pid, u, s))
        return cur.rowcount == 1
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------

def _text(value, name: str, max_len: int) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{name} is required.")
    value = value.strip()
    if not value:
        raise ValueError(f"{name} is required.")
    if len(value) > max_len:
        raise ValueError(f"{name} must be {max_len} characters or fewer.")
    return value


def validate_pin_input(label, question, sql, headline) -> dict:
    """Normalise POST /pins input. Returns {label, question, sql, headline_column,
    headline_format}; raises ValueError with a message safe to show the user."""
    out = {
        "label": _text(label, "Label", LABEL_MAX),
        "question": _text(question, "Question", QUESTION_MAX),
        "sql": _text(sql, "Query", SQL_MAX),
    }
    if not isinstance(headline, dict):
        raise ValueError("Pick which value to show on the pin.")
    out["headline_column"] = _text(headline.get("column"), "Headline column", COLUMN_MAX)
    fmt = headline.get("format")
    fmt = fmt.strip().lower() if isinstance(fmt, str) else fmt
    if fmt not in HEADLINE_FORMATS:
        raise ValueError("Headline format must be one of: " + ", ".join(sorted(HEADLINE_FORMATS)) + ".")
    out["headline_format"] = fmt
    return out


# ---------------------------------------------------------------------------
# Fixed-period detection (spec 8.3 / Phase 3: "this pin will always show that period")
# ---------------------------------------------------------------------------

# EBMS's FoxPro empty-date sentinel, used in null-date guards everywhere. Not a period.
_NULL_DATE_SENTINEL = "1899-12-30"

_ISO_DATE_LITERAL_RE = re.compile(
    r"^\s*(\d{4})-(\d{2})-(\d{2})"
    r"(?:[ T]\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?(?:\s*(?:Z|[+-]\d{2}(?::?\d{2})?))?)?\s*$"
)
_FIXED_YEAR_RE = re.compile(
    r"(?:\bEXTRACT\s*\(\s*YEAR\s+FROM\b[^()]*(?:\([^()]*\)[^()]*)*\)"
    r"|\bDATE_PART\s*\(\s*'year'\s*,[^()]*(?:\([^()]*\)[^()]*)*\))"
    r"\s*(?:=|<>|!=|<=|>=|<|>|\bIN\s*\(|\bBETWEEN\b)\s*(?:19|20)\d{2}\b",
    re.IGNORECASE,
)
_MAKE_DATE_RE = re.compile(r"\bMAKE_(?:DATE|TIMESTAMP)\s*\(\s*(?:19|20)\d{2}\b", re.IGNORECASE)


def _literals_without_comments(sql: str) -> tuple[str, list[str]]:
    """Scan once, like server.py's _strip_sql_literals_and_comments(): drop '--' and nesting
    /* */ comments, pass "identifiers" through untouched, and collect every single-quoted
    literal's content ('' unescaped). Returns (sql with comments blanked, literal contents).
    An unterminated literal/comment ends the scan (this is a UI hint, not a safety check)."""
    out: list[str] = []
    literals: list[str] = []
    i, n = 0, len(sql)
    while i < n:
        if sql.startswith("--", i):
            j = sql.find("\n", i)
            i = j if j != -1 else n
            out.append(" ")
            continue
        if sql.startswith("/*", i):
            depth, j = 1, i + 2
            while j < n and depth > 0:
                if sql.startswith("/*", j):
                    depth, j = depth + 1, j + 2
                elif sql.startswith("*/", j):
                    depth, j = depth - 1, j + 2
                else:
                    j += 1
            out.append(" ")
            i = j
            continue
        ch = sql[i]
        if ch == '"':
            j = i + 1
            while j < n:
                if sql[j] == '"':
                    if j + 1 < n and sql[j + 1] == '"':
                        j += 2
                        continue
                    j += 1
                    break
                j += 1
            out.append(sql[i:j])
            i = j
            continue
        if ch == "'":
            j, buf = i + 1, []
            while j < n:
                if sql[j] == "'":
                    if j + 1 < n and sql[j + 1] == "'":
                        buf.append("'")
                        j += 2
                        continue
                    j += 1
                    break
                buf.append(sql[j])
                j += 1
            literals.append("".join(buf))
            out.append(sql[i:j])
            i = j
            continue
        out.append(ch)
        i += 1
    return "".join(out), literals


def has_fixed_period(sql: str) -> bool:
    """True when the SQL pins a calendar period with a literal: an ISO date or timestamp string
    ('2026-09-01', DATE '2026-09-01', '2026-09-01 00:00'), EXTRACT(YEAR ...)/date_part('year', ...)
    compared to a 4-digit year, or make_date(2026, ...). Ignores the EBMS null-date sentinel
    '1899-12-30', anything inside comments, INTERVAL '30 days' and CURRENT_DATE-relative SQL."""
    if not sql:
        return False
    no_comments, literals = _literals_without_comments(sql)
    for lit in literals:
        m = _ISO_DATE_LITERAL_RE.match(lit)
        if m and f"{m.group(1)}-{m.group(2)}-{m.group(3)}" != _NULL_DATE_SENTINEL:
            return True
    return bool(_FIXED_YEAR_RE.search(no_comments) or _MAKE_DATE_RE.search(no_comments))


# ---------------------------------------------------------------------------
# API shape
# ---------------------------------------------------------------------------

def build_pin_result(pin_row: dict, rows: list[dict] | None, row_count: int | None,
                     error: str | None) -> dict:
    """Shape one pin for the API. Never includes the SQL. status is 'ok' only when the query ran
    and the headline column is present in the first row; a pin that ran but returned zero rows
    is 'ok' with row=None and row_count=0 (the UI shows "No results", not a blank value)."""
    column = pin_row["headline_column"]
    result = {
        "id": pin_row["id"],
        "label": pin_row["label"],
        "question": pin_row["question"],
        "headline": {"column": column, "format": pin_row["headline_format"]},
        "status": "ok",
        "row": None,
        "row_count": None,
        "fixed_period": has_fixed_period(pin_row.get("sql") or ""),
        "error": None,
    }
    if error:
        result["status"] = "error"
        result["error"] = str(error)[:300]
        return result
    rows = rows or []
    result["row_count"] = int(row_count) if row_count is not None else len(rows)
    if rows:
        first = rows[0]
        if column not in first:
            result["status"] = "error"
            result["error"] = MISSING_COLUMN_ERROR
            return result
        result["row"] = dict(first)
    return result
