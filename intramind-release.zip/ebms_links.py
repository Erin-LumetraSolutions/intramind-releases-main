"""EBMS deep links (86e1x1xkr): references to EBMS records that the UI turns into links.

The server builds every reference from data it read from EBMS or got back from the API, never
from model text, so a link can't point at a record that was only guessed. The UI decides the
URL format (EBMS help "Hyperlink to EBMS Documents": EBMS:<FILE>?<key>, or the Eagle redirector),
so a format change after testing touches ui.html only.

A reference is {"file": "APINV", "key": "STIHL|PO#4634", "autoid": "663CBR9O8B4OB000"}:
- key: the document key from the EBMS help table, multi-part keys joined with "|".
- autoid: the record's AUTOID when known. EBMS's own scripts link by it (ebms:task?autoid=...),
  and it survives what the key doesn't: a PO's key INVOICE "PO#<n>" changes to the vendor's
  invoice number once a bill is entered on it (gateway research K.1).
"""

import re

# EBMS help table (file names the hyperlink format accepts), only the ones IntraMind links to
FILES = frozenset({"ARINV", "APINV", "ARCUST", "APVENDOR", "INVENTRY", "ARQT", "JCJB",
                   "GLJRN", "GLEDGER", "PYEMP", "PYTM"})

KEY_PART_MAX = 40
# Printable, no "|" (the key separator) and no control characters. Spaces inside an ID are
# allowed (EBMS IDs can have them); the UI URL-encodes the whole key.
_KEY_PART = re.compile(r"[^\x00-\x1f\x7f|]+")
_AUTOID = re.compile(r"[A-Za-z0-9]{1,32}")


def _part(value) -> str | None:
    s = str(value if value is not None else "").strip()
    if not s or len(s) > KEY_PART_MAX or not _KEY_PART.fullmatch(s):
        return None
    return s


def ref(file: str, *parts, autoid=None) -> dict | None:
    """A reference to one EBMS record, or None when the key isn't usable (so no link is shown).

    Every key part must be present and clean; a bad AUTOID is dropped rather than failing the
    whole reference, since the key alone still opens the record."""
    f = str(file or "").upper()
    if f not in FILES or not parts:
        return None
    clean = [_part(p) for p in parts]
    if any(p is None for p in clean):
        return None
    out = {"file": f, "key": "|".join(clean)}
    a = str(autoid or "").strip()
    if a and _AUTOID.fullmatch(a):
        out["autoid"] = a
    return out


def po_ref(vendor, po_number, autoid=None) -> dict | None:
    """An unprocessed purchase order: APINV keyed vendor | "PO#<PO_NO>" (research K.1)."""
    n = str(po_number or "").strip()
    if n.upper().startswith("PO#"):
        n = n[3:]
    return ref("APINV", vendor, f"PO#{n}" if n else "", autoid=autoid)


def bill_ref(vendor, invoice, autoid=None) -> dict | None:
    return ref("APINV", vendor, invoice, autoid=autoid)


def saved_ref(type_: str, summary: dict, doc_number, doc_id=None) -> dict | None:
    """The document a saved draft created in EBMS, from the draft's summary and save result."""
    summary = summary or {}
    if type_ == "po":
        return po_ref(summary.get("vendor"), doc_number, doc_id)
    if type_ == "bill":
        return bill_ref(summary.get("vendor"), doc_number, doc_id)
    if type_ == "so":
        return ref("ARINV", doc_number, autoid=doc_id)
    return None
