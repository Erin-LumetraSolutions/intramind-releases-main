"""Sales-order drafts: payload, read-only EBMS lookups, and the card (ClickUp 86e3q4ze8).

Contract: docs/design/v3-drafts-contract.md ("Sales order"). Sources: the Create menu (empty
draft), plain English via /drafts/from-text ("sales order for Trucktex: 4 HF-2201"), and a
customer's purchase order dropped as a PDF or photo (bill_document.extract_document, kind
customer_order). Every value from a document is tagged "From PDF" until edited.

Pure, like drafts_po.py / drafts_bill.py: no FastAPI, no psycopg, does not import server.py.
Every lookup is one parameterised SELECT through the `query` server.py supplies
(enforce_permissions, read-only transaction, statement timeout). Nothing here writes.

WHAT A SALES ORDER IS IN EBMS (research C1, K.2 rows 4-6)
  An unprocessed ARINV (STATUS 'U'). EBMS auto-numbers INVOICE, prices each line from the
  customer's price level and taxes it; TOTAL stays 0 on an order (it follows the shipped qty)
  and TOTAL_SO is the order total. IntraMind sends no UNIT unless the user overrode the price,
  and M_SHIP_VIS 0 (nothing shipped). Invoicing and processing happen in EBMS.

RULES DOCUMENTED HERE
  Customer: exact ID first; then active customers by name (L_NAME / F_NAME / ID ILIKE); one hit
    -> matched (warn); several -> the one whose normalised name (drafts_bill.norm_name) equals
    the printed name if exactly one does; none -> the normalised core name. Still none -> a NEW
    customer block when the user may add customers (drafts_masters), else a block. Several ->
    "Pick the customer".
  Lines: 1. our part number (printed as ours) = an INVENTRY ID; 2. the customer's part number =
    an INVENTRY ID (EBMS has no customer part-number cross reference table in the schema, so
    there is nothing else to look it up in); 3. the description (or typed text) -> exactly one
    active part (ILIKE), fuzzy, so it warns; 4. no match at all -> a NEW part block when the
    user may add parts, else a block. Several matches -> "pick one".
  Duplicate: an ARINV for this customer whose trimmed PO_NO equals the customer PO # (any
    status) blocks.
  Past due: the shared AR past-due predicate (server.AR_PAST_DUE_PREDICATE_SQL: STATUS 'O',
    effective due date before today) summed for this customer -> warn.
  Stock: track-count parts (TRACK_COUNT_C_TYPES), warehouse-aware like the reorder rule: on
    INVENWH installs the SUM of INVENWH.COUNT, else INVENTRY.COUNT. qty above on hand -> warn
    "backordered"; all covered -> good.
  Inactive customer or part: block.
  Cross-check: no customer matched but the name matches an APVENDOR -> warn "X is a vendor in
    EBMS — is this a bill rather than an order?" (drafts_bill does the reverse for bills).
"""

from __future__ import annotations

from datetime import date

import drafts_masters as dm
import ebms_links
from drafts_bill import norm_name, _iso, _money_in, line_bases, NEW_VALUE, TAG_PDF, TAG_FOUND, TAG_OPTIONAL
from drafts_po import (PoLookups, TRACK_COUNT_C_TYPES, _plural, _short, fmt_date, fmt_money, fmt_qty,
                       vendor_display, ID_MAX, HINT_MAX, MEMO_MAX, MAX_QTY)

TYPE_TILE = "SO"
TYPE_LABEL = "Sales order"
SAVE_LABEL = "Save sales order"
NOTE = ("Saves as an unprocessed sales order. Invoice and process it in EBMS when it ships. "
        "EBMS applies the customer's prices and tax.")
UNDO_TITLE = "Deletes the sales order. Only possible while it is unprocessed and nothing is paid."
LINE_COLUMNS = [
    {"key": "item", "label": "Item"},
    {"key": "qty", "label": "Qty", "num": True},
    # The key is "cost" so the card's existing price editing works; the label says Price.
    {"key": "cost", "label": "Price", "num": True},
    {"key": "amount", "label": "Amount", "num": True},
]
SOURCES = ("menu", "text", "document")
PO_MAX = 20                # ARINV.PO_NO length (ebms_api.SO_PO_MAX)
MAX_LINES = 100
EDITABLE_FIELDS = ("customer", "customer_po", "memo")


def part_lookup(query) -> dict:
    """Picker keys for a line whose item can be edited. can_create is filled in by the card."""
    return {"lookup": "part", "query": (query or "").strip()}


def customer_display(c: dict) -> str:
    return vendor_display(c)


def _line(**kw) -> dict:
    base = {"item": "", "qty": 1.0, "price": None, "description": "", "customer_part": "", "our_part": "",
            "doc_price": None, "match": None, "new_part": None}
    base.update(kw)
    return base


# ---------------------------------------------------------------------------
# Payloads
# ---------------------------------------------------------------------------

def normalize_so_input(body: dict) -> dict:
    """POST /drafts (type so) or the from-text extraction -> the stored payload."""
    if not isinstance(body, dict):
        raise ValueError("Draft input must be an object.")
    source = body.get("source") or "menu"
    if source not in ("menu", "text"):
        raise ValueError("Unknown draft source.")
    lines_in = body.get("lines") or []
    if not isinstance(lines_in, list) or len(lines_in) > MAX_LINES:
        raise ValueError(f"A sales order can have up to {MAX_LINES} lines.")
    lines = []
    for i, ln in enumerate(lines_in, 1):
        if not isinstance(ln, dict):
            raise ValueError(f"Line {i} is not valid.")
        item = _short(ln.get("item"), f"Line {i} item", ID_MAX)
        hint = _short(ln.get("item_hint"), f"Line {i} item", HINT_MAX)
        if not item and not hint:
            raise ValueError(f"Line {i} needs an item.")
        q = _money_in(ln.get("qty", 1), f"Line {i} quantity", allow_negative=False)
        if q is None or q <= 0 or q > MAX_QTY:
            raise ValueError(f"Line {i} quantity must be more than 0.")
        row = _line(item=item, qty=q, match="user" if hint and not item else None)
        if hint and not item:
            row["item_hint"] = hint
        lines.append(row)
    payload = {"type": "so", "source": source, "customer": _short(body.get("customer"), "Customer", ID_MAX),
               "customer_po": _short(body.get("customer_po"), "Customer PO #", 60),
               "memo": _short(body.get("memo"), "Memo", MEMO_MAX), "edited": [], "lines": lines,
               "new_customer": None}
    hint = _short(body.get("customer_hint"), "Customer", HINT_MAX)
    if hint and not payload["customer"]:
        payload["customer_hint"] = hint
    return payload


def payload_from_extraction(ext: dict, document: dict | None = None) -> dict:
    """A customer's PO read from a document (bill_document kind customer_order)."""
    pdf = {k: ext.get(k) for k in ("customer_name", "customer_po_number", "order_date", "requested_date", "ship_to")}
    lines = []
    for ln in (ext.get("order_lines") or [])[:MAX_LINES]:
        qty = ln.get("quantity")
        lines.append(_line(qty=float(qty) if isinstance(qty, (int, float)) and qty > 0 else 1.0,
                           description=(ln.get("description") or "")[:200],
                           customer_part=(ln.get("customer_part_number") or "")[:HINT_MAX],
                           our_part=(ln.get("our_part_number") or "")[:HINT_MAX],
                           doc_price=ln.get("unit_price") if isinstance(ln.get("unit_price"), (int, float)) else None,
                           pdf_qty=qty))
    payload = {"type": "so", "source": "document", "pdf": pdf, "customer": "",
               "customer_po": (ext.get("customer_po_number") or "").strip()[:60], "memo": "", "edited": [],
               "lines": lines, "new_customer": None}
    own = (ext.get("our_order_number") or "").strip().lstrip("#").strip()[:20]
    if own:
        payload["our_order"] = own
        payload["memo"] = f"Order {own} (from PDF)"
    hint = (ext.get("customer_name") or "").strip()[:HINT_MAX]
    if hint:
        payload["customer_hint"] = hint
    if document:
        payload["document"] = {"name": document.get("name"), "pages": document.get("pages")}
    return payload


def apply_so_patch(payload: dict, fields, lines, options: dict | None = None) -> dict:
    """PATCH /drafts/{id} for a sales order. fields: customer, customer_po, memo and the new
    records' "new_customer.<name>" / "new_part.<line #>.<name>" keys. lines are positional
    (card order): {item | item_hint, qty, cost (= price override)}; extra lines are new parts."""
    new = dict(payload)
    edited = set(new.get("edited") or [])
    plain, groups = dm.split_new_fields(fields if isinstance(fields, dict) else {})
    if fields is not None and not isinstance(fields, dict):
        raise ValueError("Fields must be an object.")
    if set(plain) - set(EDITABLE_FIELDS):
        raise ValueError("Only the customer, customer PO #, memo and new records can be changed here.")
    if lines is not None:
        new["lines"] = _patch_lines(new.get("lines") or [], lines)
    if plain.get("customer") == NEW_VALUE:
        # "Create new" from the customer picker (server.py checks the user may add customers)
        plain = dict(plain)
        plain.pop("customer")
        name = (new.get("customer_hint") or new.get("customer_matched_from")
                or (new.get("pdf") or {}).get("customer_name") or "").strip()[:HINT_MAX]
        new.update(customer="", new_customer=None, want_new_customer=True)
        new.pop("customer_matched_from", None)
        new.pop("customer_hint", None)
        if name:
            new["customer_hint"] = name
        edited.add("customer")
    if "customer" in plain:
        v = _short(plain["customer"], "Customer", HINT_MAX)
        nc = new.get("new_customer") or {}
        if v.upper() != (new.get("customer") or "").upper() and not (nc and v.upper() == (nc.get("id") or "").upper()):
            new["customer"] = ""
            new["customer_hint"] = v
            new.pop("customer_matched_from", None)
            new.pop("want_new_customer", None)
            new["new_customer"] = None
            edited.add("customer")
            if not v:
                new.pop("customer_hint")
    if "customer_po" in plain:
        v = _short(plain["customer_po"], "Customer PO #", 60)
        if v != new.get("customer_po"):
            new["customer_po"] = v
            edited.add("customer_po")
    if "memo" in plain:
        new["memo"] = _short(plain["memo"], "Memo", MEMO_MAX)
    for prefix, values in groups.items():
        if prefix == "new_customer":
            if new.get("new_customer"):
                new["new_customer"] = dm.apply_fields("customer", new["new_customer"], values, options)
            continue
        parts = prefix.split(".")
        if len(parts) == 2 and parts[0] == "new_part" and parts[1].isdigit():
            i = int(parts[1]) - 1
            if 0 <= i < len(new["lines"]) and new["lines"][i].get("new_part"):
                ln = dict(new["lines"][i])
                ln["new_part"] = dm.apply_fields("part", ln["new_part"], values, options)
                new["lines"][i] = ln
            continue
        raise ValueError("That field can't be changed here.")
    new["edited"] = sorted(edited)
    return new


def _patch_lines(old: list[dict], lines) -> list[dict]:
    if not isinstance(lines, list):
        raise ValueError("Lines must be a list.")
    if len(lines) > MAX_LINES:
        raise ValueError(f"A sales order can have up to {MAX_LINES} lines.")
    bases = line_bases(old, lines, "sales order")
    out = []
    for i, ln in enumerate(lines, 1):
        if not isinstance(ln, dict):
            raise ValueError(f"Line {i} is not valid.")
        base = bases[i - 1] or _line(added=True)
        np = base.get("new_part") or {}
        if ln.get("item") == NEW_VALUE:
            # "Create new" from the part picker: a new-part block seeded from the line's text
            # (server.py checks the user may add parts)
            seed = base.get("item_hint") or base.get("item") or ""
            base.pop("matched_from", None)
            base.update(item="", new_part=None, match="want_new")
            if seed:
                base["item_hint"] = seed
            ln = {k: v for k, v in ln.items() if k != "item"}
        if "item_hint" in ln:
            hint = _short(ln.get("item_hint"), f"Line {i} item", HINT_MAX)
            if hint != (base.get("item_hint") or base.get("item") or ""):
                base.pop("matched_from", None)
                base.update(item="", new_part=None)
                if hint:
                    base.update(item_hint=hint, match="user")
                else:
                    base.update(match="none")
                    base.pop("item_hint", None)
        elif "item" in ln:
            item = _short(ln.get("item"), f"Line {i} item", ID_MAX)
            if np and item.upper() == (np.get("id") or "").upper():
                pass   # the card shows the new part's ID in the item column
            elif item.upper() != (base.get("item") or "").upper():
                base.pop("matched_from", None)
                base.pop("item_hint", None)
                base.update(item="", new_part=None, match="user" if item else "none")
                if item:
                    base["item_hint"] = item
        if "qty" in ln:
            q = _money_in(ln.get("qty"), f"Line {i} quantity", allow_negative=False)
            if q is None or q <= 0:
                raise ValueError(f"Line {i} quantity must be more than 0.")
            if q > MAX_QTY:
                raise ValueError(f"Line {i} quantity is too large.")
            base["qty"] = q
        if ln.get("cost") not in (None, ""):
            base["price"] = _money_in(ln.get("cost"), f"Line {i} price", allow_negative=False)
        out.append(base)
    return out


# ---------------------------------------------------------------------------
# Lookups
# ---------------------------------------------------------------------------

class SoLookups(PoLookups):
    """PoLookups (items, item_search, vendor, vendor_search) plus customers, duplicates, past
    due and stock. ar_past_due_sql: the shared predicate with {s} filled (server supplies it)."""

    def __init__(self, schema: str, query, *, has_invenwh: bool = False, ar_past_due_sql: str | None = None):
        super().__init__(schema, query)
        self.has_invenwh = has_invenwh
        self.ar_past_due_sql = ar_past_due_sql

    def duplicate_orders(self, cust_id: str, po: str) -> list[dict]:
        t = self._t("ARINV")
        return self.query(
            f'SELECT trim({t}."INVOICE") AS invoice, {t}."STATUS" AS status, trim({t}."AUTOID") AS doc_id FROM {t}'
            f' WHERE upper(trim({t}."ID")) = upper(trim(%s)) AND upper(trim({t}."PO_NO")) = upper(trim(%s))'
            f' AND {t}."__deleted" IS NOT TRUE LIMIT 5', (cust_id, po))

    def orders_by_number(self, cust_id: str, number: str) -> list[dict]:
        """This customer's EBMS documents numbered like the order (SO INVOICE is a bare number)."""
        t = self._t("ARINV")
        return self.query(
            f'SELECT trim({t}."INVOICE") AS invoice, {t}."STATUS" AS status, trim({t}."AUTOID") AS doc_id FROM {t}'
            f' WHERE upper(trim({t}."ID")) = upper(trim(%s)) AND upper(trim({t}."INVOICE")) = upper(trim(%s))'
            f' AND {t}."__deleted" IS NOT TRUE LIMIT 5', (cust_id, number))

    def past_due(self, cust_id: str) -> dict | None:
        if not self.ar_past_due_sql:
            return None
        t = self._t("ARINV")
        rows = self.query(
            f'SELECT COALESCE(SUM({t}."BALANCE"), 0) AS balance, COUNT(*) AS invoices FROM {t}'
            f' WHERE upper(trim({t}."ID")) = upper(trim(%s)) AND {self.ar_past_due_sql}', (cust_id,))
        return rows[0] if rows else None

    def on_hand(self, ids: list[str]) -> dict[str, float]:
        keys = sorted({i.strip().upper() for i in ids if i and i.strip()})
        if not keys:
            return {}
        if self.has_invenwh:
            t = self._t("INVENWH")
            rows = self.query(
                f'SELECT upper(trim({t}."ID")) AS item, SUM({t}."COUNT") AS on_hand FROM {t}'
                f' WHERE upper(trim({t}."ID")) = ANY(%s) AND {t}."__deleted" IS NOT TRUE GROUP BY 1', (keys,))
        else:
            t = self._t("INVENTRY")
            rows = self.query(
                f'SELECT upper(trim({t}."ID")) AS item, {t}."COUNT" AS on_hand FROM {t}'
                f' WHERE upper(trim({t}."ID")) = ANY(%s) AND {t}."__deleted" IS NOT TRUE', (keys,))
        return {r["item"]: float(r.get("on_hand") or 0) for r in rows}


# ---------------------------------------------------------------------------
# Resolution (creation, and after edits that clear a match)
# ---------------------------------------------------------------------------

def _match_customer(hint: str, lookups) -> tuple[list[dict], dict | None]:
    """(candidates, exact) for a customer name or ID."""
    c = lookups.customer(hint)
    if c is not None:
        return [c], c
    found = lookups.customer_search(hint)
    core = norm_name(hint)
    if not found and core and core != hint.strip().lower():
        found = lookups.customer_search(core)
    if len(found) > 1 and core:
        same = [f for f in found if norm_name(customer_display(f)) == core]
        found = same if len(same) == 1 else found
    return found, None


def resolve_so(payload: dict, lookups, *, can_create: dict | None = None) -> dict:
    """Fill the customer and the lines' items where the match is safe; offer new records where
    nothing matches and the user may add them. Never guesses between several matches."""
    can = can_create or {}
    out = dict(payload)
    hint = out.get("customer_hint")
    if out.pop("want_new_customer", None) and can.get("customer") and not out.get("new_customer"):
        name = hint or ""
        out["new_customer"] = dm.new_record(
            "customer", name=name[:50], id=dm.suggest_id(name, lambda i: lookups.record_exists("customer", i), 10),
            folder=lookups.common_folder("customer") or "")
    if hint and not out.get("customer") and not out.get("new_customer"):
        found, exact = _match_customer(hint, lookups)
        if exact is not None:
            out["customer"] = exact["id"]
            out.pop("customer_hint")
        elif len(found) == 1:
            out["customer"] = found[0]["id"]
            out["customer_matched_from"] = out.pop("customer_hint")
        elif not found and can.get("customer"):
            out["new_customer"] = dm.new_record(
                "customer", name=hint[:50],
                id=dm.suggest_id(hint, lambda i: lookups.record_exists("customer", i), 10),
                folder=lookups.common_folder("customer") or "")
    lines = [dict(ln) for ln in out.get("lines") or []]
    for ln in lines:
        if ln.get("match") == "want_new" and not ln.get("new_part"):
            if can.get("part"):
                seed = ln.get("item_hint") or ln.get("our_part") or ln.get("customer_part") or ln.get("description") or ""
                desc = ln.get("description") or ln.get("item_hint") or ""
                ln["new_part"] = dm.new_record(
                    "part", id=dm.suggest_id(seed, lambda i: lookups.record_exists("part", i), 24),
                    description=desc[:80], folder=lookups.part_folder_for(desc) or "",
                    price=ln.get("doc_price") if ln.get("doc_price") is not None else "")
                ln["match"] = "new"
            else:
                ln["match"] = "user" if ln.get("item_hint") else "none"
    todo = [ln for ln in lines if not ln.get("item") and not ln.get("new_part") and ln.get("match") in (None, "user")]
    keys = []
    for ln in todo:
        keys += [k for k in (ln.get("item_hint"), ln.get("our_part"), ln.get("customer_part")) if k]
    exact = lookups.items(keys) if keys else {}
    for ln in todo:
        hit = None
        for k in (ln.get("item_hint"), ln.get("our_part"), ln.get("customer_part")):
            if k and k.strip().upper() in exact:
                hit = exact[k.strip().upper()]
                ln["match"] = "user" if k == ln.get("item_hint") else ("our_part" if k == ln.get("our_part") else "customer_part")
                break
        if hit is not None:
            ln["item"] = hit["id"].strip()
            ln.pop("item_hint", None)
            continue
        text = (ln.get("item_hint") or ln.get("description") or "").strip()
        found = lookups.item_search(text) if len(text) >= 3 else []
        if len(found) == 1:
            ln.update(item=found[0]["id"].strip(), match="description", matched_from=text)
            ln.pop("item_hint", None)
        elif not found and can.get("part") and text:
            seed = ln.get("our_part") or ln.get("customer_part") or ln.get("item_hint") or text
            desc = ln.get("description") or ln.get("item_hint") or ""
            ln["new_part"] = dm.new_record(
                "part", id=dm.suggest_id(seed, lambda i: lookups.record_exists("part", i), 24),
                description=desc[:80], folder=lookups.part_folder_for(desc) or "",
                price=ln.get("doc_price") if ln.get("doc_price") is not None else "")
            ln["match"] = "new"
        elif not found:
            ln["match"] = "none"
        else:
            ln["match"] = "ambiguous"
    out["lines"] = lines
    return out


# ---------------------------------------------------------------------------
# The card
# ---------------------------------------------------------------------------

def build_so_card(payload: dict, lookups, *, today: date, can_create: dict | None = None,
                  options: dict | None = None) -> dict:
    """Card body plus "_api" (header, lines, new_records) when not blocking, "_summary" and
    "_undo_title". Pure given the lookups."""
    can = can_create or {}
    checks: list[dict] = []

    def check(level, text, ebms=None):
        # ebms: the EBMS record the check is about, as an ebms_links reference (86e1x1xkr)
        checks.append({"level": level, "text": text, **({"ebms": ebms} if ebms else {})})

    pdf = payload.get("pdf") or {}
    from_doc = payload.get("source") == "document"
    edited = set(payload.get("edited") or [])

    def ptag(key):
        return dict(TAG_PDF) if from_doc and key not in edited else None

    new_records, records = [], []   # records: the card's new-record blocks

    # ---- customer
    cust_id = (payload.get("customer") or "").strip()
    cust = lookups.customer(cust_id) if cust_id else None
    nc = payload.get("new_customer")
    cname = customer_display(cust) if cust else ""
    hint = payload.get("customer_hint") or ""
    cust_tag, cust_hint_text, new_fields = None, None, []
    if cust_id and cust is None:
        check("block", f"{cust_id} isn't a customer in EBMS. Pick the customer.")
        cust_hint_text = "Not found in EBMS"
    elif cust is None and nc:
        if can.get("customer"):
            cname = nc.get("name") or hint
            cust_tag = dict(dm.NEW_TAG)
            new_fields = dm.record_fields("customer", nc, "new_customer", options)
            rc = dm.record_checks("customer", nc, lookups, what="new customer")
            for lv, text in rc:
                check(lv, text)
            records.append(dm.record_meta("customer", nc, "new_customer", options, rc, field="customer"))
            new_records.append({"kind": "customer", "tag": "C", "rec": dict(nc)})
            if hint and lookups.vendor_search(hint):
                check("warn", f"{hint} is a vendor in EBMS — is this a bill rather than an order?")
        else:
            check("block", dm.blocked_text(hint or nc.get("name") or "This customer", "customer", can))
    elif cust is None:
        if hint:
            found, _ = _match_customer(hint, lookups)
            if found:
                names = ", ".join(f"{customer_display(c)} ({c['id']})" for c in found[:3])
                more = "" if len(found) <= 3 else f" and {len(found) - 3} more"
                check("block", f"Pick the customer: “{hint}” matches {_plural(len(found), 'customer')}: {names}{more}")
            elif can_create is not None and not can.get("customer"):
                check("block", dm.blocked_text(hint, "customer", can))
            else:
                check("block", f"Pick the customer: no customer in EBMS matches “{hint}”")
            vend = lookups.vendor_search(hint) if not found else []
            if vend:
                check("warn", f"{hint} is a vendor in EBMS — is this a bill rather than an order?")
            cust_hint_text = f"The order says “{hint}”" if from_doc else f"You said “{hint}”"
        else:
            check("block", "Pick a customer")
            cust_hint_text = "Customer ID or name"
    else:
        cname = cname or cust["id"]
        if cust.get("inactive") is True:
            check("block", f"{cname} is inactive in EBMS")
        if payload.get("customer_matched_from"):
            m = payload["customer_matched_from"]
            cust_tag = {"kind": "matched", "text": f"Matched “{m}”"}
            check("warn", f"Matched “{m}” to {cname} ({cust['id']}). Check it's the right customer.")
        else:
            cust_tag = dict(TAG_FOUND)
        pd = lookups.past_due(cust["id"])
        if pd and float(pd.get("balance") or 0) > 0:
            n = int(pd.get("invoices") or 0)
            check("warn", f"{cname} has {fmt_money(pd['balance'])} past due on {_plural(n, 'invoice')}")
    order_customer = cust["id"] if cust else ((nc or {}).get("id") if (nc and can.get("customer")) else "")

    # ---- customer PO
    po = (payload.get("customer_po") or "").strip()
    if len(po) > PO_MAX:
        check("block", f"Customer PO # “{po}” is longer than EBMS allows ({PO_MAX} characters). Edit it to fit.")
    elif po and cust is not None:
        dups = lookups.duplicate_orders(cust["id"], po)
        if dups:
            check("block", f"{cname} PO {po} is already in EBMS (order/invoice {dups[0].get('invoice')}). "
                           "Don't enter it twice.",
                  ebms=ebms_links.ref("ARINV", dups[0].get("invoice"), autoid=dups[0].get("doc_id")))
        else:
            check("good", f"No order for {cname} PO {po} in EBMS yet")
    # This company's own sales order (a PDF it issued): its order number may already be in EBMS
    own = (payload.get("our_order") or "").strip()
    if own and cust is not None:
        own_rows = lookups.orders_by_number(cust["id"], own)
        if own_rows:
            check("warn", f"Order {own} for {cname} is already in EBMS. Saving creates a second order; "
                          "skip it if this PDF was printed from EBMS.",
                  ebms=ebms_links.ref("ARINV", own_rows[0].get("invoice") or own, autoid=own_rows[0].get("doc_id")))
        else:
            check("good", f"No order {own} for {cname} in EBMS yet. EBMS gives the new order its own number.")

    # ---- lines
    raw_lines = payload.get("lines") or []
    ids = [ln["item"] for ln in raw_lines if ln.get("item")]
    items = lookups.items(ids) if ids else {}
    stock_ids = [i for i in ids if (items.get(i.upper()) or {}).get("c_type") is not None
                 and int(items[i.upper()]["c_type"]) in TRACK_COUNT_C_TYPES]
    on_hand = lookups.on_hand(stock_ids) if stock_ids else {}
    card_lines, api_lines = [], []
    short, priced_from_doc, total, all_priced = [], [], 0.0, bool(raw_lines)
    for i, ln in enumerate(raw_lines, 1):
        qty = float(ln.get("qty") or 0)
        price = ln.get("price")
        amount = round(qty * float(price), 2) if price is not None else None
        if amount is None:
            all_priced = False
        else:
            total += amount
        row = {"qty": fmt_qty(qty), "cost": fmt_money(price, unit=True) if price is not None else "",
               "amount": fmt_money(amount) if amount is not None else ""}
        if qty <= 0:
            check("block", f"Line {i} quantity must be more than 0")
        if ln.get("doc_price") is not None and price is None:
            priced_from_doc.append(ln)
        item_id = (ln.get("item") or "").strip()
        np = ln.get("new_part")
        if item_id:
            it = items.get(item_id.upper())
            if it is None:
                check("block", f"{item_id} isn't an item in EBMS")
                card_lines.append(dict(row, item=item_id, description="Not found in EBMS", editable=["item", "qty", "cost"],
                                       **part_lookup(item_id)))
                continue
            real = it["id"].strip()
            if it.get("inactive") is True:
                check("block", f"{real} is inactive in EBMS")
            if ln.get("match") == "description" or ln.get("matched_from"):
                check("warn", f"Matched “{ln.get('matched_from') or ln.get('description')}” to {real} "
                              f"{it.get('description') or ''}".rstrip() + ". Check it's the right part.")
            if real.upper() in on_hand and qty > on_hand[real.upper()]:
                short.append((real, qty, max(on_hand[real.upper()], 0)))
            card_lines.append(dict(row, item=real, description=it.get("description") or ln.get("description") or "",
                                   editable=["qty", "cost"], ebms=ebms_links.ref("INVENTRY", real)))
            api_lines.append({"item": real, "qty": qty, "price": price})
            continue
        if np:
            label = f"new part on line {i}"
            if can.get("part"):
                setup = lookups.folder_setup(np.get("folder"))
                new_fields += dm.record_fields("part", np, f"new_part.{i}", options, setup=setup)
                rc = dm.record_checks("part", np, lookups, what=label, setup=setup)
                for lv, text in rc:
                    check(lv, text)
                records.append(dm.record_meta("part", np, f"new_part.{i}", options, rc, setup=setup))
                new_records.append({"kind": "part", "tag": f"P{i}", "rec": dict(np), "line": i})
                card_lines.append(dict(row, item=np.get("id") or "", description="New part: " + (np.get("description") or ""),
                                       editable=["qty", "cost"], record=f"new_part.{i}"))
                api_lines.append({"item": np.get("id") or "", "qty": qty, "price": price})
            else:
                check("block", dm.blocked_text(ln.get("item_hint") or ln.get("description") or f"Line {i}'s part", "part", can))
                card_lines.append(dict(row, item=ln.get("item_hint") or "", description=ln.get("description") or "",
                                       editable=["item", "qty", "cost"],
                                       **part_lookup(ln.get("item_hint") or ln.get("customer_part") or ln.get("description"))))
            continue
        text = ln.get("item_hint") or ln.get("customer_part") or ln.get("description") or f"Line {i}"
        found = lookups.item_search(text) if len(text) >= 3 else []
        if found:
            names = ", ".join(r["id"] for r in found[:3])
            more = "" if len(found) <= 3 else f" and {len(found) - 3} more"
            check("block", f"“{text}” matches {_plural(len(found), 'part')}: {names}{more}. Pick one.")
        elif can_create is not None and not can.get("part"):
            check("block", dm.blocked_text(text, "part", can))
        else:
            check("block", f"No part in EBMS matches “{text}”")
        card_lines.append(dict(row, item=ln.get("item_hint") or ln.get("customer_part") or "",
                               description=ln.get("description") or "Not matched to a part yet",
                               editable=["item", "qty", "cost"], **part_lookup(text if text != f"Line {i}" else "")))

    if not raw_lines:
        check("block", "Add at least one part")
    for real, qty, have in short:
        back = qty - have
        check("warn", f"Only {fmt_qty(have)} of {real} in stock; {fmt_qty(back)} will be backordered")
    if stock_ids and not short:
        check("good", "Enough stock on hand for " + ("every part" if len(stock_ids) > 1 else stock_ids[0]))
    if priced_from_doc:
        ex = priced_from_doc[0]
        what = ex.get("item") or ex.get("customer_part") or ex.get("description") or "a line"
        check("warn", f"The customer's PO shows prices (e.g. {what} at {fmt_money(ex['doc_price'], unit=True)}). "
                      "EBMS applies the customer's own price; edit a price to use theirs instead.")
    if pdf.get("requested_date"):
        rd = _iso(pdf["requested_date"])
        check("warn", "The customer asks for delivery by "
              + (fmt_date(date.fromisoformat(rd)) if rd else f"“{pdf['requested_date']}”")
              + ". Set the ship date in EBMS.")
    if pdf.get("ship_to"):
        check("warn", f"The PO ships to “{pdf['ship_to']}”. Check the ship-to address in EBMS.")
    if len(new_records) > 5:
        check("block", "A draft can create at most 5 new records. Add some in EBMS first.")

    # ---- fields
    memo = payload.get("memo") or ""
    fields = [
        {"key": "customer", "label": "Customer", "value": cust["id"] if cust else cust_id,
         "display": cname or cust_id or hint, "tag": cust_tag, "editable": True, "input": "text",
         "hint": cust_hint_text, "lookup": "customer", "can_create": can.get("customer") is True,
         **({"query": hint or (pdf.get("customer_name") or "") or cust_id} if cust is None else {}),
         **({"ebms": ebms_links.ref("ARCUST", cust["id"])} if cust else {})},
    ]
    if nc and cust is None and can.get("customer"):
        fields += [f for f in new_fields if f["key"].startswith("new_customer.")]
    od = _iso(pdf.get("order_date"))
    fields += [
        {"key": "customer_po", "label": "Customer PO #", "value": po, "display": po,
         "tag": ptag("customer_po") if po else dict(TAG_OPTIONAL), "editable": True, "input": "text", "hint": None},
        {"key": "order_date", "label": "Order date", "value": today.isoformat(), "display": fmt_date(today),
         "tag": None, "editable": False, "input": "date",
         "hint": (f"The PO is dated {fmt_date(date.fromisoformat(od))}" if od else None)},
        {"key": "memo", "label": "Memo", "value": memo, "display": memo,
         "tag": None if memo else dict(TAG_OPTIONAL), "editable": True, "input": "text", "hint": None},
    ]
    fields += [f for f in new_fields if f["key"].startswith("new_part.")]

    for cl in card_lines:
        if cl.get("lookup"):
            cl["can_create"] = can.get("part") is True
    blocking = any(c["level"] == "block" for c in checks)
    n = len(raw_lines)
    total_text = fmt_money(total) if all_priced else ""
    totals = [{"label": "Total", "value": total_text or "Priced by EBMS on save"}]
    title = f"{cname or hint or 'New sales order'}" + (f", PO {po}" if po else (f", {_plural(n, 'part')}" if n else ""))
    source = payload.get("source") or "menu"
    if source == "document":
        lead = "Here is the customer's order I read from the document. Values taken from it are marked From PDF."
    elif source == "text":
        lead = "Here is a sales order from your request."
    else:
        lead = f"Here is a sales order for {cname}." if cname else "Here is a new sales order. Pick a customer and add parts."
    if blocking:
        lead += " A few things need a look before you can save it."
    return {
        "type": "so", "type_tile": TYPE_TILE, "type_label": TYPE_LABEL, "title": title, "lead": lead,
        "fields": fields, "line_columns": [dict(c) for c in LINE_COLUMNS], "lines": card_lines,
        "totals": totals, "checks": checks, "blocking": blocking, "note": NOTE, "save_label": SAVE_LABEL,
        "records": records,
        "amount": total_text, "_undo_title": UNDO_TITLE,
        "_api": None if blocking else {
            "header": {"customer": order_customer, "po_no": po, "memo": memo},
            "lines": api_lines, "new_records": new_records,
        },
        "_summary": {"customer": order_customer or cust_id, "customer_name": cname or hint, "po": po, "parts": n,
                     "total": total_text or None,
                     "new_records": [{"kind": r["kind"], "id": r["rec"].get("id")} for r in new_records],
                     "lines": [{"item": a["item"], "qty": a["qty"], "price": a["price"]} for a in api_lines]},
    }
